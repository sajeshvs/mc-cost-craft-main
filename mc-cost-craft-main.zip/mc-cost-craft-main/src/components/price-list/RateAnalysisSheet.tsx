
import React from 'react';
import { RateAnalysisSheet as NewRateAnalysisSheet } from '@/components/rate-analysis/RateAnalysisSheet';

interface RateAnalysisSheetProps {
  projectId: string;
  priceCode: string;
  currentNetRate: number;
  onClose: () => void;
  onSave: (netRate: number, splitRates: {
    labor: number;
    material: number;
    equipment: number;
    subcontractor: number;
    consultant: number;
  }) => Promise<void>;
}

export function RateAnalysisSheet(props: RateAnalysisSheetProps) {
  return <NewRateAnalysisSheet {...props} />;
}
