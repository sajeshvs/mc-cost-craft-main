
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Upload, Download, Plus, Trash2, RefreshCw, Calculator, Copy, ExpandIcon, ShrinkIcon, Shield, FileText, Database } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { doDStandardsService } from '@/services/doDStandardsService';

interface PriceListSpreadsheetToolbarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
  onAddPriceItem: () => void;
  onDeleteSelected: () => void;
  selectedCount: number;
  onRefresh: () => void;
  onImportCSV: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onExportCSV: () => void;
  onExpandAll: () => void;
  onCollapseAll: () => void;
  onCalculateTotals: () => void;
  onRecreatePrices: () => void;
  onCopyFromProject: () => void;
  onInitializeDoDStandards?: () => void;
  onExportDoDTemplate?: () => void;
  onValidateRateAnalysis?: () => void;
  projectId?: string;
}

export function PriceListSpreadsheetToolbar({
  searchTerm,
  onSearchChange,
  onAddPriceItem,
  onDeleteSelected,
  selectedCount,
  onRefresh,
  onImportCSV,
  onExportCSV,
  onExpandAll,
  onCollapseAll,
  onCalculateTotals,
  onRecreatePrices,
  onCopyFromProject,
  onInitializeDoDStandards,
  onExportDoDTemplate,
  onValidateRateAnalysis,
  projectId
}: PriceListSpreadsheetToolbarProps) {
  const { toast } = useToast();
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [isCreatingStandards, setIsCreatingStandards] = React.useState(false);

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleDoDStandardsInit = async () => {
    if (!projectId) {
      toast({
        title: 'Error',
        description: 'Project ID is required to initialize DoD standards',
        variant: 'destructive'
      });
      return;
    }

    setIsCreatingStandards(true);
    try {
      // Initialize DoD resource library
      const resourceResult = await doDStandardsService.initializeDoDStandards();
      
      // Create comprehensive UFGS price list
      await doDStandardsService.createComprehensivePriceList(projectId);
      
      toast({
        title: 'DoD Standards Initialized',
        description: `Successfully created ${resourceResult.resourceCount} DoD-standard resources and comprehensive UFGS price list per UFC 3-701-01 standards.`
      });
      
      // Refresh the data
      onRefresh();
      
    } catch (error) {
      console.error('Error initializing DoD standards:', error);
      toast({
        title: 'Error',
        description: 'Failed to initialize DoD standards. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsCreatingStandards(false);
    }
  };

  const handleDoDTemplateExport = () => {
    if (onExportDoDTemplate) {
      onExportDoDTemplate();
      toast({
        title: 'DoD Template Exported',
        description: 'DoD-compliant price list template exported with UFGS divisions and standard rate analysis.'
      });
    }
  };

  const handleRateAnalysisValidation = () => {
    if (onValidateRateAnalysis) {
      onValidateRateAnalysis();
      toast({
        title: 'Rate Analysis Validation',
        description: 'Validating all rate analysis sheets against DoD standards and M-CACES productivity factors.'
      });
    }
  };

  return (
    <div className="flex flex-col gap-3 p-4 bg-white border-b border-gray-200">
      {/* Search and Primary Actions */}
      <div className="flex items-center gap-3">
        <Input
          placeholder="Search price codes, descriptions, or divisions..."
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          className="max-w-md"
        />
        
        <Separator orientation="vertical" className="h-6" />
        
        <Button onClick={onAddPriceItem} size="sm">
          <Plus className="h-4 w-4 mr-1" />
          Add Price Item
        </Button>
        
        <Button 
          onClick={onDeleteSelected} 
          variant="destructive" 
          size="sm"
          disabled={selectedCount === 0}
        >
          <Trash2 className="h-4 w-4 mr-1" />
          Delete ({selectedCount})
        </Button>
        
        <Button onClick={onRefresh} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-1" />
          Refresh
        </Button>
      </div>

      {/* DoD Standards and Advanced Actions */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-blue-600" />
          <span className="text-sm font-medium text-blue-900">DoD Standards:</span>
        </div>
        
        <Button 
          onClick={handleDoDStandardsInit} 
          variant="outline" 
          size="sm"
          disabled={isCreatingStandards}
        >
          {isCreatingStandards ? (
            <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
          ) : (
            <Database className="h-4 w-4 mr-1" />
          )}
          {isCreatingStandards ? 'Creating...' : 'Initialize Full DoD Standards'}
        </Button>
        
        <Button onClick={onRecreatePrices} variant="outline" size="sm">
          <FileText className="h-4 w-4 mr-1" />
          Create UFGS Prices
        </Button>
        
        {onValidateRateAnalysis && (
          <Button onClick={handleRateAnalysisValidation} variant="outline" size="sm">
            <Calculator className="h-4 w-4 mr-1" />
            Validate Rate Analysis
          </Button>
        )}
        
        <Separator orientation="vertical" className="h-6" />
        
        <Button onClick={onCopyFromProject} variant="outline" size="sm">
          <Copy className="h-4 w-4 mr-1" />
          Copy from Project
        </Button>
        
        <Button onClick={onCalculateTotals} variant="outline" size="sm">
          <Calculator className="h-4 w-4 mr-1" />
          Calculate Totals
        </Button>
      </div>

      {/* Import/Export and View Controls */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <Button onClick={handleImportClick} variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-1" />
            Import CSV
          </Button>
          
          <Button onClick={onExportCSV} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-1" />
            Export CSV
          </Button>
          
          {onExportDoDTemplate && (
            <Button onClick={handleDoDTemplateExport} variant="outline" size="sm">
              <Download className="h-4 w-4 mr-1" />
              Export DoD Template
            </Button>
          )}
        </div>
        
        <Separator orientation="vertical" className="h-6" />
        
        <div className="flex items-center gap-2">
          <Button onClick={onExpandAll} variant="ghost" size="sm">
            <ExpandIcon className="h-4 w-4 mr-1" />
            Expand All
          </Button>
          
          <Button onClick={onCollapseAll} variant="ghost" size="sm">
            <ShrinkIcon className="h-4 w-4 mr-1" />
            Collapse All
          </Button>
        </div>
      </div>

      {/* Status indicator */}
      {isCreatingStandards && (
        <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
          <div className="flex items-center gap-2">
            <RefreshCw className="h-3 w-3 animate-spin" />
            Creating comprehensive DoD standards database... This may take a moment.
          </div>
        </div>
      )}

      {/* Hidden file input for CSV import */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv"
        onChange={onImportCSV}
        className="hidden"
      />
    </div>
  );
}
