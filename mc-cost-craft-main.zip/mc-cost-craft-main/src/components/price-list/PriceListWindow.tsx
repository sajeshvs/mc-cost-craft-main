
import React from 'react';
import { PriceListSpreadsheetTable } from './PriceListSpreadsheetTable';
import { PriceListSpreadsheetToolbar } from './PriceListSpreadsheetToolbar';
import { RateAnalysisSheet } from './RateAnalysisSheet';
import { usePriceListData } from './hooks/usePriceListData';
import { useToast } from '@/hooks/use-toast';
import { doDStandardsService } from '@/services/doDStandardsService';

interface PriceListWindowProps {
  projectId: string;
  onClose: () => void;
}

export function PriceListWindow({ projectId, onClose }: PriceListWindowProps) {
  const priceListData = usePriceListData(projectId);
  const [showRateAnalysis, setShowRateAnalysis] = React.useState(false);
  const [currentPriceCode, setCurrentPriceCode] = React.useState<string>('');
  const [currentNetRate, setCurrentNetRate] = React.useState<number>(0);
  const [isInitializingStandards, setIsInitializingStandards] = React.useState(false);
  const { toast } = useToast();

  const handleOpenRateAnalysis = (priceCode: string, netRate: number) => {
    setCurrentPriceCode(priceCode);
    setCurrentNetRate(netRate);
    setShowRateAnalysis(true);
  };

  const handleSaveRateAnalysis = async (netRate: number, splitRates: any) => {
    try {
      const item = priceListData.priceItems.find(p => p.price_code === currentPriceCode);
      if (item) {
        await priceListData.handleUpdatePriceItem(item.id, {
          unit_rate: netRate,
          split_labor: splitRates.labor,
          split_material: splitRates.material,
          split_equipment: splitRates.equipment,
          split_subcontractor: splitRates.subcontractor,
          split_consultant: splitRates.consultant
        });
        
        await priceListData.refreshData();
      }
    } catch (error) {
      console.error('Error saving rate analysis:', error);
      throw error;
    }
  };

  const handleInitializeComprehensiveStandards = async () => {
    setIsInitializingStandards(true);
    try {
      toast({
        title: 'Initializing DoD Standards',
        description: 'Creating comprehensive DoD resource library and UFGS price list...',
      });

      // Initialize DoD resource library
      const resourceResult = await doDStandardsService.initializeDoDStandards();
      
      // Create comprehensive UFGS price list
      const priceResult = await doDStandardsService.createComprehensivePriceList(projectId);
      
      // Refresh the data
      await priceListData.refreshData();
      
      toast({
        title: 'DoD Standards Initialized',
        description: `Successfully created ${resourceResult.resourceCount} DoD-standard resources and ${priceResult.priceCount} UFGS price items across all divisions (01-48) per UFC 3-701-01 standards.`,
      });
    } catch (error) {
      console.error('Error initializing comprehensive DoD standards:', error);
      toast({
        title: 'Error',
        description: 'Failed to initialize comprehensive DoD standards. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsInitializingStandards(false);
    }
  };

  // Auto-initialize if no price items exist
  React.useEffect(() => {
    if (!priceListData.isLoading && priceListData.priceItems.length === 0 && !isInitializingStandards) {
      handleInitializeComprehensiveStandards();
    }
  }, [priceListData.isLoading, priceListData.priceItems.length, isInitializingStandards]);

  if (priceListData.isLoading || isInitializingStandards) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl p-8">
          <div className="flex items-center gap-2">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
            <span>
              {isInitializingStandards 
                ? 'Initializing comprehensive DoD standards and UFGS price list...' 
                : 'Loading comprehensive DoD price list...'}
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-40">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-7xl h-5/6 flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold">DoD Price List - UFC 3-701-01 Compliant</h2>
              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                {priceListData.priceItems.length} Items
              </span>
              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                All UFGS Divisions (01-48)
              </span>
              <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">
                DoD-Standard Resources
              </span>
            </div>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              ×
            </button>
          </div>

          {/* Toolbar */}
          <PriceListSpreadsheetToolbar
            projectId={projectId}
            searchTerm={priceListData.searchTerm}
            onSearchChange={priceListData.setSearchTerm}
            onAddPriceItem={() => priceListData.handleAddPriceItem('01', 'A')}
            onDeleteSelected={() => priceListData.deletePriceItems(Array.from(priceListData.selectedRows))}
            selectedCount={priceListData.selectedRows.size}
            onRefresh={priceListData.refreshData}
            onImportCSV={priceListData.importFromCSV}
            onExportCSV={priceListData.exportToCSV}
            onExpandAll={() => {
              const allDivisions = Array.from(new Set(priceListData.priceItems.map(item => item.division)));
              allDivisions.forEach(div => {
                if (!priceListData.expandedDivisions.has(div)) {
                  priceListData.toggleDivision(div);
                }
              });
            }}
            onCollapseAll={() => {
              priceListData.expandedDivisions.forEach(div => priceListData.toggleDivision(div));
            }}
            onCalculateTotals={priceListData.calculateTotals}
            onRecreatePrices={handleInitializeComprehensiveStandards}
            onCopyFromProject={() => {
              toast({
                title: 'Copy from Project',
                description: 'This feature will allow copying price lists from other projects',
              });
            }}
            onInitializeDoDStandards={handleInitializeComprehensiveStandards}
            onExportDoDTemplate={() => {
              toast({
                title: 'DoD Template Export',
                description: 'Exporting DoD-compliant price list template with comprehensive UFGS sections',
              });
            }}
            onValidateRateAnalysis={() => {
              toast({
                title: 'Rate Analysis Validation',
                description: 'Validating all rate analysis sheets against DoD standards',
              });
            }}
          />

          {/* Content */}
          <div className="flex-1 overflow-hidden">
            <PriceListSpreadsheetTable
              projectId={projectId}
              searchTerm={priceListData.searchTerm}
              onOpenRateAnalysis={handleOpenRateAnalysis}
            />
          </div>
        </div>
      </div>

      {/* Rate Analysis Sheet */}
      {showRateAnalysis && (
        <RateAnalysisSheet
          projectId={projectId}
          priceCode={currentPriceCode}
          currentNetRate={currentNetRate}
          onClose={() => setShowRateAnalysis(false)}
          onSave={handleSaveRateAnalysis}
        />
      )}
    </>
  );
}
