
import React from 'react';
import { ChevronDown, ChevronRight, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { PriceListItem, UFGS_DIVISIONS } from '@/types/priceList';

interface PriceListTableProps {
  priceItems: PriceListItem[];
  onUpdatePriceItem: (id: string, updates: Partial<PriceListItem>) => Promise<void>;
  onDeletePriceItems: (ids: string[]) => Promise<void>;
  onAddPriceItem: (division: string, subtradeLetter: string) => Promise<void>;
  searchTerm: string;
  onSearchChange: (term: string) => void;
  showHeader?: boolean;
  selectedRows: Set<string>;
  onRowSelectionChange: (selectedRows: Set<string>) => void;
  divisionKey?: string;
  divisionName?: string;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export function PriceListTable({
  priceItems,
  onUpdatePriceItem,
  onDeletePriceItems,
  onAddPriceItem,
  searchTerm,
  onSearchChange,
  showHeader = true,
  selectedRows,
  onRowSelectionChange,
  divisionKey,
  divisionName,
  isCollapsed = false,
  onToggleCollapse
}: PriceListTableProps) {
  const columns = [
    { key: 'checkbox', label: '', width: '40px' },
    { key: 'expand', label: '', width: '40px' },
    { key: 'price_code', label: 'Price Code', width: '120px' },
    { key: 'description', label: 'Description', width: '300px' },
    { key: 'unit', label: 'Unit', width: '80px' },
    { key: 'unit_rate', label: 'Unit Rate', width: '120px' },
    { key: 'boq_reference', label: 'BOQ Reference', width: '150px' }
  ];

  const filteredPriceItems = priceItems.filter(item =>
    searchTerm === '' || 
    item.price_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCellEdit = async (itemId: string, field: keyof PriceListItem, value: any) => {
    await onUpdatePriceItem(itemId, { [field]: value });
  };

  const handleSelectRow = (itemId: string, checked: boolean) => {
    const newSelection = new Set(selectedRows);
    if (checked) {
      newSelection.add(itemId);
    } else {
      newSelection.delete(itemId);
    }
    onRowSelectionChange(newSelection);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = new Set(filteredPriceItems.map(item => item.id));
      onRowSelectionChange(allIds);
    } else {
      onRowSelectionChange(new Set());
    }
  };

  const renderEditableCell = (item: PriceListItem, field: keyof PriceListItem, value: any) => {
    return (
      <input
        type={field === 'unit_rate' ? 'number' : 'text'}
        value={value || ''}
        onChange={(e) => {
          const newValue = field === 'unit_rate' ? parseFloat(e.target.value) || 0 : e.target.value;
          handleCellEdit(item.id, field, newValue);
        }}
        className="w-full p-1 border-0 bg-transparent focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-center"
        step={field === 'unit_rate' ? "0.01" : undefined}
      />
    );
  };

  return (
    <div className="flex flex-col">
      {/* Sticky Column Headers */}
      <div className="overflow-auto">
        <table className="w-full border-collapse">
          <thead className="sticky top-0 bg-yellow-200 z-20">
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="border border-gray-200 p-2 text-center text-sm font-bold text-gray-900"
                  style={{ width: column.width, minWidth: column.width }}
                >
                  {column.key === 'checkbox' ? (
                    <Checkbox
                      checked={selectedRows.size === filteredPriceItems.length && filteredPriceItems.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  ) : (
                    column.label
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {/* Division Header Row */}
            {divisionKey && divisionName && (
              <tr className="bg-gray-100 font-bold">
                <td className="border border-gray-200 p-2 text-center">
                  <Checkbox disabled />
                </td>
                <td className="border border-gray-200 p-2 text-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onToggleCollapse}
                    className="p-0 h-6 w-6"
                  >
                    {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </Button>
                </td>
                <td className="border border-gray-200 p-2 text-center font-bold">
                  {divisionKey}
                </td>
                <td className="border border-gray-200 p-2 text-center font-bold">
                  {divisionName}
                </td>
                <td className="border border-gray-200 p-2 text-center"></td>
                <td className="border border-gray-200 p-2 text-center font-bold">
                  {filteredPriceItems.reduce((sum, item) => sum + (item.unit_rate || 0), 0).toLocaleString('en-US', {
                    style: 'currency',
                    currency: 'USD'
                  })}
                </td>
                <td className="border border-gray-200 p-2 text-center">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onAddPriceItem(divisionKey, 'A')}
                    className="p-0 h-6 w-6"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            )}

            {/* Price Item Rows */}
            {!isCollapsed && filteredPriceItems.map((item) => (
              <tr
                key={item.id}
                className={`hover:bg-gray-50 ${selectedRows.has(item.id) ? 'bg-blue-50' : ''}`}
              >
                <td className="border border-gray-200 p-2 text-center">
                  <Checkbox
                    checked={selectedRows.has(item.id)}
                    onCheckedChange={(checked) => handleSelectRow(item.id, !!checked)}
                  />
                </td>
                <td className="border border-gray-200 p-2 text-center"></td>
                <td className="border border-gray-200 p-2 text-center">
                  {renderEditableCell(item, 'price_code', item.price_code)}
                </td>
                <td className="border border-gray-200 p-2 text-center">
                  {renderEditableCell(item, 'description', item.description)}
                </td>
                <td className="border border-gray-200 p-2 text-center">
                  {renderEditableCell(item, 'unit', item.unit)}
                </td>
                <td className="border border-gray-200 p-2 text-center">
                  {renderEditableCell(item, 'unit_rate', item.unit_rate)}
                </td>
                <td className="border border-gray-200 p-2 text-center">
                  <span className="text-xs text-gray-500">
                    {Array.isArray(item.boq_reference) ? item.boq_reference.length : 0} linked
                  </span>
                </td>
              </tr>
            ))}

            {/* Empty state */}
            {filteredPriceItems.length === 0 && (
              <tr>
                <td colSpan={columns.length} className="border border-gray-200 p-8 text-center text-gray-500">
                  No price items found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
