
import React from 'react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ChevronDown, ChevronRight, Shield } from 'lucide-react';
import { useColumnResize } from '@/hooks/useColumnResize';
import { usePriceListData } from './hooks/usePriceListData';

interface PriceListSpreadsheetTableProps {
  projectId: string;
  searchTerm: string;
  onOpenRateAnalysis: (priceCode: string, netRate: number) => void;
}

export function PriceListSpreadsheetTable({ 
  projectId,
  searchTerm,
  onOpenRateAnalysis
}: PriceListSpreadsheetTableProps) {
  const { columnWidths, handleMouseDown, handleDoubleClick } = useColumnResize();
  const priceListData = usePriceListData(projectId);

  // Filter items based on search term
  const filteredItems = priceListData.priceItems.filter(item => 
    item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.price_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.division.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRowSelect = (itemId: string, isShiftClick = false) => {
    const newSet = new Set(priceListData.selectedRows);
    if (newSet.has(itemId)) {
      newSet.delete(itemId);
    } else {
      if (!isShiftClick) {
        newSet.clear();
      }
      newSet.add(itemId);
    }
    priceListData.setSelectedRows(newSet);
  };

  // Comprehensive division names based on CSI MasterFormat and UFGS
  const divisionNames: { [key: string]: string } = {
    '01': 'General Requirements',
    '02': 'Existing Conditions', 
    '03': 'Concrete',
    '04': 'Masonry',
    '05': 'Metals',
    '06': 'Wood, Plastics, and Composites',
    '07': 'Thermal and Moisture Protection',
    '08': 'Openings',
    '09': 'Finishes',
    '10': 'Specialties',
    '11': 'Equipment',
    '12': 'Furnishings',
    '13': 'Special Construction',
    '14': 'Conveying Equipment',
    '21': 'Fire Suppression',
    '22': 'Plumbing',
    '23': 'Heating Ventilating and Air Conditioning',
    '25': 'Integrated Automation',
    '26': 'Electrical',
    '27': 'Communications',
    '28': 'Electronic Safety and Security',
    '31': 'Earthwork',
    '32': 'Exterior Improvements',
    '33': 'Utilities',
    '34': 'Transportation',
    '35': 'Waterway and Marine Construction',
    '40': 'Process Integration',
    '41': 'Material Processing and Handling Equipment',
    '42': 'Process Heating, Cooling, and Drying Equipment',
    '43': 'Process Gas and Liquid Handling, Purification, and Storage Equipment',
    '44': 'Pollution Control Equipment',
    '45': 'Industry-Specific Manufacturing Equipment',
    '46': 'Water and Wastewater Equipment',
    '47': 'Electrical Power Generation',
    '48': 'Electrical Power Transmission'
  };

  return (
    <div className="flex flex-col h-full">
      <ScrollArea className="flex-1">
        <div className="relative">
          {/* Header */}
          <div className="sticky top-0 z-10 bg-white border-b border-gray-200">
            <div className="flex text-sm font-medium text-gray-700 bg-gray-50">
              <div className="w-10 p-2 border-r border-gray-200 flex items-center justify-center">
                <input
                  type="checkbox"
                  className="rounded border-gray-300"
                  onChange={(e) => {
                    if (e.target.checked) {
                      priceListData.setSelectedRows(new Set(filteredItems.map(item => item.id)));
                    } else {
                      priceListData.setSelectedRows(new Set());
                    }
                  }}
                />
              </div>
              <div className="w-12 p-2 border-r border-gray-200 text-center" title="DoD Compliant">
                <Shield className="h-4 w-4 text-blue-600 mx-auto" />
              </div>
              <div 
                className="p-2 border-r border-gray-200 text-center cursor-col-resize hover:bg-gray-100 transition-colors resize-handle"
                style={{ width: `${columnWidths.price_code || 140}px` }}
                onMouseDown={(e) => handleMouseDown('price_code', e)}
                onDoubleClick={() => handleDoubleClick('price_code')}
              >
                UFGS Price Code
              </div>
              <div 
                className="flex-1 p-2 border-r border-gray-200 cursor-col-resize hover:bg-gray-100 transition-colors resize-handle"
                style={{ minWidth: `${columnWidths.description || 400}px` }}
                onMouseDown={(e) => handleMouseDown('description', e)}
                onDoubleClick={() => handleDoubleClick('description')}
              >
                Description (UFGS Section & UFC 3-701-01 Compliant)
              </div>
              <div 
                className="p-2 border-r border-gray-200 text-center cursor-col-resize hover:bg-gray-100 transition-colors resize-handle"
                style={{ width: `${columnWidths.unit || 80}px` }}
                onMouseDown={(e) => handleMouseDown('unit', e)}
                onDoubleClick={() => handleDoubleClick('unit')}
              >
                Unit
              </div>
              <div 
                className="p-2 border-r border-gray-200 text-center cursor-col-resize hover:bg-gray-100 transition-colors resize-handle"
                style={{ width: `${columnWidths.unit_rate || 120}px` }}
                onMouseDown={(e) => handleMouseDown('unit_rate', e)}
                onDoubleClick={() => handleDoubleClick('unit_rate')}
              >
                Net Rate
              </div>
              <div 
                className="p-2 border-r border-gray-200 text-center cursor-col-resize hover:bg-gray-100 transition-colors resize-handle"
                style={{ width: `280px` }}
              >
                DoD Split Rates (L|M|E|S|C) - UFC 3-701-01
              </div>
              <div 
                className="p-2 text-center cursor-col-resize hover:bg-gray-100 transition-colors resize-handle"
                style={{ width: `${columnWidths.boq_reference || 150}px` }}
                onMouseDown={(e) => handleMouseDown('boq_reference', e)}
                onDoubleClick={() => handleDoubleClick('boq_reference')}
              >
                BOQ Reference
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="min-w-full">
            {Object.entries(
              filteredItems.reduce((groups, item) => {
                const division = item.division;
                if (!groups[division]) {
                  groups[division] = [];
                }
                groups[division].push(item);
                return groups;
              }, {} as { [key: string]: typeof filteredItems })
            )
            .sort(([divisionA], [divisionB]) => {
              const numA = parseInt(divisionA, 10);
              const numB = parseInt(divisionB, 10);
              return numA - numB;
            })
            .map(([division, items]) => (
              <div key={division}>
                {/* Division Header */}
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 border-b border-gray-200 sticky top-10 z-5">
                  <div className="flex items-center p-2 font-medium text-blue-900">
                    <div className="w-10 flex items-center justify-center">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => priceListData.toggleDivision(division)}
                        className="p-0 h-6 w-6"
                      >
                        {priceListData.expandedDivisions.has(division) ? 
                          <ChevronDown className="h-4 w-4" /> : 
                          <ChevronRight className="h-4 w-4" />
                        }
                      </Button>
                    </div>
                    <div className="w-12 flex items-center justify-center" title="DoD Compliant per UFC 3-701-01">
                      <Shield className="h-4 w-4 text-blue-600" />
                    </div>
                    <div className="w-32 text-center font-mono font-bold text-blue-800">
                      DIV {division}
                    </div>
                    <div className="flex-1 px-2">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-blue-900">
                          {divisionNames[division] || `Division ${division}`}
                        </span>
                        <span className="text-sm text-blue-600 bg-blue-200 px-2 py-1 rounded">
                          {items.length} UFGS sections
                        </span>
                        <span className="text-xs text-blue-500 bg-blue-100 px-2 py-1 rounded">
                          UFC 3-701-01 Compliant
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Division Items */}
                {priceListData.expandedDivisions.has(division) && items.map((item) => (
                  <div 
                    key={item.id}
                    className={`flex border-b border-gray-100 hover:bg-gray-50 transition-colors ${
                      priceListData.selectedRows.has(item.id) ? 'bg-blue-50' : ''
                    }`}
                  >
                    <div className="w-10 p-2 border-r border-gray-200 flex items-center justify-center">
                      <input
                        type="checkbox"
                        className="rounded border-gray-300"
                        checked={priceListData.selectedRows.has(item.id)}
                        onChange={() => handleRowSelect(item.id)}
                      />
                    </div>
                    <div className="w-12 p-2 border-r border-gray-200 text-center text-sm" title="DoD Standard">
                      <Shield className="h-3 w-3 text-green-600 mx-auto" />
                    </div>
                    <div 
                      className="p-2 border-r border-gray-200 text-sm font-mono overflow-hidden"
                      style={{ width: `${columnWidths.price_code || 140}px` }}
                    >
                      <div className="truncate font-medium text-blue-700">{item.price_code}</div>
                    </div>
                    <div 
                      className="flex-1 p-2 border-r border-gray-200 text-sm text-left overflow-hidden"
                      style={{ minWidth: `${columnWidths.description || 400}px` }}
                    >
                      <div className="whitespace-pre-wrap break-words">
                        <span className="font-medium text-gray-900">{item.description}</span>
                        <div className="text-xs text-gray-500 mt-1">
                          DoD Standard • UFC 3-701-01 Compliant • UFGS Division {item.division}
                        </div>
                      </div>
                    </div>
                    <div 
                      className="p-2 border-r border-gray-200 text-sm text-center overflow-hidden"
                      style={{ width: `${columnWidths.unit || 80}px` }}
                    >
                      <div className="truncate font-medium">{item.unit}</div>
                    </div>
                    <div 
                      className="p-2 border-r border-gray-200 text-sm text-right overflow-hidden cursor-pointer hover:bg-blue-50 transition-colors"
                      style={{ width: `${columnWidths.unit_rate || 120}px` }}
                      onClick={() => onOpenRateAnalysis(item.price_code, item.unit_rate)}
                      title="Click to open DoD Rate Analysis Sheet with standard resources"
                    >
                      <div className="truncate font-bold text-blue-700 hover:text-blue-900">
                        ${item.unit_rate.toFixed(2)}
                      </div>
                      <div className="text-xs text-blue-500">
                        Click for Analysis
                      </div>
                    </div>
                    <div 
                      className="p-2 border-r border-gray-200 text-xs overflow-hidden"
                      style={{ width: `280px` }}
                    >
                      <div className="grid grid-cols-5 gap-1 text-center">
                        <div className="bg-blue-50 p-1 rounded">
                          <div className="text-blue-700 font-medium" title="Labor (Davis-Bacon)">
                            L: ${item.split_labor.toFixed(0)}
                          </div>
                        </div>
                        <div className="bg-green-50 p-1 rounded">
                          <div className="text-green-700 font-medium" title="Material (UFGS)">
                            M: ${item.split_material.toFixed(0)}
                          </div>
                        </div>
                        <div className="bg-yellow-50 p-1 rounded">
                          <div className="text-yellow-700 font-medium" title="Equipment (USACE)">
                            E: ${item.split_equipment.toFixed(0)}
                          </div>
                        </div>
                        <div className="bg-purple-50 p-1 rounded">
                          <div className="text-purple-700 font-medium" title="Subcontractor">
                            S: ${item.split_subcontractor.toFixed(0)}
                          </div>
                        </div>
                        <div className="bg-red-50 p-1 rounded">
                          <div className="text-red-700 font-medium" title="Consultant">
                            C: ${item.split_consultant.toFixed(0)}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div 
                      className="p-2 text-sm text-center overflow-hidden"
                      style={{ width: `${columnWidths.boq_reference || 150}px` }}
                    >
                      <span className="text-xs text-gray-500">
                        {Array.isArray(item.boq_reference) ? item.boq_reference.length : 0} linked
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
