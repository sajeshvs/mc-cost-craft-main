
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, Calculator } from 'lucide-react';
import { PriceListItem } from '@/types/priceList';

interface PriceCodeSelectorProps {
  projectId: string;
  priceList: PriceListItem[];
  onSelectPriceCode: (priceCode: string, unitRate: number, splitRates: {
    labor: number;
    material: number;
    equipment: number;
    subcontractor: number;
    consultant: number;
  }) => void;
  onOpenRateAnalysis: (priceCode: string, currentRate: number) => void;
}

export function PriceCodeSelector({ 
  projectId, 
  priceList, 
  onSelectPriceCode, 
  onOpenRateAnalysis 
}: PriceCodeSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPriceList = priceList
    .filter(item => 
      item && 
      item.price_code && 
      typeof item.price_code === 'string' &&
      item.price_code.trim() !== '' &&
      item.description &&
      typeof item.description === 'string' &&
      item.description.trim() !== ''
    )
    .filter(item =>
      item.price_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const handleSelectPrice = (item: PriceListItem) => {
    // Ensure we have a valid price code before calling the handler
    if (item.price_code && item.price_code.trim() !== '') {
      onSelectPriceCode(item.price_code, item.unit_rate, {
        labor: item.split_labor || 0,
        material: item.split_material || 0,
        equipment: item.split_equipment || 0,
        subcontractor: item.split_subcontractor || 0,
        consultant: item.split_consultant || 0
      });
    }
  };

  const handleRateAnalysis = (item: PriceListItem) => {
    // Ensure we have a valid price code before calling the handler
    if (item.price_code && item.price_code.trim() !== '') {
      onOpenRateAnalysis(item.price_code, item.unit_rate);
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Search */}
      <div className="p-4 border-b">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search price codes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Price List */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-2">
          {filteredPriceList.map((item) => (
            <div
              key={item.id}
              className="border rounded-lg p-3 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-medium text-blue-600">
                      {item.price_code}
                    </span>
                    <span className="text-xs bg-gray-100 px-2 py-1 rounded">
                      {item.division}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700 mt-1">{item.description}</p>
                  <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                    <span>Unit: {item.unit}</span>
                    <span className="font-medium text-green-600">
                      Rate: ${item.unit_rate.toFixed(2)}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <Button
                    size="sm"
                    onClick={() => handleSelectPrice(item)}
                    className="h-8"
                  >
                    Select
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleRateAnalysis(item)}
                    className="h-8"
                  >
                    <Calculator className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      {filteredPriceList.length === 0 && (
        <div className="flex-1 flex items-center justify-center text-gray-500">
          <div className="text-center">
            <p>No price codes found</p>
            <p className="text-sm">Try a different search term</p>
          </div>
        </div>
      )}
    </div>
  );
}
