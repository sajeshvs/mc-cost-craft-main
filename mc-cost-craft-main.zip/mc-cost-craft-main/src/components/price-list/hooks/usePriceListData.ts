import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { priceListService } from '@/services/priceList';
import { PriceListItem } from '@/types/priceList';
import { useToast } from '@/hooks/use-toast';
import { priceCodeVersionsService } from '@/services/priceCodeVersions';

export function usePriceListData(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // UI State Management
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedRows, setSelectedRows] = React.useState<Set<string>>(new Set());
  const [expandedDivisions, setExpandedDivisions] = React.useState<Set<string>>(new Set());

  // Query for price list items
  const {
    data: priceItems = [],
    isLoading,
    error,
    refetch: loadPriceItems
  } = useQuery({
    queryKey: ['price-list', projectId],
    queryFn: () => priceListService.getByProject(projectId),
    enabled: !!projectId
  });

  // Check if we have any price items, if not, create defaults
  const {
    mutate: createDefaultPrices,
    isPending: isCreatingPrices
  } = useMutation({
    mutationFn: () => priceListService.createDefaultPrices(projectId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-list', projectId] });
      toast({
        title: 'Success',
        description: 'Default UFGS prices created successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create default prices',
        variant: 'destructive'
      });
    }
  });

  React.useEffect(() => {
    if (!isLoading && priceItems.length === 0 && !isCreatingPrices) {
      createDefaultPrices();
    }
  }, [isLoading, priceItems.length, isCreatingPrices, createDefaultPrices]);

  // Mutation for updating price items
  const updatePriceItemMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<PriceListItem> }) =>
      priceListService.update(id, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-list', projectId] });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update price item',
        variant: 'destructive'
      });
    }
  });

  // Mutation for adding new price items
  const addPriceItemMutation = useMutation({
    mutationFn: (newItem: Omit<PriceListItem, 'id' | 'created_at' | 'updated_at'>) =>
      priceListService.create(newItem),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-list', projectId] });
      toast({
        title: 'Success',
        description: 'Price item added successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to add price item',
        variant: 'destructive'
      });
    }
  });

  // Mutation for deleting price items
  const deletePriceItemsMutation = useMutation({
    mutationFn: (ids: string[]) => priceListService.deleteMultiple(ids),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-list', projectId] });
      setSelectedRows(new Set());
      toast({
        title: 'Success',
        description: 'Price items deleted successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete price items',
        variant: 'destructive'
      });
    }
  });

  const handleUpdatePriceItem = async (id: string, updates: Partial<PriceListItem>) => {
    // If updating unit_rate or split rates, create a new approved version
    if (updates.unit_rate || updates.split_labor || updates.split_material || 
        updates.split_equipment || updates.split_subcontractor || updates.split_consultant) {
      
      const priceItem = priceItems.find(item => item.id === id);
      if (priceItem) {
        try {
          // Create new approved version for this price code
          await priceCodeVersionsService.createVersion({
            price_code: priceItem.price_code,
            project_id: projectId,
            status: 'approved',
            change_summary: 'Updated from Price List',
            created_by: '' // Will be set by service
          });
        } catch (error) {
          console.error('Error creating version for price update:', error);
        }
      }
    }
    
    updatePriceItemMutation.mutate({ id, updates });
  };

  const updatePriceItem = handleUpdatePriceItem; // Alias for backward compatibility

  const handleAddPriceItem = async (division: string, subtradeLetter: string) => {
    const existingItems = priceItems.filter(item => item.division === division);
    const nextSerial = (existingItems.length + 1).toString().padStart(4, '0');
    const priceCode = `${division}${subtradeLetter}-${nextSerial}`;

    const newItem: Omit<PriceListItem, 'id' | 'created_at' | 'updated_at'> = {
      project_id: projectId,
      division,
      price_code: priceCode,
      description: `New ${division} Item`,
      unit: 'EA',
      unit_rate: 0,
      split_labor: 0,
      split_material: 0,
      split_equipment: 0,
      split_subcontractor: 0,
      split_consultant: 0,
      boq_reference: [],
      sort_order: existingItems.length,
      user_id: undefined
    };

    addPriceItemMutation.mutate(newItem);
  };

  const addPriceItem = handleAddPriceItem; // Alias for backward compatibility

  const deletePriceItems = async (ids: string[]) => {
    deletePriceItemsMutation.mutate(ids);
  };

  const toggleDivision = (division: string) => {
    setExpandedDivisions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(division)) {
        newSet.delete(division);
      } else {
        newSet.add(division);
      }
      return newSet;
    });
  };

  const refreshData = async () => {
    await loadPriceItems();
  };

  const exportToCSV = async () => {
    try {
      const csvData = await priceListService.exportToCSV(projectId);
      
      // Create download link
      const blob = new Blob([csvData], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `price-list-${projectId}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: 'Success',
        description: 'Price list exported to CSV',
      });
    } catch (error) {
      console.error('Error exporting CSV:', error);
      toast({
        title: 'Error',
        description: 'Failed to export CSV',
        variant: 'destructive'
      });
    }
  };

  const importFromCSV = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    try {
      const text = await file.text();
      const importedCount = await priceListService.importFromCSV(projectId, text);
      
      await refreshData();
      
      toast({
        title: 'Success',
        description: `Imported ${importedCount} price items from CSV`,
      });
    } catch (error) {
      console.error('Error importing CSV:', error);
      toast({
        title: 'Error',
        description: 'Failed to import CSV file',
        variant: 'destructive'
      });
    }
    
    // Reset file input
    event.target.value = '';
  };

  const calculateTotals = () => {
    toast({
      title: 'Calculate Totals',
      description: 'Calculating project totals based on current price list and rate analysis data...',
    });
  };

  return {
    // Data
    priceItems,
    isLoading,
    isCreatingPrices,
    error,
    
    // UI State
    searchTerm,
    setSearchTerm,
    selectedRows,
    setSelectedRows,
    expandedDivisions,
    toggleDivision,
    
    // Actions
    handleUpdatePriceItem,
    updatePriceItem,
    handleAddPriceItem,
    addPriceItem,
    deletePriceItems,
    loadPriceItems,
    refreshData,
    exportToCSV,
    importFromCSV,
    calculateTotals
  };
}
