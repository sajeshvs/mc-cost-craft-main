
import React, { useState } from 'react';
import { X, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

interface SubmitDialogProps {
  onSubmit: (changeSummary?: string) => void;
  onClose: () => void;
}

export function SubmitDialog({ onSubmit, onClose }: SubmitDialogProps) {
  const [changeSummary, setChangeSummary] = useState('');

  const handleSubmit = () => {
    onSubmit(changeSummary || undefined);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-60">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">Submit for Approval</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          <div>
            <Label htmlFor="changeSummary">Change Summary (Optional)</Label>
            <Textarea
              id="changeSummary"
              placeholder="Describe the changes made in this version..."
              value={changeSummary}
              onChange={(e) => setChangeSummary(e.target.value)}
              className="mt-1"
              rows={4}
            />
          </div>

          <div className="text-sm text-gray-600">
            <p>By submitting this rate analysis:</p>
            <ul className="list-disc ml-4 mt-1 space-y-1">
              <li>It will be locked for editing</li>
              <li>It will be available for approval</li>
              <li>You can create a new version if changes are needed</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 p-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>
            <Send className="h-4 w-4 mr-1" />
            Submit for Approval
          </Button>
        </div>
      </div>
    </div>
  );
}
