
import React, { useState } from 'react';
import { X, Plus, Save, Send, CheckCircle, History, Database, Shield, Calculator } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useRateAnalysis } from '@/hooks/useRateAnalysis';
import { RateAnalysisTable } from './RateAnalysisTable';
import { RateAnalysisFooter } from './RateAnalysisFooter';
import { RateAnalysisHeader } from './RateAnalysisHeader';
import { VersionHistoryDialog } from './VersionHistoryDialog';
import { SubmitDialog } from './SubmitDialog';
import { useResourcesIntegration } from '@/hooks/useResourcesIntegration';

interface RateAnalysisSheetProps {
  projectId: string;
  priceCode: string;
  currentNetRate: number;
  onClose: () => void;
  onSave: (netRate: number, splitRates: {
    labor: number;
    material: number;
    equipment: number;
    subcontractor: number;
    consultant: number;
  }) => Promise<void>;
}

export function RateAnalysisSheet({ 
  projectId,
  priceCode, 
  currentNetRate, 
  onClose, 
  onSave 
}: RateAnalysisSheetProps) {
  const [showVersionHistory, setShowVersionHistory] = useState(false);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [isLoadingStandards, setIsLoadingStandards] = useState(false);
  
  const rateAnalysis = useRateAnalysis(projectId, priceCode);
  const { updateResourcesFromPriceAnalysis } = useResourcesIntegration(projectId);

  const handleSave = async () => {
    try {
      await onSave(rateAnalysis.totals.netRate, {
        labor: rateAnalysis.totals.labor,
        material: rateAnalysis.totals.material,
        equipment: rateAnalysis.totals.equipment,
        subcontractor: rateAnalysis.totals.subcontractor,
        consultant: rateAnalysis.totals.consultant
      });

      // Update resources integration
      const analysisResources = rateAnalysis.resources.map(resource => ({
        resourceCode: resource.resource_code,
        quantity: resource.quantity,
        category: resource.category
      }));

      await updateResourcesFromPriceAnalysis(priceCode, analysisResources);
      
      onClose();
    } catch (error) {
      console.error('Error saving rate analysis:', error);
    }
  };

  const handleSubmit = async (changeSummary?: string) => {
    await rateAnalysis.submitForApproval(changeSummary);
    setShowSubmitDialog(false);
  };

  const getStatusBadge = () => {
    if (!rateAnalysis.currentVersion) return null;
    
    const status = rateAnalysis.currentVersion.status;
    const variants = {
      draft: 'secondary',
      submitted: 'outline',
      approved: 'default'
    } as const;
    
    const colors = {
      draft: 'bg-yellow-100 text-yellow-800',
      submitted: 'bg-blue-100 text-blue-800',
      approved: 'bg-green-100 text-green-800'
    };

    return (
      <Badge className={colors[status]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const canEdit = rateAnalysis.currentVersion?.status === 'draft';
  const canSubmit = rateAnalysis.currentVersion?.status === 'draft' && rateAnalysis.resources.length > 0;
  const canApprove = rateAnalysis.currentVersion?.status === 'submitted';

  if (rateAnalysis.isLoading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl p-8">
          <div className="flex items-center gap-2">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
            <span>Loading DoD-compliant rate analysis...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-7xl h-5/6 flex flex-col">
          {/* Header */}
          <RateAnalysisHeader
            priceCode={priceCode}
            currentVersion={rateAnalysis.currentVersion}
            netRate={rateAnalysis.totals.netRate}
            onClose={onClose}
            onLoadStandards={() => setIsLoadingStandards(true)}
            onShowHistory={() => setShowVersionHistory(true)}
            onAddResource={() => rateAnalysis.addResource({
              project_id: projectId,
              price_code: priceCode,
              resource_code: '',
              resource_name: '',
              category: 'P',
              unit: 'HR',
              quantity: 1,
              unit_rate: 0,
              wastage_percent: 0,
              total_amount: 0,
              sort_order: rateAnalysis.resources.length
            })}
            onSave={handleSave}
            onSubmit={() => setShowSubmitDialog(true)}
            onApprove={rateAnalysis.approve}
            canEdit={canEdit}
            canSubmit={canSubmit}
            canApprove={canApprove}
            isSaving={rateAnalysis.isSaving}
            isLoadingStandards={isLoadingStandards}
          />

          {/* Content */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <ScrollArea className="flex-1">
              <RateAnalysisTable
                resources={rateAnalysis.resources}
                availableResources={rateAnalysis.availableResources}
                priceCode={priceCode}
                onUpdateResource={rateAnalysis.updateResource}
                onDeleteResource={rateAnalysis.deleteResource}
                onAddFromLibrary={rateAnalysis.addResource}
                canEdit={canEdit}
              />
            </ScrollArea>

            {/* Footer with totals */}
            <RateAnalysisFooter totals={rateAnalysis.totals} />
          </div>
        </div>
      </div>

      {/* Version History Dialog */}
      {showVersionHistory && (
        <VersionHistoryDialog
          versions={rateAnalysis.versions}
          onClose={() => setShowVersionHistory(false)}
        />
      )}

      {/* Submit Dialog */}
      {showSubmitDialog && (
        <SubmitDialog
          onSubmit={handleSubmit}
          onClose={() => setShowSubmitDialog(false)}
        />
      )}
    </>
  );
}
