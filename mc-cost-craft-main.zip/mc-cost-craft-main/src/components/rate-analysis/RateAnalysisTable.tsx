
import React from 'react';
import { Trash2, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PriceCodeAnalysisResource } from '@/services/priceCodeAnalysis';

interface RateAnalysisTableProps {
  resources: PriceCodeAnalysisResource[];
  availableResources: any[];
  priceCode: string;
  onUpdateResource: (id: string, updates: Partial<PriceCodeAnalysisResource>) => void;
  onDeleteResource: (id: string) => void;
  onAddFromLibrary: (resourceData: Omit<PriceCodeAnalysisResource, 'id' | 'created_at' | 'updated_at'>) => void;
  canEdit: boolean;
}

export function RateAnalysisTable({
  resources,
  availableResources,
  priceCode,
  onUpdateResource,
  onDeleteResource,
  onAddFromLibrary,
  canEdit
}: RateAnalysisTableProps) {
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'P': return 'bg-blue-50 text-blue-800';
      case 'M': return 'bg-green-50 text-green-800';
      case 'E': return 'bg-yellow-50 text-yellow-800';
      case 'S': return 'bg-purple-50 text-purple-800';
      case 'C': return 'bg-red-50 text-red-800';
      default: return 'bg-gray-50 text-gray-800';
    }
  };

  const handleResourceUpdate = (id: string, field: string, value: any) => {
    const updates: Partial<PriceCodeAnalysisResource> = { [field]: value };
    
    // Recalculate total_amount when quantity, unit_rate, or wastage_percent changes
    if (['quantity', 'unit_rate', 'wastage_percent'].includes(field)) {
      const resource = resources.find(r => r.id === id);
      if (resource) {
        const newQuantity = field === 'quantity' ? value : resource.quantity;
        const newUnitRate = field === 'unit_rate' ? value : resource.unit_rate;
        const newWastagePercent = field === 'wastage_percent' ? value : resource.wastage_percent;
        
        let total = newQuantity * newUnitRate;
        if (resource.category === 'M' && newWastagePercent > 0) {
          total *= (1 + newWastagePercent / 100);
        }
        updates.total_amount = total;
      }
    }
    
    onUpdateResource(id, updates);
  };

  const getRelevantResourcesByDivision = (divisionCode: string, library: any[]): any[] => {
    const divisionResourceMap: { [key: string]: string[] } = {
      '01': ['P018', 'P019', 'P020', 'C001', 'C009'],
      '02': ['P016', 'E001', 'E002', 'S008', 'S009'],
      '03': ['P004', 'P001', 'M001', 'M002', 'E005'],
      '04': ['P013', 'P001', 'M006', 'M007', 'M004'],
      '05': ['P005', 'P009', 'M003', 'E006', 'C001'],
      '06': ['P003', 'P001', 'M005', 'E012', 'C001'],
      '07': ['P011', 'P015', 'M008', 'M015', 'M016'],
      '08': ['P014', 'P003', 'M013', 'M014', 'S011'],
      '09': ['P010', 'P012', 'M009', 'M010', 'M011'],
      '10': ['P003', 'P001', 'M009', 'S012', 'C001'],
      '11': ['P002', 'P001', 'M001', 'S006', 'C001'],
      '12': ['P003', 'P001', 'M009', 'S012', 'C001'],
      '13': ['P001', 'P018', 'E001', 'S001', 'C001'],
      '14': ['P002', 'P001', 'E006', 'S003', 'C001'],
      '21': ['P006', 'P007', 'M018', 'S004', 'C012'],
      '22': ['P007', 'P001', 'M018', 'M019', 'C001'],
      '23': ['P008', 'P001', 'M020', 'M019', 'C001'],
      '25': ['P006', 'P008', 'M017', 'S005', 'C001'],
      '26': ['P006', 'P001', 'M017', 'E014', 'C001'],
      '27': ['P006', 'P001', 'M017', 'S005', 'C001'],
      '28': ['P006', 'P001', 'M017', 'S005', 'C011'],
      '31': ['P001', 'P002', 'M021', 'E001', 'C002'],
      '32': ['P001', 'P002', 'M022', 'E010', 'S015'],
      '33': ['P007', 'P006', 'M018', 'E009', 'S014'],
      '34': ['P002', 'P001', 'M022', 'E010', 'C006'],
      '35': ['P001', 'P002', 'E001', 'S001', 'C002'],
      '40': ['P008', 'P006', 'M017', 'S005', 'C001'],
      '41': ['P002', 'P001', 'E001', 'S001', 'C001'],
      '42': ['P008', 'P001', 'M020', 'S001', 'C001'],
      '43': ['P007', 'P008', 'M018', 'S001', 'C001'],
      '44': ['P001', 'P008', 'E001', 'S001', 'C010'],
      '45': ['P002', 'P001', 'E001', 'S001', 'C001'],
      '46': ['P007', 'P008', 'M018', 'S001', 'C001'],
      '47': ['P006', 'P001', 'M017', 'S001', 'C001'],
      '48': ['P006', 'P001', 'M017', 'S001', 'C001']
    };

    const resourceCodes = divisionResourceMap[divisionCode] || ['P001', 'M001', 'E001', 'S001', 'C001'];
    return library.filter(resource => resourceCodes.includes(resource.resource_code));
  };

  const handleAddFromLibrary = (resource: any) => {
    const quantity = resource.default_productivity || 1;
    const unitRate = resource.default_rate || 0;
    const wastagePercent = resource.resource_type === 'M' ? 5.0 : 0;
    
    let totalAmount = quantity * unitRate;
    if (resource.resource_type === 'M' && wastagePercent > 0) {
      totalAmount *= (1 + wastagePercent / 100);
    }

    onAddFromLibrary({
      project_id: '', // Will be set by the service
      price_code: priceCode,
      resource_code: resource.resource_code,
      resource_name: resource.resource_name,
      category: resource.resource_type as 'P' | 'M' | 'E' | 'S' | 'C',
      unit: resource.unit,
      quantity: quantity,
      unit_rate: unitRate,
      wastage_percent: wastagePercent,
      total_amount: totalAmount,
      sort_order: resources.length
    });
  };

  const divisionCode = priceCode.substring(0, 2);
  const relevantResources = getRelevantResourcesByDivision(divisionCode, availableResources);

  return (
    <div className="p-4">
      <div className="border rounded-lg overflow-hidden">
        {/* Table Header */}
        <div className="bg-gray-50 border-b">
          <div className="grid grid-cols-12 gap-2 p-2 text-sm font-medium text-gray-700">
            <div className="col-span-2">Resource Code</div>
            <div className="col-span-3">DoD Standard Description</div>
            <div className="col-span-1">Category</div>
            <div className="col-span-1">Unit</div>
            <div className="col-span-1">Quantity</div>
            <div className="col-span-1">Unit Rate</div>
            <div className="col-span-1">Wastage %</div>
            <div className="col-span-1">Total</div>
            <div className="col-span-1">Actions</div>
          </div>
        </div>

        {/* Table Body */}
        <div className="divide-y">
          {resources.map((resource) => (
            <div key={resource.id} className="grid grid-cols-12 gap-2 p-2 items-center hover:bg-gray-50">
              <div className="col-span-2">
                <Input
                  value={resource.resource_code}
                  onChange={(e) => handleResourceUpdate(resource.id, 'resource_code', e.target.value)}
                  placeholder="Resource code"
                  className="text-sm font-mono"
                  disabled={!canEdit}
                />
              </div>
              <div className="col-span-3">
                <Input
                  value={resource.resource_name}
                  onChange={(e) => handleResourceUpdate(resource.id, 'resource_name', e.target.value)}
                  placeholder="DoD resource description"
                  className="text-sm"
                  disabled={!canEdit}
                />
              </div>
              <div className="col-span-1">
                <Select
                  value={resource.category}
                  onValueChange={(value) => handleResourceUpdate(resource.id, 'category', value)}
                  disabled={!canEdit}
                >
                  <SelectTrigger className="text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="P">P - People (Labor)</SelectItem>
                    <SelectItem value="M">M - Material</SelectItem>
                    <SelectItem value="E">E - Equipment</SelectItem>
                    <SelectItem value="S">S - Subcontractor</SelectItem>
                    <SelectItem value="C">C - Consultant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-1">
                <Input
                  value={resource.unit}
                  onChange={(e) => handleResourceUpdate(resource.id, 'unit', e.target.value)}
                  placeholder="Unit"
                  className="text-sm"
                  disabled={!canEdit}
                />
              </div>
              <div className="col-span-1">
                <Input
                  type="number"
                  value={resource.quantity}
                  onChange={(e) => handleResourceUpdate(resource.id, 'quantity', parseFloat(e.target.value) || 0)}
                  step="0.01"
                  className="text-sm"
                  disabled={!canEdit}
                />
              </div>
              <div className="col-span-1">
                <Input
                  type="number"
                  value={resource.unit_rate}
                  onChange={(e) => handleResourceUpdate(resource.id, 'unit_rate', parseFloat(e.target.value) || 0)}
                  step="0.01"
                  className="text-sm"
                  disabled={!canEdit}
                />
              </div>
              <div className="col-span-1">
                <Input
                  type="number"
                  value={resource.wastage_percent}
                  onChange={(e) => handleResourceUpdate(resource.id, 'wastage_percent', parseFloat(e.target.value) || 0)}
                  step="0.1"
                  disabled={resource.category !== 'M' || !canEdit}
                  className="text-sm"
                  placeholder={resource.category === 'M' ? '5.0' : '0'}
                />
              </div>
              <div className="col-span-1">
                <div className="text-sm font-medium text-right">
                  ${resource.total_amount.toFixed(2)}
                </div>
              </div>
              <div className="col-span-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDeleteResource(resource.id)}
                  className="p-1 h-8 w-8"
                  disabled={!canEdit}
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {resources.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            <p>No resources loaded yet</p>
            <p className="text-sm">Click "Load DoD Standards" to auto-populate with division-specific resources</p>
          </div>
        )}
      </div>

      {/* DoD Resource Library Browser */}
      {relevantResources.length > 0 && canEdit && (
        <div className="mt-6">
          <h3 className="text-md font-medium mb-3 flex items-center gap-2">
            Available DoD Standard Resources (Division {divisionCode})
          </h3>
          <div className="border rounded-lg max-h-48 overflow-y-auto">
            <div className="divide-y">
              {relevantResources.map((resource) => (
                <div key={resource.id} className="flex items-center justify-between p-3 hover:bg-gray-50">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm bg-gray-100 px-2 py-1 rounded">
                        {resource.resource_code}
                      </span>
                      <span className="font-medium">{resource.resource_name}</span>
                      <span className={`text-xs px-2 py-1 rounded ${getCategoryColor(resource.resource_type)}`}>
                        {resource.resource_type}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {resource.unit} • ${resource.default_rate} • {resource.dod_reference}
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleAddFromLibrary(resource)}
                    className="ml-2"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
