
import React from 'react';
import { X, Plus, Save, Send, CheckCircle, History, Database, Shield, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PriceCodeVersion } from '@/services/priceCodeVersions';

interface RateAnalysisHeaderProps {
  priceCode: string;
  currentVersion: PriceCodeVersion | null;
  netRate: number;
  onClose: () => void;
  onLoadStandards: () => void;
  onShowHistory: () => void;
  onAddResource: () => void;
  onSave: () => void;
  onSubmit: () => void;
  onApprove: () => void;
  canEdit: boolean;
  canSubmit: boolean;
  canApprove: boolean;
  isSaving: boolean;
  isLoadingStandards: boolean;
}

export function RateAnalysisHeader({
  priceCode,
  currentVersion,
  netRate,
  onClose,
  onLoadStandards,
  onShowHistory,
  onAddResource,
  onSave,
  onSubmit,
  onApprove,
  canEdit,
  canSubmit,
  canApprove,
  isSaving,
  isLoadingStandards
}: RateAnalysisHeaderProps) {
  const getStatusBadge = () => {
    if (!currentVersion) return null;
    
    const status = currentVersion.status;
    const colors = {
      draft: 'bg-yellow-100 text-yellow-800',
      submitted: 'bg-blue-100 text-blue-800',
      approved: 'bg-green-100 text-green-800'
    };

    return (
      <Badge className={colors[status]}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
        {currentVersion.version_number && ` v${currentVersion.version_number}`}
      </Badge>
    );
  };

  return (
    <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-blue-50 to-blue-100">
      <div className="flex items-center gap-3">
        <Shield className="h-5 w-5 text-blue-600" />
        <h2 className="text-lg font-semibold text-blue-900">
          DoD Rate Analysis Sheet
        </h2>
        <span className="text-sm text-gray-600">– {priceCode}</span>
        
        <div className="flex items-center gap-2">
          <Badge className="bg-blue-100 text-blue-800">UFC 3-701-01 Compliant</Badge>
          <Badge className="bg-green-100 text-green-800">Auto-Populated</Badge>
          {getStatusBadge()}
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="text-sm text-gray-600">
          Net Rate: <span className="font-bold text-lg text-blue-600">${netRate.toFixed(2)}</span>
        </div>
        
        <Button 
          onClick={onLoadStandards}
          variant="outline" 
          size="sm"
          disabled={!canEdit || isLoadingStandards}
        >
          {isLoadingStandards ? (
            <Loader2 className="h-4 w-4 mr-1 animate-spin" />
          ) : (
            <Database className="h-4 w-4 mr-1" />
          )}
          Load DoD Standards
        </Button>
        
        <Button 
          onClick={onAddResource}
          variant="outline" 
          size="sm"
          disabled={!canEdit}
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Resource
        </Button>
        
        <Button 
          onClick={onShowHistory}
          variant="outline" 
          size="sm"
        >
          <History className="h-4 w-4 mr-1" />
          History
        </Button>
        
        {canEdit && (
          <Button 
            onClick={onSave}
            disabled={isSaving}
          >
            {isSaving ? (
              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-1" />
            )}
            Save
          </Button>
        )}
        
        {canSubmit && (
          <Button 
            onClick={onSubmit}
            variant="outline"
          >
            <Send className="h-4 w-4 mr-1" />
            Submit for Approval
          </Button>
        )}
        
        {canApprove && (
          <Button 
            onClick={onApprove}
            variant="default"
          >
            <CheckCircle className="h-4 w-4 mr-1" />
            Approve
          </Button>
        )}
        
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
