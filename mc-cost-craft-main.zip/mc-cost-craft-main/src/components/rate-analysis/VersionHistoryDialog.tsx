
import React from 'react';
import { X, Clock, User, CheckCircle, Send, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { PriceCodeVersion } from '@/services/priceCodeVersions';

interface VersionHistoryDialogProps {
  versions: PriceCodeVersion[];
  onClose: () => void;
}

export function VersionHistoryDialog({ versions, onClose }: VersionHistoryDialogProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'draft':
        return <Edit className="h-4 w-4" />;
      case 'submitted':
        return <Send className="h-4 w-4" />;
      case 'approved':
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft':
        return 'bg-yellow-100 text-yellow-800';
      case 'submitted':
        return 'bg-blue-100 text-blue-800';
      case 'approved':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-60">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl h-3/4">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">Version History</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Content */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {versions.map((version) => (
              <div key={version.id} className="border rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(version.status)}
                      <span className="font-medium">Version {version.version_number}</span>
                    </div>
                    <Badge className={getStatusColor(version.status)}>
                      {version.status.charAt(0).toUpperCase() + version.status.slice(1)}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-500">
                    {new Date(version.created_at).toLocaleDateString()}
                  </div>
                </div>

                {version.change_summary && (
                  <div className="mt-2 text-sm text-gray-700">
                    <strong>Changes:</strong> {version.change_summary}
                  </div>
                )}

                <div className="mt-3 flex items-center gap-4 text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <User className="h-3 w-3" />
                    Created by {version.created_by}
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {new Date(version.created_at).toLocaleString()}
                  </div>
                </div>

                {version.approved_by && version.approved_at && (
                  <div className="mt-2 flex items-center gap-1 text-xs text-green-600">
                    <CheckCircle className="h-3 w-3" />
                    Approved by {version.approved_by} on {new Date(version.approved_at).toLocaleString()}
                  </div>
                )}
              </div>
            ))}

            {versions.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Clock className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No version history available</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
