import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Trash2, Edit, Plus, Building2, ArrowRight } from 'lucide-react';
import { Company, COUNTRIES, CURRENCIES } from '@/types/mccost';
import { companiesService } from '@/services/companies';
import { useToast } from '@/hooks/use-toast';

export function CompanyManager() {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCompany, setEditingCompany] = useState<Company | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  const loadCompanies = async () => {
    try {
      setIsLoading(true);
      const data = await companiesService.getAll();
      setCompanies(data);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to load companies: ' + error.message,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const companyData = {
      name: formData.get('name') as string,
      code: formData.get('code') as string,
      country: formData.get('country') as string,
      base_currency: formData.get('base_currency') as string,
      logo_url: formData.get('logo_url') as string || undefined,
      notes: formData.get('notes') as string || undefined,
    };

    try {
      if (editingCompany) {
        await companiesService.update(editingCompany.id, companyData);
        toast({ title: 'Success', description: 'Company updated successfully' });
      } else {
        await companiesService.create(companyData);
        toast({ title: 'Success', description: 'Company created successfully' });
      }
      
      setIsDialogOpen(false);
      setEditingCompany(null);
      loadCompanies();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const handleEdit = (company: Company) => {
    setEditingCompany(company);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this company?')) return;
    
    try {
      await companiesService.delete(id);
      toast({ title: 'Success', description: 'Company deleted successfully' });
      loadCompanies();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const handleCompanyClick = (companyId: string) => {
    navigate(`/mccost/companies/${companyId}/jobs`);
  };

  useEffect(() => {
    loadCompanies();
  }, []);

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Companies</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingCompany(null)}>
              <Plus className="mr-2 h-4 w-4" />
              Add Company
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingCompany ? 'Edit Company' : 'Add New Company'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Company Name</Label>
                <Input
                  id="name"
                  name="name"
                  defaultValue={editingCompany?.name || ''}
                  required
                />
              </div>
              <div>
                <Label htmlFor="code">Company Code</Label>
                <Input
                  id="code"
                  name="code"
                  defaultValue={editingCompany?.code || ''}
                  required
                />
              </div>
              <div>
                <Label htmlFor="country">Country</Label>
                <Select name="country" defaultValue={editingCompany?.country || ''}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {COUNTRIES.map((country) => (
                      <SelectItem key={country.code} value={country.code}>
                        {country.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="base_currency">Base Currency</Label>
                <Select name="base_currency" defaultValue={editingCompany?.base_currency || ''}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {CURRENCIES.map((currency) => (
                      <SelectItem key={currency.code} value={currency.code}>
                        {currency.code} - {currency.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="logo_url">Logo URL</Label>
                <Input
                  id="logo_url"
                  name="logo_url"
                  type="url"
                  defaultValue={editingCompany?.logo_url || ''}
                />
              </div>
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  name="notes"
                  defaultValue={editingCompany?.notes || ''}
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  {editingCompany ? 'Update' : 'Create'} Company
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div>Loading companies...</div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {companies.map((company) => (
            <Card key={company.id} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    {company.name}
                  </div>
                </CardTitle>
                <div className="flex space-x-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEdit(company);
                    }}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(company.id);
                    }}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent onClick={() => handleCompanyClick(company.id)}>
                <CardDescription>
                  <div className="space-y-1 text-xs">
                    <div>Code: {company.code}</div>
                    <div>Country: {company.country}</div>
                    <div>Currency: {company.base_currency}</div>
                    {company.notes && <div>Notes: {company.notes}</div>}
                  </div>
                  <div className="flex items-center justify-end mt-2 text-primary">
                    <span className="text-xs mr-1">View Jobs</span>
                    <ArrowRight className="h-3 w-3" />
                  </div>
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
