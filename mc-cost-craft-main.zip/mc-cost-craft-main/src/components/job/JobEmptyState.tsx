
import { Button } from '@/components/ui/button';
import { Briefcase, Plus } from 'lucide-react';

interface JobEmptyStateProps {
  onAddJob: () => void;
}

export function JobEmptyState({ onAddJob }: JobEmptyStateProps) {
  return (
    <div className="text-center py-8">
      <Briefcase className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium mb-2">No jobs found</h3>
      <p className="text-muted-foreground mb-4">Create your first job to get started</p>
      <Button onClick={onAddJob}>
        <Plus className="mr-2 h-4 w-4" />
        Add Job
      </Button>
    </div>
  );
}
