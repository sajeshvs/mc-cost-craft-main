
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Company } from '@/types/mccost';

interface JobHeaderProps {
  company: Company | null;
  onBack: () => void;
}

export function JobHeader({ company, onBack }: JobHeaderProps) {
  return (
    <div className="flex items-center gap-4 mb-4">
      <Button variant="outline" onClick={onBack}>
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Companies
      </Button>
      {company && (
        <div>
          <h2 className="text-2xl font-bold">{company.name} - Jobs</h2>
          <p className="text-muted-foreground">Manage jobs for {company.name}</p>
        </div>
      )}
    </div>
  );
}
