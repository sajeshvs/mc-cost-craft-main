
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus } from 'lucide-react';
import { Job, Company } from '@/types/mccost';
import { jobsService } from '@/services/jobs';
import { companiesService } from '@/services/companies';
import { useToast } from '@/hooks/use-toast';
import { JobHeader } from './JobHeader';
import { JobCard } from './JobCard';
import { JobForm } from './JobForm';
import { JobEmptyState } from './JobEmptyState';

export function JobManager() {
  const { companyId } = useParams<{ companyId: string }>();
  const navigate = useNavigate();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [company, setCompany] = useState<Company | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingJob, setEditingJob] = useState<Job | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  const loadJobs = async () => {
    if (!companyId) return;
    
    try {
      setIsLoading(true);
      const data = await jobsService.getByCompany(companyId);
      setJobs(data);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to load jobs: ' + error.message,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadCompany = async () => {
    if (!companyId) return;
    
    try {
      const data = await companiesService.getById(companyId);
      setCompany(data);
    } catch (error: any) {
      console.error('Failed to load company:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!companyId) return;
    
    const formData = new FormData(e.currentTarget);
    
    const jobData = {
      name: formData.get('name') as string,
      client: formData.get('client') as string,
      project_location: formData.get('project_location') as string,
      currency: formData.get('currency') as string,
      company_id: companyId,
      logo_url: formData.get('logo_url') as string || undefined,
      notes: formData.get('notes') as string || undefined,
    };

    try {
      if (editingJob) {
        await jobsService.update(editingJob.id, jobData);
        toast({ title: 'Success', description: 'Job updated successfully' });
      } else {
        await jobsService.create(jobData);
        toast({ title: 'Success', description: 'Job created successfully' });
      }
      
      setIsDialogOpen(false);
      setEditingJob(null);
      loadJobs();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const handleEdit = (job: Job) => {
    setEditingJob(job);
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this job?')) return;
    
    try {
      await jobsService.delete(id);
      toast({ title: 'Success', description: 'Job deleted successfully' });
      loadJobs();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const handleJobClick = (jobId: string) => {
    navigate(`/mccost/jobs/${jobId}/boq`);
  };

  const handleImportBOQ = (jobId: string) => {
    navigate(`/mccost/jobs/${jobId}/import-boq`);
  };

  const handleAddJob = () => {
    setEditingJob(null);
    setIsDialogOpen(true);
  };

  const handleBack = () => {
    navigate('/mccost/companies');
  };

  useEffect(() => {
    if (companyId) {
      loadJobs();
      loadCompany();
    }
  }, [companyId]);

  if (!companyId) {
    return <div>Company ID is required</div>;
  }

  return (
    <div className="space-y-4">
      <JobHeader company={company} onBack={handleBack} />

      <div className="flex justify-between items-center">
        <h3 className="text-xl font-semibold">Jobs</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleAddJob}>
              <Plus className="mr-2 h-4 w-4" />
              Add Job
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingJob ? 'Edit Job' : 'Add New Job'}
              </DialogTitle>
            </DialogHeader>
            <JobForm
              editingJob={editingJob}
              company={company}
              onSubmit={handleSubmit}
              onCancel={() => setIsDialogOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div>Loading jobs...</div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {jobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onJobClick={handleJobClick}
              onImportBOQ={handleImportBOQ}
            />
          ))}
        </div>
      )}

      {jobs.length === 0 && !isLoading && (
        <JobEmptyState onAddJob={handleAddJob} />
      )}
    </div>
  );
}
