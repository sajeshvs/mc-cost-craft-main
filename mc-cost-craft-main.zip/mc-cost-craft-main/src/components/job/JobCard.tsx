
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Trash2, Edit, Briefcase, FileSpreadsheet, ArrowRight } from 'lucide-react';
import { Job } from '@/types/mccost';

interface JobCardProps {
  job: Job;
  onEdit: (job: Job) => void;
  onDelete: (id: string) => void;
  onJobClick: (jobId: string) => void;
  onImportBOQ: (jobId: string) => void;
}

export function JobCard({ job, onEdit, onDelete, onJobClick, onImportBOQ }: JobCardProps) {
  return (
    <Card className="cursor-pointer hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">
          <div className="flex items-center gap-2">
            <Briefcase className="h-4 w-4" />
            {job.name}
          </div>
        </CardTitle>
        <div className="flex space-x-1">
          <Button
            variant="outline"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onImportBOQ(job.id);
            }}
            title="Import BOQ"
          >
            <FileSpreadsheet className="h-3 w-3" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(job);
            }}
          >
            <Edit className="h-3 w-3" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(job.id);
            }}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </CardHeader>
      <CardContent onClick={() => onJobClick(job.id)}>
        <CardDescription>
          <div className="space-y-1 text-xs">
            <div>Client: {job.client}</div>
            <div>Location: {job.project_location}</div>
            <div>Currency: {job.currency}</div>
            {job.notes && <div>Notes: {job.notes}</div>}
          </div>
          <div className="flex items-center justify-end mt-2 text-primary">
            <span className="text-xs mr-1">View BOQ</span>
            <ArrowRight className="h-3 w-3" />
          </div>
        </CardDescription>
      </CardContent>
    </Card>
  );
}
