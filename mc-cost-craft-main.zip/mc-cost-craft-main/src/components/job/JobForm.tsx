
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Job, Company, CURRENCIES } from '@/types/mccost';

interface JobFormProps {
  editingJob: Job | null;
  company: Company | null;
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => Promise<void>;
  onCancel: () => void;
}

export function JobForm({ editingJob, company, onSubmit, onCancel }: JobFormProps) {
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Job Name</Label>
        <Input
          id="name"
          name="name"
          defaultValue={editingJob?.name || ''}
          required
        />
      </div>
      <div>
        <Label htmlFor="client">Client</Label>
        <Input
          id="client"
          name="client"
          defaultValue={editingJob?.client || ''}
          required
        />
      </div>
      <div>
        <Label htmlFor="project_location">Project Location</Label>
        <Input
          id="project_location"
          name="project_location"
          defaultValue={editingJob?.project_location || ''}
          required
        />
      </div>
      <div>
        <Label htmlFor="currency">Currency</Label>
        <Select name="currency" defaultValue={editingJob?.currency || company?.base_currency || ''}>
          <SelectTrigger>
            <SelectValue placeholder="Select currency" />
          </SelectTrigger>
          <SelectContent>
            {CURRENCIES.map((currency) => (
              <SelectItem key={currency.code} value={currency.code}>
                {currency.code} - {currency.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label htmlFor="logo_url">Logo URL</Label>
        <Input
          id="logo_url"
          name="logo_url"
          type="url"
          defaultValue={editingJob?.logo_url || ''}
        />
      </div>
      <div>
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          name="notes"
          defaultValue={editingJob?.notes || ''}
        />
      </div>
      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {editingJob ? 'Update' : 'Create'} Job
        </Button>
      </div>
    </form>
  );
}
