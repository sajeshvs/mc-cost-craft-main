
import { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Card } from '@/components/ui/card';
import { Building2, Briefcase, FileSpreadsheet, Calculator, Users, Settings, Menu, LogOut } from 'lucide-react';
import { useAuth } from '@/components/auth/AuthProvider';
import { useToast } from '@/hooks/use-toast';

const navigation = [
  { name: 'Companies', href: '/mccost/companies', icon: Building2 },
  { name: 'Jobs', href: '/mccost/jobs', icon: Briefcase },
  { name: 'BOQ Import', href: '/mccost/boq-import', icon: FileSpreadsheet },
  { name: 'Pricing', href: '/mccost/pricing', icon: Calculator },
  { name: 'Resources', href: '/mccost/resources', icon: Users },
  { name: 'Reports', href: '/mccost/reports', icon: Settings },
];

export function McCostLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const location = useLocation();
  const { user, signOut } = useAuth();
  const { toast } = useToast();

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: 'Success',
        description: 'Signed out successfully'
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const NavItems = () => (
    <nav className="space-y-2">
      {navigation.map((item) => {
        const isActive = location.pathname === item.href || 
          (item.href === '/mccost/companies' && location.pathname.startsWith('/mccost/companies')) ||
          (item.href === '/mccost/jobs' && location.pathname.startsWith('/mccost/jobs')) ||
          (item.href === '/mccost/boq-import' && location.pathname.startsWith('/mccost/boq-import'));
        return (
          <Link
            key={item.name}
            to={item.href}
            className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              isActive
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
            onClick={() => setSidebarOpen(false)}
          >
            <item.icon className="h-4 w-4" />
            {item.name}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-14 items-center px-4">
          <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="sm" className="md:hidden">
                <Menu className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64">
              <div className="py-4">
                <h2 className="text-lg font-semibold mb-4">McCost</h2>
                <NavItems />
              </div>
            </SheetContent>
          </Sheet>
          
          <div className="flex items-center gap-2 ml-2">
            <Calculator className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold">McCost</h1>
          </div>
          
          <div className="ml-auto flex items-center gap-2">
            <span className="text-sm text-muted-foreground">{user?.email}</span>
            <Button variant="outline" size="sm" onClick={handleSignOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Desktop Sidebar */}
        <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 md:pt-14">
          <Card className="flex-1 m-4 p-4">
            <NavItems />
          </Card>
        </aside>

        {/* Main Content */}
        <main className="flex-1 md:pl-64">
          <div className="p-6">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
