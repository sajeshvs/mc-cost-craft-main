
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Download, RefreshCw, Trash2, X } from 'lucide-react';
import { MarkupMode, MARKUP_TYPES } from '@/types/markup';

interface MarkupToolbarProps {
  mode: MarkupMode;
  projectId: string;
  searchTerm: string;
  onSearchChange: (value: string) => void;
  filters: {
    division: string;
    markupType: string;
    minPercent: string;
    maxPercent: string;
  };
  onFilterChange: (key: string, value: string) => void;
  onClearFilters: () => void;
  selectedCount: number;
}

export function MarkupToolbar({
  mode,
  searchTerm,
  onSearchChange,
  filters,
  onFilterChange,
  onClearFilters,
  selectedCount
}: MarkupToolbarProps) {
  const hasActiveFilters = Object.values(filters).some(filter => filter !== '') || searchTerm !== '';

  // Filter valid markup types to prevent empty values
  const validMarkupTypes = MARKUP_TYPES.filter(type => 
    type && 
    typeof type === 'object' &&
    type.value && 
    typeof type.value === 'string' &&
    type.value.trim() !== '' &&
    type.label &&
    typeof type.label === 'string' &&
    type.label.trim() !== ''
  );

  const handleExportExcel = () => {
    // TODO: Implement Excel export
    console.log('Export to Excel');
  };

  const handleRefresh = () => {
    // TODO: Implement refresh
    console.log('Refresh markup data');
  };

  const handleAddMarkup = () => {
    // TODO: Implement add markup
    console.log('Add markup item');
  };

  const handleDeleteSelected = () => {
    // TODO: Implement delete selected
    console.log('Delete selected items');
  };

  return (
    <div className="flex flex-col gap-4 mb-6">
      {/* Main Toolbar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-sm">
            {mode === 'trade' ? 'Trade Mode' : 'Item Mode'}
          </Badge>
          
          <Input
            placeholder={`Search by ${mode === 'trade' ? 'trade code' : 'BOQ ref'}...`}
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="max-w-sm"
          />
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleAddMarkup}
            className="gap-2"
          >
            <Plus className="h-4 w-4" />
            Add Markup
          </Button>

          {selectedCount > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleDeleteSelected}
              className="gap-2 text-red-600 hover:text-red-700"
            >
              <Trash2 className="h-4 w-4" />
              Delete ({selectedCount})
            </Button>
          )}

          <Button
            variant="outline"
            size="sm"
            onClick={handleExportExcel}
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            Export Excel
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            className="gap-2"
          >
            <RefreshCw className="h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
        <span className="text-sm font-medium text-gray-700">Filters:</span>
        
        <Select value={filters.division} onValueChange={(value) => onFilterChange('division', value || '')}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Division" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All Divisions</SelectItem>
            <SelectItem value="01">01 - General</SelectItem>
            <SelectItem value="02">02 - Existing</SelectItem>
            <SelectItem value="03">03 - Concrete</SelectItem>
            <SelectItem value="04">04 - Masonry</SelectItem>
            <SelectItem value="05">05 - Metals</SelectItem>
            <SelectItem value="06">06 - Wood</SelectItem>
            <SelectItem value="07">07 - Thermal</SelectItem>
            <SelectItem value="08">08 - Openings</SelectItem>
            <SelectItem value="09">09 - Finishes</SelectItem>
            <SelectItem value="26">26 - Electrical</SelectItem>
          </SelectContent>
        </Select>

        <Select value={filters.markupType} onValueChange={(value) => onFilterChange('markupType', value || '')}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Markup Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">All Types</SelectItem>
            {validMarkupTypes.map(type => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Input
          placeholder="Min %"
          value={filters.minPercent}
          onChange={(e) => onFilterChange('minPercent', e.target.value)}
          className="w-20"
          type="number"
        />

        <Input
          placeholder="Max %"
          value={filters.maxPercent}
          onChange={(e) => onFilterChange('maxPercent', e.target.value)}
          className="w-20"
          type="number"
        />

        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearFilters}
            className="gap-2 text-gray-600"
          >
            <X className="h-4 w-4" />
            Clear
          </Button>
        )}
      </div>
    </div>
  );
}
