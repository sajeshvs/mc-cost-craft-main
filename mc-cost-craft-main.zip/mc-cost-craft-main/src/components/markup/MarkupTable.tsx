
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, Edit2 } from 'lucide-react';
import { MarkupItem, MARKUP_TYPES } from '@/types/markup';
import { useMarkupItems, useCreateMarkupItem, useUpdateMarkupItem, useDeleteMarkupItem } from '@/hooks/useMarkup';

interface MarkupTableProps {
  projectId: string;
  refType: 'trade' | 'item';
  refId: string;
  refDescription: string;
  baseAmount: number;
}

export function MarkupTable({ projectId, refType, refId, refDescription, baseAmount }: MarkupTableProps) {
  const [newMarkupType, setNewMarkupType] = useState<string>('');
  const [newMarkupPercent, setNewMarkupPercent] = useState<number>(0);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingPercent, setEditingPercent] = useState<number>(0);

  const { data: markupItems = [], isLoading } = useMarkupItems(projectId);
  const createMarkupItem = useCreateMarkupItem(projectId);
  const updateMarkupItem = useUpdateMarkupItem(projectId);
  const deleteMarkupItem = useDeleteMarkupItem(projectId);

  const filteredItems = markupItems.filter(item => 
    item.ref_type === refType && item.ref_id === refId
  );

  const handleAddMarkup = () => {
    if (newMarkupType && newMarkupPercent > 0) {
      const markupValue = baseAmount * (newMarkupPercent / 100);
      const totalWithMarkup = baseAmount + markupValue;

      createMarkupItem.mutate({
        project_id: projectId,
        ref_type: refType,
        ref_id: refId,
        ref_description: refDescription,
        base_amount: baseAmount,
        markup_type: newMarkupType as 'Site Overhead' | 'H.O G&A' | 'Profit' | 'Contingencies' | 'Escalation' | 'Tax' | 'Other',
        markup_percent: newMarkupPercent,
        markup_value: markupValue,
        total_with_markup: totalWithMarkup
      });

      setNewMarkupType('');
      setNewMarkupPercent(0);
    }
  };

  const handleUpdateMarkup = (id: string) => {
    if (editingPercent >= 0) {
      const markupValue = baseAmount * (editingPercent / 100);
      const totalWithMarkup = baseAmount + markupValue;

      updateMarkupItem.mutate({
        id,
        updates: {
          markup_percent: editingPercent,
          markup_value: markupValue,
          total_with_markup: totalWithMarkup
        }
      });

      setEditingId(null);
      setEditingPercent(0);
    }
  };

  const handleDeleteMarkup = (id: string) => {
    deleteMarkupItem.mutate(id);
  };

  const startEdit = (item: MarkupItem) => {
    setEditingId(item.id);
    setEditingPercent(item.markup_percent);
  };

  const totalMarkup = filteredItems.reduce((sum, item) => sum + item.markup_value, 0);
  const grandTotal = baseAmount + totalMarkup;

  if (isLoading) {
    return <div className="p-4 text-center">Loading markup data...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Markup Details</h3>
        <div className="text-sm text-gray-600">
          Base: ${baseAmount.toLocaleString()} | Total: ${grandTotal.toLocaleString()}
        </div>
      </div>

      <div className="border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="p-3 text-left font-medium">Type</th>
              <th className="p-3 text-center font-medium">Percentage</th>
              <th className="p-3 text-right font-medium">Value</th>
              <th className="p-3 text-right font-medium">Total</th>
              <th className="p-3 text-center font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredItems.map(item => (
              <tr key={item.id} className="hover:bg-gray-50">
                <td className="p-3">
                  <Badge className={MARKUP_TYPES.find(t => t.value === item.markup_type)?.color}>
                    {item.markup_type}
                  </Badge>
                </td>
                <td className="p-3 text-center">
                  {editingId === item.id ? (
                    <Input
                      type="number"
                      value={editingPercent}
                      onChange={(e) => setEditingPercent(Number(e.target.value))}
                      className="w-20 text-center"
                      step="0.1"
                      min="0"
                    />
                  ) : (
                    `${item.markup_percent}%`
                  )}
                </td>
                <td className="p-3 text-right font-mono">
                  ${item.markup_value.toLocaleString()}
                </td>
                <td className="p-3 text-right font-mono font-medium">
                  ${item.total_with_markup.toLocaleString()}
                </td>
                <td className="p-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    {editingId === item.id ? (
                      <>
                        <Button
                          size="sm"
                          onClick={() => handleUpdateMarkup(item.id)}
                          className="h-7 px-2"
                        >
                          Save
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditingId(null)}
                          className="h-7 px-2"
                        >
                          Cancel
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => startEdit(item)}
                          className="h-7 w-7 p-0"
                        >
                          <Edit2 className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeleteMarkup(item.id)}
                          className="h-7 w-7 p-0 text-red-600"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add New Markup */}
      <div className="border rounded-lg p-4 bg-gray-50">
        <h4 className="font-medium mb-3">Add New Markup</h4>
        <div className="flex items-center gap-3">
          <Select value={newMarkupType} onValueChange={setNewMarkupType}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              {MARKUP_TYPES.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Input
            type="number"
            placeholder="Percentage"
            value={newMarkupPercent}
            onChange={(e) => setNewMarkupPercent(Number(e.target.value))}
            className="w-24"
            step="0.1"
            min="0"
          />
          
          <Button 
            onClick={handleAddMarkup}
            disabled={!newMarkupType || newMarkupPercent <= 0}
            className="gap-1"
          >
            <Plus className="h-4 w-4" />
            Add Markup
          </Button>
        </div>
      </div>
    </div>
  );
}
