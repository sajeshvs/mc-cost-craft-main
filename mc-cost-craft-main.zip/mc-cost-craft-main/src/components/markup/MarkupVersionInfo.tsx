
import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, User, CheckCircle, Archive, FileText } from 'lucide-react';
import { MarkupVersion, WORKFLOW_STATUS_COLORS, WORKFLOW_STATUS_LABELS } from '@/types/markup';

interface MarkupVersionInfoProps {
  currentVersion: MarkupVersion | null;
  allVersions: MarkupVersion[];
  onVersionSelect: (version: MarkupVersion) => void;
  onViewHistory: () => void;
  isReadOnly?: boolean;
}

export function MarkupVersionInfo({
  currentVersion,
  allVersions,
  onVersionSelect,
  onViewHistory,
  isReadOnly = false
}: MarkupVersionInfoProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'draft':
        return <FileText className="h-3 w-3" />;
      case 'submitted':
        return <Clock className="h-3 w-3" />;
      case 'approved':
        return <CheckCircle className="h-3 w-3" />;
      case 'archived':
        return <Archive className="h-3 w-3" />;
      default:
        return <FileText className="h-3 w-3" />;
    }
  };

  if (!currentVersion) {
    return (
      <div className="flex items-center gap-2 text-sm text-gray-500">
        <FileText className="h-4 w-4" />
        No version available
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg border">
      {/* Current Version Status */}
      <div className="flex items-center gap-2">
        <Badge className={WORKFLOW_STATUS_COLORS[currentVersion.status as keyof typeof WORKFLOW_STATUS_COLORS]}>
          {getStatusIcon(currentVersion.status)}
          <span className="ml-1">
            {WORKFLOW_STATUS_LABELS[currentVersion.status as keyof typeof WORKFLOW_STATUS_LABELS]}
          </span>
        </Badge>
        <span className="text-sm font-medium">
          M-{String(currentVersion.version_number).padStart(3, '0')}
        </span>
      </div>

      {/* Version Details */}
      <div className="text-xs text-gray-600">
        {currentVersion.status === 'approved' && currentVersion.approved_at ? (
          <span>Approved on {new Date(currentVersion.approved_at).toLocaleDateString()}</span>
        ) : (
          <span>Created on {new Date(currentVersion.created_at).toLocaleDateString()}</span>
        )}
      </div>

      {/* Version Selector */}
      {!isReadOnly && allVersions.length > 1 && (
        <Select
          value={currentVersion.id}
          onValueChange={(versionId) => {
            const version = allVersions.find(v => v.id === versionId);
            if (version) onVersionSelect(version);
          }}
        >
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {allVersions.map((version) => (
              <SelectItem key={version.id} value={version.id}>
                <div className="flex items-center gap-2">
                  {getStatusIcon(version.status)}
                  <span>M-{String(version.version_number).padStart(3, '0')}</span>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${WORKFLOW_STATUS_COLORS[version.status as keyof typeof WORKFLOW_STATUS_COLORS]}`}
                  >
                    {WORKFLOW_STATUS_LABELS[version.status as keyof typeof WORKFLOW_STATUS_LABELS]}
                  </Badge>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {/* History Button */}
      <Button
        variant="outline"
        size="sm"
        onClick={onViewHistory}
        className="gap-1"
      >
        <Clock className="h-3 w-3" />
        History
      </Button>
    </div>
  );
}
