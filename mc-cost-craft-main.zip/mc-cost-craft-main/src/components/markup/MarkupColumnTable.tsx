
import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Trash2, Eye, EyeOff } from 'lucide-react';
import { MarkupMode, MarkupEntry, MarkupConfig, DEFAULT_MARKUP_TYPES } from '@/types/markup';
import { useTradeMarkupData, useItemMarkupData } from '@/hooks/useMarkup';

interface MarkupColumnTableProps {
  mode: MarkupMode;
  projectId: string;
  entries: MarkupEntry[];
  configs: MarkupConfig[];
  onUpdateEntry: (id: string, updates: Partial<MarkupEntry>) => void;
  onAddCustomColumn: (label: string, defaultPercent: number) => void;
  onToggleColumnVisibility: (configId: string) => void;
  onResetMarkup: (entryIds: string[]) => void;
  searchTerm: string;
}

export function MarkupColumnTable({
  mode,
  projectId,
  entries,
  configs,
  onUpdateEntry,
  onAddCustomColumn,
  onToggleColumnVisibility,
  onResetMarkup,
  searchTerm
}: MarkupColumnTableProps) {
  const [selectedEntries, setSelectedEntries] = useState<Set<string>>(new Set());
  const [columnVisibility, setColumnVisibility] = useState<{ [key: string]: boolean }>({});
  const [newColumnLabel, setNewColumnLabel] = useState('');
  const [newColumnPercent, setNewColumnPercent] = useState(0);
  const [showAddColumn, setShowAddColumn] = useState(false);

  const { data: tradeData = [] } = useTradeMarkupData(projectId);
  const { data: itemData = [] } = useItemMarkupData(projectId);

  const baseData = mode === 'trade' ? tradeData : itemData;

  const filteredEntries = entries.filter(entry => {
    if (searchTerm) {
      return entry.ref_description.toLowerCase().includes(searchTerm.toLowerCase()) ||
             entry.ref_id.toLowerCase().includes(searchTerm.toLowerCase());
    }
    return true;
  });

  const calculateTotalMarkup = useCallback((entry: MarkupEntry) => {
    const defaultMarkup = (entry.site_overhead_percent + entry.ho_ga_percent + entry.profit_percent + entry.contingencies_percent + entry.escalation_percent) / 100;
    const customMarkup = Object.values(entry.custom_markups || {}).reduce((sum, percent) => sum + percent, 0) / 100;
    return entry.base_amount * (defaultMarkup + customMarkup);
  }, []);

  const calculateGrandTotal = useCallback((entry: MarkupEntry) => {
    return entry.base_amount + calculateTotalMarkup(entry);
  }, [calculateTotalMarkup]);

  const handlePercentChange = (entryId: string, field: string, value: number) => {
    const entry = entries.find(e => e.id === entryId);
    if (!entry) return;

    let updates: Partial<MarkupEntry>;
    
    if (field.startsWith('custom_')) {
      const customKey = field.replace('custom_', '');
      updates = {
        custom_markups: {
          ...entry.custom_markups,
          [customKey]: value
        }
      };
    } else {
      updates = { [field]: value };
    }

    // Calculate new totals
    const updatedEntry = { ...entry, ...updates };
    const totalMarkup = calculateTotalMarkup(updatedEntry);
    const grandTotal = calculateGrandTotal(updatedEntry);

    onUpdateEntry(entryId, {
      ...updates,
      total_markup_value: totalMarkup,
      grand_total: grandTotal
    });
  };

  const handleSelectEntry = (entryId: string) => {
    setSelectedEntries(prev => {
      const newSet = new Set(prev);
      if (newSet.has(entryId)) {
        newSet.delete(entryId);
      } else {
        newSet.add(entryId);
      }
      return newSet;
    });
  };

  const handleSelectAll = () => {
    if (selectedEntries.size === filteredEntries.length) {
      setSelectedEntries(new Set());
    } else {
      setSelectedEntries(new Set(filteredEntries.map(entry => entry.id)));
    }
  };

  const handleAddCustomColumn = () => {
    if (newColumnLabel.trim()) {
      onAddCustomColumn(newColumnLabel.trim(), newColumnPercent);
      setNewColumnLabel('');
      setNewColumnPercent(0);
      setShowAddColumn(false);
    }
  };

  const getConfigId = (config: typeof DEFAULT_MARKUP_TYPES[0] | MarkupConfig) => {
    return 'key' in config ? config.key : config.id;
  };

  const getConfigLabel = (config: typeof DEFAULT_MARKUP_TYPES[0] | MarkupConfig) => {
    return config.label;
  };

  const visibleConfigs = configs.filter(config => columnVisibility[config.id] !== false);
  const allConfigs = [...DEFAULT_MARKUP_TYPES, ...configs.filter(c => c.type === 'custom')];

  return (
    <div className="flex flex-col h-full">
      {/* Column Controls */}
      <div className="flex items-center justify-between p-3 border-b bg-gray-50">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Columns:</span>
          {allConfigs.map(config => {
            const configId = getConfigId(config);
            const configLabel = getConfigLabel(config);
            return (
              <Button
                key={configId}
                variant="outline"
                size="sm"
                onClick={() => onToggleColumnVisibility(configId)}
                className="gap-1"
              >
                {columnVisibility[configId] === false ? (
                  <EyeOff className="h-3 w-3" />
                ) : (
                  <Eye className="h-3 w-3" />
                )}
                {configLabel}
              </Button>
            );
          })}
        </div>
        
        <div className="flex items-center gap-2">
          {selectedEntries.size > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onResetMarkup(Array.from(selectedEntries))}
              className="gap-1 text-red-600"
            >
              <Trash2 className="h-3 w-3" />
              Reset Selected
            </Button>
          )}
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAddColumn(!showAddColumn)}
            className="gap-1"
          >
            <Plus className="h-3 w-3" />
            Add Column
          </Button>
        </div>
      </div>

      {/* Add Column Form */}
      {showAddColumn && (
        <div className="p-3 border-b bg-blue-50">
          <div className="flex items-center gap-2">
            <Input
              placeholder="Column Label"
              value={newColumnLabel}
              onChange={(e) => setNewColumnLabel(e.target.value)}
              className="w-40"
            />
            <Input
              type="number"
              placeholder="Default %"
              value={newColumnPercent}
              onChange={(e) => setNewColumnPercent(Number(e.target.value))}
              className="w-24"
            />
            <Button onClick={handleAddCustomColumn} size="sm">
              Add
            </Button>
            <Button onClick={() => setShowAddColumn(false)} variant="outline" size="sm">
              Cancel
            </Button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-gray-50 border-b">
            <tr>
              <th className="w-8 p-2 text-left">
                <Checkbox
                  checked={selectedEntries.size === filteredEntries.length && filteredEntries.length > 0}
                  onCheckedChange={handleSelectAll}
                />
              </th>
              <th className="p-2 text-left font-medium min-w-[100px]">BOQ Ref</th>
              <th className="p-2 text-left font-medium min-w-[200px]">Description</th>
              <th className="p-2 text-right font-medium min-w-[100px]">Base Rate ($)</th>
              
              {/* Default Markup Columns */}
              {DEFAULT_MARKUP_TYPES.map(type => (
                columnVisibility[type.key] !== false && (
                  <th key={type.key} className="p-2 text-center font-medium min-w-[80px]">
                    {type.label} %
                  </th>
                )
              ))}
              
              {/* Custom Markup Columns */}
              {configs.filter(c => c.type === 'custom' && columnVisibility[c.id] !== false).map(config => (
                <th key={config.id} className="p-2 text-center font-medium min-w-[80px]">
                  {config.label} %
                </th>
              ))}
              
              <th className="p-2 text-right font-medium min-w-[120px]">Total Markup ($)</th>
              <th className="p-2 text-right font-medium min-w-[120px]">Grand Total ($)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredEntries.map(entry => (
              <tr key={entry.id} className="hover:bg-gray-50">
                <td className="p-2">
                  <Checkbox
                    checked={selectedEntries.has(entry.id)}
                    onCheckedChange={() => handleSelectEntry(entry.id)}
                  />
                </td>
                <td className="p-2 font-mono text-xs">{entry.ref_id}</td>
                <td className="p-2 text-sm">{entry.ref_description}</td>
                <td className="p-2 text-right font-mono text-sm">
                  ${entry.base_amount.toLocaleString()}
                </td>
                
                {/* Default Markup Columns */}
                {DEFAULT_MARKUP_TYPES.map(type => (
                  columnVisibility[type.key] !== false && (
                    <td key={type.key} className="p-2 text-center">
                      <Input
                        type="number"
                        value={entry[`${type.key}_percent` as keyof MarkupEntry] as number || 0}
                        onChange={(e) => handlePercentChange(entry.id, `${type.key}_percent`, Number(e.target.value))}
                        className="w-16 text-center text-xs"
                        step="0.1"
                        min="0"
                      />
                    </td>
                  )
                ))}
                
                {/* Custom Markup Columns */}
                {configs.filter(c => c.type === 'custom' && columnVisibility[c.id] !== false).map(config => (
                  <td key={config.id} className="p-2 text-center">
                    <Input
                      type="number"
                      value={entry.custom_markups?.[config.id] || 0}
                      onChange={(e) => handlePercentChange(entry.id, `custom_${config.id}`, Number(e.target.value))}
                      className="w-16 text-center text-xs"
                      step="0.1"
                      min="0"
                    />
                  </td>
                ))}
                
                <td className="p-2 text-right font-mono text-sm font-medium text-blue-600">
                  ${calculateTotalMarkup(entry).toLocaleString()}
                </td>
                <td className="p-2 text-right font-mono text-sm font-bold text-green-600">
                  ${calculateGrandTotal(entry).toLocaleString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Footer */}
      <div className="border-t bg-gray-50 p-3">
        <div className="flex justify-between items-center text-sm">
          <span>{filteredEntries.length} items</span>
          <div className="flex items-center gap-6">
            <span>
              Base Total: <strong>${filteredEntries.reduce((sum, entry) => sum + entry.base_amount, 0).toLocaleString()}</strong>
            </span>
            <span>
              Markup Total: <strong className="text-blue-600">${filteredEntries.reduce((sum, entry) => sum + calculateTotalMarkup(entry), 0).toLocaleString()}</strong>
            </span>
            <span>
              Grand Total: <strong className="text-green-600">${filteredEntries.reduce((sum, entry) => sum + calculateGrandTotal(entry), 0).toLocaleString()}</strong>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
