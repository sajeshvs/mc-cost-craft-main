
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Building2, ListChecks, Download, RefreshCw, Maximize2, Minimize2, Copy, Printer, Plus } from 'lucide-react';
import { MarkupDataTable } from './MarkupDataTable';
import { MarkupVersionInfo } from './MarkupVersionInfo';
import { MarkupWorkflowActions } from './MarkupWorkflowActions';
import { MarkupMode, MarkupEntry, MarkupConfig, MarkupVersion, MarkupLine } from '@/types/markup';
import { useMarkupVersions, useCurrentMarkupVersion, useCreateMarkupVersion, useUpdateVersionStatus, useSaveMarkupLines, useMarkupLines } from '@/hooks/useMarkupVersions';
import { useToast } from '@/hooks/use-toast';

interface MarkupWindowProps {
  projectId: string;
  onClose: () => void;
}

export function MarkupWindow({ projectId, onClose }: MarkupWindowProps) {
  const [mode, setMode] = useState<MarkupMode>('trade');
  const [searchTerm, setSearchTerm] = useState('');
  const [isMaximized, setIsMaximized] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState<MarkupVersion | null>(null);
  const [workingData, setWorkingData] = useState<{ [key: string]: Partial<MarkupLine> }>({});
  const [filters, setFilters] = useState({
    division: '',
    markupType: '',
    minPercent: '',
    maxPercent: ''
  });
  
  const { toast } = useToast();

  // Version queries
  const { data: allVersions = [] } = useMarkupVersions(projectId, mode);
  const { data: currentVersion } = useCurrentMarkupVersion(projectId, mode);
  const { data: markupLines = [] } = useMarkupLines(selectedVersion?.id || '');

  // Version mutations
  const createVersionMutation = useCreateMarkupVersion(projectId, mode);
  const updateStatusMutation = useUpdateVersionStatus(projectId, mode);
  const saveLinesMutation = useSaveMarkupLines(selectedVersion?.id || '', projectId, mode);

  // Set selected version when current version loads
  useEffect(() => {
    if (currentVersion && !selectedVersion) {
      setSelectedVersion(currentVersion);
    }
  }, [currentVersion, selectedVersion]);

  // Reset working data when version changes
  useEffect(() => {
    setWorkingData({});
  }, [selectedVersion?.id]);

  const handleModeChange = (newMode: MarkupMode) => {
    setMode(newMode);
    setSelectedVersion(null);
    setWorkingData({});
  };

  const handleCreateVersion = async () => {
    try {
      const version = await createVersionMutation.mutateAsync('Initial version'); // Fix: Pass remarks argument
      setSelectedVersion(version);
    } catch (error) {
      console.error('Failed to create version:', error);
    }
  };

  const handleUpdateEntry = (id: string, updates: Partial<MarkupEntry>) => {
    setWorkingData(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        ...updates,
        ref_id: id.split('_')[1] || id,
        base_rate: updates.base_amount || prev[id]?.base_rate || 0 // Fix: Use base_amount consistently
      }
    }));
  };

  const handleSaveDraft = async () => {
    if (!selectedVersion) return;

    const linesToSave = Object.entries(workingData).map(([id, data]) => ({
      ref_id: data.ref_id || id.split('_')[1] || id,
      ref_description: data.ref_description || '',
      base_rate: data.base_amount || 0, // Fix: Use base_amount
      base_amount: data.base_amount || 0, // Add base_amount field
      site_overhead_percent: data.site_overhead_percent || 0,
      ho_ga_percent: data.ho_ga_percent || 0,
      profit_percent: data.profit_percent || 0,
      contingencies_percent: data.contingencies_percent || 0,
      escalation_percent: data.escalation_percent || 0,
      tax_percent: data.tax_percent || 0,
      total_markup_value: data.total_markup_value || 0,
      grand_total: data.grand_total || 0,
      tax_amount: data.tax_amount || 0,
      final_total: data.final_total || 0,
      remarks: data.remarks || '',
      user_id: data.user_id
    }));

    await saveLinesMutation.mutateAsync(linesToSave);
  };

  const handleSubmitForReview = async (remarks?: string) => {
    if (!selectedVersion) return;
    
    // Save current data first
    await handleSaveDraft();
    
    // Then update status
    await updateStatusMutation.mutateAsync({
      versionId: selectedVersion.id,
      status: 'submitted',
      remarks
    });
  };

  const handleApprove = async (remarks?: string) => {
    if (!selectedVersion) return;

    await updateStatusMutation.mutateAsync({
      versionId: selectedVersion.id,
      status: 'approved',
      remarks
    });
  };

  const handleArchive = async (remarks?: string) => {
    if (!selectedVersion) return;

    await updateStatusMutation.mutateAsync({
      versionId: selectedVersion.id,
      status: 'archived',
      remarks
    });
  };

  const handleResetMarkup = (entryIds: string[]) => {
    const resetData = entryIds.reduce((acc, id) => ({
      ...acc,
      [id]: {
        site_overhead_percent: 0,
        ho_ga_percent: 0,
        profit_percent: 0,
        contingencies_percent: 0,
        escalation_percent: 0,
        tax_percent: 0,
        total_markup_value: 0,
        grand_total: workingData[id]?.base_amount || 0, // Fix: Use base_amount consistently
        tax_amount: 0,
        final_total: workingData[id]?.base_amount || 0, // Fix: Use base_amount consistently
        remarks: ''
      }
    }), {});

    setWorkingData(prev => ({ ...prev, ...resetData }));
    
    toast({
      title: 'Markup Reset',
      description: `Reset markup for ${entryIds.length} items`
    });
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      division: '',
      markupType: '',
      minPercent: '',
      maxPercent: ''
    });
    setSearchTerm('');
  };

  const toggleMaximize = () => {
    setIsMaximized(!isMaximized);
  };

  const canEdit = selectedVersion?.status === 'draft';
  const canApprove = selectedVersion?.status === 'submitted'; // Would need role check in real app
  const isSaving = saveLinesMutation.isPending || updateStatusMutation.isPending;

  // Convert markup lines to entries format for the table
  const entries: MarkupEntry[] = markupLines.map(line => ({
    id: `${mode}_${line.ref_id}`,
    project_id: projectId,
    ref_type: mode,
    ref_id: line.ref_id,
    ref_description: line.ref_description,
    base_amount: line.base_amount || line.base_rate, // Use base_amount or fallback to base_rate
    site_overhead_percent: line.site_overhead_percent,
    ho_ga_percent: line.ho_ga_percent,
    profit_percent: line.profit_percent,
    contingencies_percent: line.contingencies_percent,
    escalation_percent: line.escalation_percent,
    tax_percent: line.tax_percent,
    custom_markups: {},
    total_markup_value: line.total_markup_value,
    grand_total: line.grand_total,
    tax_amount: line.tax_amount,
    final_total: line.final_total,
    remarks: line.remarks || '',
    user_id: line.user_id,
    created_at: line.created_at,
    updated_at: line.updated_at,
    ...workingData[`${mode}_${line.ref_id}`]
  }));

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className={`${isMaximized ? 'max-w-[95vw] h-[95vh]' : 'max-w-[90vw] h-[85vh]'} flex flex-col p-0`}>
        <DialogHeader className="flex flex-row items-center justify-between p-4 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <span className="text-lg font-bold text-blue-600">M</span>
            </div>
            <div>
              <DialogTitle className="text-xl">Markup Manager</DialogTitle>
              <p className="text-sm text-gray-600">Apply markup percentages with version control</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Version Info */}
            <MarkupVersionInfo
              currentVersion={selectedVersion}
              allVersions={allVersions}
              onVersionSelect={setSelectedVersion}
              onViewHistory={() => {}} // TODO: Implement history view
              isReadOnly={!canEdit}
            />

            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={toggleMaximize}>
                {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="p-4 border-b bg-gray-50 space-y-4">
            {/* Mode Toggle */}
            <div className="flex items-center justify-between">
              <Tabs value={mode} onValueChange={handleModeChange}>
                <TabsList className="grid w-full max-w-md grid-cols-2">
                  <TabsTrigger value="trade" className="flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    Apply by Trade
                  </TabsTrigger>
                  <TabsTrigger value="item" className="flex items-center gap-2">
                    <ListChecks className="h-4 w-4" />
                    Apply by Item
                  </TabsTrigger>
                </TabsList>
              </Tabs>

              {/* Workflow Actions */}
              <MarkupWorkflowActions
                version={selectedVersion}
                onSaveDraft={handleSaveDraft}
                onSubmitForReview={handleSubmitForReview}
                onApprove={handleApprove}
                onArchive={handleArchive}
                isSaving={isSaving}
                canEdit={canEdit}
                canApprove={canApprove}
              />
            </div>

            {/* Create Version Button if no current version */}
            {!selectedVersion && (
              <div className="text-center py-4">
                <Button
                  onClick={handleCreateVersion}
                  disabled={createVersionMutation.isPending}
                  className="gap-2"
                >
                  <Plus className="h-4 w-4" />
                  {createVersionMutation.isPending ? 'Creating...' : 'Create New Version'}
                </Button>
              </div>
            )}

            {/* Search and Filter Row */}
            {selectedVersion && (
              <>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder={`Search by ${mode === 'trade' ? 'trade code' : 'BOQ ref'}...`}
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="max-w-sm"
                      disabled={!canEdit}
                    />
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">Filters:</span>
                    <Select value={filters.division} onValueChange={(value) => handleFilterChange('division', value)}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Division" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__all__">All Divisions</SelectItem>
                        <SelectItem value="01">01 - General</SelectItem>
                        <SelectItem value="02">02 - Site Work</SelectItem>
                        <SelectItem value="03">03 - Concrete</SelectItem>
                        <SelectItem value="04">04 - Masonry</SelectItem>
                        <SelectItem value="05">05 - Metals</SelectItem>
                        <SelectItem value="06">06 - Wood</SelectItem>
                        <SelectItem value="07">07 - Thermal</SelectItem>
                        <SelectItem value="08">08 - Openings</SelectItem>
                        <SelectItem value="09">09 - Finishes</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Input
                      placeholder="Min %"
                      value={filters.minPercent}
                      onChange={(e) => handleFilterChange('minPercent', e.target.value)}
                      className="w-20"
                      type="number"
                      disabled={!canEdit}
                    />
                    
                    <Input
                      placeholder="Max %"
                      value={filters.maxPercent}
                      onChange={(e) => handleFilterChange('maxPercent', e.target.value)}
                      className="w-20"
                      type="number"
                      disabled={!canEdit}
                    />
                    
                    <Button variant="outline" size="sm" onClick={clearFilters}>
                      Clear
                    </Button>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => {}}>
                      <Download className="h-4 w-4 mr-1" />
                      Export Excel
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
                      <RefreshCw className="h-4 w-4 mr-1" />
                      Refresh
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => {}}>
                      <Copy className="h-4 w-4 mr-1" />
                      Copy
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => window.print()}>
                      <Printer className="h-4 w-4 mr-1" />
                      Print
                    </Button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Main Table */}
          {selectedVersion && (
            <div className="flex-1 overflow-hidden">
              <MarkupDataTable
                mode={mode}
                projectId={projectId}
                entries={entries}
                onUpdateEntry={canEdit ? handleUpdateEntry : () => {}}
                onResetMarkup={canEdit ? handleResetMarkup : () => {}}
                searchTerm={searchTerm}
                filters={filters}
                isReadOnly={!canEdit}
              />
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
