
import React, { useState, useCallback, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Eye, EyeOff, Download, Copy, Printer, Upload, Settings } from 'lucide-react';
import { MarkupMode, MarkupEntry, MarkupConfig, DEFAULT_MARKUP_TYPES, MarkupSummary } from '@/types/markup';
import { useTradeMarkupData, useItemMarkupData } from '@/hooks/useMarkup';
import { useToast } from '@/hooks/use-toast';

interface EnhancedMarkupTableProps {
  mode: MarkupMode;
  projectId: string;
  entries: MarkupEntry[];
  configs: MarkupConfig[];
  onUpdateEntry: (id: string, updates: Partial<MarkupEntry>) => void;
  onAddCustomColumn: (label: string, defaultPercent: number) => void;
  onResetMarkup: (entryIds: string[]) => void;
  searchTerm: string;
  filters: {
    division: string;
    markupType: string;
    minPercent: string;
    maxPercent: string;
  };
}

export function EnhancedMarkupTable({
  mode,
  projectId,
  entries,
  configs,
  onUpdateEntry,
  onAddCustomColumn,
  onResetMarkup,
  searchTerm,
  filters
}: EnhancedMarkupTableProps) {
  const [selectedEntries, setSelectedEntries] = useState<Set<string>>(new Set());
  const [columnVisibility, setColumnVisibility] = useState<{ [key: string]: boolean }>({});
  const [showColumnManager, setShowColumnManager] = useState(false);
  const { toast } = useToast();

  const { data: tradeData = [] } = useTradeMarkupData(projectId);
  const { data: itemData = [] } = useItemMarkupData(projectId);

  const baseData = mode === 'trade' ? tradeData : itemData;

  const filteredEntries = useMemo(() => {
    return entries.filter(entry => {
      // Search filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        if (!entry.ref_description.toLowerCase().includes(searchLower) &&
            !entry.ref_id.toLowerCase().includes(searchLower)) {
          return false;
        }
      }

      // Division filter
      if (filters.division && filters.division !== '__all__') {
        const division = entry.ref_id.substring(0, 2);
        if (division !== filters.division) {
          return false;
        }
      }

      // Percentage filters
      if (filters.minPercent || filters.maxPercent) {
        const totalPercent = entry.site_overhead_percent + entry.ho_ga_percent + 
                           entry.profit_percent + entry.contingencies_percent + 
                           entry.escalation_percent + entry.tax_percent;
        
        if (filters.minPercent && totalPercent < Number(filters.minPercent)) {
          return false;
        }
        if (filters.maxPercent && totalPercent > Number(filters.maxPercent)) {
          return false;
        }
      }

      return true;
    });
  }, [entries, searchTerm, filters]);

  const calculateMarkupValues = useCallback((entry: MarkupEntry) => {
    const siteOverheadValue = entry.base_amount * (entry.site_overhead_percent / 100);
    const hoGaValue = entry.base_amount * (entry.ho_ga_percent / 100);
    const profitValue = entry.base_amount * (entry.profit_percent / 100);
    const contingenciesValue = entry.base_amount * (entry.contingencies_percent / 100);
    const escalationValue = entry.base_amount * (entry.escalation_percent / 100);
    
    const totalMarkup = siteOverheadValue + hoGaValue + profitValue + contingenciesValue + escalationValue;
    const grandTotal = entry.base_amount + totalMarkup;
    const taxAmount = grandTotal * (entry.tax_percent / 100);
    const finalTotal = grandTotal + taxAmount;

    return {
      totalMarkup,
      grandTotal,
      taxAmount,
      finalTotal
    };
  }, []);

  const handlePercentChange = (entryId: string, field: string, value: number) => {
    // Prevent negative values
    if (value < 0) {
      toast({
        title: 'Invalid Value',
        description: 'Markup percentages cannot be negative',
        variant: 'destructive'
      });
      return;
    }

    const entry = entries.find(e => e.id === entryId);
    if (!entry) return;

    const updates: Partial<MarkupEntry> = { [field]: value };
    
    // Calculate new totals
    const updatedEntry = { ...entry, ...updates };
    const calculations = calculateMarkupValues(updatedEntry);

    onUpdateEntry(entryId, {
      ...updates,
      total_markup_value: calculations.totalMarkup,
      grand_total: calculations.grandTotal,
      tax_amount: calculations.taxAmount,
      final_total: calculations.finalTotal
    });
  };

  const handleRemarksChange = (entryId: string, remarks: string) => {
    onUpdateEntry(entryId, { remarks });
  };

  const handleSelectEntry = (entryId: string) => {
    setSelectedEntries(prev => {
      const newSet = new Set(prev);
      if (newSet.has(entryId)) {
        newSet.delete(entryId);
      } else {
        newSet.add(entryId);
      }
      return newSet;
    });
  };

  const handleSelectAll = () => {
    if (selectedEntries.size === filteredEntries.length) {
      setSelectedEntries(new Set());
    } else {
      setSelectedEntries(new Set(filteredEntries.map(entry => entry.id)));
    }
  };

  const handleExport = (format: 'excel' | 'csv' | 'pdf') => {
    toast({
      title: 'Export Started',
      description: `Exporting markup table to ${format.toUpperCase()}...`
    });
  };

  const handleCopy = () => {
    toast({
      title: 'Copied',
      description: 'Markup table copied to clipboard'
    });
  };

  const handlePrint = () => {
    window.print();
  };

  const toggleColumnVisibility = (columnKey: string) => {
    setColumnVisibility(prev => ({
      ...prev,
      [columnKey]: !prev[columnKey]
    }));
  };

  const summary: MarkupSummary = useMemo(() => {
    return filteredEntries.reduce((acc, entry) => {
      const calculations = calculateMarkupValues(entry);
      return {
        base_total: acc.base_total + entry.base_amount,
        markup_total: acc.markup_total + calculations.totalMarkup,
        grand_total: acc.grand_total + calculations.grandTotal,
        tax_total: acc.tax_total + calculations.taxAmount,
        final_total: acc.final_total + calculations.finalTotal
      };
    }, {
      base_total: 0,
      markup_total: 0,
      grand_total: 0,
      tax_total: 0,
      final_total: 0
    });
  }, [filteredEntries, calculateMarkupValues]);

  const defaultColumns = [
    { key: 'ref_id', label: mode === 'trade' ? 'Trade Code' : 'BOQ Ref', visible: true },
    { key: 'description', label: 'Description', visible: true },
    { key: 'base_amount', label: 'Base Rate ($)', visible: true },
    { key: 'site_overhead_percent', label: 'Site Overhead %', visible: true },
    { key: 'ho_ga_percent', label: 'H.O G&A %', visible: true },
    { key: 'profit_percent', label: 'Profit %', visible: true },
    { key: 'contingencies_percent', label: 'Contingencies %', visible: true },
    { key: 'escalation_percent', label: 'Escalation %', visible: true },
    { key: 'total_markup_value', label: 'Total Markup ($)', visible: true },
    { key: 'grand_total', label: 'Grand Total ($)', visible: true },
    { key: 'tax_percent', label: 'Tax %', visible: true },
    { key: 'tax_amount', label: 'Tax Amount ($)', visible: true },
    { key: 'final_total', label: 'Final Total ($)', visible: true },
    { key: 'remarks', label: 'Remarks', visible: true }
  ];

  const visibleColumns = defaultColumns.filter(col => 
    columnVisibility[col.key] !== false
  );

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Toolbar */}
      <div className="flex items-center justify-between p-4 border-b bg-gray-50">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Actions:</span>
          {selectedEntries.size > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onResetMarkup(Array.from(selectedEntries))}
              className="gap-1 text-red-600"
            >
              Reset Selected ({selectedEntries.size})
            </Button>
          )}
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleCopy}
            className="gap-1"
          >
            <Copy className="h-4 w-4" />
            Copy
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrint}
            className="gap-1"
          >
            <Printer className="h-4 w-4" />
            Print
          </Button>
          
          <Select onValueChange={handleExport}>
            <SelectTrigger className="w-32">
              <Download className="h-4 w-4 mr-2" />
              Export
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="excel">Excel</SelectItem>
              <SelectItem value="csv">CSV</SelectItem>
              <SelectItem value="pdf">PDF</SelectItem>
            </SelectContent>
          </Select>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowColumnManager(!showColumnManager)}
            className="gap-1"
          >
            <Settings className="h-4 w-4" />
            Columns
          </Button>
        </div>
      </div>

      {/* Column Manager */}
      {showColumnManager && (
        <div className="p-3 border-b bg-blue-50">
          <div className="flex flex-wrap gap-2">
            {defaultColumns.map(col => (
              <Button
                key={col.key}
                variant="outline"
                size="sm"
                onClick={() => toggleColumnVisibility(col.key)}
                className="gap-1"
              >
                {columnVisibility[col.key] === false ? (
                  <EyeOff className="h-3 w-3" />
                ) : (
                  <Eye className="h-3 w-3" />
                )}
                {col.label}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm border-collapse">
          <thead className="sticky top-0 bg-gray-100 border-b-2">
            <tr>
              <th className="w-8 p-2 text-left border-r">
                <Checkbox
                  checked={selectedEntries.size === filteredEntries.length && filteredEntries.length > 0}
                  onCheckedChange={handleSelectAll}
                />
              </th>
              {visibleColumns.map(col => (
                <th key={col.key} className="p-2 text-left font-medium border-r min-w-[100px]">
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredEntries.map((entry, index) => {
              const calculations = calculateMarkupValues(entry);
              const isEven = index % 2 === 0;
              
              return (
                <tr key={entry.id} className={`hover:bg-gray-50 ${isEven ? 'bg-white' : 'bg-gray-25'}`}>
                  <td className="p-2 border-r">
                    <Checkbox
                      checked={selectedEntries.has(entry.id)}
                      onCheckedChange={() => handleSelectEntry(entry.id)}
                    />
                  </td>
                  
                  {visibleColumns.map(col => {
                    switch (col.key) {
                      case 'ref_id':
                        return (
                          <td key={col.key} className="p-2 font-mono text-xs border-r">
                            {entry.ref_id}
                          </td>
                        );
                      case 'description':
                        return (
                          <td key={col.key} className="p-2 text-sm border-r max-w-[200px]">
                            <div className="truncate" title={entry.ref_description}>
                              {entry.ref_description}
                            </div>
                          </td>
                        );
                      case 'base_amount':
                        return (
                          <td key={col.key} className="p-2 text-right font-mono text-sm border-r">
                            ${entry.base_amount.toLocaleString()}
                          </td>
                        );
                      case 'site_overhead_percent':
                      case 'ho_ga_percent':
                      case 'profit_percent':
                      case 'contingencies_percent':
                      case 'escalation_percent':
                      case 'tax_percent':
                        return (
                          <td key={col.key} className="p-2 text-center border-r">
                            <Input
                              type="number"
                              value={entry[col.key as keyof MarkupEntry] as number || 0}
                              onChange={(e) => handlePercentChange(entry.id, col.key, Number(e.target.value))}
                              className="w-16 text-center text-xs"
                              step="0.1"
                              min="0"
                            />
                          </td>
                        );
                      case 'total_markup_value':
                        return (
                          <td key={col.key} className="p-2 text-right font-mono text-sm font-medium text-blue-600 border-r">
                            ${calculations.totalMarkup.toLocaleString()}
                          </td>
                        );
                      case 'grand_total':
                        return (
                          <td key={col.key} className="p-2 text-right font-mono text-sm font-bold text-green-600 border-r">
                            ${calculations.grandTotal.toLocaleString()}
                          </td>
                        );
                      case 'tax_amount':
                        return (
                          <td key={col.key} className="p-2 text-right font-mono text-sm font-medium text-yellow-600 border-r">
                            ${calculations.taxAmount.toLocaleString()}
                          </td>
                        );
                      case 'final_total':
                        return (
                          <td key={col.key} className="p-2 text-right font-mono text-sm font-bold text-purple-600 border-r">
                            ${calculations.finalTotal.toLocaleString()}
                          </td>
                        );
                      case 'remarks':
                        return (
                          <td key={col.key} className="p-2 border-r">
                            <Input
                              value={entry.remarks || ''}
                              onChange={(e) => handleRemarksChange(entry.id, e.target.value)}
                              className="w-full text-xs"
                              placeholder="Add remarks..."
                            />
                          </td>
                        );
                      default:
                        return <td key={col.key} className="p-2 border-r"></td>;
                    }
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Summary Footer */}
      <div className="border-t bg-gray-50 p-4">
        <div className="grid grid-cols-5 gap-4 text-sm font-medium">
          <div className="text-center">
            <div className="text-gray-600">Base Total</div>
            <div className="text-lg font-bold">${summary.base_total.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-600">Markup Total</div>
            <div className="text-lg font-bold text-blue-600">${summary.markup_total.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-600">Grand Total</div>
            <div className="text-lg font-bold text-green-600">${summary.grand_total.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-600">Tax Total</div>
            <div className="text-lg font-bold text-yellow-600">${summary.tax_total.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-600">Final Total</div>
            <div className="text-lg font-bold text-purple-600">${summary.final_total.toLocaleString()}</div>
          </div>
        </div>
        <div className="mt-2 text-center text-xs text-gray-500">
          {filteredEntries.length} items displayed
        </div>
      </div>
    </div>
  );
}
