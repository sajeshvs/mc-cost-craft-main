
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Save, Send, CheckCircle, Archive, FileText } from 'lucide-react';
import { MarkupVersion, MarkupStatus } from '@/types/markup';

interface MarkupWorkflowActionsProps {
  version: MarkupVersion | null;
  onSaveDraft: () => void;
  onSubmitForReview: (remarks?: string) => void;
  onApprove: (remarks?: string) => void;
  onArchive: (remarks?: string) => void;
  isSaving: boolean;
  canEdit: boolean;
  canApprove: boolean;
}

export function MarkupWorkflowActions({
  version,
  onSaveDraft,
  onSubmitForReview,
  onApprove,
  onArchive,
  isSaving,
  canEdit,
  canApprove
}: MarkupWorkflowActionsProps) {
  const [showDialog, setShowDialog] = useState(false);
  const [dialogType, setDialogType] = useState<'submit' | 'approve' | 'archive'>('submit');
  const [remarks, setRemarks] = useState('');

  const handleAction = (action: 'submit' | 'approve' | 'archive') => {
    setDialogType(action);
    setRemarks('');
    setShowDialog(true);
  };

  const handleConfirm = () => {
    switch (dialogType) {
      case 'submit':
        onSubmitForReview(remarks);
        break;
      case 'approve':
        onApprove(remarks);
        break;
      case 'archive':
        onArchive(remarks);
        break;
    }
    setShowDialog(false);
    setRemarks('');
  };

  const getDialogTitle = () => {
    switch (dialogType) {
      case 'submit':
        return 'Submit for Review';
      case 'approve':
        return 'Approve Version';
      case 'archive':
        return 'Archive Version';
      default:
        return '';
    }
  };

  const getDialogDescription = () => {
    switch (dialogType) {
      case 'submit':
        return 'This will submit the current version for review and lock it from further editing.';
      case 'approve':
        return 'This will approve the version and apply markup values to the BOQ. This action cannot be undone.';
      case 'archive':
        return 'This will archive the current version. Archived versions are read-only.';
      default:
        return '';
    }
  };

  if (!version) return null;

  return (
    <>
      <div className="flex items-center gap-2">
        {/* Save Draft - always available in draft mode */}
        {version.status === 'draft' && canEdit && (
          <Button
            variant="outline"
            size="sm"
            onClick={onSaveDraft}
            disabled={isSaving}
            className="gap-1"
          >
            <Save className="h-4 w-4" />
            {isSaving ? 'Saving...' : 'Save Draft'}
          </Button>
        )}

        {/* Submit for Review - from draft */}
        {version.status === 'draft' && canEdit && (
          <Button
            variant="default"
            size="sm"
            onClick={() => handleAction('submit')}
            disabled={isSaving}
            className="gap-1"
          >
            <Send className="h-4 w-4" />
            Submit for Review
          </Button>
        )}

        {/* Approve - from submitted */}
        {version.status === 'submitted' && canApprove && (
          <Button
            variant="default"
            size="sm"
            onClick={() => handleAction('approve')}
            disabled={isSaving}
            className="gap-1 bg-green-600 hover:bg-green-700"
          >
            <CheckCircle className="h-4 w-4" />
            Approve
          </Button>
        )}

        {/* Archive - from approved */}
        {version.status === 'approved' && canApprove && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleAction('archive')}
            disabled={isSaving}
            className="gap-1 text-orange-600 border-orange-200 hover:bg-orange-50"
          >
            <Archive className="h-4 w-4" />
            Archive
          </Button>
        )}

        {/* Status indicator for read-only states */}
        {(version.status === 'archived' || (!canEdit && !canApprove)) && (
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <FileText className="h-4 w-4" />
            Read-only
          </div>
        )}
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{getDialogTitle()}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              {getDialogDescription()}
            </p>
            
            <div className="space-y-2">
              <Label htmlFor="remarks">
                Remarks {dialogType === 'submit' ? '(optional)' : '(required)'}
              </Label>
              <Textarea
                id="remarks"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder={`Add ${dialogType === 'submit' ? 'optional ' : ''}remarks...`}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleConfirm}
              disabled={dialogType !== 'submit' && !remarks.trim()}
            >
              {getDialogTitle()}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
