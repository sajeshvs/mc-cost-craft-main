
import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { MarkupMode, MarkupEntry, MarkupSummary } from '@/types/markup';
import { useTradeMarkupData, useItemMarkupData } from '@/hooks/useMarkup';
import { useToast } from '@/hooks/use-toast';

interface MarkupDataTableProps {
  mode: MarkupMode;
  projectId: string;
  entries: MarkupEntry[];
  onUpdateEntry: (id: string, updates: Partial<MarkupEntry>) => void;
  onResetMarkup: (entryIds: string[]) => void;
  searchTerm: string;
  filters: {
    division: string;
    markupType: string;
    minPercent: string;
    maxPercent: string;
  };
  isReadOnly?: boolean;
}

export function MarkupDataTable({
  mode,
  projectId,
  entries,
  onUpdateEntry,
  onResetMarkup,
  searchTerm,
  filters,
  isReadOnly = false
}: MarkupDataTableProps) {
  const [selectedEntries, setSelectedEntries] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const { data: tradeData = [] } = useTradeMarkupData(projectId);
  const { data: itemData = [] } = useItemMarkupData(projectId);

  const baseData = mode === 'trade' ? tradeData : itemData;

  // Create entries from base data if not already created
  const processedEntries = useMemo(() => {
    if (entries.length > 0) return entries;

    return baseData.map(item => ({
      id: `${mode}_${item.trade_code || item.item_id}`,
      project_id: projectId,
      ref_type: mode,
      ref_id: item.trade_code || item.item_id,
      ref_description: item.description,
      base_amount: item.base_amount,
      site_overhead_percent: 0,
      ho_ga_percent: 0,
      profit_percent: 0,
      contingencies_percent: 0,
      escalation_percent: 0,
      tax_percent: 0,
      custom_markups: {},
      total_markup_value: 0,
      grand_total: item.base_amount,
      tax_amount: 0,
      final_total: item.base_amount,
      remarks: '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }));
  }, [baseData, entries, mode, projectId]);

  const filteredEntries = useMemo(() => {
    return processedEntries.filter(entry => {
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        if (!entry.ref_description.toLowerCase().includes(searchLower) &&
            !entry.ref_id.toLowerCase().includes(searchLower)) {
          return false;
        }
      }

      if (filters.division && filters.division !== '__all__') {
        const division = entry.ref_id.substring(0, 2);
        if (division !== filters.division) {
          return false;
        }
      }

      return true;
    });
  }, [processedEntries, searchTerm, filters]);

  const calculateValues = (entry: MarkupEntry) => {
    const siteOverheadValue = entry.base_amount * (entry.site_overhead_percent / 100);
    const hoGaValue = entry.base_amount * (entry.ho_ga_percent / 100);
    const profitValue = entry.base_amount * (entry.profit_percent / 100);
    const contingenciesValue = entry.base_amount * (entry.contingencies_percent / 100);
    const escalationValue = entry.base_amount * (entry.escalation_percent / 100);
    
    const totalMarkup = siteOverheadValue + hoGaValue + profitValue + contingenciesValue + escalationValue;
    const grandTotal = entry.base_amount + totalMarkup;
    const taxAmount = grandTotal * (entry.tax_percent / 100);
    const finalTotal = grandTotal + taxAmount;

    return {
      totalMarkup,
      grandTotal,
      taxAmount,
      finalTotal
    };
  };

  const handlePercentChange = (entryId: string, field: string, value: number) => {
    if (isReadOnly) return;
    
    if (value < 0) {
      toast({
        title: 'Invalid Value',
        description: 'Markup percentages cannot be negative',
        variant: 'destructive'
      });
      return;
    }

    const entry = processedEntries.find(e => e.id === entryId);
    if (!entry) return;

    const updates: Partial<MarkupEntry> = { [field]: value };
    const updatedEntry = { ...entry, ...updates };
    const calculations = calculateValues(updatedEntry);

    onUpdateEntry(entryId, {
      ...updates,
      total_markup_value: calculations.totalMarkup,
      grand_total: calculations.grandTotal,
      tax_amount: calculations.taxAmount,
      final_total: calculations.finalTotal
    });
  };

  const handleRemarksChange = (entryId: string, remarks: string) => {
    if (isReadOnly) return;
    onUpdateEntry(entryId, { remarks });
  };

  const handleSelectEntry = (entryId: string) => {
    if (isReadOnly) return;
    
    setSelectedEntries(prev => {
      const newSet = new Set(prev);
      if (newSet.has(entryId)) {
        newSet.delete(entryId);
      } else {
        newSet.add(entryId);
      }
      return newSet;
    });
  };

  const handleSelectAll = () => {
    if (isReadOnly) return;
    
    if (selectedEntries.size === filteredEntries.length) {
      setSelectedEntries(new Set());
    } else {
      setSelectedEntries(new Set(filteredEntries.map(entry => entry.id)));
    }
  };

  const summary: MarkupSummary = useMemo(() => {
    return filteredEntries.reduce((acc, entry) => {
      const calculations = calculateValues(entry);
      return {
        base_total: acc.base_total + entry.base_amount,
        markup_total: acc.markup_total + calculations.totalMarkup,
        grand_total: acc.grand_total + calculations.grandTotal,
        tax_total: acc.tax_total + calculations.taxAmount,
        final_total: acc.final_total + calculations.finalTotal
      };
    }, {
      base_total: 0,
      markup_total: 0,
      grand_total: 0,
      tax_total: 0,
      final_total: 0
    });
  }, [filteredEntries]);

  if (filteredEntries.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500">No data available for {mode} mode</p>
          <p className="text-sm text-gray-400 mt-2">
            {mode === 'trade' ? 'No trades found in BOQ' : 'No items found in BOQ'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Actions Bar */}
      <div className="flex items-center justify-between p-3 border-b bg-gray-50">
        <div className="flex items-center gap-2">
          {selectedEntries.size > 0 && !isReadOnly && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => onResetMarkup(Array.from(selectedEntries))}
              className="gap-1 text-red-600"
            >
              Reset Selected ({selectedEntries.size})
            </Button>
          )}
          {isReadOnly && (
            <Badge variant="outline" className="text-orange-600 border-orange-200">
              Read-only Mode
            </Badge>
          )}
        </div>
        <div className="text-sm text-gray-600">
          {filteredEntries.length} items displayed
        </div>
      </div>

      {/* Table Container */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm border-collapse">
          <thead className="sticky top-0 bg-gray-100 border-b-2">
            <tr>
              <th className="w-8 p-2 text-left border-r">
                {!isReadOnly && (
                  <Checkbox
                    checked={selectedEntries.size === filteredEntries.length && filteredEntries.length > 0}
                    onCheckedChange={handleSelectAll}
                  />
                )}
              </th>
              <th className="p-2 text-left font-medium border-r min-w-[100px]">
                {mode === 'trade' ? 'Trade Code' : 'BOQ Ref'}
              </th>
              <th className="p-2 text-left font-medium border-r min-w-[200px]">Description</th>
              <th className="p-2 text-right font-medium border-r min-w-[100px]">Base Rate ($)</th>
              <th className="p-2 text-center font-medium border-r min-w-[100px]">Site Overhead %</th>
              <th className="p-2 text-center font-medium border-r min-w-[100px]">H.O G&A %</th>
              <th className="p-2 text-center font-medium border-r min-w-[100px]">Profit %</th>
              <th className="p-2 text-center font-medium border-r min-w-[100px]">Contingencies %</th>
              <th className="p-2 text-center font-medium border-r min-w-[100px]">Escalation %</th>
              <th className="p-2 text-right font-medium border-r min-w-[120px]">Total Markup ($)</th>
              <th className="p-2 text-right font-medium border-r min-w-[120px]">Grand Total ($)</th>
              <th className="p-2 text-center font-medium border-r min-w-[80px]">Tax %</th>
              <th className="p-2 text-right font-medium border-r min-w-[100px]">Tax Amount ($)</th>
              <th className="p-2 text-right font-medium border-r min-w-[120px]">Final Total ($)</th>
              <th className="p-2 text-left font-medium border-r min-w-[150px]">Remarks</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredEntries.map((entry, index) => {
              const calculations = calculateValues(entry);
              const isEven = index % 2 === 0;
              
              return (
                <tr key={entry.id} className={`hover:bg-gray-50 ${isEven ? 'bg-white' : 'bg-gray-25'}`}>
                  <td className="p-2 border-r">
                    {!isReadOnly && (
                      <Checkbox
                        checked={selectedEntries.has(entry.id)}
                        onCheckedChange={() => handleSelectEntry(entry.id)}
                      />
                    )}
                  </td>
                  <td className="p-2 font-mono text-xs border-r">
                    {entry.ref_id}
                  </td>
                  <td className="p-2 text-sm border-r max-w-[200px]">
                    <div className="truncate" title={entry.ref_description}>
                      {entry.ref_description}
                    </div>
                  </td>
                  <td className="p-2 text-right font-mono text-sm border-r">
                    ${entry.base_amount.toLocaleString()}
                  </td>
                  <td className="p-2 text-center border-r">
                    <Input
                      type="number"
                      value={entry.site_overhead_percent || 0}
                      onChange={(e) => handlePercentChange(entry.id, 'site_overhead_percent', Number(e.target.value))}
                      className="w-20 text-center text-xs"
                      step="0.1"
                      min="0"
                      disabled={isReadOnly}
                    />
                  </td>
                  <td className="p-2 text-center border-r">
                    <Input
                      type="number"
                      value={entry.ho_ga_percent || 0}
                      onChange={(e) => handlePercentChange(entry.id, 'ho_ga_percent', Number(e.target.value))}
                      className="w-20 text-center text-xs"
                      step="0.1"
                      min="0"
                      disabled={isReadOnly}
                    />
                  </td>
                  <td className="p-2 text-center border-r">
                    <Input
                      type="number"
                      value={entry.profit_percent || 0}
                      onChange={(e) => handlePercentChange(entry.id, 'profit_percent', Number(e.target.value))}
                      className="w-20 text-center text-xs"
                      step="0.1"
                      min="0"
                      disabled={isReadOnly}
                    />
                  </td>
                  <td className="p-2 text-center border-r">
                    <Input
                      type="number"
                      value={entry.contingencies_percent || 0}
                      onChange={(e) => handlePercentChange(entry.id, 'contingencies_percent', Number(e.target.value))}
                      className="w-20 text-center text-xs"
                      step="0.1"
                      min="0"
                      disabled={isReadOnly}
                    />
                  </td>
                  <td className="p-2 text-center border-r">
                    <Input
                      type="number"
                      value={entry.escalation_percent || 0}
                      onChange={(e) => handlePercentChange(entry.id, 'escalation_percent', Number(e.target.value))}
                      className="w-20 text-center text-xs"
                      step="0.1"
                      min="0"
                      disabled={isReadOnly}
                    />
                  </td>
                  <td className="p-2 text-right font-mono text-sm font-medium text-blue-600 border-r">
                    ${calculations.totalMarkup.toLocaleString()}
                  </td>
                  <td className="p-2 text-right font-mono text-sm font-bold text-green-600 border-r">
                    ${calculations.grandTotal.toLocaleString()}
                  </td>
                  <td className="p-2 text-center border-r">
                    <Input
                      type="number"
                      value={entry.tax_percent || 0}
                      onChange={(e) => handlePercentChange(entry.id, 'tax_percent', Number(e.target.value))}
                      className="w-20 text-center text-xs"
                      step="0.1"
                      min="0"
                      disabled={isReadOnly}
                    />
                  </td>
                  <td className="p-2 text-right font-mono text-sm font-medium text-yellow-600 border-r">
                    ${calculations.taxAmount.toLocaleString()}
                  </td>
                  <td className="p-2 text-right font-mono text-sm font-bold text-purple-600 border-r">
                    ${calculations.finalTotal.toLocaleString()}
                  </td>
                  <td className="p-2 border-r">
                    <Input
                      value={entry.remarks || ''}
                      onChange={(e) => handleRemarksChange(entry.id, e.target.value)}
                      className="w-full text-xs"
                      placeholder={isReadOnly ? 'No remarks' : 'Add remarks...'}
                      disabled={isReadOnly}
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Summary Footer */}
      <div className="border-t bg-gray-50 p-4">
        <div className="grid grid-cols-5 gap-4 text-sm font-medium">
          <div className="text-center">
            <div className="text-gray-600">Base Total</div>
            <div className="text-lg font-bold">${summary.base_total.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-600">Markup Total</div>
            <div className="text-lg font-bold text-blue-600">${summary.markup_total.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-600">Grand Total</div>
            <div className="text-lg font-bold text-green-600">${summary.grand_total.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-600">Tax Total</div>
            <div className="text-lg font-bold text-yellow-600">${summary.tax_total.toLocaleString()}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-600">Final Total</div>
            <div className="text-lg font-bold text-purple-600">${summary.final_total.toLocaleString()}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
