
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MarkupSummary } from '@/types/markup';
import { TrendingUp, DollarSign, Calculator } from 'lucide-react';

interface MarkupSummaryCardProps {
  summary: MarkupSummary;
}

export function MarkupSummaryCard({ summary }: MarkupSummaryCardProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5" />
          Markup Summary
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          {/* Base Total */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Base Total</span>
            </div>
            <div className="text-2xl font-bold text-gray-900">
              {formatCurrency(summary.base_total)}
            </div>
          </div>

          {/* Total Markup */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-blue-500" />
              <span className="text-sm font-medium text-gray-700">Total Markup</span>
            </div>
            <div className="text-2xl font-bold text-blue-600">
              {formatCurrency(summary.markup_total)}
            </div>
            <div className="text-sm text-gray-500">
              {summary.base_total > 0 
                ? `${((summary.markup_total / summary.base_total) * 100).toFixed(1)}% of base`
                : '0%'
              }
            </div>
          </div>

          {/* Grand Total */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Calculator className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium text-gray-700">Grand Total</span>
            </div>
            <div className="text-2xl font-bold text-green-600">
              {formatCurrency(summary.grand_total)}
            </div>
            <div className="text-sm text-gray-500">
              Base + Markup
            </div>
          </div>

          {/* Tax Total */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Calculator className="h-4 w-4 text-yellow-500" />
              <span className="text-sm font-medium text-gray-700">Tax Total</span>
            </div>
            <div className="text-2xl font-bold text-yellow-600">
              {formatCurrency(summary.tax_total)}
            </div>
            <div className="text-sm text-gray-500">
              Tax Amount
            </div>
          </div>

          {/* Final Total */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Calculator className="h-4 w-4 text-purple-500" />
              <span className="text-sm font-medium text-gray-700">Final Total</span>
            </div>
            <div className="text-2xl font-bold text-purple-600">
              {formatCurrency(summary.final_total)}
            </div>
            <div className="text-sm text-gray-500">
              Grand + Tax
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
