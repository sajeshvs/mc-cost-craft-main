
import React from 'react';
import { TableRow, TableCell } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronRight, Plus } from 'lucide-react';
import { UFGS_DIVISIONS } from '@/types/trades';

interface TradesSpreadsheetDivisionHeaderProps {
  divisionCode: string;
  isExpanded: boolean;
  tradesCount: number;
  columnWidths: Record<string, number>;
  onToggle: () => void;
  onAddTrade: () => void;
}

export function TradesSpreadsheetDivisionHeader({
  divisionCode,
  isExpanded,
  tradesCount,
  columnWidths,
  onToggle,
  onAddTrade
}: TradesSpreadsheetDivisionHeaderProps) {
  const division = UFGS_DIVISIONS.find(d => d.code === divisionCode);
  
  return (
    <TableRow 
      className="bg-muted/30 font-bold cursor-pointer hover:bg-muted/50 border-b"
      onClick={onToggle}
    >
      <TableCell 
        className="border-r sticky left-0 bg-muted/30 z-10"
        style={{ minWidth: '48px', width: '48px' }}
      >
        {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
      </TableCell>
      <TableCell 
        className="font-bold border-r text-lg"
        style={{ 
          width: columnWidths.trade_code || 120,
          minWidth: columnWidths.trade_code || 120,
          maxWidth: columnWidths.trade_code || 120
        }}
      >
        <div className="text-wrap break-words whitespace-normal">
          {divisionCode}
        </div>
      </TableCell>
      <TableCell 
        className="font-bold border-r text-lg"
        style={{ 
          width: columnWidths.description || 300,
          minWidth: columnWidths.description || 300,
          maxWidth: columnWidths.description || 300
        }}
      >
        <div className="flex items-center justify-between">
          <div className="text-wrap break-words whitespace-normal flex-1">
            {division?.name}
          </div>
          <div className="flex items-center gap-2 ml-2">
            <span className="text-sm text-muted-foreground whitespace-nowrap">
              {tradesCount} subtrade{tradesCount !== 1 ? 's' : ''}
            </span>
            <Button
              size="sm"
              variant="ghost"
              onClick={(e) => {
                e.stopPropagation();
                onAddTrade();
              }}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </TableCell>
      <TableCell 
        className="font-bold border-r text-lg"
        style={{ 
          width: columnWidths.color_code || 100,
          minWidth: columnWidths.color_code || 100,
          maxWidth: columnWidths.color_code || 100
        }}
      >
        <div className="text-wrap break-words whitespace-normal">
          Color
        </div>
      </TableCell>
    </TableRow>
  );
}
