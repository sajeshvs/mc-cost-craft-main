
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { UFGS_DIVISIONS, SUBTRADE_LETTERS, TradeFormData, Trade } from '@/types/trades';

interface TradeFormProps {
  trade?: Trade;
  onSubmit: (data: TradeFormData) => void;
  onCancel: () => void;
}

export function TradeForm({ trade, onSubmit, onCancel }: TradeFormProps) {
  const [formData, setFormData] = useState<TradeFormData>({
    division: trade?.division || '',
    subtrade_letter: trade?.subtrade_letter || '',
    description: trade?.description || '',
    color_code: trade?.color_code || '#3b82f6'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const selectedDivision = UFGS_DIVISIONS.find(d => d.code === formData.division);

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>{trade ? 'Edit Trade' : 'Add New Trade'}</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="division">Division</Label>
            <Select 
              value={formData.division} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, division: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select division" />
              </SelectTrigger>
              <SelectContent>
                {UFGS_DIVISIONS.map(division => (
                  <SelectItem key={division.code} value={division.code}>
                    {division.code} - {division.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="subtrade_letter">Subtrade Letter</Label>
            <Select 
              value={formData.subtrade_letter} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, subtrade_letter: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select letter" />
              </SelectTrigger>
              <SelectContent>
                {SUBTRADE_LETTERS.map(letter => (
                  <SelectItem key={letter} value={letter}>
                    {letter}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedDivision && formData.subtrade_letter && (
            <div className="text-sm text-muted-foreground">
              Trade Code: <strong>{formData.division}{formData.subtrade_letter}</strong>
            </div>
          )}

          <div>
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Enter trade description"
              required
            />
          </div>

          <div>
            <Label htmlFor="color_code">Color (Optional)</Label>
            <div className="flex items-center gap-2">
              <Input
                id="color_code"
                type="color"
                value={formData.color_code || '#3b82f6'}
                onChange={(e) => setFormData(prev => ({ ...prev, color_code: e.target.value }))}
                className="w-16 h-10"
              />
              <Input
                value={formData.color_code || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, color_code: e.target.value }))}
                placeholder="#3b82f6"
                className="flex-1"
              />
            </div>
          </div>

          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              {trade ? 'Update' : 'Create'} Trade
            </Button>
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
