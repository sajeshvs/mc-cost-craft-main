
import { useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Paintbrush } from 'lucide-react';
import { useTrades } from '@/hooks/useTrades';
import { Trade } from '@/types/trades';

interface TradeSelectorProps {
  projectId: string;
  value?: string;
  onValueChange?: (value: string) => void;
  onOpenTradesWindow?: () => void;
}

export function TradeSelector({ 
  projectId, 
  value, 
  onValueChange,
  onOpenTradesWindow 
}: TradeSelectorProps) {
  const { data: trades = [], isLoading } = useTrades(projectId);

  if (isLoading) {
    return <div>Loading trades...</div>;
  }

  // Multiple layers of validation to ensure no empty values
  const validTrades = (trades as Trade[])
    .filter(trade => 
      trade && 
      typeof trade === 'object' &&
      trade.trade_code && 
      typeof trade.trade_code === 'string' &&
      trade.trade_code.trim() !== '' &&
      trade.description &&
      typeof trade.description === 'string' &&
      trade.description.trim() !== '' &&
      trade.division &&
      typeof trade.division === 'string' &&
      trade.division.trim() !== ''
    );
  
  const groupedTrades = validTrades.reduce((acc, trade) => {
    const divisionName = getDivisionName(trade.division);
    if (!acc[divisionName]) {
      acc[divisionName] = [];
    }
    acc[divisionName].push(trade);
    return acc;
  }, {} as Record<string, Trade[]>);

  return (
    <div className="flex items-center gap-2">
      <Select value={value} onValueChange={onValueChange}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Select trade..." />
        </SelectTrigger>
        <SelectContent>
          {Object.entries(groupedTrades).map(([divisionName, divisionTrades]) => (
            <div key={divisionName}>
              <div className="px-2 py-1 text-sm font-medium text-muted-foreground">
                {divisionName}
              </div>
              {divisionTrades
                .filter(trade => 
                  trade && 
                  trade.trade_code && 
                  typeof trade.trade_code === 'string' &&
                  trade.trade_code.trim() !== '' &&
                  trade.description &&
                  typeof trade.description === 'string' &&
                  trade.description.trim() !== ''
                )
                .map((trade) => (
                  <SelectItem 
                    key={trade.id} 
                    value={trade.trade_code}
                    className="pl-4"
                  >
                    <div className="flex items-center gap-2">
                      {trade.color_code && (
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: trade.color_code }}
                        />
                      )}
                      <span>{trade.trade_code} - {trade.description}</span>
                    </div>
                  </SelectItem>
                ))}
            </div>
          ))}
        </SelectContent>
      </Select>
      
      {onOpenTradesWindow && (
        <Button
          variant="outline"
          size="icon"
          onClick={onOpenTradesWindow}
          title="Manage Trades"
        >
          <Paintbrush className="h-4 w-4" />
        </Button>
      )}
    </div>
  );
}

function getDivisionName(division: string): string {
  const divisionNames: Record<string, string> = {
    '01': 'General Requirements',
    '02': 'Existing Conditions', 
    '03': 'Concrete',
    '04': 'Masonry',
    '05': 'Metals',
    '06': 'Wood, Plastics, and Composites',
    '07': 'Thermal and Moisture Protection',
    '08': 'Openings',
    '09': 'Finishes',
    '10': 'Specialties',
    '11': 'Equipment',
    '12': 'Furnishings',
    '13': 'Special Construction',
    '14': 'Conveying Equipment',
    '21': 'Fire Suppression',
    '22': 'Plumbing',
    '23': 'Heating, Ventilating, and Air Conditioning',
    '25': 'Integrated Automation',
    '26': 'Electrical',
    '27': 'Communications',
    '28': 'Electronic Safety and Security',
    '31': 'Earthwork',
    '32': 'Exterior Improvements',
    '33': 'Utilities',
    '34': 'Transportation',
    '35': 'Waterway and Marine Construction',
    '40': 'Process Integration',
    '41': 'Material Processing and Handling Equipment',
    '42': 'Process Heating, Cooling, and Drying Equipment',
    '43': 'Process Gas and Liquid Handling, Purification, and Storage Equipment',
    '44': 'Pollution Control Equipment',
    '45': 'Industry-Specific Manufacturing Equipment',
    '46': 'Water and Wastewater Equipment',
    '47': 'Power Generation',
    '48': 'Electrical Power Transmission'
  };
  
  return `${division} - ${divisionNames[division] || 'Unknown Division'}`;
}
