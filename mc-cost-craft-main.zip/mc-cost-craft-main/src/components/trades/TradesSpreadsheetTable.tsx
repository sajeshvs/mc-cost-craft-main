
import React from 'react';
import { Table, TableBody, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Trade, UFGS_DIVISIONS } from '@/types/trades';
import { TradesSpreadsheetDivisionHeader } from './TradesSpreadsheetDivisionHeader';
import { TradesSpreadsheetRow } from './TradesSpreadsheetRow';

interface CellPosition {
  tradeId: string;
  field: string;
}

interface TradesSpreadsheetTableProps {
  trades: Trade[];
  expandedDivisions: Set<string>;
  selectedRows: Set<string>;
  editingCell: { id: string; field: string } | null;
  focusedCell: CellPosition | null;
  selectedCells: Set<string>;
  tableRef: React.RefObject<HTMLTableElement>;
  columnWidths: Record<string, number>;
  isColumnResizing: string | null;
  onToggleDivision: (division: string) => void;
  onAddTrade: (division: string) => void;
  onRowSelect: (tradeId: string, isCtrl: boolean, isShift: boolean) => void;
  onCellMouseDown: (tradeId: string, field: string, e: React.MouseEvent) => void;
  onCellDoubleClick: (tradeId: string, field: string) => void;
  onCellEditComplete: (tradeId: string, field: string, value: string) => void;
  onCellEditCancel: () => void;
  onColumnMouseDown: (columnKey: string, event: React.MouseEvent) => void;
  onColumnDoubleClick: (columnKey: string) => void;
  getCellKey: (tradeId: string, field: string) => string;
}

export function TradesSpreadsheetTable({
  trades,
  expandedDivisions,
  selectedRows,
  editingCell,
  focusedCell,
  selectedCells,
  tableRef,
  columnWidths,
  isColumnResizing,
  onToggleDivision,
  onAddTrade,
  onRowSelect,
  onCellMouseDown,
  onCellDoubleClick,
  onCellEditComplete,
  onCellEditCancel,
  onColumnMouseDown,
  onColumnDoubleClick,
  getCellKey
}: TradesSpreadsheetTableProps) {
  // Group trades by division
  const tradesByDivision = trades.reduce((acc, trade) => {
    if (!acc[trade.division]) {
      acc[trade.division] = [];
    }
    acc[trade.division].push(trade);
    return acc;
  }, {} as Record<string, Trade[]>);

  return (
    <ScrollArea className="flex-1 w-full h-full">
      <div className="overflow-auto w-full h-full" style={{ minWidth: '800px' }}>
        <Table ref={tableRef} className="border-separate border-spacing-0">
          <TableHeader className="sticky top-0 z-10 bg-background">
            <TableRow>
              <TableHead 
                className="w-12 border-r border-b bg-background sticky left-0 z-20"
                style={{ minWidth: '48px', width: '48px' }}
              >
                Select
              </TableHead>
              <TableHead 
                className="border-r border-b bg-background relative group"
                style={{ width: columnWidths.trade_code || 120, minWidth: columnWidths.trade_code || 120 }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-wrap break-words">Trade Code</span>
                  <div 
                    className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-primary/50 transition-colors"
                    onMouseDown={(e) => onColumnMouseDown('trade_code', e)}
                    onDoubleClick={() => onColumnDoubleClick('trade_code')}
                  />
                </div>
              </TableHead>
              <TableHead 
                className="border-r border-b bg-background relative group"
                style={{ width: columnWidths.description || 300, minWidth: columnWidths.description || 300 }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-wrap break-words">Description</span>
                  <div 
                    className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-primary/50 transition-colors"
                    onMouseDown={(e) => onColumnMouseDown('description', e)}
                    onDoubleClick={() => onColumnDoubleClick('description')}
                  />
                </div>
              </TableHead>
              <TableHead 
                className="border-r border-b bg-background relative group"
                style={{ width: columnWidths.color_code || 100, minWidth: columnWidths.color_code || 100 }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-wrap break-words">Color</span>
                  <div 
                    className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-primary/50 transition-colors"
                    onMouseDown={(e) => onColumnMouseDown('color_code', e)}
                    onDoubleClick={() => onColumnDoubleClick('color_code')}
                  />
                </div>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {UFGS_DIVISIONS.map(division => {
              const divisionTrades = tradesByDivision[division.code] || [];
              const isExpanded = expandedDivisions.has(division.code);
              
              return (
                <React.Fragment key={division.code}>
                  <TradesSpreadsheetDivisionHeader
                    divisionCode={division.code}
                    isExpanded={isExpanded}
                    tradesCount={divisionTrades.length}
                    columnWidths={columnWidths}
                    onToggle={() => onToggleDivision(division.code)}
                    onAddTrade={() => onAddTrade(division.code)}
                  />
                  
                  {isExpanded && divisionTrades.map(trade => (
                    <TradesSpreadsheetRow
                      key={trade.id}
                      trade={trade}
                      isSelected={selectedRows.has(trade.id)}
                      editingCell={editingCell}
                      focusedCell={focusedCell}
                      selectedCells={selectedCells}
                      columnWidths={columnWidths}
                      onRowSelect={onRowSelect}
                      onCellMouseDown={onCellMouseDown}
                      onCellDoubleClick={onCellDoubleClick}
                      onCellEditComplete={onCellEditComplete}
                      onCellEditCancel={onCellEditCancel}
                      getCellKey={getCellKey}
                    />
                  ))}
                </React.Fragment>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </ScrollArea>
  );
}
