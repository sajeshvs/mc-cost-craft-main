
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, ChevronRight, Edit, Trash2, Plus } from 'lucide-react';
import { Trade, UFGS_DIVISIONS } from '@/types/trades';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

interface TradesListProps {
  trades: Trade[];
  onEdit: (trade: Trade) => void;
  onDelete: (id: string) => void;
  onAddTrade: (division?: string) => void;
}

export function TradesList({ trades, onEdit, onDelete, onAddTrade }: TradesListProps) {
  const [expandedDivisions, setExpandedDivisions] = useState<Set<string>>(new Set());

  const toggleDivision = (division: string) => {
    const newExpanded = new Set(expandedDivisions);
    if (newExpanded.has(division)) {
      newExpanded.delete(division);
    } else {
      newExpanded.add(division);
    }
    setExpandedDivisions(newExpanded);
  };

  // Group trades by division
  const tradesByDivision = trades.reduce((acc, trade) => {
    if (!acc[trade.division]) {
      acc[trade.division] = [];
    }
    acc[trade.division].push(trade);
    return acc;
  }, {} as Record<string, Trade[]>);

  const divisionsWithTrades = UFGS_DIVISIONS.filter(division => 
    tradesByDivision[division.code]?.length > 0
  );

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">Trades & Subtrades</h3>
        <Button onClick={() => onAddTrade()} size="sm">
          <Plus className="h-4 w-4 mr-1" />
          Add Trade
        </Button>
      </div>

      {divisionsWithTrades.map(division => {
        const divisionTrades = tradesByDivision[division.code] || [];
        const isExpanded = expandedDivisions.has(division.code);

        return (
          <Card key={division.code}>
            <Collapsible open={isExpanded} onOpenChange={() => toggleDivision(division.code)}>
              <CollapsibleTrigger asChild>
                <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2">
                      {isExpanded ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                      <span className="font-mono text-sm bg-muted px-2 py-1 rounded">
                        {division.code}
                      </span>
                      {division.name}
                      <Badge variant="secondary">{divisionTrades.length}</Badge>
                    </CardTitle>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        onAddTrade(division.code);
                      }}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
              </CollapsibleTrigger>
              <CollapsibleContent>
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    {divisionTrades.map(trade => (
                      <div
                        key={trade.id}
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/30 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          {trade.color_code && (
                            <div
                              className="w-4 h-4 rounded border border-border"
                              style={{ backgroundColor: trade.color_code }}
                            />
                          )}
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-sm font-medium">
                                {trade.trade_code}
                              </span>
                              <span className="text-sm">
                                {trade.description}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => onEdit(trade)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="ghost">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Trade</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to delete trade {trade.trade_code} - {trade.description}?
                                  This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => onDelete(trade.id)}>
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        );
      })}

      {divisionsWithTrades.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-muted-foreground mb-4">No trades defined yet</p>
            <Button onClick={() => onAddTrade()}>
              <Plus className="h-4 w-4 mr-2" />
              Add First Trade
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
