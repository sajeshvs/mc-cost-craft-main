
import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus, CornerDownRight, Trash2, Expand, Shrink, Upload, Download, Copy, Clipboard, RefreshCw, Settings, Calculator } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface TradesSpreadsheetToolbarProps {
  onAddTrade: (division: string) => void;
  onInsertRowAbove: () => void;
  onDeleteSelected: () => void;
  onExpandAll: () => void;
  onCollapseAll: () => void;
  onImportCSV: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onExportCSV: () => void;
  selectedRowsCount: number;
}

export function TradesSpreadsheetToolbar({
  onAddTrade,
  onInsertRowAbove,
  onDeleteSelected,
  onExpandAll,
  onCollapseAll,
  onImportCSV,
  onExportCSV,
  selectedRowsCount
}: TradesSpreadsheetToolbarProps) {
  const handleCopy = () => {
    // TODO: Implement copy functionality
    console.log('Copy selected trades');
  };

  const handlePaste = () => {
    // TODO: Implement paste functionality
    console.log('Paste trades');
  };

  const handleRefresh = () => {
    // TODO: Implement refresh functionality
    console.log('Refresh trades');
  };

  const handleSettings = () => {
    // TODO: Implement settings functionality
    console.log('Open trade settings');
  };

  const handleBulkEdit = () => {
    // TODO: Implement bulk edit functionality
    console.log('Bulk edit trades');
  };

  return (
    <div className="flex items-center gap-2 p-2 border-b bg-muted/50 flex-wrap overflow-x-auto">
      {/* Primary Actions */}
      <Button size="sm" variant="outline" onClick={() => onAddTrade('01')}>
        <Plus className="h-4 w-4 mr-1" />
        Add Trade
      </Button>
      
      <Button size="sm" variant="outline" onClick={onInsertRowAbove}>
        <CornerDownRight className="h-4 w-4 mr-1" />
        Insert Above
      </Button>
      
      <Button 
        size="sm" 
        variant="outline" 
        onClick={onDeleteSelected}
        disabled={selectedRowsCount === 0}
        className={selectedRowsCount > 0 ? "text-red-600 hover:text-red-700" : ""}
      >
        <Trash2 className="h-4 w-4 mr-1" />
        Delete {selectedRowsCount > 0 ? `(${selectedRowsCount})` : ''}
      </Button>

      <div className="w-px h-6 bg-border" />

      {/* Edit Actions */}
      <Button 
        size="sm" 
        variant="outline" 
        onClick={handleCopy}
        disabled={selectedRowsCount === 0}
      >
        <Copy className="h-4 w-4 mr-1" />
        Copy
      </Button>

      <Button size="sm" variant="outline" onClick={handlePaste}>
        <Clipboard className="h-4 w-4 mr-1" />
        Paste
      </Button>

      <div className="w-px h-6 bg-border" />

      {/* View Controls */}
      <Button size="sm" variant="outline" onClick={onExpandAll}>
        <Expand className="h-4 w-4 mr-1" />
        Expand All
      </Button>
      
      <Button size="sm" variant="outline" onClick={onCollapseAll}>
        <Shrink className="h-4 w-4 mr-1" />
        Collapse All
      </Button>

      <div className="w-px h-6 bg-border" />

      {/* File Operations */}
      <input
        type="file"
        accept=".csv"
        onChange={onImportCSV}
        className="hidden"
        id="trades-csv-import"
      />
      <label htmlFor="trades-csv-import">
        <Button size="sm" variant="outline" asChild>
          <span>
            <Upload className="h-4 w-4 mr-1" />
            Import CSV
          </span>
        </Button>
      </label>
      
      <Button size="sm" variant="outline" onClick={onExportCSV}>
        <Download className="h-4 w-4 mr-1" />
        Export CSV
      </Button>

      <div className="w-px h-6 bg-border" />

      {/* Utility Actions */}
      <Button size="sm" variant="outline" onClick={handleRefresh}>
        <RefreshCw className="h-4 w-4 mr-1" />
        Refresh
      </Button>

      {/* More Actions Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button size="sm" variant="outline">
            <Settings className="h-4 w-4 mr-1" />
            More
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={handleBulkEdit} disabled={selectedRowsCount === 0}>
            <Calculator className="h-4 w-4 mr-2" />
            Bulk Edit ({selectedRowsCount})
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleSettings}>
            <Settings className="h-4 w-4 mr-2" />
            Trade Settings
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
