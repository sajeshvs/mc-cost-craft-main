
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Download, Upload, Copy, FileText, Table } from 'lucide-react';
import { TradesList } from './TradesList';
import { TradeForm } from './TradeForm';
import { TradesSpreadsheetWindow } from './TradesSpreadsheetWindow';
import { useTrades, useCreateTrade, useUpdateTrade, useDeleteTrade } from '@/hooks/useTrades';
import { Trade, TradeFormData } from '@/types/trades';

interface TradesWindowProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  projectId: string;
}

export function TradesWindow({ open, onOpenChange, projectId }: TradesWindowProps) {
  // Open spreadsheet directly when this window opens
  return (
    <TradesSpreadsheetWindow
      open={open}
      onOpenChange={onOpenChange}
      projectId={projectId}
    />
  );
}
