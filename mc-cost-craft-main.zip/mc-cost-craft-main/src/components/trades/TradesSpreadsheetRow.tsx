
import React from 'react';
import { TableRow, TableCell } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Trade } from '@/types/trades';

interface CellPosition {
  tradeId: string;
  field: string;
}

interface TradesSpreadsheetRowProps {
  trade: Trade;
  isSelected: boolean;
  editingCell: { id: string; field: string } | null;
  focusedCell: CellPosition | null;
  selectedCells: Set<string>;
  columnWidths: Record<string, number>;
  onRowSelect: (tradeId: string, isCtrl: boolean, isShift: boolean) => void;
  onCellMouseDown: (tradeId: string, field: string, e: React.MouseEvent) => void;
  onCellDoubleClick: (tradeId: string, field: string) => void;
  onCellEditComplete: (tradeId: string, field: string, value: string) => void;
  onCellEditCancel: () => void;
  getCellKey: (tradeId: string, field: string) => string;
}

export function TradesSpreadsheetRow({
  trade,
  isSelected,
  editingCell,
  focusedCell,
  selectedCells,
  columnWidths,
  onRowSelect,
  onCellMouseDown,
  onCellDoubleClick,
  onCellEditComplete,
  onCellEditCancel,
  getCellKey
}: TradesSpreadsheetRowProps) {
  return (
    <TableRow
      className={`border-b ${isSelected ? 'bg-primary/10' : 'hover:bg-muted/30'}`}
    >
      <TableCell 
        className="border-r sticky left-0 bg-background z-10"
        style={{ minWidth: '48px', width: '48px' }}
      >
        <input
          type="checkbox"
          checked={isSelected}
          onChange={(e) => {
            const event = e.nativeEvent as MouseEvent;
            onRowSelect(
              trade.id, 
              event.ctrlKey || event.metaKey, 
              event.shiftKey
            );
          }}
        />
      </TableCell>
      <TableCell 
        className={`border-r cursor-pointer font-mono text-sm relative ${
          focusedCell?.tradeId === trade.id && focusedCell?.field === 'trade_code' ? 'ring-2 ring-primary' : ''
        } ${
          selectedCells.has(getCellKey(trade.id, 'trade_code')) ? 'bg-primary/20' : ''
        }`}
        style={{ 
          width: columnWidths.trade_code || 120,
          minWidth: columnWidths.trade_code || 120,
          maxWidth: columnWidths.trade_code || 120
        }}
        onMouseDown={(e) => onCellMouseDown(trade.id, 'trade_code', e)}
        onDoubleClick={() => onCellDoubleClick(trade.id, 'trade_code')}
        tabIndex={0}
      >
        {editingCell?.id === trade.id && editingCell?.field === 'trade_code' ? (
          <Input
            defaultValue={trade.trade_code}
            onBlur={(e) => onCellEditComplete(trade.id, 'trade_code', e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                onCellEditComplete(trade.id, 'trade_code', e.currentTarget.value);
              } else if (e.key === 'Escape') {
                onCellEditCancel();
              }
            }}
            autoFocus
            className="h-8 border-0 bg-transparent p-0 text-sm"
          />
        ) : (
          <div className="w-full h-full p-2 text-wrap break-words whitespace-normal">
            {trade.trade_code}
          </div>
        )}
      </TableCell>
      <TableCell 
        className={`border-r cursor-pointer relative ${
          focusedCell?.tradeId === trade.id && focusedCell?.field === 'description' ? 'ring-2 ring-primary' : ''
        } ${
          selectedCells.has(getCellKey(trade.id, 'description')) ? 'bg-primary/20' : ''
        }`}
        style={{ 
          width: columnWidths.description || 300,
          minWidth: columnWidths.description || 300,
          maxWidth: columnWidths.description || 300
        }}
        onMouseDown={(e) => onCellMouseDown(trade.id, 'description', e)}
        onDoubleClick={() => onCellDoubleClick(trade.id, 'description')}
        tabIndex={0}
      >
        {editingCell?.id === trade.id && editingCell?.field === 'description' ? (
          <Input
            defaultValue={trade.description}
            onBlur={(e) => onCellEditComplete(trade.id, 'description', e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                onCellEditComplete(trade.id, 'description', e.currentTarget.value);
              } else if (e.key === 'Escape') {
                onCellEditCancel();
              }
            }}
            autoFocus
            className="h-8 border-0 bg-transparent p-0 text-sm"
          />
        ) : (
          <div className="w-full h-full p-2 text-wrap break-words whitespace-normal">
            {trade.description}
          </div>
        )}
      </TableCell>
      <TableCell 
        className={`border-r cursor-pointer relative ${
          focusedCell?.tradeId === trade.id && focusedCell?.field === 'color_code' ? 'ring-2 ring-primary' : ''
        } ${
          selectedCells.has(getCellKey(trade.id, 'color_code')) ? 'bg-primary/20' : ''
        }`}
        style={{ 
          width: columnWidths.color_code || 100,
          minWidth: columnWidths.color_code || 100,
          maxWidth: columnWidths.color_code || 100
        }}
        onMouseDown={(e) => onCellMouseDown(trade.id, 'color_code', e)}
        onDoubleClick={() => onCellDoubleClick(trade.id, 'color_code')}
        tabIndex={0}
      >
        <div className="flex items-center gap-2 p-2">
          {editingCell?.id === trade.id && editingCell?.field === 'color_code' ? (
            <Input
              type="color"
              defaultValue={trade.color_code || '#3b82f6'}
              onBlur={(e) => onCellEditComplete(trade.id, 'color_code', e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  onCellEditComplete(trade.id, 'color_code', e.currentTarget.value);
                } else if (e.key === 'Escape') {
                  onCellEditCancel();
                }
              }}
              autoFocus
              className="h-8 w-16 border rounded p-0"
            />
          ) : (
            <>
              <div 
                className="w-6 h-6 rounded border border-gray-300"
                style={{ backgroundColor: trade.color_code || '#3b82f6' }}
              />
              <span className="text-sm font-mono text-wrap break-words">
                {trade.color_code || '#3b82f6'}
              </span>
            </>
          )}
        </div>
      </TableCell>
    </TableRow>
  );
}
