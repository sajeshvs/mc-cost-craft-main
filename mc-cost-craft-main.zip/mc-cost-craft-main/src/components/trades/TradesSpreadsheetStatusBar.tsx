
import React from 'react';

interface TradesSpreadsheetStatusBarProps {
  selectedCellsCount: number;
  selectedRowsCount: number;
  totalTradesCount: number;
}

export function TradesSpreadsheetStatusBar({
  selectedCellsCount,
  selectedRowsCount,
  totalTradesCount
}: TradesSpreadsheetStatusBarProps) {
  return (
    <div className="flex items-center justify-between px-4 py-2 border-t bg-muted/30 text-sm text-muted-foreground">
      <span>
        {selectedCellsCount > 0 ? `${selectedCellsCount} cells selected` : 
         selectedRowsCount > 0 ? `${selectedRowsCount} rows selected` : 
         `${totalTradesCount} total trades`}
      </span>
      <span>
        Use Arrow keys, Tab, Enter to navigate • Double-click to edit • Shift/Ctrl+Click for selection
      </span>
    </div>
  );
}
