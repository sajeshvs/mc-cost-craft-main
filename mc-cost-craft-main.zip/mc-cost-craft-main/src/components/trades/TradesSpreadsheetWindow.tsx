import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Minimize2, Maximize2, X, FileText, Plus } from 'lucide-react';
import { TradesSpreadsheetTable } from './TradesSpreadsheetTable';
import { TradesSpreadsheetToolbar } from './TradesSpreadsheetToolbar';
import { TradesSpreadsheetStatusBar } from './TradesSpreadsheetStatusBar';
import { useTradesSpreadsheetState } from '@/hooks/useTradesSpreadsheetState';
import { useTradesSpreadsheetKeyboard } from '@/hooks/useTradesSpreadsheetKeyboard';

interface TradesSpreadsheetWindowProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  projectId: string;
}

export function TradesSpreadsheetWindow({
  open,
  onOpenChange,
  projectId
}: TradesSpreadsheetWindowProps) {
  const [isMinimized, setIsMinimized] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [windowSize, setWindowSize] = useState({ width: 1200, height: 800 });
  const [position, setPosition] = useState({ x: 100, y: 100 });
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const dragRef = React.useRef<HTMLDivElement>(null);

  const spreadsheetState = useTradesSpreadsheetState(projectId);

  useTradesSpreadsheetKeyboard({
    trades: spreadsheetState.trades || [],
    selectedRows: spreadsheetState.selectedRows || new Set(),
    focusedCell: spreadsheetState.focusedCell,
    selectedCells: spreadsheetState.selectedCells || new Set(),
    editingCell: spreadsheetState.editingCell,
    onCellEditComplete: spreadsheetState.handleCellEditComplete || (() => {}),
    onCellEditCancel: spreadsheetState.handleCellEditCancel || (() => {}),
    onDeleteSelected: () => spreadsheetState.handleDeleteTrades && spreadsheetState.handleDeleteTrades(Array.from(spreadsheetState.selectedRows || [])),
    onRowSelect: (tradeId: string) => spreadsheetState.handleRowSelection && spreadsheetState.handleRowSelection(tradeId, false, false),
    onCellMouseDown: spreadsheetState.handleCellMouseDown || (() => {}),
    getCellKey: spreadsheetState.getCellKey || (() => '')
  });

  // Handle window dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    if (isMaximized) return;
    
    setIsDragging(true);
    const rect = dragRef.current?.getBoundingClientRect();
    if (rect) {
      const offsetX = e.clientX - rect.left;
      const offsetY = e.clientY - rect.top;

      const handleMouseMove = (e: MouseEvent) => {
        setPosition({
          x: e.clientX - offsetX,
          y: e.clientY - offsetY
        });
      };

      const handleMouseUp = () => {
        setIsDragging(false);
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }
  };

  // Handle window resizing
  const handleResize = (e: React.MouseEvent, direction: 'se' | 'e' | 's' | 'w' | 'n') => {
    if (isMaximized) return;
    
    e.preventDefault();
    setIsResizing(true);
    const startX = e.clientX;
    const startY = e.clientY;
    const startWidth = windowSize.width;
    const startHeight = windowSize.height;
    const startPos = position;

    const handleMouseMove = (e: MouseEvent) => {
      const deltaX = e.clientX - startX;
      const deltaY = e.clientY - startY;

      let newWidth = startWidth;
      let newHeight = startHeight;
      let newX = startPos.x;
      let newY = startPos.y;

      if (direction.includes('e')) {
        newWidth = Math.max(600, startWidth + deltaX);
      }
      if (direction.includes('w')) {
        newWidth = Math.max(600, startWidth - deltaX);
        newX = startPos.x + deltaX;
      }
      if (direction.includes('s')) {
        newHeight = Math.max(400, startHeight + deltaY);
      }
      if (direction.includes('n')) {
        newHeight = Math.max(400, startHeight - deltaY);
        newY = startPos.y + deltaY;
      }

      setWindowSize({ width: newWidth, height: newHeight });
      setPosition({ x: newX, y: newY });
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  if (!open) return null;

  // Fixed windowStyle with proper string types
  const windowStyle: React.CSSProperties = isMaximized
    ? { 
        position: 'fixed', 
        top: '0px', 
        left: '0px', 
        right: '0px', 
        bottom: '0px', 
        zIndex: 50 
      }
    : { 
        position: 'fixed', 
        top: `${position.y}px`, 
        left: `${position.x}px`, 
        zIndex: 50,
        width: isMinimized ? '300px' : `${windowSize.width}px`,
        height: isMinimized ? '60px' : `${windowSize.height}px`
      };

  return (
    <div style={windowStyle} className="bg-white border shadow-lg rounded-lg flex flex-col overflow-hidden">
      {/* Title Bar */}
      <div
        ref={dragRef}
        className="flex items-center justify-between p-2 border-b bg-orange-50 cursor-move select-none"
        onMouseDown={handleMouseDown}
      >
        <div className="flex items-center gap-2">
          <FileText className="h-4 w-4 text-orange-600" />
          <span className="font-medium text-sm">Trades Spreadsheet</span>
          <span className="text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded">
            {spreadsheetState.trades?.length || 0} trades
          </span>
        </div>
        
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMinimized(!isMinimized)}
            className="h-6 w-6 p-0"
          >
            <Minimize2 className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMaximized(!isMaximized)}
            className="h-6 w-6 p-0"
          >
            <Maximize2 className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onOpenChange(false)}
            className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </div>

      {/* Content */}
      {!isMinimized && (
        <div className="flex-1 flex flex-col overflow-hidden">
          <TradesSpreadsheetToolbar
            onAddTrade={spreadsheetState.handleAddTrade || (() => {})}
            onInsertRowAbove={() => {}}
            onDeleteSelected={() => spreadsheetState.handleDeleteTrades && spreadsheetState.handleDeleteTrades(Array.from(spreadsheetState.selectedRows || []))}
            onExpandAll={spreadsheetState.handleExpandAll || (() => {})}
            onCollapseAll={spreadsheetState.handleCollapseAll || (() => {})}
            onImportCSV={spreadsheetState.handleImportCSV || (() => {})}
            onExportCSV={spreadsheetState.handleExportCSV || (() => {})}
            selectedRowsCount={spreadsheetState.selectedRows?.size || 0}
          />
          
          <div className="flex-1 overflow-hidden">
            <TradesSpreadsheetTable
              trades={spreadsheetState.trades || []}
              expandedDivisions={spreadsheetState.expandedDivisions || new Set()}
              selectedRows={spreadsheetState.selectedRows || new Set()}
              editingCell={spreadsheetState.editingCell}
              focusedCell={spreadsheetState.focusedCell}
              selectedCells={spreadsheetState.selectedCells || new Set()}
              tableRef={spreadsheetState.tableRef}
              columnWidths={spreadsheetState.columnWidths || {}}
              isColumnResizing={spreadsheetState.isColumnResizing ? 'resizing' : null}
              onToggleDivision={spreadsheetState.toggleDivision || (() => {})}
              onAddTrade={spreadsheetState.handleAddTrade || (() => {})}
              onRowSelect={(tradeId: string) => spreadsheetState.handleRowSelection && spreadsheetState.handleRowSelection(tradeId, false, false)}
              onCellMouseDown={spreadsheetState.handleCellMouseDown || (() => {})}
              onCellDoubleClick={spreadsheetState.handleCellDoubleClick || (() => {})}
              onCellEditComplete={spreadsheetState.handleCellEditComplete || (() => {})}
              onCellEditCancel={spreadsheetState.handleCellEditCancel || (() => {})}
              onColumnMouseDown={spreadsheetState.handleColumnMouseDown || (() => {})}
              onColumnDoubleClick={spreadsheetState.handleColumnDoubleClick || (() => {})}
              getCellKey={spreadsheetState.getCellKey || (() => '')}
            />
          </div>
          
          <TradesSpreadsheetStatusBar
            selectedCellsCount={spreadsheetState.selectedCells?.size || 0}
            selectedRowsCount={spreadsheetState.selectedRows?.size || 0}
            totalTradesCount={spreadsheetState.trades?.length || 0}
          />
        </div>
      )}

      {/* Resize handles */}
      {!isMinimized && !isMaximized && (
        <>
          <div
            className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize bg-gray-300 hover:bg-gray-400 transition-colors opacity-50 hover:opacity-100"
            onMouseDown={(e) => handleResize(e, 'se')}
          />
          <div
            className="absolute top-8 right-0 bottom-4 w-2 cursor-e-resize hover:bg-blue-200 transition-colors opacity-0 hover:opacity-50"
            onMouseDown={(e) => handleResize(e, 'e')}
          />
          <div
            className="absolute bottom-0 left-0 right-4 h-2 cursor-s-resize hover:bg-blue-200 transition-colors opacity-0 hover:opacity-50"
            onMouseDown={(e) => handleResize(e, 's')}
          />
          <div
            className="absolute top-8 left-0 bottom-4 w-2 cursor-w-resize hover:bg-blue-200 transition-colors opacity-0 hover:opacity-50"
            onMouseDown={(e) => handleResize(e, 'w')}
          />
          <div
            className="absolute top-0 left-4 right-4 h-2 cursor-n-resize hover:bg-blue-200 transition-colors opacity-0 hover:opacity-50"
            onMouseDown={(e) => handleResize(e, 'n')}
          />
        </>
      )}
    </div>
  );
}
