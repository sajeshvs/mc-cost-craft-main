
import { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { BOQItem } from '@/types/mccost';

interface EditableCellProps {
  value: any;
  field: keyof BOQItem;
  isEditing: boolean;
  onStartEdit: () => void;
  onSave: (value: any) => void;
  onCancel: () => void;
  className?: string;
  disabled?: boolean;
}

export function EditableCell({ 
  value, 
  field, 
  isEditing, 
  onStartEdit, 
  onSave, 
  onCancel,
  className = "",
  disabled = false
}: EditableCellProps) {
  const [editValue, setEditValue] = useState(String(value || ''));
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  useEffect(() => {
    setEditValue(String(value || ''));
  }, [value]);

  const displayValue = () => {
    if (field === 'level_type') {
      if (!value || value === 'item') return '';
      if (value === 'comment') return 'c';
      if (value && value.startsWith('level_')) {
        return value.split('_')[1];
      }
      return value || '';
    }
    if (field === 'quantity' && typeof value === 'number') {
      return value.toLocaleString(undefined, { 
        minimumFractionDigits: 0,
        maximumFractionDigits: 2 
      });
    }
    if (field === 'page_number' && value === '+') {
      return '+ (Break)';
    }
    return value || '';
  };

  const handleSave = () => {
    if (field === 'quantity') {
      const numValue = parseFloat(editValue) || 0;
      onSave(numValue);
    } else if (field === 'page_number') {
      if (editValue === '+') {
        onSave('+');
      } else {
        const numValue = parseInt(editValue) || null;
        onSave(numValue);
      }
    } else if (field === 'level_type') {
      const trimmed = editValue.toLowerCase().trim();
      if (trimmed === 'c') {
        onSave('comment');
      } else if (trimmed === '' || trimmed === 'item') {
        onSave('item');
      } else {
        const num = parseInt(trimmed);
        if (!isNaN(num) && num >= 1 && num <= 9) {
          onSave(`level_${num}`);
        } else {
          onSave('item');
        }
      }
    } else {
      onSave(editValue);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSave();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onCancel();
    } else if (e.key === 'Tab') {
      handleSave();
    }
  };

  if (disabled) {
    return (
      <div className={`h-full flex items-center px-2 py-1 min-h-[2.5rem] w-full bg-gray-100 text-gray-500 ${className}`}>
        <span className="truncate w-full text-left break-words whitespace-pre-wrap">
          {displayValue()}
        </span>
      </div>
    );
  }

  if (isEditing) {
    return (
      <Input
        ref={inputRef}
        value={editValue}
        onChange={(e) => setEditValue(e.target.value)}
        onBlur={handleSave}
        onKeyDown={handleKeyDown}
        className="h-full border-2 border-blue-500 shadow-none bg-blue-50 focus:ring-2 focus:ring-blue-500 px-2"
        type={field === 'quantity' ? 'number' : 'text'}
        step={field === 'quantity' ? '0.01' : undefined}
        placeholder={field === 'page_number' ? 'Page # or +' : field === 'level_type' ? '1-9,c' : undefined}
        maxLength={field === 'level_type' ? 1 : undefined}
      />
    );
  }

  const getCellStyles = () => {
    let baseClass = `
      h-full flex items-center px-2 py-1 cursor-pointer hover:bg-blue-50 
      transition-colors duration-150 min-h-[2.5rem] w-full
      border border-transparent hover:border-blue-200 rounded
      focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500
    `;

    // Text alignment based on field
    if (field === 'quantity') {
      baseClass += ' justify-end';
    } else if (field === 'page_number' || field === 'level_type') {
      baseClass += ' justify-center';
    } else {
      baseClass += ' justify-start';
    }

    // Special styling for comment rows
    if (field === 'level_type' && value === 'comment') {
      baseClass += ' text-green-700 italic font-medium bg-green-50';
    }

    return baseClass;
  };

  return (
    <div
      className={`${getCellStyles()} ${className}`}
      onClick={onStartEdit}
      title="Click to edit"
      tabIndex={0}
      role="button"
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onStartEdit();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          (e.target as HTMLElement).blur();
        }
      }}
    >
      <span className="truncate w-full text-left break-words whitespace-pre-wrap overflow-wrap-anywhere">
        {displayValue()}
      </span>
    </div>
  );
}
