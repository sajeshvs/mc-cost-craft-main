
import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, ChevronRight, Layers } from 'lucide-react';

interface LevelTotals {
  totalAmount: number;
  labor: number;
  material: number;
  equipment: number;
  subcontractor: number;
  consultant: number;
  itemCount: number;
}

interface BOQHierarchyManagerProps {
  expandedLevels: Set<string>;
  onExpandAll: () => void;
  onCollapseAll: () => void;
  onToggleLevel: (levelId: string) => void;
  levelTotals: Record<string, LevelTotals>;
}

export function BOQHierarchyManager({
  expandedLevels,
  onExpandAll,
  onCollapseAll,
  onToggleLevel,
  levelTotals
}: BOQHierarchyManagerProps) {
  const totalExpanded = expandedLevels.size;
  const totalLevels = Object.keys(levelTotals).length;
  const grandTotal = Object.values(levelTotals).reduce(
    (acc, level) => ({ 
      itemCount: acc.itemCount + level.itemCount,
      totalAmount: acc.totalAmount + level.totalAmount 
    }), 
    { itemCount: 0, totalAmount: 0 }
  );

  return (
    <div className="flex items-center justify-between p-2 bg-blue-50 border-b border-blue-200">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1 text-sm font-medium text-blue-700">
          <Layers className="h-4 w-4" />
          <span>Levels: {totalExpanded} expanded</span>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onExpandAll}
            className="h-7 px-2 text-xs"
            disabled={totalExpanded === totalLevels}
          >
            <ChevronDown className="h-3 w-3 mr-1" />
            Expand All
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={onCollapseAll}
            className="h-7 px-2 text-xs"
            disabled={totalExpanded === 0}
          >
            <ChevronRight className="h-3 w-3 mr-1" />
            Collapse All
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Badge variant="secondary" className="text-xs">
          Total Items: {grandTotal.itemCount.toLocaleString()}
        </Badge>
        <Badge variant="secondary" className="text-xs">
          Grand Total: ${grandTotal.totalAmount.toLocaleString()}
        </Badge>
      </div>
    </div>
  );
}
