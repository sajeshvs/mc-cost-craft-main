
import React, { useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface BOQTradeCodeCellProps {
  value: string;
  isEditing: boolean;
  onEdit: () => void;
  onSave: (value: string) => void;
  onCancel: () => void;
  disabled?: boolean;
}

export function BOQTradeCodeCell({
  value,
  isEditing,
  onEdit,
  onSave,
  onCancel,
  disabled = false
}: BOQTradeCodeCellProps) {
  const { data: trades = [] } = useQuery({
    queryKey: ['trades'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('trades')
        .select('trade_code, description')
        .order('trade_code');
      
      if (error) throw error;
      return data || [];
    }
  });

  // Comprehensive filtering to ensure no empty values reach SelectItem
  const validTrades = trades.filter(trade => 
    trade && 
    typeof trade === 'object' &&
    trade.trade_code && 
    typeof trade.trade_code === 'string' &&
    trade.trade_code.trim() !== '' &&
    trade.description &&
    typeof trade.description === 'string' &&
    trade.description.trim() !== ''
  );

  if (disabled) {
    return <div className="p-1 text-gray-400 text-xs">-</div>;
  }

  if (isEditing) {
    return (
      <Select value={value} onValueChange={(newValue) => {
        // Validate the value before saving
        if (newValue && newValue.trim() !== '') {
          onSave(newValue);
        }
      }}>
        <SelectTrigger className="w-full h-6 text-xs">
          <SelectValue placeholder="Select trade" />
        </SelectTrigger>
        <SelectContent>
          {validTrades.map((trade) => (
            <SelectItem key={trade.trade_code} value={trade.trade_code}>
              <div className="text-xs">
                <div className="font-mono">{trade.trade_code}</div>
                <div className="text-gray-600 truncate">{trade.description}</div>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }

  return (
    <div
      onClick={onEdit}
      className="p-1 text-xs cursor-pointer hover:bg-gray-100 rounded font-mono"
      title="Click to select trade code"
    >
      {value || 'Select'}
    </div>
  );
}
