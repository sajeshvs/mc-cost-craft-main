
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { BOQItem } from '@/types/mccost';

interface BOQLevelCellProps {
  value: BOQItem['level_type'];
  isEditing: boolean;
  onEdit: () => void;
  onSave: (value: string) => void;
  onCancel: () => void;
}

export function BOQLevelCell({ 
  value, 
  isEditing, 
  onEdit, 
  onSave, 
  onCancel 
}: BOQLevelCellProps) {
  const [editValue, setEditValue] = useState('');

  React.useEffect(() => {
    if (isEditing) {
      setEditValue(getDisplayValue(value));
    }
  }, [isEditing, value]);

  const getDisplayValue = (levelType: BOQItem['level_type']): string => {
    if (levelType === 'comment') return 'C';
    if (levelType === 'item') return '';
    if (levelType && levelType.startsWith('level_')) {
      return levelType.split('_')[1];
    }
    return '';
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      // Ensure we don't save empty values that could cause issues
      const valueToSave = editValue.trim();
      if (valueToSave === '') {
        onSave('item'); // Default to 'item' if empty
      } else {
        onSave(valueToSave);
      }
    } else if (e.key === 'Escape') {
      onCancel();
    }
  };

  const handleBlur = () => {
    // Ensure we don't save empty values that could cause issues
    const valueToSave = editValue.trim();
    if (valueToSave === '') {
      onSave('item'); // Default to 'item' if empty
    } else {
      onSave(valueToSave);
    }
  };

  if (isEditing) {
    return (
      <Input
        value={editValue}
        onChange={(e) => setEditValue(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
        className="w-12 h-6 p-1 text-center text-xs font-mono"
        maxLength={1}
        autoFocus
      />
    );
  }

  return (
    <div
      onClick={onEdit}
      className="w-12 h-6 flex items-center justify-center text-xs font-mono cursor-pointer hover:bg-gray-100 rounded"
      title="Click to edit level (1-9 for levels, C for comment)"
    >
      {getDisplayValue(value)}
    </div>
  );
}
