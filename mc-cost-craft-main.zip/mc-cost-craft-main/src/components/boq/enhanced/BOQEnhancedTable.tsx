
import React, { useState, useCallback } from 'react';
import { BOQItem } from '@/types/mccost';
import { BOQEnhancedTableHeader } from './BOQEnhancedTableHeader';
import { BOQEnhancedTableRow } from './BOQEnhancedTableRow';
import { BOQHierarchyManager } from './BOQHierarchyManager';
import { BOQTotalsSummary } from './BOQTotalsSummary';
import { BOQFilterToolbar } from './BOQFilterToolbar';
import { BOQContextMenu } from './BOQContextMenu';
import { useBOQSelection } from '../hooks/useBOQSelection';
import { useBOQHierarchy } from '../hooks/useBOQHierarchy';
import { useBOQMultiCellSelection } from '../hooks/useBOQMultiCellSelection';
import { useBOQKeyboardNavigation } from '../hooks/useBOQKeyboardNavigation';
import { useBOQClipboard } from '../hooks/useBOQClipboard';
import { useToast } from '@/hooks/use-toast';

interface BOQEnhancedTableProps {
  items: BOQItem[];
  onUpdateItem: (id: string, updates: Partial<BOQItem>) => void;
  onDeleteItems: (ids: string[]) => void;
  onAddItem: () => void;
  onReorderItems: (items: BOQItem[]) => void;
}

export function BOQEnhancedTable({
  items,
  onUpdateItem,
  onDeleteItems,
  onAddItem,
  onReorderItems
}: BOQEnhancedTableProps) {
  const { toast } = useToast();
  
  const {
    selectedRows,
    editingCell,
    setEditingCell,
    handleRowSelect,
    handleSelectAll,
    clearSelection,
    filteredItems,
    filters,
    updateFilter,
    clearFilters
  } = useBOQSelection(items);

  const {
    expandedLevels,
    visibleItems,
    levelTotals,
    toggleLevel,
    expandAll,
    collapseAll
  } = useBOQHierarchy(filteredItems);

  const {
    selectedCells,
    isSelecting,
    startCellSelection,
    updateCellSelection,
    endCellSelection,
    clearCellSelection,
    isCellSelected,
    getSelectedCellsData,
    applyToSelectedCells
  } = useBOQMultiCellSelection();

  const {
    copyRows,
    copyCells,
    pasteRows,
    pasteCells,
    canPaste
  } = useBOQClipboard();

  const [draggedItem, setDraggedItem] = useState<string | null>(null);

  const handleCellEdit = useCallback((itemId: string, field: keyof BOQItem, value: any) => {
    // Handle special cases for level_type
    if (field === 'level_type') {
      const processedValue = processLevelValue(value);
      onUpdateItem(itemId, { [field]: processedValue });
    } else if (field === 'page_number') {
      // Handle page breaks with + notation
      const pageValue = typeof value === 'string' && value.endsWith('+') 
        ? value.slice(0, -1) 
        : value;
      onUpdateItem(itemId, { [field]: pageValue });
    } else {
      onUpdateItem(itemId, { [field]: value });
    }
    setEditingCell(null);
  }, [onUpdateItem, setEditingCell]);

  const processLevelValue = (value: string): BOQItem['level_type'] => {
    const trimmed = value.toLowerCase().trim();
    
    if (trimmed === 'c' || trimmed === 'comment') {
      return 'comment';
    }
    
    const num = parseInt(trimmed);
    if (!isNaN(num) && num >= 1 && num <= 9) {
      return `level_${num}` as BOQItem['level_type'];
    }
    
    return 'item';
  };

  // Keyboard navigation
  useBOQKeyboardNavigation({
    visibleItems,
    editingCell,
    setEditingCell,
    onCellSave: handleCellEdit,
    selectedCells,
    clearCellSelection,
    onDeleteItems,
    selectedRows
  });

  // Multi-cell selection handlers
  const handleCellMouseDown = (rowId: string, field: keyof BOQItem, e: React.MouseEvent) => {
    const isCtrlClick = e.ctrlKey || e.metaKey;
    startCellSelection(rowId, field, isCtrlClick);
  };

  const handleCellMouseEnter = (rowId: string, field: keyof BOQItem) => {
    updateCellSelection(rowId, field, visibleItems);
  };

  const handleCellMouseUp = () => {
    endCellSelection();
  };

  // Context menu handlers
  const handleCopyRows = useCallback(() => {
    const selectedItems = visibleItems.filter(item => selectedRows.has(item.id));
    copyRows(selectedItems);
  }, [visibleItems, selectedRows, copyRows]);

  const handleCopyCells = useCallback(() => {
    const cellsData = getSelectedCellsData(visibleItems);
    const formattedData = cellsData.map(cell => ({ field: cell.field, value: cell.value }));
    copyCells(formattedData);
  }, [getSelectedCellsData, visibleItems, copyCells]);

  const handlePasteCells = useCallback(() => {
    pasteCells(selectedCells, visibleItems, handleCellEdit);
  }, [pasteCells, selectedCells, visibleItems, handleCellEdit]);

  const handleInsertRowAbove = useCallback(() => {
    // Implementation for inserting row above
    onAddItem();
  }, [onAddItem]);

  const handleInsertRowBelow = useCallback(() => {
    // Implementation for inserting row below
    onAddItem();
  }, [onAddItem]);

  // Drag and drop handlers
  const handleDragStart = (e: React.DragEvent, itemId: string) => {
    setDraggedItem(itemId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    if (!draggedItem || draggedItem === targetId) return;

    const draggedIndex = items.findIndex(item => item.id === draggedItem);
    const targetIndex = items.findIndex(item => item.id === targetId);
    
    if (draggedIndex === -1 || targetIndex === -1) return;

    const newItems = [...items];
    const [draggedItemObj] = newItems.splice(draggedIndex, 1);
    newItems.splice(targetIndex, 0, draggedItemObj);
    
    onReorderItems(newItems);
    setDraggedItem(null);
  };

  const getRowBackground = (item: BOQItem): string => {
    if (item.level_type === 'comment') return 'bg-gray-50';
    if (item.level_type === 'level_1') return 'bg-blue-50';
    if (item.level_type === 'level_2') return 'bg-indigo-25';
    if (item.level_type === 'level_3') return 'bg-purple-25';
    return 'bg-white';
  };

  return (
    <div className="flex flex-col h-full">
      {/* Hierarchy Controls */}
      <BOQHierarchyManager
        expandedLevels={expandedLevels}
        onExpandAll={expandAll}
        onCollapseAll={collapseAll}
        onToggleLevel={toggleLevel}
        levelTotals={levelTotals}
      />

      {/* Filter Toolbar */}
      <BOQFilterToolbar
        filters={filters}
        onFilterChange={updateFilter}
        onClearFilters={clearFilters}
      />

      {/* Selection Info */}
      {selectedCells.size > 0 && (
        <div className="px-4 py-2 bg-blue-50 border-b text-sm text-blue-700">
          {selectedCells.size} cells selected. Use Ctrl+C to copy, Ctrl+V to paste, or right-click for options.
        </div>
      )}

      {/* Main Table with Context Menu */}
      <div className="flex-1 overflow-auto border border-gray-200 bg-white">
        <BOQContextMenu
          selectedRows={selectedRows}
          selectedCells={selectedCells}
          onCopyRows={handleCopyRows}
          onCutRows={handleCopyRows}
          onPasteRows={() => {}}
          onCopyCells={handleCopyCells}
          onPasteCells={handlePasteCells}
          onInsertRowAbove={handleInsertRowAbove}
          onInsertRowBelow={handleInsertRowBelow}
          onDeleteRows={() => onDeleteItems(Array.from(selectedRows))}
          onMoveRowsUp={() => {}}
          onMoveRowsDown={() => {}}
          onEditCell={() => {}}
          onClearCellSelection={clearCellSelection}
          canPaste={canPaste}
        >
          <table className="w-full border-collapse table-fixed">
            <BOQEnhancedTableHeader
              selectedCount={selectedRows.size}
              totalCount={visibleItems.length}
              onSelectAll={handleSelectAll}
            />
            <tbody>
              {visibleItems.map((item, index) => (
                <BOQEnhancedTableRow
                  key={item.id}
                  item={item}
                  index={index}
                  isSelected={selectedRows.has(item.id)}
                  editingCell={editingCell}
                  onSelect={() => handleRowSelect(item.id)}
                  onEdit={setEditingCell}
                  onSave={handleCellEdit}
                  onCancel={() => setEditingCell(null)}
                  onToggleLevel={() => toggleLevel(item.id)}
                  isExpanded={expandedLevels.has(item.id)}
                  backgroundColor={getRowBackground(item)}
                  onDragStart={(e) => handleDragStart(e, item.id)}
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDrop(e, item.id)}
                  isDragging={draggedItem === item.id}
                  onCellMouseDown={handleCellMouseDown}
                  onCellMouseEnter={handleCellMouseEnter}
                  onCellMouseUp={handleCellMouseUp}
                  isCellSelected={isCellSelected}
                />
              ))}
            </tbody>
          </table>
        </BOQContextMenu>
      </div>

      {/* Totals Summary */}
      <BOQTotalsSummary
        visibleItems={visibleItems}
        levelTotals={levelTotals}
      />
    </div>
  );
}
