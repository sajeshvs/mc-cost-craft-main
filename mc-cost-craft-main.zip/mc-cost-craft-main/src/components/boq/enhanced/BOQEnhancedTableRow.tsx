
import React from 'react';
import { BOQItem } from '@/types/mccost';
import { Checkbox } from '@/components/ui/checkbox';
import { ChevronRight, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { BOQLevelCell } from './BOQLevelCell';
import { BOQEditableCell } from './BOQEditableCell';
import { BOQTradeCodeCell } from './BOQTradeCodeCell';
import { BOQPriceCodeCell } from './BOQPriceCodeCell';

interface BOQEnhancedTableRowProps {
  item: BOQItem;
  index: number;
  isSelected: boolean;
  editingCell: { rowId: string; field: keyof BOQItem } | null;
  onSelect: () => void;
  onEdit: (cell: { rowId: string; field: keyof BOQItem }) => void;
  onSave: (itemId: string, field: keyof BOQItem, value: any) => void;
  onCancel: () => void;
  onToggleLevel: () => void;
  isExpanded: boolean;
  backgroundColor: string;
  onDragStart: (e: React.DragEvent) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent) => void;
  isDragging: boolean;
  // Multi-cell selection props
  onCellMouseDown?: (rowId: string, field: keyof BOQItem, e: React.MouseEvent) => void;
  onCellMouseEnter?: (rowId: string, field: keyof BOQItem) => void;
  onCellMouseUp?: () => void;
  isCellSelected?: (rowId: string, field: keyof BOQItem) => boolean;
}

export function BOQEnhancedTableRow({
  item,
  index,
  isSelected,
  editingCell,
  onSelect,
  onEdit,
  onSave,
  onCancel,
  onToggleLevel,
  isExpanded,
  backgroundColor,
  onDragStart,
  onDragOver,
  onDrop,
  isDragging,
  onCellMouseDown,
  onCellMouseEnter,
  onCellMouseUp,
  isCellSelected
}: BOQEnhancedTableRowProps) {
  const isCommentRow = item.level_type === 'comment';
  const isLevelRow = item.level_type && item.level_type.startsWith('level_');
  const hasPageBreak = item.page_number != null && 
                      String(item.page_number).includes('+');
  
  const rowClasses = [
    'border-b border-gray-200 hover:bg-gray-50 transition-colors h-10',
    backgroundColor,
    isSelected ? 'ring-2 ring-blue-500' : '',
    isDragging ? 'opacity-50' : '',
    isCommentRow ? 'italic text-gray-600' : '',
    hasPageBreak ? 'border-b-4 border-blue-400' : ''
  ].filter(Boolean).join(' ');

  const isEditing = (field: keyof BOQItem) => 
    editingCell?.rowId === item.id && editingCell?.field === field;

  const handleKeyDown = (field: keyof BOQItem) => (e: React.KeyboardEvent) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const fields: (keyof BOQItem)[] = ['level_type', 'page_number', 'item_no', 'price_code', 'description', 'unit', 'quantity'];
      const currentIndex = fields.indexOf(field);
      const nextIndex = e.shiftKey 
        ? (currentIndex - 1 + fields.length) % fields.length 
        : (currentIndex + 1) % fields.length;
      onEdit({ rowId: item.id, field: fields[nextIndex] });
    } else if (e.key === 'Enter') {
      e.preventDefault();
      onEdit({ rowId: item.id, field });
    } else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault();
      // Navigate vertically - this would need parent component support
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
      e.preventDefault();
      const fields: (keyof BOQItem)[] = ['level_type', 'page_number', 'item_no', 'price_code', 'description', 'unit', 'quantity'];
      const currentIndex = fields.indexOf(field);
      const nextIndex = e.key === 'ArrowLeft' 
        ? Math.max(0, currentIndex - 1)
        : Math.min(fields.length - 1, currentIndex + 1);
      onEdit({ rowId: item.id, field: fields[nextIndex] });
    }
  };

  const handleCellMouseDown = (field: keyof BOQItem) => (e: React.MouseEvent) => {
    if (onCellMouseDown) {
      onCellMouseDown(item.id, field, e);
    }
  };

  const handleCellMouseEnter = (field: keyof BOQItem) => () => {
    if (onCellMouseEnter) {
      onCellMouseEnter(item.id, field);
    }
  };

  const getCellSelectedClass = (field: keyof BOQItem) => {
    return isCellSelected?.(item.id, field) ? 'bg-blue-100 ring-1 ring-blue-300' : '';
  };

  return (
    <tr
      className={rowClasses}
      draggable
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
    >
      {/* Selection Checkbox */}
      <td className="p-1 border-r border-gray-200 text-center w-10">
        <Checkbox checked={isSelected} onCheckedChange={onSelect} />
      </td>

      {/* Level with Expand/Collapse */}
      <td className="p-1 border-r border-gray-200 w-12">
        <div className="flex items-center gap-1 justify-center">
          {isLevelRow && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleLevel}
              className="p-0 h-5 w-5"
            >
              {isExpanded ? (
                <ChevronDown className="h-3 w-3" />
              ) : (
                <ChevronRight className="h-3 w-3" />
              )}
            </Button>
          )}
          <BOQLevelCell
            value={item.level_type || 'item'}
            isEditing={isEditing('level_type')}
            onEdit={() => onEdit({ rowId: item.id, field: 'level_type' })}
            onSave={(value) => onSave(item.id, 'level_type', value)}
            onCancel={onCancel}
          />
        </div>
      </td>

      {/* Page */}
      <td 
        className={`p-1 border-r border-gray-200 w-16 ${getCellSelectedClass('page_number')}`}
        tabIndex={0} 
        onKeyDown={handleKeyDown('page_number')}
        onMouseDown={handleCellMouseDown('page_number')}
        onMouseEnter={handleCellMouseEnter('page_number')}
        onMouseUp={onCellMouseUp}
      >
        <BOQEditableCell
          value={item.page_number?.toString() || ''}
          isEditing={isEditing('page_number')}
          onEdit={() => onEdit({ rowId: item.id, field: 'page_number' })}
          onSave={(value) => onSave(item.id, 'page_number', value)}
          onCancel={onCancel}
          className="text-center font-mono text-xs h-full break-words"
          placeholder="A-101"
          disabled={false}
        />
      </td>

      {/* Item No */}
      <td 
        className={`p-1 border-r border-gray-200 w-20 ${getCellSelectedClass('item_no')}`}
        tabIndex={0} 
        onKeyDown={handleKeyDown('item_no')}
        onMouseDown={handleCellMouseDown('item_no')}
        onMouseEnter={handleCellMouseEnter('item_no')}
        onMouseUp={onCellMouseUp}
      >
        <BOQEditableCell
          value={item.item_no || ''}
          isEditing={isEditing('item_no')}
          onEdit={() => onEdit({ rowId: item.id, field: 'item_no' })}
          onSave={(value) => onSave(item.id, 'item_no', value)}
          onCancel={onCancel}
          className="font-mono text-xs h-full break-words"
          disabled={false}
        />
      </td>

      {/* Trade Code */}
      <td 
        className={`p-1 border-r border-gray-200 w-24 ${getCellSelectedClass('price_code')}`}
        tabIndex={0} 
        onKeyDown={handleKeyDown('price_code')}
        onMouseDown={handleCellMouseDown('price_code')}
        onMouseEnter={handleCellMouseEnter('price_code')}
        onMouseUp={onCellMouseUp}
      >
        <div className="text-xs font-mono break-words overflow-hidden">
          <BOQTradeCodeCell
            value={item.price_code || ''}
            isEditing={isEditing('price_code')}
            onEdit={() => onEdit({ rowId: item.id, field: 'price_code' })}
            onSave={(value) => onSave(item.id, 'price_code', value)}
            onCancel={onCancel}
            disabled={isCommentRow}
          />
        </div>
      </td>

      {/* Price Code */}
      <td 
        className={`p-1 border-r border-gray-200 w-32 ${getCellSelectedClass('price_code')}`}
        tabIndex={0} 
        onKeyDown={handleKeyDown('price_code')}
        onMouseDown={handleCellMouseDown('price_code')}
        onMouseEnter={handleCellMouseEnter('price_code')}
        onMouseUp={onCellMouseUp}
      >
        <div className="text-xs font-mono break-words overflow-hidden">
          <BOQPriceCodeCell
            value={item.price_code || ''}
            isEditing={isEditing('price_code')}
            onEdit={() => onEdit({ rowId: item.id, field: 'price_code' })}
            onSave={(value) => onSave(item.id, 'price_code', value)}
            onCancel={onCancel}
            disabled={isCommentRow}
          />
        </div>
      </td>

      {/* Description */}
      <td 
        className={`p-1 border-r border-gray-200 min-w-64 ${getCellSelectedClass('description')}`}
        tabIndex={0} 
        onKeyDown={handleKeyDown('description')}
        onMouseDown={handleCellMouseDown('description')}
        onMouseEnter={handleCellMouseEnter('description')}
        onMouseUp={onCellMouseUp}
      >
        <div className="text-xs break-words overflow-hidden">
          <BOQEditableCell
            value={item.description || ''}
            isEditing={isEditing('description')}
            onEdit={() => onEdit({ rowId: item.id, field: 'description' })}
            onSave={(value) => onSave(item.id, 'description', value)}
            onCancel={onCancel}
            className="text-xs h-full break-words whitespace-normal"
            multiline={true}
            disabled={false}
          />
        </div>
      </td>

      {/* Unit */}
      <td 
        className={`p-1 border-r border-gray-200 w-16 ${getCellSelectedClass('unit')}`}
        tabIndex={0} 
        onKeyDown={handleKeyDown('unit')}
        onMouseDown={handleCellMouseDown('unit')}
        onMouseEnter={handleCellMouseEnter('unit')}
        onMouseUp={onCellMouseUp}
      >
        <BOQEditableCell
          value={item.unit || ''}
          isEditing={isEditing('unit')}
          onEdit={() => onEdit({ rowId: item.id, field: 'unit' })}
          onSave={(value) => onSave(item.id, 'unit', value)}
          onCancel={onCancel}
          className="text-center text-xs h-full break-words"
          disabled={isCommentRow}
        />
      </td>

      {/* Quantity */}
      <td 
        className={`p-1 border-r border-gray-200 w-20 ${getCellSelectedClass('quantity')}`}
        tabIndex={0} 
        onKeyDown={handleKeyDown('quantity')}
        onMouseDown={handleCellMouseDown('quantity')}
        onMouseEnter={handleCellMouseEnter('quantity')}
        onMouseUp={onCellMouseUp}
      >
        <BOQEditableCell
          value={item.quantity?.toString() || ''}
          isEditing={isEditing('quantity')}
          onEdit={() => onEdit({ rowId: item.id, field: 'quantity' })}
          onSave={(value) => onSave(item.id, 'quantity', parseFloat(value) || 0)}
          onCancel={onCancel}
          className="text-right font-mono text-xs h-full break-words"
          type="number"
          disabled={isCommentRow}
        />
      </td>

      {/* Net Rate */}
      <td className="p-1 border-r border-gray-200 w-20 text-right">
        <span className={`text-xs font-mono break-words ${isCommentRow ? 'text-gray-400' : ''}`}>
          {isCommentRow ? '-' : `$${(item.net_rate || 0).toFixed(2)}`}
        </span>
      </td>

      {/* Amount */}
      <td className="p-1 border-r border-gray-200 w-24 text-right">
        <span className={`text-xs font-mono font-medium break-words ${isCommentRow ? 'text-gray-400' : ''}`}>
          {isCommentRow ? '-' : `$${(item.amount || 0).toFixed(2)}`}
        </span>
      </td>

      {/* Cost Splits */}
      <td className="p-1 border-r border-gray-200 w-16 text-right">
        <span className={`text-xs font-mono text-blue-600 break-words ${isCommentRow ? 'text-gray-400' : ''}`}>
          {isCommentRow ? '-' : `$${(item.amount_labor || 0).toFixed(0)}`}
        </span>
      </td>

      <td className="p-1 border-r border-gray-200 w-16 text-right">
        <span className={`text-xs font-mono text-green-600 break-words ${isCommentRow ? 'text-gray-400' : ''}`}>
          {isCommentRow ? '-' : `$${(item.amount_material || 0).toFixed(0)}`}
        </span>
      </td>

      <td className="p-1 border-r border-gray-200 w-16 text-right">
        <span className={`text-xs font-mono text-yellow-600 break-words ${isCommentRow ? 'text-gray-400' : ''}`}>
          {isCommentRow ? '-' : `$${(item.amount_equipment || 0).toFixed(0)}`}
        </span>
      </td>

      <td className="p-1 border-r border-gray-200 w-16 text-right">
        <span className={`text-xs font-mono text-purple-600 break-words ${isCommentRow ? 'text-gray-400' : ''}`}>
          {isCommentRow ? '-' : `$${(item.amount_subcontractor || 0).toFixed(0)}`}
        </span>
      </td>

      <td className="p-1 border-gray-200 w-16 text-right">
        <span className={`text-xs font-mono text-red-600 break-words ${isCommentRow ? 'text-gray-400' : ''}`}>
          {isCommentRow ? '-' : `$${(item.amount_consultant || 0).toFixed(0)}`}
        </span>
      </td>
    </tr>
  );
}
