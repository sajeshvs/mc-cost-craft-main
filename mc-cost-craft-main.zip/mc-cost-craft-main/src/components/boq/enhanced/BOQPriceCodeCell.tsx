
import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface BOQPriceCodeCellProps {
  value: string;
  isEditing: boolean;
  onEdit: () => void;
  onSave: (value: string) => void;
  onCancel: () => void;
  disabled?: boolean;
}

export function BOQPriceCodeCell({
  value,
  isEditing,
  onEdit,
  onSave,
  onCancel,
  disabled = false
}: BOQPriceCodeCellProps) {
  const { data: priceCodes = [] } = useQuery({
    queryKey: ['price-codes'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('price_list')
        .select('price_code, description, unit_rate')
        .order('price_code');
      
      if (error) throw error;
      return data || [];
    }
  });

  // Comprehensive filtering to ensure no empty values reach SelectItem
  const validPriceCodes = priceCodes.filter(price => 
    price && 
    typeof price === 'object' &&
    price.price_code && 
    typeof price.price_code === 'string' &&
    price.price_code.trim() !== '' &&
    price.description &&
    typeof price.description === 'string' &&
    price.description.trim() !== '' &&
    typeof price.unit_rate === 'number' &&
    !isNaN(price.unit_rate)
  );

  if (disabled) {
    return <div className="p-1 text-gray-400 text-xs">-</div>;
  }

  if (isEditing) {
    return (
      <Select value={value} onValueChange={(newValue) => {
        // Validate the value before saving
        if (newValue && newValue.trim() !== '') {
          onSave(newValue);
        }
      }}>
        <SelectTrigger className="w-full h-6 text-xs">
          <SelectValue placeholder="Select price" />
        </SelectTrigger>
        <SelectContent>
          {validPriceCodes.map((price) => (
            <SelectItem key={price.price_code} value={price.price_code}>
              <div className="text-xs">
                <div className="font-mono">{price.price_code}</div>
                <div className="text-gray-600 truncate">{price.description}</div>
                <div className="text-green-600 font-mono">${price.unit_rate.toFixed(2)}</div>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }

  return (
    <div
      onClick={onEdit}
      className="p-1 text-xs cursor-pointer hover:bg-gray-100 rounded font-mono"
      title="Click to select price code"
    >
      {value || 'Select'}
    </div>
  );
}
