
import React from 'react';
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from '@/components/ui/context-menu';
import { 
  Copy, 
  Scissors, 
  ClipboardPaste, 
  Plus, 
  Trash2, 
  MoveUp, 
  MoveDown,
  Edit,
  RotateCcw
} from 'lucide-react';

interface BOQContextMenuProps {
  children: React.ReactNode;
  selectedRows: Set<string>;
  selectedCells: Set<string>;
  onCopyRows: () => void;
  onCutRows: () => void;
  onPasteRows: () => void;
  onCopyCells: () => void;
  onPasteCells: () => void;
  onInsertRowAbove: () => void;
  onInsertRowBelow: () => void;
  onDeleteRows: () => void;
  onMoveRowsUp: () => void;
  onMoveRowsDown: () => void;
  onEditCell: () => void;
  onClearCellSelection: () => void;
  canPaste: boolean;
}

export function BOQContextMenu({
  children,
  selectedRows,
  selectedCells,
  onCopyRows,
  onCutRows,
  onPasteRows,
  onCopyCells,
  onPasteCells,
  onInsertRowAbove,
  onInsertRowBelow,
  onDeleteRows,
  onMoveRowsUp,
  onMoveRowsDown,
  onEditCell,
  onClearCellSelection,
  canPaste
}: BOQContextMenuProps) {
  const hasSelectedRows = selectedRows.size > 0;
  const hasSelectedCells = selectedCells.size > 0;

  return (
    <ContextMenu>
      <ContextMenuTrigger asChild>
        {children}
      </ContextMenuTrigger>
      <ContextMenuContent className="w-56">
        {hasSelectedCells && (
          <>
            <ContextMenuItem onClick={onCopyCells} className="flex items-center gap-2">
              <Copy className="h-4 w-4" />
              Copy Cells
            </ContextMenuItem>
            {canPaste && (
              <ContextMenuItem onClick={onPasteCells} className="flex items-center gap-2">
                <ClipboardPaste className="h-4 w-4" />
                Paste to Cells
              </ContextMenuItem>
            )}
            <ContextMenuItem onClick={onEditCell} className="flex items-center gap-2">
              <Edit className="h-4 w-4" />
              Edit Cell
            </ContextMenuItem>
            <ContextMenuItem onClick={onClearCellSelection} className="flex items-center gap-2">
              <RotateCcw className="h-4 w-4" />
              Clear Selection
            </ContextMenuItem>
            <ContextMenuSeparator />
          </>
        )}

        {hasSelectedRows && (
          <>
            <ContextMenuItem onClick={onCopyRows} className="flex items-center gap-2">
              <Copy className="h-4 w-4" />
              Copy Rows ({selectedRows.size})
            </ContextMenuItem>
            <ContextMenuItem onClick={onCutRows} className="flex items-center gap-2">
              <Scissors className="h-4 w-4" />
              Cut Rows ({selectedRows.size})
            </ContextMenuItem>
            {canPaste && (
              <ContextMenuItem onClick={onPasteRows} className="flex items-center gap-2">
                <ClipboardPaste className="h-4 w-4" />
                Paste Rows
              </ContextMenuItem>
            )}
            <ContextMenuSeparator />
          </>
        )}

        <ContextMenuItem onClick={onInsertRowAbove} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Insert Row Above
        </ContextMenuItem>
        <ContextMenuItem onClick={onInsertRowBelow} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Insert Row Below
        </ContextMenuItem>

        {hasSelectedRows && (
          <>
            <ContextMenuSeparator />
            <ContextMenuItem onClick={onMoveRowsUp} className="flex items-center gap-2">
              <MoveUp className="h-4 w-4" />
              Move Up
            </ContextMenuItem>
            <ContextMenuItem onClick={onMoveRowsDown} className="flex items-center gap-2">
              <MoveDown className="h-4 w-4" />
              Move Down
            </ContextMenuItem>
            <ContextMenuSeparator />
            <ContextMenuItem 
              onClick={onDeleteRows} 
              className="flex items-center gap-2 text-red-600 focus:text-red-600"
            >
              <Trash2 className="h-4 w-4" />
              Delete Rows ({selectedRows.size})
            </ContextMenuItem>
          </>
        )}
      </ContextMenuContent>
    </ContextMenu>
  );
}
