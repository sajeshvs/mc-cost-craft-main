
import React from 'react';
import { Checkbox } from '@/components/ui/checkbox';

interface BOQEnhancedTableHeaderProps {
  selectedCount: number;
  totalCount: number;
  onSelectAll: (checked: boolean) => void;
}

export function BOQEnhancedTableHeader({
  selectedCount,
  totalCount,
  onSelectAll
}: BOQEnhancedTableHeaderProps) {
  const isAllSelected = totalCount > 0 && selectedCount === totalCount;
  const isPartiallySelected = selectedCount > 0 && selectedCount < totalCount;

  return (
    <thead className="sticky top-0 z-10 bg-gray-50 border-b-2 border-gray-300">
      <tr className="bg-gray-50">
        <th className="w-10 p-2 border-r border-gray-300 text-center">
          <Checkbox
            checked={isAllSelected}
            ref={(el) => {
              if (el) {
                const inputEl = el.querySelector('input') as HTMLInputElement;
                if (inputEl) {
                  inputEl.indeterminate = isPartiallySelected;
                }
              }
            }}
            onCheckedChange={(checked) => onSelectAll(!!checked)}
          />
        </th>
        <th className="w-12 p-2 border-r border-gray-300 text-xs font-semibold text-center bg-gray-50">
          Level
        </th>
        <th className="w-16 p-2 border-r border-gray-300 text-xs font-semibold text-center bg-gray-50">
          Page
        </th>
        <th className="w-20 p-2 border-r border-gray-300 text-xs font-semibold text-center bg-gray-50">
          Item No
        </th>
        <th className="w-24 p-2 border-r border-gray-300 text-xs font-semibold text-center bg-gray-50">
          Trade Code
        </th>
        <th className="w-32 p-2 border-r border-gray-300 text-xs font-semibold text-center bg-gray-50">
          Price Code
        </th>
        <th className="min-w-64 p-2 border-r border-gray-300 text-xs font-semibold text-left bg-gray-50">
          Description
        </th>
        <th className="w-16 p-2 border-r border-gray-300 text-xs font-semibold text-center bg-gray-50">
          Unit
        </th>
        <th className="w-20 p-2 border-r border-gray-300 text-xs font-semibold text-right bg-gray-50">
          Quantity
        </th>
        <th className="w-20 p-2 border-r border-gray-300 text-xs font-semibold text-right bg-gray-50">
          Net Rate
        </th>
        <th className="w-24 p-2 border-r border-gray-300 text-xs font-semibold text-right bg-gray-50">
          Amount
        </th>
        <th className="w-16 p-2 border-r border-gray-300 text-xs font-semibold text-right bg-gray-50 text-blue-600">
          Labor
        </th>
        <th className="w-16 p-2 border-r border-gray-300 text-xs font-semibold text-right bg-gray-50 text-green-600">
          Material
        </th>
        <th className="w-16 p-2 border-r border-gray-300 text-xs font-semibold text-right bg-gray-50 text-yellow-600">
          Equipment
        </th>
        <th className="w-16 p-2 border-r border-gray-300 text-xs font-semibold text-right bg-gray-50 text-purple-600">
          Subcontractor
        </th>
        <th className="w-16 p-2 border-gray-300 text-xs font-semibold text-right bg-gray-50 text-red-600">
          Consultant
        </th>
      </tr>
    </thead>
  );
}
