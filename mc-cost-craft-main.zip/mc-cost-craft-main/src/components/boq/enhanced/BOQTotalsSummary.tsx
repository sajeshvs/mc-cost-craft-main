
import React from 'react';
import { BOQItem } from '@/types/mccost';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

interface LevelTotals {
  totalAmount: number;
  labor: number;
  material: number;
  equipment: number;
  subcontractor: number;
  consultant: number;
  itemCount: number;
}

interface BOQTotalsSummaryProps {
  visibleItems: BOQItem[];
  levelTotals: Record<string, LevelTotals>;
}

export function BOQTotalsSummary({ visibleItems, levelTotals }: BOQTotalsSummaryProps) {
  const totals = visibleItems.reduce(
    (acc, item) => {
      if (item.level_type === 'item') {
        acc.totalQuantity += item.quantity || 0;
        acc.totalAmount += item.amount || 0;
        acc.totalLabor += item.amount_labor || 0;
        acc.totalMaterial += item.amount_material || 0;
        acc.totalEquipment += item.amount_equipment || 0;
        acc.totalSubcontractor += item.amount_subcontractor || 0;
        acc.totalConsultant += item.amount_consultant || 0;
      }
      return acc;
    },
    {
      totalQuantity: 0,
      totalAmount: 0,
      totalLabor: 0,
      totalMaterial: 0,
      totalEquipment: 0,
      totalSubcontractor: 0,
      totalConsultant: 0
    }
  );

  const pricedItems = visibleItems.filter(item => 
    item.level_type === 'item' && (item.net_rate || 0) > 0
  ).length;
  
  const totalItems = visibleItems.filter(item => item.level_type === 'item').length;

  return (
    <Card className="border-t border-gray-200 rounded-none">
      <CardContent className="p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="text-xs">
              Items: {totalItems.toLocaleString()}
            </Badge>
            <Badge variant="outline" className="text-xs">
              Priced: {pricedItems.toLocaleString()}
            </Badge>
            <Badge variant="outline" className="text-xs">
              Unpriced: {(totalItems - pricedItems).toLocaleString()}
            </Badge>
          </div>
          
          <div className="flex items-center gap-6 text-sm font-medium">
            <div className="text-gray-600">
              Total Qty: <span className="font-bold">{totals.totalQuantity.toLocaleString()}</span>
            </div>
            <div className="text-blue-600">
              Labor: <span className="font-bold">${totals.totalLabor.toLocaleString()}</span>
            </div>
            <div className="text-green-600">
              Material: <span className="font-bold">${totals.totalMaterial.toLocaleString()}</span>
            </div>
            <div className="text-orange-600">
              Equipment: <span className="font-bold">${totals.totalEquipment.toLocaleString()}</span>
            </div>
            <div className="text-purple-600">
              Total: <span className="font-bold text-lg">${totals.totalAmount.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
