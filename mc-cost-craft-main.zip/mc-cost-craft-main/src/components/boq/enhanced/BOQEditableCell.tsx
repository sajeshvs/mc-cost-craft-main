
import React, { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

interface BOQEditableCellProps {
  value: string;
  isEditing: boolean;
  onEdit: () => void;
  onSave: (value: string) => void;
  onCancel: () => void;
  className?: string;
  type?: 'text' | 'number';
  multiline?: boolean;
  disabled?: boolean;
  placeholder?: string;
}

export function BOQEditableCell({
  value,
  isEditing,
  onEdit,
  onSave,
  onCancel,
  className = '',
  type = 'text',
  multiline = false,
  disabled = false,
  placeholder = ''
}: BOQEditableCellProps) {
  const [editValue, setEditValue] = useState(value);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isEditing) {
      setEditValue(value);
      // Focus and select all text when editing starts
      setTimeout(() => {
        if (inputRef.current) {
          inputRef.current.focus();
          inputRef.current.select();
        }
      }, 0);
    }
  }, [isEditing, value]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !multiline) {
      e.preventDefault();
      e.stopPropagation();
      onSave(editValue);
    } else if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      onCancel();
    } else if (e.key === 'Tab') {
      e.preventDefault();
      e.stopPropagation();
      onSave(editValue);
      // Tab navigation is handled by the keyboard navigation hook
    }
  };

  const handleBlur = () => {
    onSave(editValue);
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    if (!disabled && !isEditing) {
      e.preventDefault();
      e.stopPropagation();
      onEdit();
    }
  };

  const handleClick = (e: React.MouseEvent) => {
    if (!disabled && !isEditing) {
      e.stopPropagation();
      // Single click just focuses, double click edits
    }
  };

  if (disabled) {
    return (
      <div className={`p-1 text-gray-400 text-xs min-h-[24px] flex items-center break-words whitespace-normal ${className}`}>
        -
      </div>
    );
  }

  if (isEditing) {
    const Component = multiline ? Textarea : Input;
    
    return (
      <Component
        ref={inputRef as any}
        value={editValue}
        onChange={(e) => setEditValue(e.target.value)}
        onKeyDown={handleKeyDown}
        onBlur={handleBlur}
        className={`w-full min-h-[24px] p-1 text-xs border-2 border-blue-500 focus:ring-2 focus:ring-blue-300 bg-white ${className}`}
        type={type}
        placeholder={placeholder}
        rows={multiline ? 2 : undefined}
      />
    );
  }

  return (
    <div
      onClick={handleClick}
      onDoubleClick={handleDoubleClick}
      className={`p-1 min-h-[24px] cursor-pointer hover:bg-gray-100 rounded transition-colors break-words whitespace-normal ${className} ${
        disabled ? 'cursor-not-allowed text-gray-400' : ''
      }`}
      title={disabled ? 'Not editable for this row type' : 'Double-click to edit'}
      style={{ 
        wordBreak: 'break-word',
        overflowWrap: 'break-word',
        hyphens: 'auto'
      }}
    >
      {value || (disabled ? '-' : placeholder)}
    </div>
  );
}
