
import React from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, X, Filter } from 'lucide-react';

interface BOQFilterToolbarProps {
  filters: {
    page: string;
    itemNo: string;
    tradeCode: string;
    priceCode: string;
    description: string;
    showUnpriced: boolean;
  };
  onFilterChange: (key: string, value: string | boolean) => void;
  onClearFilters: () => void;
}

export function BOQFilterToolbar({
  filters,
  onFilterChange,
  onClearFilters
}: BOQFilterToolbarProps) {
  const hasActiveFilters = Object.values(filters).some(value => 
    typeof value === 'string' ? value.trim() !== '' : value === true
  );

  const getActiveFilterCount = () => {
    return Object.values(filters).filter(value => 
      typeof value === 'string' ? value.trim() !== '' : value === true
    ).length;
  };

  return (
    <div className="flex items-center gap-3 p-3 bg-gray-50 border-t border-gray-200">
      <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
        <Filter className="h-4 w-4" />
        <span>Filters:</span>
        {hasActiveFilters && (
          <Badge variant="secondary" className="text-xs">
            {getActiveFilterCount()} active
          </Badge>
        )}
      </div>
      
      <div className="flex items-center gap-2 flex-1">
        <Input
          placeholder="Page..."
          value={filters.page}
          onChange={(e) => onFilterChange('page', e.target.value)}
          className="w-20 h-8 text-xs"
        />

        <Input
          placeholder="Item No..."
          value={filters.itemNo}
          onChange={(e) => onFilterChange('itemNo', e.target.value)}
          className="w-24 h-8 text-xs"
        />

        <Input
          placeholder="Trade Code..."
          value={filters.tradeCode}
          onChange={(e) => onFilterChange('tradeCode', e.target.value)}
          className="w-28 h-8 text-xs"
        />

        <Input
          placeholder="Price Code..."
          value={filters.priceCode}
          onChange={(e) => onFilterChange('priceCode', e.target.value)}
          className="w-32 h-8 text-xs"
        />

        <Input
          placeholder="Description..."
          value={filters.description}
          onChange={(e) => onFilterChange('description', e.target.value)}
          className="w-48 h-8 text-xs flex-1"
        />

        <Select
          value={filters.showUnpriced ? "unpriced" : "all"}
          onValueChange={(value) => onFilterChange('showUnpriced', value === "unpriced")}
        >
          <SelectTrigger className="w-32 h-8 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Items</SelectItem>
            <SelectItem value="unpriced">Unpriced Only</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {hasActiveFilters && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearFilters}
          className="h-8 px-3 text-xs gap-1"
        >
          <X className="h-3 w-3" />
          Clear All
        </Button>
      )}
    </div>
  );
}
