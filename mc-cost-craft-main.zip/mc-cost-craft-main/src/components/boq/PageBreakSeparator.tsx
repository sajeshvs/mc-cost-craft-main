
interface PageBreakSeparatorProps {
  pageNumber: number | null;
}

export function PageBreakSeparator({ pageNumber }: PageBreakSeparatorProps) {
  return (
    <tr className="border-0">
      <td colSpan={8} className="p-0">
        <div className="relative py-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t-2 border-double border-gray-400"></div>
          </div>
          <div className="relative flex justify-center">
            <span className="bg-background px-4 text-sm font-medium text-muted-foreground">
              Page {pageNumber || '?'}
            </span>
          </div>
        </div>
      </td>
    </tr>
  );
}
