
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Plus, Upload, Expand, Minimize2, Calculator, Trash2, Copy, Clipboard, RotateCcw } from 'lucide-react';
import { ImportPositionDialog } from './ImportPositionDialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface BOQFlatToolbarProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  selectedRowsCount: number;
  totalItemsCount: number;
  totalQuantity: number;
  onImportMore: (position: 'after' | 'before' | 'beginning' | 'end') => void;
  onCalculateTotals: () => void;
  onExpandAll: () => void;
  onCollapseAll: () => void;
  onDeleteSelected: () => void;
  onInsertRow: (position: 'above' | 'below' | 'beginning' | 'end') => void;
  onDuplicateSelected: () => void;
  onCopy?: () => void;
  onPaste?: () => void;
  canPaste?: boolean;
  extraActions?: React.ReactNode;
}

export function BOQFlatToolbar({
  searchTerm,
  setSearchTerm,
  selectedRowsCount,
  totalItemsCount,
  totalQuantity,
  onImportMore,
  onCalculateTotals,
  onExpandAll,
  onCollapseAll,
  onDeleteSelected,
  onInsertRow,
  onDuplicateSelected,
  onCopy,
  onPaste,
  canPaste = false,
  extraActions
}: BOQFlatToolbarProps) {
  return (
    <div className="flex items-center gap-2 p-3 bg-white border-b border-gray-200 overflow-x-auto min-w-fit">
      {/* Search */}
      <div className="relative min-w-64 max-w-sm">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          placeholder="Search BOQ items..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 h-8"
        />
      </div>

      {/* Stats */}
      <div className="flex items-center gap-3 text-sm text-gray-600 bg-gray-50 px-3 py-1 rounded-md border">
        <span className="font-medium">
          {totalItemsCount.toLocaleString()} items
        </span>
        <span className="text-gray-300">|</span>
        <span className="font-medium">
          Qty: {totalQuantity.toLocaleString()}
        </span>
      </div>

      <div className="h-6 w-px bg-gray-300" />

      {/* Primary Actions */}
      <Button
        variant="outline"
        size="sm"
        onClick={() => onInsertRow('end')}
        className="h-8 gap-2"
      >
        <Plus className="h-4 w-4" />
        Insert Row
      </Button>

      <ImportPositionDialog
        selectedRowsCount={selectedRowsCount}
        onImport={onImportMore}
        trigger={
          <Button variant="outline" size="sm" className="h-8 gap-2">
            <Upload className="h-4 w-4" />
            Import More
          </Button>
        }
      />

      <div className="h-6 w-px bg-gray-300" />

      {/* View Controls */}
      <Button
        variant="outline"
        size="sm"
        onClick={onExpandAll}
        className="h-8 gap-2"
      >
        <Expand className="h-4 w-4" />
        Expand All
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onCollapseAll}
        className="h-8 gap-2"
      >
        <Minimize2 className="h-4 w-4" />
        Collapse All
      </Button>

      <div className="h-6 w-px bg-gray-300" />

      {/* Tools */}
      <Button
        variant="outline"
        size="sm"
        onClick={onCalculateTotals}
        className="h-8 gap-2"
      >
        <Calculator className="h-4 w-4" />
        Calculate
      </Button>

      {/* Copy/Paste */}
      {onCopy && (
        <>
          <Button
            variant="outline"
            size="sm"
            onClick={onCopy}
            disabled={selectedRowsCount === 0}
            className="h-8 gap-2"
          >
            <Copy className="h-4 w-4" />
            Copy
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={onPaste}
            disabled={!canPaste}
            className="h-8 gap-2"
          >
            <Clipboard className="h-4 w-4" />
            Paste
          </Button>
        </>
      )}

      {/* Extra Actions */}
      {extraActions}

      {/* Selection Actions */}
      {selectedRowsCount > 0 && (
        <>
          <div className="h-6 w-px bg-gray-300" />
          
          <span className="text-sm text-muted-foreground font-medium px-2">
            {selectedRowsCount} selected
          </span>

          <Button
            variant="outline"
            size="sm"
            onClick={onDuplicateSelected}
            className="h-8 gap-2"
          >
            <Copy className="h-4 w-4" />
            Duplicate
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={onDeleteSelected}
            className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50 gap-2"
          >
            <Trash2 className="h-4 w-4" />
            Delete
          </Button>
        </>
      )}
    </div>
  );
}
