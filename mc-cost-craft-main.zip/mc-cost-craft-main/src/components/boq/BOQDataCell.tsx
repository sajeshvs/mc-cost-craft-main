
import { TableCell } from '@/components/ui/table';
import { BOQItem } from '@/types/mccost';
import { EditableCell } from './EditableCell';
import { getLevelNumber } from '@/utils/levelUtils';

interface BOQDataCellProps {
  item: BOQItem;
  field: keyof BOQItem;
  index: number;
  width: number;
  editingCell: { rowId: string; field: keyof BOQItem } | null;
  onStartEditing: (rowId: string, field: keyof BOQItem, currentValue: any) => void;
  onCellSave: (itemId: string, field: keyof BOQItem, value: any) => void;
  onCancelEditing: () => void;
  onKeyDown: (e: React.KeyboardEvent, rowIndex: number, field: keyof BOQItem) => void;
  className?: string;
  disabled?: boolean;
  isSelected?: boolean;
  onCellMouseDown?: (rowIndex: number, columnKey: string) => void;
  onCellMouseEnter?: (rowIndex: number, columnKey: string) => void;
  onCellMouseUp?: () => void;
}

export function BOQDataCell({
  item,
  field,
  index,
  width,
  editingCell,
  onStartEditing,
  onCellSave,
  onCancelEditing,
  onKeyDown,
  className = "",
  disabled = false,
  isSelected = false,
  onCellMouseDown,
  onCellMouseEnter,
  onCellMouseUp
}: BOQDataCellProps) {
  const level = getLevelNumber(item.level_type);
  const isComment = item.level_type === 'comment';
  const isEditing = editingCell?.rowId === item.id && editingCell?.field === field;
  
  // Disable pricing fields for comment rows
  const isPricingField = field === 'unit' || field === 'quantity';
  const shouldDisable = disabled || (isComment && isPricingField);
  
  const getCellClassName = () => {
    let baseClass = "border-r p-0 bg-white relative";
    
    if (field === 'description' && level > 0) {
      baseClass += ` pl-${Math.min(level * 2, 8)}`;
    }

    if (shouldDisable) {
      baseClass += " bg-gray-50 opacity-60";
    } else if (isComment) {
      baseClass += " bg-green-50";
    }

    if (isSelected) {
      baseClass += " ring-2 ring-blue-500 ring-inset bg-blue-50";
    }
    
    return `${baseClass} ${className}`;
  };

  const getEditableCellClassName = () => {
    let baseClass = "h-full break-words overflow-wrap-anywhere whitespace-pre-wrap";
    
    switch (field) {
      case 'page_number':
      case 'unit':
        return baseClass + " text-center";
      case 'quantity':
        return baseClass + " text-right";
      case 'item_no':
        return baseClass + " font-mono text-sm";
      case 'level_type':
        return baseClass + " text-center font-medium";
      case 'description':
        return baseClass + " text-left" + (isComment ? " italic text-green-700 font-medium" : "");
      default:
        return baseClass;
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (onCellMouseDown) {
      e.preventDefault();
      onCellMouseDown(index, field as string);
    }
  };

  const handleMouseEnter = (e: React.MouseEvent) => {
    if (onCellMouseEnter && e.buttons === 1) { // Only if mouse button is pressed
      onCellMouseEnter(index, field as string);
    }
  };

  const handleMouseUp = () => {
    if (onCellMouseUp) {
      onCellMouseUp();
    }
  };

  return (
    <TableCell 
      className={getCellClassName()}
      style={{ 
        width, 
        minWidth: width,
        maxWidth: width,
        wordWrap: 'break-word',
        overflowWrap: 'break-word',
        whiteSpace: 'pre-wrap',
        verticalAlign: 'top'
      }}
      onKeyDown={(e) => onKeyDown(e, index, field)}
      onMouseDown={handleMouseDown}
      onMouseEnter={handleMouseEnter}
      onMouseUp={handleMouseUp}
    >
      <EditableCell
        value={item[field]}
        field={field}
        isEditing={isEditing}
        onStartEdit={() => !shouldDisable && onStartEditing(item.id, field, item[field])}
        onSave={(value) => onCellSave(item.id, field, value)}
        onCancel={onCancelEditing}
        className={getEditableCellClassName()}
        disabled={shouldDisable}
      />
    </TableCell>
  );
}
