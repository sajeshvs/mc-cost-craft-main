
import React from 'react';
import { BOQItem } from '@/types/mccost';
import { BOQTableHeader } from './BOQTableHeader';
import { BOQTableRow } from './BOQTableRow';
import { BOQPricingSummary } from './BOQPricingSummary';

interface BOQTableProps {
  items: BOQItem[];
  visibleItems: BOQItem[];
  selectedRows: Set<string>;
  editingCell: { rowId: string; field: keyof BOQItem } | null;
  expandedSections: Set<string>;
  onToggleRowSelection: (id: string) => void;
  onSelectAllRows: () => void;
  onClearSelection: () => void;
  onStartEditing: (id: string, field: keyof BOQItem) => void;
  onCellSave: (id: string, field: string, value: string | number) => void;
  onCancelEditing: () => void;
  onDragEnd: () => void;
  onInsertRow: () => void;
  onDeleteItem: () => void;
  onDuplicateItem: () => void;
  onToggleExpand: (id: string) => void;
  onCopy: () => void;
  onPaste: () => void;
  onClear: () => void;
  onSetQuantity: () => void;
  onMultiplyQuantity: () => void;
  onShowSum: () => void;
  onEnterText: () => void;
  canPaste: boolean;
}

export function BOQTable({
  items,
  visibleItems,
  selectedRows,
  editingCell,
  expandedSections,
  onToggleRowSelection,
  onSelectAllRows,
  onClearSelection,
  onStartEditing,
  onCellSave,
  onCancelEditing,
  onToggleExpand,
  ...otherProps
}: BOQTableProps) {
  const allSelected = visibleItems.length > 0 && selectedRows.size === visibleItems.length;
  const someSelected = selectedRows.size > 0 && selectedRows.size < visibleItems.length;

  // Get job ID from the first item (assuming all items belong to the same job)
  const jobId = items.length > 0 ? items[0].job_id : '';

  // Helper function to check if an item has children
  const hasChildren = (item: BOQItem): boolean => {
    if (!item.level_type || !item.level_type.startsWith('level_')) {
      return false;
    }
    
    const itemIndex = items.findIndex(i => i.id === item.id);
    if (itemIndex === -1) return false;
    
    const currentLevel = parseInt(item.level_type.replace('level_', ''));
    
    // Look for items after this one that are at a deeper level or are regular items
    for (let i = itemIndex + 1; i < items.length; i++) {
      const nextItem = items[i];
      
      if (nextItem.level_type?.startsWith('level_')) {
        const nextLevel = parseInt(nextItem.level_type.replace('level_', ''));
        if (nextLevel > currentLevel) {
          return true;
        }
        if (nextLevel <= currentLevel) {
          break;
        }
      } else if (nextItem.level_type === 'item' || !nextItem.level_type) {
        return true;
      }
    }
    
    return false;
  };

  const handleItemUpdate = (id: string, updates: Partial<BOQItem>) => {
    // This would typically call a mutation to update the item
    console.log('Updating item:', id, updates);
    // For now, we'll use the onCellSave callback for individual field updates
    Object.entries(updates).forEach(([field, value]) => {
      if (value !== undefined) {
        onCellSave(id, field, value);
      }
    });
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse">
          <BOQTableHeader
            onSelectAll={onSelectAllRows}
            allSelected={allSelected}
            someSelected={someSelected}
          />
          <tbody>
            {visibleItems.map((item) => {
              const itemHasChildren = hasChildren(item);
              
              return (
                <BOQTableRow
                  key={item.id}
                  item={item}
                  jobId={jobId}
                  isSelected={selectedRows.has(item.id)}
                  isEditing={editingCell?.rowId === item.id}
                  editingField={editingCell?.rowId === item.id ? editingCell.field : undefined}
                  onSelect={() => onToggleRowSelection(item.id)}
                  onStartEdit={(field) => onStartEditing(item.id, field)}
                  onSave={(field, value) => onCellSave(item.id, field, value)}
                  onCancel={onCancelEditing}
                  onUpdate={handleItemUpdate}
                  isExpanded={expandedSections.has(item.id)}
                  onToggleExpand={() => onToggleExpand(item.id)}
                  hasChildren={itemHasChildren}
                />
              );
            })}
          </tbody>
        </table>
      </div>
      
      {/* Pricing Summary */}
      <BOQPricingSummary items={visibleItems} />
    </div>
  );
}
