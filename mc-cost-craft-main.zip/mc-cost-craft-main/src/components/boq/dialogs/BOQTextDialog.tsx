
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

interface BOQTextDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApply: (text: string) => void;
  selectedRowsCount: number;
}

export function BOQTextDialog({
  open,
  onOpenChange,
  onApply,
  selectedRowsCount
}: BOQTextDialogProps) {
  const [inputValue, setInputValue] = useState('');

  const handleApply = () => {
    if (inputValue.trim()) {
      onApply(inputValue.trim());
      onOpenChange(false);
      setInputValue('');
    }
  };

  const handleCancel = () => {
    onOpenChange(false);
    setInputValue('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Enter Text</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Enter description text"
            onKeyDown={(e) => e.key === 'Enter' && handleApply()}
            autoFocus
          />
          <div className="flex gap-2">
            <Button onClick={handleApply} className="flex-1">Apply</Button>
            <Button variant="outline" onClick={handleCancel}>Cancel</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
