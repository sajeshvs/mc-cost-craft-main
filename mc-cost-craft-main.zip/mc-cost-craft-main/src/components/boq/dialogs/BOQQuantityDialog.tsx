
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

interface BOQQuantityDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApply: (quantity: number) => void;
  selectedRowsCount: number;
}

export function BOQQuantityDialog({
  open,
  onOpenChange,
  onApply,
  selectedRowsCount
}: BOQQuantityDialogProps) {
  const [inputValue, setInputValue] = useState('');

  const handleApply = () => {
    const quantity = parseFloat(inputValue);
    if (!isNaN(quantity)) {
      onApply(quantity);
      onOpenChange(false);
      setInputValue('');
    }
  };

  const handleCancel = () => {
    onOpenChange(false);
    setInputValue('');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Set Quantity</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Enter quantity"
            type="number"
            step="0.01"
            onKeyDown={(e) => e.key === 'Enter' && handleApply()}
            autoFocus
          />
          <div className="flex gap-2">
            <Button onClick={handleApply} className="flex-1">Apply</Button>
            <Button variant="outline" onClick={handleCancel}>Cancel</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
