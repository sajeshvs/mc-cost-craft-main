
import React from 'react';
import { BOQItem } from '@/types/mccost';
import { Checkbox } from '@/components/ui/checkbox';
import { BOQSelectionCell } from './BOQSelectionCell';
import { EditableCell } from './EditableCell';
import { ExpandToggle } from './ExpandToggle';
import { BOQPricingColumns } from './BOQPricingColumns';

interface BOQTableRowProps {
  item: BOQItem;
  jobId: string;
  isSelected: boolean;
  isEditing: boolean;
  editingField?: keyof BOQItem;
  onSelect: () => void;
  onStartEdit: (field: keyof BOQItem) => void;
  onSave: (field: keyof BOQItem, value: string | number) => void;
  onCancel: () => void;
  onUpdate: (id: string, updates: Partial<BOQItem>) => void;
  isExpanded?: boolean;
  onToggleExpand?: () => void;
  hasChildren?: boolean;
}

export function BOQTableRow({
  item,
  jobId,
  isSelected,
  isEditing,
  editingField,
  onSelect,
  onStartEdit,
  onSave,
  onCancel,
  onUpdate,
  isExpanded = false,
  onToggleExpand,
  hasChildren = false
}: BOQTableRowProps) {
  const getRowClassName = () => {
    let className = "border-b hover:bg-gray-50";
    
    if (isSelected) {
      className += " bg-blue-50";
    }
    
    // Add level-based styling
    switch (item.level_type) {
      case 'level_1':
        className += " bg-blue-100 font-semibold";
        break;
      case 'level_2':
        className += " bg-blue-50 font-medium";
        break;
      case 'level_3':
        className += " bg-gray-50";
        break;
      case 'comment':
        className += " bg-yellow-50 italic";
        break;
      default:
        break;
    }
    
    return className;
  };

  return (
    <tr className={getRowClassName()}>
      {/* Selection */}
      <td className="border-r border-gray-200 p-2">
        <Checkbox checked={isSelected} onCheckedChange={onSelect} />
      </td>

      {/* Item No with Expand Toggle */}
      <td className="border-r border-gray-200 p-2">
        <div className="flex items-center gap-1">
          <ExpandToggle
            isExpanded={isExpanded}
            hasChildren={hasChildren}
            onToggle={onToggleExpand || (() => {})}
            level={item.level_type || ''}
          />
          <EditableCell
            value={item.item_no}
            field="item_no"
            isEditing={isEditing && editingField === 'item_no'}
            onStartEdit={() => onStartEdit('item_no')}
            onSave={(value) => onSave('item_no', value)}
            onCancel={onCancel}
            className="font-mono text-sm"
          />
        </div>
      </td>

      {/* Description */}
      <td className="border-r border-gray-200 p-2">
        <EditableCell
          value={item.description}
          field="description"
          isEditing={isEditing && editingField === 'description'}
          onStartEdit={() => onStartEdit('description')}
          onSave={(value) => onSave('description', value)}
          onCancel={onCancel}
          className="text-sm"
        />
      </td>

      {/* Unit */}
      <td className="border-r border-gray-200 p-2 text-center">
        <EditableCell
          value={item.unit}
          field="unit"
          isEditing={isEditing && editingField === 'unit'}
          onStartEdit={() => onStartEdit('unit')}
          onSave={(value) => onSave('unit', value)}
          onCancel={onCancel}
          className="text-sm text-center"
        />
      </td>

      {/* Quantity */}
      <td className="border-r border-gray-200 p-2 text-right">
        <EditableCell
          value={item.quantity?.toString() || ''}
          field="quantity"
          isEditing={isEditing && editingField === 'quantity'}
          onStartEdit={() => onStartEdit('quantity')}
          onSave={(value) => onSave('quantity', parseFloat(value) || 0)}
          onCancel={onCancel}
          className="text-sm text-right font-mono"
        />
      </td>

      {/* Pricing Columns */}
      <BOQPricingColumns 
        item={item}
        jobId={jobId}
        onUpdate={onUpdate}
      />
    </tr>
  );
}
