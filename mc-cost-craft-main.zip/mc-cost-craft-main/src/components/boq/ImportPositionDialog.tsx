
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Upload } from 'lucide-react';

interface ImportPositionDialogProps {
  selectedRowsCount: number;
  onImport: (position: 'after' | 'before' | 'beginning' | 'end') => void;
  trigger?: React.ReactNode;
}

export function ImportPositionDialog({ selectedRowsCount, onImport, trigger }: ImportPositionDialogProps) {
  const [position, setPosition] = useState<'after' | 'before' | 'beginning' | 'end'>('end');
  const [open, setOpen] = useState(false);

  const handleImport = () => {
    onImport(position);
    setOpen(false);
  };

  const hasSelection = selectedRowsCount > 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline">
            <Upload className="mr-2 h-4 w-4" />
            Import More
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Import BOQ Data</DialogTitle>
          <DialogDescription>
            Where do you want to insert the new BOQ data?
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <RadioGroup value={position} onValueChange={setPosition as (value: string) => void}>
            {hasSelection && (
              <>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="after" id="after" />
                  <Label htmlFor="after">After selected row{selectedRowsCount > 1 ? 's' : ''}</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="before" id="before" />
                  <Label htmlFor="before">Before selected row{selectedRowsCount > 1 ? 's' : ''}</Label>
                </div>
              </>
            )}
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="beginning" id="beginning" />
              <Label htmlFor="beginning">At the beginning</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="end" id="end" />
              <Label htmlFor="end">At the end</Label>
            </div>
          </RadioGroup>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleImport}>
              Continue Import
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
