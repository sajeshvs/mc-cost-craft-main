
import React from 'react';
import { BOQItem } from '@/types/mccost';
import { BOQPriceCodeCell } from './BOQPriceCodeCell';

interface BOQPricingColumnsProps {
  item: BOQItem;
  jobId: string;
  onUpdate: (id: string, updates: Partial<BOQItem>) => void;
}

export function BOQPricingColumns({ item, jobId, onUpdate }: BOQPricingColumnsProps) {
  const handlePriceUpdate = (updates: {
    price_code?: string;
    net_rate?: number;
    amount_labor?: number;
    amount_material?: number;
    amount_equipment?: number;
    amount_subcontractor?: number;
    amount_consultant?: number;
  }) => {
    // Also calculate total amount when price updates
    const quantity = item.quantity || 0;
    const netRate = updates.net_rate || item.net_rate || 0;
    const amount = quantity * netRate;
    
    onUpdate(item.id, {
      ...updates,
      amount
    });
  };

  return (
    <>
      {/* Price Code Column */}
      <td className="border-r border-gray-200 p-2 min-w-32">
        <BOQPriceCodeCell
          jobId={jobId}
          itemId={item.id}
          priceCode={item.price_code}
          netRate={item.net_rate}
          onUpdate={handlePriceUpdate}
        />
      </td>

      {/* Net Rate Column */}
      <td className="border-r border-gray-200 p-2 text-right min-w-24">
        <div className="text-sm font-mono">
          {item.net_rate ? `$${item.net_rate.toFixed(2)}` : '-'}
        </div>
      </td>

      {/* Amount Column */}
      <td className="border-r border-gray-200 p-2 text-right min-w-28">
        <div className="text-sm font-mono font-medium">
          {item.amount ? `$${item.amount.toFixed(2)}` : '-'}
        </div>
      </td>

      {/* Split Amount Columns */}
      <td className="border-r border-gray-200 p-2 text-right min-w-24">
        <div className="text-xs font-mono text-blue-600">
          {item.amount_labor ? `$${item.amount_labor.toFixed(2)}` : '-'}
        </div>
      </td>

      <td className="border-r border-gray-200 p-2 text-right min-w-24">
        <div className="text-xs font-mono text-green-600">
          {item.amount_material ? `$${item.amount_material.toFixed(2)}` : '-'}
        </div>
      </td>

      <td className="border-r border-gray-200 p-2 text-right min-w-24">
        <div className="text-xs font-mono text-yellow-600">
          {item.amount_equipment ? `$${item.amount_equipment.toFixed(2)}` : '-'}
        </div>
      </td>

      <td className="border-r border-gray-200 p-2 text-right min-w-24">
        <div className="text-xs font-mono text-purple-600">
          {item.amount_subcontractor ? `$${item.amount_subcontractor.toFixed(2)}` : '-'}
        </div>
      </td>

      <td className="border-r border-gray-200 p-2 text-right min-w-24">
        <div className="text-xs font-mono text-red-600">
          {item.amount_consultant ? `$${item.amount_consultant.toFixed(2)}` : '-'}
        </div>
      </td>
    </>
  );
}
