
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface ColumnMapping {
  field: string;
  excelColumn: string;
  label: string;
}

interface ExcelColumnMapperProps {
  headers: string[];
  sampleData: any[][];
  onMappingChange: (mappings: ColumnMapping[]) => void;
  onConfirm: () => void;
  mappings: ColumnMapping[];
}

// Convert index to Excel column letter (0 -> A, 1 -> B, etc.)
const indexToExcelColumn = (index: number): string => {
  let result = '';
  while (index >= 0) {
    result = String.fromCharCode((index % 26) + 65) + result;
    index = Math.floor(index / 26) - 1;
  }
  return result;
};

export function ExcelColumnMapper({
  headers,
  sampleData,
  onMappingChange,
  onConfirm,
  mappings
}: ExcelColumnMapperProps) {
  const availableFields = [
    { field: 'item_no', label: 'Item No' },
    { field: 'description', label: 'Description' },
    { field: 'unit', label: 'Unit' },
    { field: 'quantity', label: 'Quantity' },
    { field: 'level_type', label: 'Level' },
    { field: 'page_number', label: 'Page' }
  ];

  const updateMapping = (field: string, excelColumn: string) => {
    const newMappings = [...mappings];
    const existingIndex = newMappings.findIndex(m => m.field === field);
    
    if (existingIndex >= 0) {
      if (excelColumn) {
        newMappings[existingIndex].excelColumn = excelColumn;
      } else {
        newMappings.splice(existingIndex, 1);
      }
    } else if (excelColumn) {
      const fieldInfo = availableFields.find(f => f.field === field);
      newMappings.push({
        field,
        excelColumn,
        label: fieldInfo?.label || field
      });
    }
    
    onMappingChange(newMappings);
  };

  const getSelectedColumn = (field: string) => {
    const mapping = mappings.find(m => m.field === field);
    return mapping?.excelColumn || '';
  };

  const isColumnUsed = (columnLetter: string, excludeField?: string) => {
    return mappings.some(m => m.excelColumn === columnLetter && m.field !== excludeField);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Map Excel Columns to BOQ Fields</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            {availableFields.map(({ field, label }) => (
              <div key={field} className="flex items-center gap-2">
                <label className="w-24 text-sm font-medium">{label}:</label>
                <Select
                  value={getSelectedColumn(field)}
                  onValueChange={(value) => updateMapping(field, value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Select column" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {headers.map((header, index) => {
                      const columnLetter = indexToExcelColumn(index);
                      const isUsed = isColumnUsed(columnLetter, field);
                      return (
                        <SelectItem
                          key={index}
                          value={columnLetter}
                          disabled={isUsed}
                          className={isUsed ? 'opacity-50' : ''}
                        >
                          Column {columnLetter} ({header.substring(0, 20)}{header.length > 20 ? '...' : ''})
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {sampleData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Preview (First 5 Rows)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {mappings.map(mapping => (
                      <TableHead key={mapping.field}>
                        {mapping.label} (Col {mapping.excelColumn})
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sampleData.slice(0, 5).map((row, rowIndex) => (
                    <TableRow key={rowIndex}>
                      {mappings.map(mapping => {
                        const columnIndex = headers.findIndex((_, index) => 
                          indexToExcelColumn(index) === mapping.excelColumn
                        );
                        const cellValue = columnIndex >= 0 ? row[columnIndex] : '';
                        
                        return (
                          <TableCell key={mapping.field} className="max-w-32 truncate">
                            {String(cellValue || '')}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex justify-end gap-2">
        <Button
          onClick={onConfirm}
          disabled={mappings.length === 0}
          className="bg-blue-600 hover:bg-blue-700"
        >
          Confirm Mapping & Import
        </Button>
      </div>
    </div>
  );
}
