
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from '@/components/ui/context-menu';
import { Plus, Trash2, Copy } from 'lucide-react';

interface BOQContextMenuProps {
  children: React.ReactNode;
  onInsertAbove: () => void;
  onInsertBelow: () => void;
  onDelete: () => void;
  onDuplicate: () => void;
}

export function BOQContextMenu({
  children,
  onInsertAbove,
  onInsertBelow,
  onDelete,
  onDuplicate
}: BOQContextMenuProps) {
  return (
    <ContextMenu>
      <ContextMenuTrigger asChild>
        {children}
      </ContextMenuTrigger>
      <ContextMenuContent className="w-48">
        <ContextMenuItem onClick={onInsertAbove}>
          <Plus className="mr-2 h-4 w-4" />
          Insert Row Above
        </ContextMenuItem>
        <ContextMenuItem onClick={onInsertBelow}>
          <Plus className="mr-2 h-4 w-4" />
          Insert Row Below
        </ContextMenuItem>
        <ContextMenuItem onClick={onDuplicate}>
          <Copy className="mr-2 h-4 w-4" />
          Duplicate Row
        </ContextMenuItem>
        <ContextMenuSeparator />
        <ContextMenuItem onClick={onDelete} className="text-red-600">
          <Trash2 className="mr-2 h-4 w-4" />
          Delete Row
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}
