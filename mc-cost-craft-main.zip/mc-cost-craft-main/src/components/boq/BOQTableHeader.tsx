
import React from 'react';
import { Checkbox } from '@/components/ui/checkbox';

interface BOQTableHeaderProps {
  onSelectAll: () => void;
  allSelected: boolean;
  someSelected: boolean;
}

export function BOQTableHeader({ onSelectAll, allSelected, someSelected }: BOQTableHeaderProps) {
  return (
    <thead className="bg-gray-50 sticky top-0 z-10">
      <tr className="border-b">
        {/* Selection Header */}
        <th className="w-12 p-2 border-r border-gray-200">
          <Checkbox
            checked={allSelected}
            onCheckedChange={() => onSelectAll()}
            className="mx-auto"
            {...(someSelected && !allSelected ? { 'data-state': 'indeterminate' } : {})}
          />
        </th>

        {/* Item No Header */}
        <th className="min-w-32 p-2 text-left font-medium text-gray-700 border-r border-gray-200">
          Item No
        </th>

        {/* Description Header */}
        <th className="min-w-80 p-2 text-left font-medium text-gray-700 border-r border-gray-200">
          Description
        </th>

        {/* Unit Header */}
        <th className="min-w-20 p-2 text-center font-medium text-gray-700 border-r border-gray-200">
          Unit
        </th>

        {/* Quantity Header */}
        <th className="min-w-24 p-2 text-right font-medium text-gray-700 border-r border-gray-200">
          Quantity
        </th>

        {/* Price Code Header */}
        <th className="min-w-32 p-2 text-center font-medium text-gray-700 border-r border-gray-200">
          Price Code
        </th>

        {/* Net Rate Header */}
        <th className="min-w-24 p-2 text-right font-medium text-gray-700 border-r border-gray-200">
          Net Rate
        </th>

        {/* Amount Header */}
        <th className="min-w-28 p-2 text-right font-medium text-gray-700 border-r border-gray-200">
          Amount
        </th>

        {/* Split Amount Headers */}
        <th className="min-w-24 p-2 text-right font-medium text-blue-600 border-r border-gray-200 text-xs">
          Labor
        </th>

        <th className="min-w-24 p-2 text-right font-medium text-green-600 border-r border-gray-200 text-xs">
          Material
        </th>

        <th className="min-w-24 p-2 text-right font-medium text-yellow-600 border-r border-gray-200 text-xs">
          Equipment
        </th>

        <th className="min-w-24 p-2 text-right font-medium text-purple-600 border-r border-gray-200 text-xs">
          Subcontractor
        </th>

        <th className="min-w-24 p-2 text-right font-medium text-red-600 border-r border-gray-200 text-xs">
          Consultant
        </th>
      </tr>
    </thead>
  );
}
