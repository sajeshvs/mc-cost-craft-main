
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowUp, ArrowDown, MoveUp, MoveDown } from 'lucide-react';

interface BOQImportPositionSelectorProps {
  selectedRowsCount: number;
  onPositionSelect: (position: 'beginning' | 'end' | 'after' | 'before') => void;
}

export function BOQImportPositionSelector({
  selectedRowsCount,
  onPositionSelect
}: BOQImportPositionSelectorProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Choose Import Position</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="outline"
            onClick={() => onPositionSelect('beginning')}
            className="flex items-center gap-2 h-12"
          >
            <MoveUp className="h-4 w-4" />
            At Beginning
          </Button>
          
          <Button
            variant="outline"
            onClick={() => onPositionSelect('end')}
            className="flex items-center gap-2 h-12"
          >
            <MoveDown className="h-4 w-4" />
            At End
          </Button>
          
          {selectedRowsCount > 0 && (
            <>
              <Button
                variant="outline"
                onClick={() => onPositionSelect('before')}
                className="flex items-center gap-2 h-12"
              >
                <ArrowUp className="h-4 w-4" />
                Before Selected ({selectedRowsCount})
              </Button>
              
              <Button
                variant="outline"
                onClick={() => onPositionSelect('after')}
                className="flex items-center gap-2 h-12"
              >
                <ArrowDown className="h-4 w-4" />
                After Selected ({selectedRowsCount})
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
