
import { ChevronRight, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ExpandToggleProps {
  isExpanded: boolean;
  hasChildren: boolean;
  onToggle: () => void;
  level?: string;
  className?: string;
}

export function ExpandToggle({ 
  isExpanded, 
  hasChildren, 
  onToggle, 
  level = '',
  className = "" 
}: ExpandToggleProps) {
  // Show toggle for level rows (level_1, level_2, level_3, etc.) that have children
  const isLevelRow = level && level.startsWith('level_');
  
  if (!isLevelRow || !hasChildren) {
    return <div className="w-6 h-6" />;
  }

  return (
    <div className={`w-6 h-6 flex items-center justify-center ${className}`}>
      <Button
        variant="ghost"
        size="sm"
        onClick={(e) => {
          e.stopPropagation();
          onToggle();
        }}
        className="w-6 h-6 p-0 hover:bg-gray-100 flex items-center justify-center"
        title={isExpanded ? 'Collapse' : 'Expand'}
      >
        {isExpanded ? (
          <ChevronDown className="h-4 w-4 text-gray-600" />
        ) : (
          <ChevronRight className="h-4 w-4 text-gray-600" />
        )}
      </Button>
    </div>
  );
}
