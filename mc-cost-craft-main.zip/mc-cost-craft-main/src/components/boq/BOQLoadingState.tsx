
import { Button } from '@/components/ui/button';

interface BOQLoadingStateProps {
  onNavigateToCompanies: () => void;
}

export function BOQLoadingState({ onNavigateToCompanies }: BOQLoadingStateProps) {
  return (
    <div className="flex items-center justify-center h-64">
      <div className="text-center">
        <p className="text-gray-500">Loading BOQ items...</p>
      </div>
    </div>
  );
}

export function BOQErrorState({ onNavigateToCompanies }: BOQLoadingStateProps) {
  return (
    <div className="flex items-center justify-center h-64">
      <div className="text-center">
        <p className="text-gray-500 mb-4">Job ID is required</p>
        <Button onClick={onNavigateToCompanies}>
          Go to Companies
        </Button>
      </div>
    </div>
  );
}
