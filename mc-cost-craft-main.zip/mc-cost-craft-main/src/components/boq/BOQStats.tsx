
import { Calculator, FileText, CheckSquare } from 'lucide-react';

interface BOQStatsProps {
  itemCount: number;
  selectedCount?: number;
  totalQuantity?: number;
}

export function BOQStats({ itemCount, selectedCount = 0, totalQuantity = 0 }: BOQStatsProps) {
  return (
    <div className="border-t bg-gray-50 px-4 py-2">
      <div className="flex items-center gap-6 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <FileText className="h-4 w-4" />
          <span>{itemCount} items</span>
        </div>
        
        {selectedCount > 0 && (
          <div className="flex items-center gap-2">
            <CheckSquare className="h-4 w-4" />
            <span>{selectedCount} selected</span>
          </div>
        )}
        
        {totalQuantity > 0 && (
          <div className="flex items-center gap-2">
            <Calculator className="h-4 w-4" />
            <span>Total: {totalQuantity.toLocaleString()}</span>
          </div>
        )}
        
        <div className="text-xs text-muted-foreground/70">
          Use Delete to remove, Ctrl+N to insert, Ctrl+D to duplicate
        </div>
      </div>
    </div>
  );
}
