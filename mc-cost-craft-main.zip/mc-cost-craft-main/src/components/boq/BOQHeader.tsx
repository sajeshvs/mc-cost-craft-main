
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function BOQHeader() {
  const navigate = useNavigate();

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-4">
        <Button variant="outline" onClick={() => navigate(-1)}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Jobs
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight">BOQ Estimator</h2>
          <p className="text-muted-foreground">
            Excel-style Bill of Quantities with CCS Candy formatting
          </p>
        </div>
      </div>
    </div>
  );
}
