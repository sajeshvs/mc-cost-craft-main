
import React, { useState } from 'react';
import { Calculator } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePriceListData } from '@/components/price-list/hooks/usePriceListData';
import { PriceCodeSelector } from '@/components/price-list/PriceCodeSelector';
import { RateAnalysisSheet } from '@/components/rate-analysis/RateAnalysisSheet';

interface BOQPriceCodeCellProps {
  jobId: string;
  itemId: string;
  priceCode?: string;
  netRate?: number;
  onUpdate: (updates: {
    price_code?: string;
    net_rate?: number;
    amount_labor?: number;
    amount_material?: number;
    amount_equipment?: number;
    amount_subcontractor?: number;
    amount_consultant?: number;
  }) => void;
}

export function BOQPriceCodeCell({
  jobId,
  itemId,
  priceCode,
  netRate,
  onUpdate
}: BOQPriceCodeCellProps) {
  const [showSelector, setShowSelector] = useState(false);
  const [showRateAnalysis, setShowRateAnalysis] = useState(false);
  const { priceItems, isLoading } = usePriceListData(jobId);

  // Filter and validate price items to ensure no empty values
  const validPriceItems = (priceItems || []).filter(item => 
    item && 
    typeof item === 'object' &&
    item.price_code && 
    typeof item.price_code === 'string' &&
    item.price_code.trim() !== '' &&
    item.description &&
    typeof item.description === 'string' &&
    item.description.trim() !== '' &&
    typeof item.unit_rate === 'number' &&
    !isNaN(item.unit_rate)
  );

  const handlePriceCodeSelect = (selectedPriceCode: string, unitRate: number, splitRates: {
    labor: number;
    material: number;
    equipment: number;
    subcontractor: number;
    consultant: number;
  }) => {
    // Additional validation before updating
    if (selectedPriceCode && selectedPriceCode.trim() !== '') {
      onUpdate({
        price_code: selectedPriceCode,
        net_rate: unitRate,
        amount_labor: splitRates.labor,
        amount_material: splitRates.material,
        amount_equipment: splitRates.equipment,
        amount_subcontractor: splitRates.subcontractor,
        amount_consultant: splitRates.consultant
      });
    }
    
    setShowSelector(false);
  };

  const handleRateAnalysis = (selectedPriceCode: string, currentRate: number) => {
    // Validate price code before opening rate analysis
    if (selectedPriceCode && selectedPriceCode.trim() !== '') {
      setShowSelector(false);
      setShowRateAnalysis(true);
    }
  };

  const handleRateAnalysisSave = async (newNetRate: number, splitRates: {
    labor: number;
    material: number;
    equipment: number;
    subcontractor: number;
    consultant: number;
  }) => {
    onUpdate({
      net_rate: newNetRate,
      amount_labor: splitRates.labor,
      amount_material: splitRates.material,
      amount_equipment: splitRates.equipment,
      amount_subcontractor: splitRates.subcontractor,
      amount_consultant: splitRates.consultant
    });
    
    setShowRateAnalysis(false);
  };

  if (showSelector) {
    return (
      <div className="relative">
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50" onClick={() => setShowSelector(false)}>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-lg w-96 h-96" onClick={(e) => e.stopPropagation()}>
            {validPriceItems.length > 0 ? (
              <PriceCodeSelector
                projectId={jobId}
                priceList={validPriceItems}
                onSelectPriceCode={handlePriceCodeSelect}
                onOpenRateAnalysis={handleRateAnalysis}
              />
            ) : (
              <div className="p-4 text-center text-gray-500">
                <p>No valid price codes available</p>
                <Button 
                  className="mt-2" 
                  onClick={() => setShowSelector(false)}
                >
                  Close
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1">
      <div
        className="cursor-pointer px-2 py-1 hover:bg-gray-50 rounded text-sm flex-1"
        onClick={() => setShowSelector(true)}
      >
        {isLoading ? (
          <div className="text-gray-400">Loading...</div>
        ) : (
          <div className="text-blue-600 font-mono">
            {priceCode || 'Select...'}
          </div>
        )}
      </div>
      
      {priceCode && priceCode.trim() !== '' && (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowRateAnalysis(true)}
          className="p-1 h-6 w-6"
          title="Open Rate Analysis"
        >
          <Calculator className="h-3 w-3" />
        </Button>
      )}

      {showRateAnalysis && priceCode && priceCode.trim() !== '' && (
        <RateAnalysisSheet
          projectId={jobId}
          priceCode={priceCode}
          currentNetRate={netRate || 0}
          onClose={() => setShowRateAnalysis(false)}
          onSave={handleRateAnalysisSave}
        />
      )}
    </div>
  );
}
