
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Plus } from 'lucide-react';

interface InsertRowDialogProps {
  selectedRowsCount: number;
  onInsert: (position: 'above' | 'below' | 'beginning' | 'end') => void;
  trigger?: React.ReactNode;
}

export function InsertRowDialog({ selectedRowsCount, onInsert, trigger }: InsertRowDialogProps) {
  const [position, setPosition] = useState<'above' | 'below' | 'beginning' | 'end'>('end');
  const [open, setOpen] = useState(false);

  const handleInsert = () => {
    onInsert(position);
    setOpen(false);
  };

  const hasSelection = selectedRowsCount > 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline">
            <Plus className="mr-2 h-4 w-4" />
            Insert Row
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Insert New Row</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <RadioGroup value={position} onValueChange={setPosition as (value: string) => void}>
            {hasSelection && (
              <>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="above" id="above" />
                  <Label htmlFor="above">Above selected row{selectedRowsCount > 1 ? 's' : ''}</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="below" id="below" />
                  <Label htmlFor="below">Below selected row{selectedRowsCount > 1 ? 's' : ''}</Label>
                </div>
              </>
            )}
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="beginning" id="beginning" />
              <Label htmlFor="beginning">At beginning of BOQ</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="end" id="end" />
              <Label htmlFor="end">At end of BOQ</Label>
            </div>
          </RadioGroup>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleInsert}>
              Insert Row
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
