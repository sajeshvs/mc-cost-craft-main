
import React from 'react';
import { BOQItem } from '@/types/mccost';
import { useBOQPriceIntegration } from '@/hooks/useBOQPriceIntegration';

interface BOQPricingSummaryProps {
  items: BOQItem[];
}

export function BOQPricingSummary({ items }: BOQPricingSummaryProps) {
  const { calculateProjectTotals } = useBOQPriceIntegration();
  const totals = calculateProjectTotals(items);

  return (
    <div className="bg-white border-t border-gray-200 p-4">
      <div className="grid grid-cols-7 gap-4 text-sm">
        <div className="bg-blue-50 p-3 rounded-lg border">
          <div className="text-xs text-gray-600 font-medium">Total Project</div>
          <div className="text-lg font-bold text-blue-900">
            ${totals.totalAmount.toLocaleString()}
          </div>
        </div>
        
        <div className="bg-blue-50 p-3 rounded-lg border">
          <div className="text-xs text-blue-600 font-medium">Labor</div>
          <div className="text-sm font-bold text-blue-700">
            ${totals.totalLabor.toLocaleString()}
          </div>
        </div>
        
        <div className="bg-green-50 p-3 rounded-lg border">
          <div className="text-xs text-green-600 font-medium">Material</div>
          <div className="text-sm font-bold text-green-700">
            ${totals.totalMaterial.toLocaleString()}
          </div>
        </div>
        
        <div className="bg-yellow-50 p-3 rounded-lg border">
          <div className="text-xs text-yellow-600 font-medium">Equipment</div>
          <div className="text-sm font-bold text-yellow-700">
            ${totals.totalEquipment.toLocaleString()}
          </div>
        </div>
        
        <div className="bg-purple-50 p-3 rounded-lg border">
          <div className="text-xs text-purple-600 font-medium">Subcontractor</div>
          <div className="text-sm font-bold text-purple-700">
            ${totals.totalSubcontractor.toLocaleString()}
          </div>
        </div>
        
        <div className="bg-red-50 p-3 rounded-lg border">
          <div className="text-xs text-red-600 font-medium">Consultant</div>
          <div className="text-sm font-bold text-red-700">
            ${totals.totalConsultant.toLocaleString()}
          </div>
        </div>
        
        <div className="bg-gray-50 p-3 rounded-lg border">
          <div className="text-xs text-gray-600 font-medium">Items</div>
          <div className="text-sm font-bold text-gray-700">
            {totals.itemCount}
          </div>
        </div>
      </div>
    </div>
  );
}
