
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from '@/components/ui/context-menu';
import { 
  Copy, Clipboard, Eraser, Calculator, Type 
} from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

interface BOQMultiCellContextMenuProps {
  children: React.ReactNode;
  selectedCellsCount: number;
  onCopy: () => void;
  onPaste: () => void;
  onClear: () => void;
  onEnterValue: (value: string) => void;
  onSum: () => void;
  canPaste: boolean;
  hasNumericCells: boolean;
}

export function BOQMultiCellContextMenu({
  children,
  selectedCellsCount,
  onCopy,
  onPaste,
  onClear,
  onEnterValue,
  onSum,
  canPaste,
  hasNumericCells
}: BOQMultiCellContextMenuProps) {
  const [showValueDialog, setShowValueDialog] = useState(false);
  const { toast } = useToast();

  const handleEnterValue = () => {
    const value = prompt('Enter value to fill all selected cells:');
    if (value !== null) {
      onEnterValue(value);
      toast({ 
        title: 'Success', 
        description: `Value applied to ${selectedCellsCount} cell(s)` 
      });
    }
  };

  if (selectedCellsCount === 0) {
    return <>{children}</>;
  }

  return (
    <ContextMenu>
      <ContextMenuTrigger asChild>
        {children}
      </ContextMenuTrigger>
      <ContextMenuContent className="w-56">
        <ContextMenuItem onClick={onCopy} className="gap-2">
          <Copy className="h-4 w-4" />
          Copy ({selectedCellsCount} cells)
        </ContextMenuItem>
        <ContextMenuItem onClick={onPaste} disabled={!canPaste} className="gap-2">
          <Clipboard className="h-4 w-4" />
          Paste
        </ContextMenuItem>
        <ContextMenuItem onClick={onClear} className="gap-2">
          <Eraser className="h-4 w-4" />
          Clear
        </ContextMenuItem>
        
        <ContextMenuSeparator />
        
        <ContextMenuItem onClick={handleEnterValue} className="gap-2">
          <Type className="h-4 w-4" />
          Enter Value...
        </ContextMenuItem>
        
        {hasNumericCells && (
          <ContextMenuItem onClick={onSum} className="gap-2">
            <Calculator className="h-4 w-4" />
            Sum
          </ContextMenuItem>
        )}
      </ContextMenuContent>
    </ContextMenu>
  );
}
