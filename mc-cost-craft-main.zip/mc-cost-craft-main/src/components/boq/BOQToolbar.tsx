
import React from 'react';
import { BOQModuleButtons } from './toolbar/BOQModuleButtons';
import { BOQActionButtons } from './toolbar/BOQActionButtons';
import { BOQImportExportButtons } from './toolbar/BOQImportExportButtons';
import { BOQViewButtons } from './toolbar/BOQViewButtons';

interface BOQToolbarProps {
  onOpenTrades: () => void;
  onOpenResources: () => void;
  onOpenPriceList: () => void;
  onOpenAnalysis: () => void;
  onOpenAdjudicator: () => void;
  onOpenMarkup?: () => void;
  onOpenTradeSummary?: () => void;
}

export function BOQToolbar({ 
  onOpenTrades, 
  onOpenResources, 
  onOpenPriceList, 
  onOpenAnalysis, 
  onOpenAdjudicator,
  onOpenMarkup,
  onOpenTradeSummary
}: BOQToolbarProps) {
  return (
    <div className="flex items-center justify-between p-2 border-b bg-white">
      <div className="flex items-center gap-2">
        <BOQModuleButtons
          onOpenTrades={onOpenTrades}
          onOpenResources={onOpenResources}
          onOpenPriceList={onOpenPriceList}
          onOpenAnalysis={onOpenAnalysis}
          onOpenAdjudicator={onOpenAdjudicator}
          onOpenMarkup={onOpenMarkup}
          onOpenTradeSummary={onOpenTradeSummary}
        />
        
        <div className="h-6 w-px bg-gray-300 mx-2" />
        
        <BOQActionButtons 
          onInsertRow={() => {}}
          onDeleteRow={() => {}}
          onDownloadCSV={() => {}}
          onUploadCSV={() => {}}
          onCalculateTotals={() => {}}
          onExpandAll={() => {}}
          onCollapseAll={() => {}}
        />
      </div>
      
      <div className="flex items-center gap-2">
        <BOQViewButtons 
          expandedDivisions={new Set()}
          toggleDivision={() => {}}
          onExpandAll={() => {}}
          onCollapseAll={() => {}}
        />
        
        <div className="h-6 w-px bg-gray-300 mx-2" />
        
        <BOQImportExportButtons 
          onRefresh={async () => {}}
          onImportCSV={() => {}}
          onExportCSV={() => {}}
        />
      </div>
    </div>
  );
}
