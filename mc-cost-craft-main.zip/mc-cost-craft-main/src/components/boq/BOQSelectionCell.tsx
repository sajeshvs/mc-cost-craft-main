
import { TableCell } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';

interface BOQSelectionCellProps {
  isSelected: boolean;
  width: number;
  onToggle: (isShiftClick?: boolean, isCtrlClick?: boolean) => void;
}

export function BOQSelectionCell({ isSelected, width, onToggle }: BOQSelectionCellProps) {
  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const isShiftClick = e.shiftKey;
    const isCtrlClick = e.ctrlKey || e.metaKey;
    onToggle(isShiftClick, isCtrlClick);
  };

  return (
    <TableCell 
      className="border-r text-center bg-white p-2"
      style={{ width, minWidth: width, maxWidth: width }}
      onClick={handleClick}
    >
      <Checkbox
        checked={isSelected}
        onCheckedChange={() => onToggle()}
        onClick={handleClick}
      />
    </TableCell>
  );
}
