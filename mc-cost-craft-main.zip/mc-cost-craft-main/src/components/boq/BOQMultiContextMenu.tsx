
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from '@/components/ui/context-menu';
import { 
  Copy, Clipboard, Eraser, Plus, Trash2, 
  Calculator, Hash, Type 
} from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { BOQQuantityDialog } from './dialogs/BOQQuantityDialog';
import { BOQMultiplyDialog } from './dialogs/BOQMultiplyDialog';
import { BOQTextDialog } from './dialogs/BOQTextDialog';

interface BOQMultiContextMenuProps {
  children: React.ReactNode;
  selectedRowsCount: number;
  onCopy: () => void;
  onPaste: () => void;
  onClear: () => void;
  onInsertAbove: () => void;
  onInsertBelow: () => void;
  onDelete: () => void;
  onSetQuantity: (quantity: number) => void;
  onMultiplyQuantity: (factor: number) => void;
  onShowSum: () => void;
  onEnterText: (text: string) => void;
  canPaste: boolean;
}

export function BOQMultiContextMenu({
  children,
  selectedRowsCount,
  onCopy,
  onPaste,
  onClear,
  onInsertAbove,
  onInsertBelow,
  onDelete,
  onSetQuantity,
  onMultiplyQuantity,
  onShowSum,
  onEnterText,
  canPaste
}: BOQMultiContextMenuProps) {
  const [quantityDialog, setQuantityDialog] = useState(false);
  const [multiplyDialog, setMultiplyDialog] = useState(false);
  const [textDialog, setTextDialog] = useState(false);
  const { toast } = useToast();

  const handleSetQuantity = (quantity: number) => {
    onSetQuantity(quantity);
    toast({ 
      title: 'Success', 
      description: `Quantity set to ${quantity} for ${selectedRowsCount} row(s)` 
    });
  };

  const handleMultiplyQuantity = (factor: number) => {
    onMultiplyQuantity(factor);
    toast({ 
      title: 'Success', 
      description: `Quantities multiplied by ${factor} for ${selectedRowsCount} row(s)` 
    });
  };

  const handleEnterText = (text: string) => {
    onEnterText(text);
    toast({ 
      title: 'Success', 
      description: `Text applied to ${selectedRowsCount} row(s)` 
    });
  };

  if (selectedRowsCount === 0) {
    return <>{children}</>;
  }

  return (
    <>
      <ContextMenu>
        <ContextMenuTrigger asChild>
          {children}
        </ContextMenuTrigger>
        <ContextMenuContent className="w-56">
          <ContextMenuItem onClick={onCopy} className="gap-2">
            <Copy className="h-4 w-4" />
            Copy ({selectedRowsCount} rows)
          </ContextMenuItem>
          <ContextMenuItem onClick={onPaste} disabled={!canPaste} className="gap-2">
            <Clipboard className="h-4 w-4" />
            Paste
          </ContextMenuItem>
          <ContextMenuItem onClick={onClear} className="gap-2">
            <Eraser className="h-4 w-4" />
            Clear Fields
          </ContextMenuItem>
          
          <ContextMenuSeparator />
          
          <ContextMenuItem onClick={onInsertAbove} className="gap-2">
            <Plus className="h-4 w-4" />
            Insert Above
          </ContextMenuItem>
          <ContextMenuItem onClick={onInsertBelow} className="gap-2">
            <Plus className="h-4 w-4" />
            Insert Below
          </ContextMenuItem>
          
          <ContextMenuSeparator />
          
          <ContextMenuItem onClick={() => setQuantityDialog(true)} className="gap-2">
            <Hash className="h-4 w-4" />
            Set Quantity...
          </ContextMenuItem>
          <ContextMenuItem onClick={() => setMultiplyDialog(true)} className="gap-2">
            <Calculator className="h-4 w-4" />
            Multiply Qty...
          </ContextMenuItem>
          <ContextMenuItem onClick={onShowSum} className="gap-2">
            <Calculator className="h-4 w-4" />
            Sum Quantities
          </ContextMenuItem>
          <ContextMenuItem onClick={() => setTextDialog(true)} className="gap-2">
            <Type className="h-4 w-4" />
            Enter Text...
          </ContextMenuItem>
          
          <ContextMenuSeparator />
          
          <ContextMenuItem onClick={onDelete} className="text-red-600 gap-2">
            <Trash2 className="h-4 w-4" />
            Delete Rows
          </ContextMenuItem>
        </ContextMenuContent>
      </ContextMenu>

      <BOQQuantityDialog
        open={quantityDialog}
        onOpenChange={setQuantityDialog}
        onApply={handleSetQuantity}
        selectedRowsCount={selectedRowsCount}
      />

      <BOQMultiplyDialog
        open={multiplyDialog}
        onOpenChange={setMultiplyDialog}
        onApply={handleMultiplyQuantity}
        selectedRowsCount={selectedRowsCount}
      />

      <BOQTextDialog
        open={textDialog}
        onOpenChange={setTextDialog}
        onApply={handleEnterText}
        selectedRowsCount={selectedRowsCount}
      />
    </>
  );
}
