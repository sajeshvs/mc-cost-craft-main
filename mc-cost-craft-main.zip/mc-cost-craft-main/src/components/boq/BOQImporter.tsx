import { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ArrowLeft, Upload, FileSpreadsheet, Check, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useSupabaseMutation } from '@/hooks/useSupabaseQuery';
import { boqItemsService } from '@/services/boqItems';
import * as XLSX from 'xlsx';

interface ExcelRow {
  [key: string]: any;
}

interface ColumnMapping {
  item_no: string;
  description: string;
  unit: string;
  quantity: string;
  level_type?: string;
  page_number?: string;
}

const REQUIRED_FIELDS = [
  { key: 'item_no', label: 'Item No', required: true },
  { key: 'description', label: 'Description', required: true },
  { key: 'unit', label: 'Unit', required: true },
  { key: 'quantity', label: 'Quantity', required: true }
];

const OPTIONAL_FIELDS = [
  { key: 'level_type', label: 'Level', required: false },
  { key: 'page_number', label: 'Page No', required: false }
];

export function BOQImporter() {
  const { jobId } = useParams<{ jobId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [excelData, setExcelData] = useState<ExcelRow[]>([]);
  const [columns, setColumns] = useState<string[]>([]);
  const [mapping, setMapping] = useState<ColumnMapping>({
    item_no: '',
    description: '',
    unit: '',
    quantity: '',
    level_type: '',
    page_number: ''
  });
  const [isImporting, setIsImporting] = useState(false);
  const [fileName, setFileName] = useState<string>('');
  const [importPosition, setImportPosition] = useState<string>('');
  const [baseSortOrder, setBaseSortOrder] = useState<number>(0);

  const importMutation = useSupabaseMutation(
    boqItemsService.bulkCreate,
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'BOQ imported successfully' });
        navigate(`/mccost/jobs/${jobId}/boq`);
      }
    }
  );

  useEffect(() => {
    // Get import position from sessionStorage
    const position = sessionStorage.getItem('boq-import-position') || 'end';
    const sortOrder = parseInt(sessionStorage.getItem('boq-import-sort-order') || '0');
    setImportPosition(position);
    setBaseSortOrder(sortOrder);
    
    // Clean up sessionStorage
    sessionStorage.removeItem('boq-import-position');
    sessionStorage.removeItem('boq-import-sort-order');
  }, []);

  const isRowEmpty = (row: ExcelRow) => {
    return Object.values(row).every(value => 
      value === null || 
      value === undefined || 
      (typeof value === 'string' && value.trim() === '') ||
      value === ''
    );
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        
        if (jsonData.length > 1) {
          // First row as headers
          const headers = (jsonData[0] as string[]).filter(h => h && h.trim());
          setColumns(headers);
          
          // Remaining rows as data, filter out empty rows
          const dataRows = jsonData.slice(1).map((row: any) => {
            const obj: ExcelRow = {};
            headers.forEach((header, index) => {
              obj[header] = row[index] || '';
            });
            return obj;
          }).filter(row => !isRowEmpty(row)); // Skip empty rows
          
          setExcelData(dataRows);
          
          // Auto-map common column names
          const autoMapping: Partial<ColumnMapping> = {};
          headers.forEach(header => {
            const lowerHeader = header.toLowerCase();
            if (lowerHeader.includes('item') && lowerHeader.includes('no')) {
              autoMapping.item_no = header;
            } else if (lowerHeader.includes('description') || lowerHeader.includes('desc')) {
              autoMapping.description = header;
            } else if (lowerHeader.includes('unit')) {
              autoMapping.unit = header;
            } else if (lowerHeader.includes('quantity') || lowerHeader.includes('qty')) {
              autoMapping.quantity = header;
            } else if (lowerHeader.includes('level')) {
              autoMapping.level_type = header;
            } else if (lowerHeader.includes('page')) {
              autoMapping.page_number = header;
            }
          });
          
          setMapping(prev => ({ ...prev, ...autoMapping }));
          toast({ title: 'Success', description: `${dataRows.length} rows loaded from Excel file (empty rows skipped)` });
        }
      } catch (error) {
        console.error('Error reading Excel file:', error);
        toast({ 
          title: 'Error', 
          description: 'Failed to read Excel file. Please check the format.', 
          variant: 'destructive' 
        });
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleImport = async () => {
    if (!jobId || excelData.length === 0) return;
    
    const requiredFields = REQUIRED_FIELDS.map(f => f.key);
    const missingMappings = requiredFields.filter(field => !mapping[field as keyof ColumnMapping]);
    
    if (missingMappings.length > 0) {
      toast({
        title: 'Missing Required Fields',
        description: `Please map: ${REQUIRED_FIELDS.filter(f => missingMappings.includes(f.key)).map(f => f.label).join(', ')}`,
        variant: 'destructive'
      });
      return;
    }

    setIsImporting(true);
    
    try {
      const boqItems = excelData.map((row, index) => ({
        job_id: jobId,
        item_no: String(row[mapping.item_no] || ''),
        description: String(row[mapping.description] || ''),
        unit: String(row[mapping.unit] || ''),
        quantity: Number(row[mapping.quantity]) || 0,
        level_type: (mapping.level_type && row[mapping.level_type]) ? String(row[mapping.level_type]) : 'item',
        page_number: (mapping.page_number && row[mapping.page_number]) ? Number(row[mapping.page_number]) : null,
        sort_order: baseSortOrder + index
      }));

      await importMutation.mutateAsync(boqItems);
    } catch (error) {
      console.error('Import error:', error);
    } finally {
      setIsImporting(false);
    }
  };

  const getFieldStatus = (fieldKey: string) => {
    const isRequired = REQUIRED_FIELDS.some(f => f.key === fieldKey);
    const isMapped = mapping[fieldKey as keyof ColumnMapping];
    
    if (isRequired && !isMapped) return 'error';
    if (isMapped) return 'success';
    return 'default';
  };

  const isValid = excelData.length > 0 && 
    REQUIRED_FIELDS.every(field => mapping[field.key as keyof ColumnMapping]);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" onClick={() => navigate(`/mccost/jobs/${jobId}/boq`)}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to BOQ
        </Button>
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Import BOQ</h2>
          <p className="text-muted-foreground">
            Import Bill of Quantities from Excel file
            {importPosition && (
              <span className="ml-2 text-sm font-medium">
                • Inserting at: {importPosition}
              </span>
            )}
          </p>
        </div>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Upload Excel File</CardTitle>
            <CardDescription>
              Select an Excel file (.xlsx, .xls) containing your BOQ data. The first row should contain column headers.
              Empty rows will be automatically skipped.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  variant="outline"
                  className="w-full"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Choose Excel File
                </Button>
              </div>
              
              {fileName && (
                <div className="text-sm text-muted-foreground">
                  Selected: {fileName}
                </div>
              )}
              
              {excelData.length > 0 && (
                <div className="flex items-center gap-2 text-green-600">
                  <Check className="h-4 w-4" />
                  <span>{excelData.length} rows loaded from Excel file</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {columns.length > 0 ? (
          <Card>
            <CardHeader>
              <CardTitle>Column Mapping</CardTitle>
              <CardDescription>
                Map your Excel columns to BOQ fields. Required fields are marked with *.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {REQUIRED_FIELDS.map(field => {
                  const status = getFieldStatus(field.key);
                  const fieldValue = mapping[field.key as keyof ColumnMapping] || '';
                  
                  return (
                    <div key={field.key} className="space-y-2">
                      <Label className="flex items-center gap-2">
                        {field.label} *
                        {status === 'error' && <AlertCircle className="h-4 w-4 text-red-500" />}
                        {status === 'success' && <Check className="h-4 w-4 text-green-500" />}
                      </Label>
                      <Select
                        value={fieldValue}
                        onValueChange={(value) => setMapping(prev => ({ ...prev, [field.key]: value }))}
                      >
                        <SelectTrigger className={status === 'error' ? 'border-red-500' : ''}>
                          <SelectValue placeholder="Select column" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">-- None --</SelectItem>
                          {columns.map(col => (
                            <SelectItem key={col} value={col}>{col}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  );
                })}

                {OPTIONAL_FIELDS.map(field => {
                  const fieldValue = mapping[field.key as keyof ColumnMapping] || '';
                  
                  return (
                    <div key={field.key} className="space-y-2">
                      <Label>{field.label}</Label>
                      <Select
                        value={fieldValue}
                        onValueChange={(value) => setMapping(prev => ({ ...prev, [field.key]: value === 'none' ? '' : value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select column (optional)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">-- None --</SelectItem>
                          {columns.map(col => (
                            <SelectItem key={col} value={col}>{col}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-8">
                <FileSpreadsheet className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-500">Please upload Excel file with headers to continue</p>
              </div>
            </CardContent>
          </Card>
        )}

        {excelData.length > 0 && isValid && (
          <Card>
            <CardHeader>
              <CardTitle>Preview Data</CardTitle>
              <CardDescription>
                Preview of the first 5 rows with your column mapping
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item No</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Unit</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Level</TableHead>
                      <TableHead>Page No</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {excelData.slice(0, 5).map((row, index) => (
                      <TableRow key={index}>
                        <TableCell>{String(row[mapping.item_no] || '')}</TableCell>
                        <TableCell>{String(row[mapping.description] || '')}</TableCell>
                        <TableCell>{String(row[mapping.unit] || '')}</TableCell>
                        <TableCell>{String(row[mapping.quantity] || '')}</TableCell>
                        <TableCell>{mapping.level_type ? String(row[mapping.level_type] || 'item') : 'item'}</TableCell>
                        <TableCell>{mapping.page_number ? String(row[mapping.page_number] || '-') : '-'}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}

        {isValid && (
          <Card>
            <CardContent className="pt-6">
              <Button
                onClick={handleImport}
                disabled={isImporting || importMutation.isPending}
                className="w-full"
                size="lg"
              >
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                {isImporting ? 'Importing...' : `Import ${excelData.length} Items`}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
