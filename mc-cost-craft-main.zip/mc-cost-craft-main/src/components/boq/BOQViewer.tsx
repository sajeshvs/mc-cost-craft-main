
import React, { useState, useEffect } from 'react';
import { BOQTable } from './BOQTable';
import { BOQToolbar } from './BOQToolbar';
import { BOQStats } from './BOQStats';
import { BOQDataProvider } from './BOQDataProvider';
import { useBOQData } from '@/hooks/useBOQData';
import { useToast } from '@/hooks/use-toast';

interface BOQViewerProps {
  jobId: string;
  onOpenTrades: () => void;
  onOpenResources: () => void;
  onOpenPriceList: () => void;
  onOpenAnalysis: () => void;
  onOpenAdjudicator: () => void;
  onOpenMarkup?: () => void;
  onOpenTradeSummary?: () => void;
}

export function BOQViewer({ 
  jobId, 
  onOpenTrades, 
  onOpenResources, 
  onOpenPriceList, 
  onOpenAnalysis, 
  onOpenAdjudicator,
  onOpenMarkup,
  onOpenTradeSummary
}: BOQViewerProps) {
  const { boqItems, setBOQItems, isLoading } = useBOQData(jobId);
  const { toast } = useToast();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading BOQ data...</div>
      </div>
    );
  }

  return (
    <BOQDataProvider jobId={jobId}>
      <div className="h-full flex flex-col">
        <BOQToolbar
          onOpenTrades={onOpenTrades}
          onOpenResources={onOpenResources}
          onOpenPriceList={onOpenPriceList}
          onOpenAnalysis={onOpenAnalysis}
          onOpenAdjudicator={onOpenAdjudicator}
          onOpenMarkup={onOpenMarkup}
          onOpenTradeSummary={onOpenTradeSummary}
        />
        
        <BOQStats 
          itemCount={boqItems.length}
          selectedCount={0}
          totalQuantity={0}
        />
        
        <div className="flex-1 overflow-hidden">
          <BOQTable 
            items={boqItems}
            visibleItems={boqItems}
            selectedRows={new Set()}
            editingCell={null}
            expandedSections={new Set()}
            onToggleRowSelection={() => {}}
            onSelectAllRows={() => {}}
            onClearSelection={() => {}}
            onStartEditing={() => {}}
            onCellSave={() => {}}
            onCancelEditing={() => {}}
            onDragEnd={() => {}}
            onInsertRow={() => {}}
            onDeleteItem={() => {}}
            onDuplicateItem={() => {}}
            onToggleExpand={() => {}}
            onCopy={() => {}}
            onPaste={() => {}}
            onClear={() => {}}
            onSetQuantity={() => {}}
            onMultiplyQuantity={() => {}}
            onShowSum={() => {}}
            onEnterText={() => {}}
            canPaste={false}
          />
        </div>
      </div>
    </BOQDataProvider>
  );
}
