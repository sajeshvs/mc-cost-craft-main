
import React, { useState, useCallback } from 'react';
import { BOQToolbar } from './BOQToolbar';
import { BOQEnhancedTable } from './enhanced/BOQEnhancedTable';
import { MarkupWindow } from '../markup/MarkupWindow';
import { useBOQData } from '@/hooks/useBOQData';
import { BOQItem } from '@/types/mccost';

interface BOQContentProps {
  jobId: string;
  onOpenTrades: () => void;
  onOpenResources: () => void;
  onOpenPriceList: () => void;
  onOpenAnalysis: () => void;
  onOpenAdjudicator: () => void;
}

export function BOQContent({ 
  jobId, 
  onOpenTrades, 
  onOpenResources, 
  onOpenPriceList, 
  onOpenAnalysis,
  onOpenAdjudicator
}: BOQContentProps) {
  const { boqItems, setBOQItems, isLoading } = useBOQData(jobId);
  const [searchTerm, setSearchTerm] = useState('');
  const [showMarkupManager, setShowMarkupManager] = useState(false);

  const handleUpdateItem = useCallback(async (id: string, updates: Partial<BOQItem>) => {
    try {
      setBOQItems(prevItems => 
        prevItems.map(item => 
          item.id === id ? { ...item, ...updates } : item
        )
      );
      
      // TODO: Implement API update
      console.log('Update item:', id, updates);
    } catch (error) {
      console.error('Error updating item:', error);
    }
  }, [setBOQItems]);

  const handleDeleteItems = useCallback(async (ids: string[]) => {
    try {
      setBOQItems(prevItems => 
        prevItems.filter(item => !ids.includes(item.id))
      );
      
      // TODO: Implement API delete
      console.log('Delete items:', ids);
    } catch (error) {
      console.error('Error deleting items:', error);
    }
  }, [setBOQItems]);

  const handleAddItem = useCallback(async () => {
    const newItem: BOQItem = {
      id: `temp-${Date.now()}`,
      job_id: jobId,
      item_no: '',
      description: 'New Item',
      unit: 'EA',
      quantity: 0,
      level_type: 'item',
      page_number: 1,
      sort_order: boqItems.length,
      net_rate: 0,
      amount: 0,
      amount_labor: 0,
      amount_material: 0,
      amount_equipment: 0,
      amount_subcontractor: 0,
      amount_consultant: 0,
      price_code: '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      user_id: null
    };

    setBOQItems(prevItems => [...prevItems, newItem]);
    
    // TODO: Implement API create
    console.log('Add new item');
  }, [jobId, boqItems.length, setBOQItems]);

  const handleReorderItems = useCallback(async (reorderedItems: BOQItem[]) => {
    const itemsWithOrder = reorderedItems.map((item, index) => ({
      ...item,
      sort_order: index
    }));
    
    setBOQItems(itemsWithOrder);
    
    // TODO: Implement API reorder
    console.log('Reorder items');
  }, [setBOQItems]);

  // Fix: Make this function return Promise<void>
  const handleRefresh = useCallback(async (): Promise<void> => {
    try {
      // TODO: Implement refresh logic
      console.log('Refresh BOQ data');
    } catch (error) {
      console.error('Error refreshing:', error);
    }
  }, []);

  const handleOpenMarkup = () => {
    setShowMarkupManager(true);
  };

  const handleCloseMarkup = () => {
    setShowMarkupManager(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Loading BOQ items...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <BOQToolbar
        onOpenTrades={onOpenTrades}
        onOpenResources={onOpenResources}
        onOpenPriceList={onOpenPriceList}
        onOpenAnalysis={onOpenAnalysis}
        onOpenAdjudicator={onOpenAdjudicator}
        onOpenMarkup={handleOpenMarkup}
      />
      
      <div className="flex-1 overflow-hidden">
        <BOQEnhancedTable
          items={boqItems}
          onUpdateItem={handleUpdateItem}
          onDeleteItems={handleDeleteItems}
          onAddItem={handleAddItem}
          onReorderItems={handleReorderItems}
        />
      </div>

      {/* Markup Manager Modal */}
      {showMarkupManager && (
        <MarkupWindow
          projectId={jobId}
          onClose={handleCloseMarkup}
        />
      )}
    </div>
  );
}
