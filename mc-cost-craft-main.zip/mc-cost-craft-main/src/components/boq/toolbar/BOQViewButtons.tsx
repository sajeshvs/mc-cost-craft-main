
import React from 'react';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface BOQViewButtonsProps {
  expandedDivisions: Set<string>;
  toggleDivision: (division: string) => void;
  onExpandAll: () => void;
  onCollapseAll: () => void;
}

export function BOQViewButtons({
  expandedDivisions,
  toggleDivision,
  onExpandAll,
  onCollapseAll
}: BOQViewButtonsProps) {
  return (
    <div className="flex items-center gap-1">
      <Button
        variant="outline"
        size="sm"
        onClick={onExpandAll}
        className="h-8 gap-1.5"
        title="Expand All"
      >
        <ChevronDown className="h-4 w-4" />
        Expand All
      </Button>
      
      <Button
        variant="outline"
        size="sm"
        onClick={onCollapseAll}
        className="h-8 gap-1.5"
        title="Collapse All"
      >
        <ChevronUp className="h-4 w-4" />
        Collapse All
      </Button>
    </div>
  );
}
