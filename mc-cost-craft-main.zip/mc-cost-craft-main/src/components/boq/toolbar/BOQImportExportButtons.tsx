
import React, { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { RefreshCw, Download, Upload } from 'lucide-react';

interface BOQImportExportButtonsProps {
  onRefresh: () => Promise<void>;
  onImportCSV: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onExportCSV: () => void;
}

export function BOQImportExportButtons({
  onRefresh,
  onImportCSV,
  onExportCSV
}: BOQImportExportButtonsProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImportClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onImportCSV(event);
    // Reset the input so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="flex items-center gap-1">
      <Button
        variant="outline"
        size="sm"
        onClick={onRefresh}
        className="h-8 gap-1.5"
        title="Refresh"
        type="button"
      >
        <RefreshCw className="h-4 w-4" />
        Refresh
      </Button>
      
      <Button
        variant="outline"
        size="sm"
        onClick={onExportCSV}
        className="h-8 gap-1.5"
        title="Export CSV"
        type="button"
      >
        <Download className="h-4 w-4" />
        Export
      </Button>
      
      <Button
        variant="outline"
        size="sm"
        onClick={handleImportClick}
        className="h-8 gap-1.5"
        title="Import CSV"
        type="button"
      >
        <Upload className="h-4 w-4" />
        Import
      </Button>
      
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv"
        onChange={handleFileChange}
        className="hidden"
      />
    </div>
  );
}
