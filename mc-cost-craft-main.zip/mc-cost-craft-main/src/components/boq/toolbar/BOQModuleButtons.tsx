
import React from 'react';
import { Button } from '@/components/ui/button';
import { 
  Wrench, 
  Package, 
  DollarSign, 
  Calculator, 
  Gavel,
  TrendingUp,
  BarChart3
} from 'lucide-react';

interface BOQModuleButtonsProps {
  onOpenTrades: () => void;
  onOpenResources: () => void;
  onOpenPriceList: () => void;
  onOpenAnalysis: () => void;
  onOpenAdjudicator: () => void;
  onOpenMarkup?: () => void;
  onOpenTradeSummary?: () => void;
}

export function BOQModuleButtons({ 
  onOpenTrades, 
  onOpenResources, 
  onOpenPriceList, 
  onOpenAnalysis, 
  onOpenAdjudicator,
  onOpenMarkup,
  onOpenTradeSummary
}: BOQModuleButtonsProps) {
  return (
    <div className="flex items-center gap-1">
      <Button
        variant="outline"
        size="sm"
        onClick={onOpenTrades}
        className="h-8 gap-1.5"
        title="Trades"
      >
        <Wrench className="h-4 w-4" />
        T
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onOpenResources}
        className="h-8 gap-1.5"
        title="Resources"
      >
        <Package className="h-4 w-4" />
        R
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onOpenPriceList}
        className="h-8 gap-1.5"
        title="Price List"
      >
        <DollarSign className="h-4 w-4" />
        P
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onOpenAnalysis}
        className="h-8 gap-1.5"
        title="Analysis"
      >
        <Calculator className="h-4 w-4" />
        A
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onOpenAdjudicator}
        className="h-8 gap-1.5"
        title="Adjudicator"
      >
        <Gavel className="h-4 w-4" />
        J
      </Button>

      {onOpenMarkup && (
        <Button
          variant="outline"
          size="sm"
          onClick={onOpenMarkup}
          className="h-8 gap-1.5"
          title="Markup Manager"
        >
          <TrendingUp className="h-4 w-4" />
          M
        </Button>
      )}

      {onOpenTradeSummary && (
        <Button
          variant="outline"
          size="sm"
          onClick={onOpenTradeSummary}
          className="h-8 gap-1.5"
          title="Trade Summary"
        >
          <BarChart3 className="h-4 w-4" />
          S
        </Button>
      )}
    </div>
  );
}
