
import React, { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Trash2, Plus, Download, Upload, Calculator, Expand, Shrink } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface BOQActionButtonsProps {
  onInsertRow: () => void;
  onDeleteRow: () => void;
  onDownloadCSV: () => void;
  onUploadCSV: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCalculateTotals: () => void;
  onExpandAll: () => void;
  onCollapseAll: () => void;
  onAddLineItem?: (division: string, tradeCode: string) => Promise<void>;
  onDeleteSelected?: () => void;
}

export function BOQActionButtons({
  onInsertRow,
  onDeleteRow,
  onDownloadCSV,
  onUploadCSV,
  onCalculateTotals,
  onExpandAll,
  onCollapseAll,
  onAddLineItem,
  onDeleteSelected
}: BOQActionButtonsProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUploadClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onUploadCSV(event);
    // Reset the input so the same file can be selected again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <>
      {/* Row Operations */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="h-8" type="button">
            <Plus className="w-4 h-4 mr-2" />
            Add Item
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={onInsertRow}>
            Insert Row
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => onAddLineItem?.('', '')}>
            Add Line Item
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Button
        variant="outline"
        size="sm"
        onClick={onDeleteSelected || onDeleteRow}
        className="h-8 whitespace-nowrap gap-2"
        type="button"
      >
        <Trash2 className="h-4 w-4" />
        Delete
      </Button>

      {/* File Operations */}
      <Button
        variant="outline"
        size="sm"
        onClick={onCalculateTotals}
        className="h-8 whitespace-nowrap gap-2"
        type="button"
      >
        <Calculator className="h-4 w-4" />
        Calculate
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onExpandAll}
        className="h-8 whitespace-nowrap gap-2"
        type="button"
      >
        <Expand className="h-4 w-4" />
        Expand All
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onCollapseAll}
        className="h-8 whitespace-nowrap gap-2"
        type="button"
      >
        <Shrink className="h-4 w-4" />
        Collapse All
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={handleUploadClick}
        className="h-8 whitespace-nowrap gap-2"
        type="button"
      >
        <Upload className="h-4 w-4" />
        Import
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onDownloadCSV}
        className="h-8 whitespace-nowrap gap-2"
        type="button"
      >
        <Download className="h-4 w-4" />
        Export
      </Button>

      <input
        ref={fileInputRef}
        type="file"
        accept=".csv"
        onChange={handleFileChange}
        className="hidden"
      />
    </>
  );
}
