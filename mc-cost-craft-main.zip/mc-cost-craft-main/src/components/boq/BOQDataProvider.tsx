
import React from 'react';
import { useParams } from 'react-router-dom';
import { BOQItem } from '@/types/mccost';
import { useSupabaseQuery } from '@/hooks/useSupabaseQuery';
import { boqItemsService } from '@/services/boqItems';

interface BOQDataProviderProps {
  jobId: string;
  children: React.ReactNode;
}

export function BOQDataProvider({ jobId, children }: BOQDataProviderProps) {
  const { data: boqItems = [], isLoading, error } = useSupabaseQuery(
    ['boq_items', jobId],
    () => boqItemsService.getByJob(jobId!),
    { enabled: !!jobId }
  );

  console.log('BOQ Data Provider State:', { 
    jobId, 
    boqItems: boqItems.length, 
    isLoading, 
    error: error?.message 
  });

  if (!jobId) {
    return null;
  }

  return <>{children}</>;
}
