
import { useState, useMemo } from 'react';
import { BOQItem } from '@/types/mccost';

interface LevelTotals {
  totalAmount: number;
  labor: number;
  material: number;
  equipment: number;
  subcontractor: number;
  consultant: number;
  itemCount: number;
}

export function useBOQHierarchy(items: BOQItem[]) {
  const [expandedLevels, setExpandedLevels] = useState<Set<string>>(new Set());

  const visibleItems = useMemo(() => {
    if (expandedLevels.size === 0) {
      // Show all items if nothing is expanded
      return items;
    }

    const result: BOQItem[] = [];
    const levelStack: { item: BOQItem; level: number }[] = [];

    for (const item of items) {
      const currentLevel = getLevelNumber(item.level_type);
      
      // Remove levels that are at or below current level
      while (levelStack.length > 0 && levelStack[levelStack.length - 1].level >= currentLevel) {
        levelStack.pop();
      }
      
      // Check if this item should be visible
      const shouldShow = levelStack.length === 0 || 
        levelStack.every(level => expandedLevels.has(level.item.id));
      
      if (shouldShow) {
        result.push(item);
      }
      
      // Add to stack if it's a level item
      if (item.level_type && item.level_type.startsWith('level_')) {
        levelStack.push({ item, level: currentLevel });
      }
    }

    return result;
  }, [items, expandedLevels]);

  const levelTotals = useMemo(() => {
    const totals: Record<string, LevelTotals> = {};
    
    for (const item of items) {
      if (item.level_type && item.level_type.startsWith('level_')) {
        const levelId = item.id;
        const currentLevel = getLevelNumber(item.level_type);
        
        // Calculate totals for items under this level
        const subItems = getSubItems(items, item, currentLevel);
        
        totals[levelId] = {
          totalAmount: subItems.reduce((sum, subItem) => sum + (subItem.amount || 0), 0),
          labor: subItems.reduce((sum, subItem) => sum + (subItem.amount_labor || 0), 0),
          material: subItems.reduce((sum, subItem) => sum + (subItem.amount_material || 0), 0),
          equipment: subItems.reduce((sum, subItem) => sum + (subItem.amount_equipment || 0), 0),
          subcontractor: subItems.reduce((sum, subItem) => sum + (subItem.amount_subcontractor || 0), 0),
          consultant: subItems.reduce((sum, subItem) => sum + (subItem.amount_consultant || 0), 0),
          itemCount: subItems.filter(subItem => subItem.level_type === 'item').length
        };
      }
    }
    
    return totals;
  }, [items]);

  const toggleLevel = (levelId: string) => {
    setExpandedLevels(prev => {
      const newSet = new Set(prev);
      if (newSet.has(levelId)) {
        newSet.delete(levelId);
      } else {
        newSet.add(levelId);
      }
      return newSet;
    });
  };

  const expandAll = () => {
    const allLevels = items
      .filter(item => item.level_type && item.level_type.startsWith('level_'))
      .map(item => item.id);
    setExpandedLevels(new Set(allLevels));
  };

  const collapseAll = () => {
    setExpandedLevels(new Set());
  };

  return {
    expandedLevels,
    visibleItems,
    levelTotals,
    toggleLevel,
    expandAll,
    collapseAll
  };
}

function getLevelNumber(levelType: BOQItem['level_type']): number {
  if (levelType === 'comment') return 0;
  if (levelType === 'item') return 99;
  if (levelType && levelType.startsWith('level_')) {
    return parseInt(levelType.split('_')[1]) || 99;
  }
  return 99;
}

function getSubItems(items: BOQItem[], levelItem: BOQItem, currentLevel: number): BOQItem[] {
  const levelIndex = items.findIndex(item => item.id === levelItem.id);
  const subItems: BOQItem[] = [];
  
  for (let i = levelIndex + 1; i < items.length; i++) {
    const item = items[i];
    const itemLevel = getLevelNumber(item.level_type);
    
    // Stop when we reach a same or higher level
    if (itemLevel <= currentLevel) {
      break;
    }
    
    subItems.push(item);
  }
  
  return subItems;
}
