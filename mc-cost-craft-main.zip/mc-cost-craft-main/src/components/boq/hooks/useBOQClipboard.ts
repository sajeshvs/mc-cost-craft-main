
import { useState, useCallback } from 'react';
import { BOQItem } from '@/types/mccost';
import { useToast } from '@/hooks/use-toast';

export function useBOQClipboard() {
  const { toast } = useToast();
  const [clipboardRows, setClipboardRows] = useState<BOQItem[]>([]);
  const [clipboardCells, setClipboardCells] = useState<Array<{ field: keyof BOQItem; value: any }>>([]);
  const [clipboardType, setClipboardType] = useState<'rows' | 'cells' | null>(null);

  const copyRows = useCallback((items: BOQItem[]) => {
    setClipboardRows(items);
    setClipboardType('rows');
    toast({
      title: "Copied",
      description: `${items.length} rows copied to clipboard`
    });
  }, [toast]);

  const copyCells = useCallback((cellsData: Array<{ field: keyof BOQItem; value: any }>) => {
    setClipboardCells(cellsData);
    setClipboardType('cells');
    
    // Also copy to system clipboard as tab-separated values
    const textData = cellsData.map(cell => String(cell.value || '')).join('\t');
    navigator.clipboard.writeText(textData).catch(() => {
      console.warn('Failed to copy to system clipboard');
    });
    
    toast({
      title: "Copied",
      description: `${cellsData.length} cells copied to clipboard`
    });
  }, [toast]);

  const pasteRows = useCallback((targetIndex: number, onInsertItems: (items: Partial<BOQItem>[], index: number) => void) => {
    if (clipboardType !== 'rows' || clipboardRows.length === 0) return;

    const itemsToInsert = clipboardRows.map(item => {
      const { id, created_at, updated_at, ...rest } = item;
      return {
        ...rest,
        item_no: `${rest.item_no}_copy`,
        sort_order: targetIndex
      };
    });

    onInsertItems(itemsToInsert, targetIndex);
    
    toast({
      title: "Pasted",
      description: `${itemsToInsert.length} rows pasted`
    });
  }, [clipboardType, clipboardRows, toast]);

  const pasteCells = useCallback(async (
    selectedCells: Set<string>,
    visibleItems: BOQItem[],
    onUpdateCell: (itemId: string, field: keyof BOQItem, value: any) => void
  ) => {
    if (clipboardType !== 'cells' || clipboardCells.length === 0) {
      // Try to get from system clipboard
      try {
        const text = await navigator.clipboard.readText();
        const values = text.split(/[\t\n]/);
        let index = 0;
        
        selectedCells.forEach(cellKey => {
          if (index < values.length) {
            const [rowId, field] = cellKey.split('-');
            const value = values[index].trim();
            if (value) {
              onUpdateCell(rowId, field as keyof BOQItem, value);
            }
            index++;
          }
        });
        
        toast({
          title: "Pasted",
          description: `Values pasted to ${Math.min(selectedCells.size, values.length)} cells`
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to paste from clipboard",
          variant: "destructive"
        });
      }
      return;
    }

    let index = 0;
    selectedCells.forEach(cellKey => {
      if (index < clipboardCells.length) {
        const [rowId] = cellKey.split('-');
        const clipboardCell = clipboardCells[index];
        onUpdateCell(rowId, clipboardCell.field, clipboardCell.value);
        index++;
      }
    });

    toast({
      title: "Pasted",
      description: `${Math.min(selectedCells.size, clipboardCells.length)} cells pasted`
    });
  }, [clipboardType, clipboardCells, toast]);

  const canPaste = clipboardType !== null && (
    (clipboardType === 'rows' && clipboardRows.length > 0) ||
    (clipboardType === 'cells' && clipboardCells.length > 0)
  );

  return {
    copyRows,
    copyCells,
    pasteRows,
    pasteCells,
    canPaste,
    clipboardType
  };
}
