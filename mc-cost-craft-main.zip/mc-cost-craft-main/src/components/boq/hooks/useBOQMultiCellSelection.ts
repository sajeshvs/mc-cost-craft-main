
import { useState, useCallback, useRef } from 'react';
import { BOQItem } from '@/types/mccost';

interface CellPosition {
  rowId: string;
  field: keyof BOQItem;
}

export function useBOQMultiCellSelection() {
  const [selectedCells, setSelectedCells] = useState<Set<string>>(new Set());
  const [isSelecting, setIsSelecting] = useState(false);
  const [selectionStart, setSelectionStart] = useState<CellPosition | null>(null);
  const selectionEndRef = useRef<CellPosition | null>(null);
  const isDragging = useRef(false);

  const getCellKey = (rowId: string, field: keyof BOQItem) => `${rowId}-${field}`;

  const startCellSelection = useCallback((rowId: string, field: keyof BOQItem, isCtrlClick = false) => {
    const cellKey = getCellKey(rowId, field);
    
    if (isCtrlClick) {
      setSelectedCells(prev => {
        const newSet = new Set(prev);
        if (newSet.has(cellKey)) {
          newSet.delete(cellKey);
        } else {
          newSet.add(cellKey);
        }
        return newSet;
      });
    } else {
      setSelectedCells(new Set([cellKey]));
      setSelectionStart({ rowId, field });
      setIsSelecting(true);
      isDragging.current = false;
    }
  }, []);

  const updateCellSelection = useCallback((rowId: string, field: keyof BOQItem, items: BOQItem[]) => {
    if (!isSelecting || !selectionStart) return;

    isDragging.current = true;
    selectionEndRef.current = { rowId, field };
    const start = selectionStart;
    const end = { rowId, field };

    // Find row indices
    const startRowIndex = items.findIndex(item => item.id === start.rowId);
    const endRowIndex = items.findIndex(item => item.id === end.rowId);

    if (startRowIndex === -1 || endRowIndex === -1) return;

    // Define column order for editable fields
    const columns: (keyof BOQItem)[] = [
      'level_type', 'page_number', 'item_no', 'price_code', 'description', 
      'unit', 'quantity'
    ];

    const startColIndex = columns.indexOf(start.field);
    const endColIndex = columns.indexOf(end.field);

    if (startColIndex === -1 || endColIndex === -1) return;

    const minRow = Math.min(startRowIndex, endRowIndex);
    const maxRow = Math.max(startRowIndex, endRowIndex);
    const minCol = Math.min(startColIndex, endColIndex);
    const maxCol = Math.max(startColIndex, endColIndex);

    const newSelectedCells = new Set<string>();
    for (let rowIdx = minRow; rowIdx <= maxRow; rowIdx++) {
      for (let colIdx = minCol; colIdx <= maxCol; colIdx++) {
        const item = items[rowIdx];
        if (item) {
          const field = columns[colIdx];
          // Skip non-editable fields for comment rows
          if (item.level_type === 'comment' && (field === 'unit' || field === 'quantity' || field === 'price_code')) {
            continue;
          }
          newSelectedCells.add(getCellKey(item.id, field));
        }
      }
    }

    setSelectedCells(newSelectedCells);
  }, [isSelecting, selectionStart]);

  const endCellSelection = useCallback(() => {
    setIsSelecting(false);
    setSelectionStart(null);
    selectionEndRef.current = null;
    
    // If it was just a click (not a drag), allow editing
    if (!isDragging.current && selectedCells.size === 1) {
      // This could trigger edit mode
    }
    
    isDragging.current = false;
  }, [selectedCells.size]);

  const clearCellSelection = useCallback(() => {
    setSelectedCells(new Set());
    setIsSelecting(false);
    setSelectionStart(null);
    selectionEndRef.current = null;
    isDragging.current = false;
  }, []);

  const isCellSelected = useCallback((rowId: string, field: keyof BOQItem) => {
    return selectedCells.has(getCellKey(rowId, field));
  }, [selectedCells]);

  const getSelectedCellsData = useCallback((items: BOQItem[]) => {
    const result: Array<{ rowId: string; field: keyof BOQItem; value: any }> = [];
    
    selectedCells.forEach(cellKey => {
      const [rowId, field] = cellKey.split('-');
      const item = items.find(i => i.id === rowId);
      if (item && field in item) {
        result.push({
          rowId,
          field: field as keyof BOQItem,
          value: item[field as keyof BOQItem]
        });
      }
    });
    
    return result;
  }, [selectedCells]);

  const applyToSelectedCells = useCallback((value: any, items: BOQItem[], onUpdate: (id: string, field: keyof BOQItem, value: any) => void) => {
    selectedCells.forEach(cellKey => {
      const [rowId, field] = cellKey.split('-');
      const item = items.find(i => i.id === rowId);
      if (item) {
        // Don't allow editing certain fields for comment rows
        if (item.level_type === 'comment' && (field === 'unit' || field === 'quantity' || field === 'price_code')) {
          return;
        }
        onUpdate(rowId, field as keyof BOQItem, value);
      }
    });
    clearCellSelection();
  }, [selectedCells, clearCellSelection]);

  return {
    selectedCells,
    isSelecting,
    startCellSelection,
    updateCellSelection,
    endCellSelection,
    clearCellSelection,
    isCellSelected,
    getSelectedCellsData,
    applyToSelectedCells
  };
}
