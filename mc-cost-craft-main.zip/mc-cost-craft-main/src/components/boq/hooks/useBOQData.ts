
import { useState, useEffect } from 'react';
import { BOQItem } from '@/types/mccost';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export function useBOQData(jobId: string) {
  const { toast } = useToast();
  const [boqItems, setBOQItems] = useState<BOQItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [expandedDivisions, setExpandedDivisions] = useState<Set<string>>(new Set());

  // Helper function to validate and cast level_type
  const castBOQItem = (item: any): BOQItem => {
    const validLevelTypes = ['item', 'level_1', 'level_2', 'level_3', 'level_4', 'level_5', 'level_6', 'level_7', 'level_8', 'level_9', 'comment'];
    const levelType = validLevelTypes.includes(item.level_type) ? item.level_type : 'item';
    
    return {
      ...item,
      level_type: levelType as BOQItem['level_type']
    };
  };

  // Load BOQ items
  useEffect(() => {
    if (!jobId) return;

    const loadBOQItems = async () => {
      try {
        setIsLoading(true);
        console.log('Loading BOQ items for job:', jobId);
        
        const { data, error } = await supabase
          .from('boq_items')
          .select('*')
          .eq('job_id', jobId)
          .order('sort_order');

        if (error) throw error;
        
        console.log('Loaded BOQ items:', data?.length || 0);
        
        // Cast the data to proper BOQItem type
        const typedItems = (data || []).map(castBOQItem);
        setBOQItems(typedItems);
        
      } catch (error: any) {
        console.error('Error loading BOQ items:', error);
        toast({
          title: 'Error',
          description: 'Failed to load BOQ items: ' + error.message,
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadBOQItems();
  }, [jobId, toast]);

  const handleAddItem = async (division: string, tradeCode: string) => {
    try {
      const { data, error } = await supabase
        .from('boq_items')
        .insert({
          job_id: jobId,
          item_no: '',
          description: '',
          unit: 'No',
          quantity: 0,
          level_type: 'item',
          sort_order: boqItems.length
        })
        .select()
        .single();

      if (error) throw error;
      
      setBOQItems([...boqItems, castBOQItem(data)]);
      toast({
        title: 'Success',
        description: 'Item added successfully'
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to add item: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const handleUpdateItem = async (id: string, updates: Partial<BOQItem>) => {
    try {
      const { error } = await supabase
        .from('boq_items')
        .update(updates)
        .eq('id', id);

      if (error) throw error;

      setBOQItems(items => items.map(item => 
        item.id === id ? { ...item, ...updates } : item
      ));
      
      toast({
        title: 'Success',
        description: 'Item updated successfully'
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to update item: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const handleDeleteItem = async () => {
    const selectedIds = Array.from(selectedRows);
    if (selectedIds.length === 0) return;

    try {
      const { error } = await supabase
        .from('boq_items')
        .delete()
        .in('id', selectedIds);

      if (error) throw error;

      setBOQItems(items => items.filter(item => !selectedIds.includes(item.id)));
      setSelectedRows(new Set());
      
      toast({
        title: 'Success',
        description: `${selectedIds.length} item(s) deleted successfully`
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to delete items: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const deleteItems = async (ids: string[]) => {
    try {
      const { error } = await supabase
        .from('boq_items')
        .delete()
        .in('id', ids);

      if (error) throw error;

      setBOQItems(items => items.filter(item => !ids.includes(item.id)));
      
      toast({
        title: 'Success',
        description: `${ids.length} item(s) deleted successfully`
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to delete items: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const importFromCSV = async (file: File) => {
    // TODO: Implement CSV import
    console.log('Import from CSV:', file);
  };

  const exportToCSV = () => {
    // TODO: Implement CSV export
    console.log('Export to CSV');
  };

  const refreshData = async () => {
    if (!jobId) return;

    try {
      const { data, error } = await supabase
        .from('boq_items')
        .select('*')
        .eq('job_id', jobId)
        .order('sort_order');

      if (error) throw error;
      
      const typedItems = (data || []).map(castBOQItem);
      setBOQItems(typedItems);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to refresh data: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const toggleDivision = (division: string) => {
    setExpandedDivisions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(division)) {
        newSet.delete(division);
      } else {
        newSet.add(division);
      }
      return newSet;
    });
  };

  const calculateTotals = () => {
    const total = boqItems.reduce((sum, item) => {
      if (item.level_type === 'item' && typeof item.quantity === 'number') {
        return sum + item.quantity;
      }
      return sum;
    }, 0);
    
    toast({
      title: 'Total Calculation',
      description: `Total quantity: ${total.toLocaleString()}`
    });
  };

  const totals = {
    totalAmount: boqItems.reduce((sum, item) => sum + (item.amount || 0), 0),
    totalQuantity: boqItems.reduce((sum, item) => sum + (item.quantity || 0), 0),
    itemCount: boqItems.length
  };

  return {
    boqItems,
    isLoading,
    searchTerm,
    setSearchTerm,
    selectedRows,
    setSelectedRows,
    handleAddItem,
    handleUpdateItem,
    handleDeleteItem,
    deleteItems,
    importFromCSV,
    exportToCSV,
    refreshData,
    expandedDivisions,
    toggleDivision,
    calculateTotals,
    totals
  };
}
