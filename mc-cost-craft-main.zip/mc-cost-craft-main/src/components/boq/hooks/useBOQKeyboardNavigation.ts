
import { useCallback, useEffect } from 'react';
import { BOQItem } from '@/types/mccost';

interface UseBOQKeyboardNavigationProps {
  visibleItems: BOQItem[];
  editingCell: { rowId: string; field: keyof BOQItem } | null;
  setEditingCell: (cell: { rowId: string; field: keyof BOQItem } | null) => void;
  onCellSave: (itemId: string, field: keyof BOQItem, value: any) => void;
  selectedCells: Set<string>;
  clearCellSelection: () => void;
  onDeleteItems: (ids: string[]) => void;
  selectedRows: Set<string>;
}

const EDITABLE_FIELDS: (keyof BOQItem)[] = [
  'level_type', 'page_number', 'item_no', 'price_code', 'description', 'unit', 'quantity'
];

export function useBOQKeyboardNavigation({
  visibleItems,
  editingCell,
  setEditingCell,
  onCellSave,
  selectedCells,
  clearCellSelection,
  onDeleteItems,
  selectedRows
}: UseBOQKeyboardNavigationProps) {

  const navigateCell = useCallback((direction: 'up' | 'down' | 'left' | 'right') => {
    if (!editingCell) return;

    const currentRowIndex = visibleItems.findIndex(item => item.id === editingCell.rowId);
    const currentFieldIndex = EDITABLE_FIELDS.indexOf(editingCell.field);

    if (currentRowIndex === -1 || currentFieldIndex === -1) return;

    let newRowIndex = currentRowIndex;
    let newFieldIndex = currentFieldIndex;

    switch (direction) {
      case 'up':
        newRowIndex = Math.max(0, currentRowIndex - 1);
        break;
      case 'down':
        newRowIndex = Math.min(visibleItems.length - 1, currentRowIndex + 1);
        break;
      case 'left':
        newFieldIndex = Math.max(0, currentFieldIndex - 1);
        break;
      case 'right':
        newFieldIndex = Math.min(EDITABLE_FIELDS.length - 1, currentFieldIndex + 1);
        break;
    }

    const newItem = visibleItems[newRowIndex];
    const newField = EDITABLE_FIELDS[newFieldIndex];

    if (newItem && newField) {
      setEditingCell({ rowId: newItem.id, field: newField });
    }
  }, [editingCell, visibleItems, setEditingCell]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Handle Delete key for selected rows
    if (e.key === 'Delete' && selectedRows.size > 0 && !editingCell) {
      e.preventDefault();
      onDeleteItems(Array.from(selectedRows));
      return;
    }

    // Handle Escape key
    if (e.key === 'Escape') {
      if (editingCell) {
        setEditingCell(null);
      }
      if (selectedCells.size > 0) {
        clearCellSelection();
      }
      return;
    }

    // Handle arrow navigation when editing
    if (editingCell && !e.ctrlKey && !e.shiftKey) {
      switch (e.key) {
        case 'ArrowUp':
          e.preventDefault();
          navigateCell('up');
          break;
        case 'ArrowDown':
          e.preventDefault();
          navigateCell('down');
          break;
        case 'ArrowLeft':
          if (e.target instanceof HTMLInputElement && e.target.selectionStart === 0) {
            e.preventDefault();
            navigateCell('left');
          }
          break;
        case 'ArrowRight':
          if (e.target instanceof HTMLInputElement && e.target.selectionStart === e.target.value.length) {
            e.preventDefault();
            navigateCell('right');
          }
          break;
        case 'Tab':
          e.preventDefault();
          if (e.shiftKey) {
            navigateCell('left');
          } else {
            navigateCell('right');
          }
          break;
      }
    }
  }, [editingCell, selectedRows, selectedCells, navigateCell, setEditingCell, clearCellSelection, onDeleteItems]);

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  return {
    navigateCell
  };
}
