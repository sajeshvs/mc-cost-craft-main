
import { useState, useMemo } from 'react';
import { BOQItem } from '@/types/mccost';

interface BOQFilters {
  page: string;
  itemNo: string;
  tradeCode: string;
  priceCode: string;
  description: string;
  showUnpriced: boolean;
}

export function useBOQSelection(items: BOQItem[] = []) {
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [editingCell, setEditingCell] = useState<{ rowId: string; field: keyof BOQItem } | null>(null);
  const [filters, setFilters] = useState<BOQFilters>({
    page: '',
    itemNo: '',
    tradeCode: '',
    priceCode: '',
    description: '',
    showUnpriced: false
  });

  const filteredItems = useMemo(() => {
    return items.filter(item => {
      // Page filter
      if (filters.page && !String(item.page_number || '').toLowerCase().includes(filters.page.toLowerCase())) {
        return false;
      }
      
      // Item No filter
      if (filters.itemNo && !String(item.item_no || '').toLowerCase().includes(filters.itemNo.toLowerCase())) {
        return false;
      }
      
      // Trade Code filter (using price_code field for now as trade code is stored there)
      if (filters.tradeCode && !String(item.price_code || '').toLowerCase().includes(filters.tradeCode.toLowerCase())) {
        return false;
      }
      
      // Price Code filter
      if (filters.priceCode && !String(item.price_code || '').toLowerCase().includes(filters.priceCode.toLowerCase())) {
        return false;
      }
      
      // Description filter
      if (filters.description && !String(item.description || '').toLowerCase().includes(filters.description.toLowerCase())) {
        return false;
      }
      
      // Unpriced items filter
      if (filters.showUnpriced && (item.net_rate || 0) > 0) {
        return false;
      }
      
      return true;
    });
  }, [items, filters]);

  const handleRowSelect = (rowId: string, isShiftClick = false) => {
    setSelectedRows(prev => {
      const newSet = new Set(prev);
      
      if (isShiftClick && prev.size > 0) {
        // Handle shift selection logic here if needed
        const lastSelected = Array.from(prev)[prev.size - 1];
        const currentIndex = filteredItems.findIndex(item => item.id === rowId);
        const lastIndex = filteredItems.findIndex(item => item.id === lastSelected);
        
        if (currentIndex !== -1 && lastIndex !== -1) {
          const start = Math.min(currentIndex, lastIndex);
          const end = Math.max(currentIndex, lastIndex);
          
          for (let i = start; i <= end; i++) {
            newSet.add(filteredItems[i].id);
          }
        }
      } else {
        if (newSet.has(rowId)) {
          newSet.delete(rowId);
        } else {
          newSet.add(rowId);
        }
      }
      
      return newSet;
    });
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedRows(new Set(filteredItems.map(item => item.id)));
    } else {
      setSelectedRows(new Set());
    }
  };

  const clearSelection = () => {
    setSelectedRows(new Set());
  };

  const updateFilter = (key: string, value: string | boolean) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      page: '',
      itemNo: '',
      tradeCode: '',
      priceCode: '',
      description: '',
      showUnpriced: false
    });
  };

  return {
    selectedRows,
    editingCell,
    setEditingCell,
    handleRowSelect,
    handleSelectAll,
    clearSelection,
    filteredItems,
    filters,
    updateFilter,
    clearFilters
  };
}
