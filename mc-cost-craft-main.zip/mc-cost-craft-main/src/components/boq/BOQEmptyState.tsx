
import { Button } from '@/components/ui/button';
import { BookOpen, Plus } from 'lucide-react';

interface BOQEmptyStateProps {
  onImportBOQ: () => void;
}

export function BOQEmptyState({ onImportBOQ }: BOQEmptyStateProps) {
  return (
    <div className="text-center py-8">
      <BookOpen className="mx-auto h-12 w-12 text-gray-400 mb-4" />
      <p className="text-gray-500 mb-4">No BOQ items found</p>
      <Button onClick={onImportBOQ}>
        <Plus className="mr-2 h-4 w-4" />
        Import BOQ Items
      </Button>
    </div>
  );
}
