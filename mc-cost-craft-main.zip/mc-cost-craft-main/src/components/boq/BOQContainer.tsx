
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { BOQViewer } from './BOQViewer';
import { TradesWindow } from '@/components/trades/TradesWindow';
import { ResourcesWindow } from '@/components/resources/ResourcesWindow';
import { PriceListWindow } from '@/components/price-list/PriceListWindow';
import { AnalysisWindow } from '@/components/analysis/AnalysisWindow';
import { AdjudicatorWindow } from '@/components/adjudicator/AdjudicatorWindow';
import { MarkupWindow } from '@/components/markup/MarkupWindow';
import { TradeSummaryWindow } from '@/components/trade-summary/TradeSummaryWindow';
import { useBOQData } from '@/hooks/useBOQData';
import { useToast } from '@/hooks/use-toast';

export function BOQContainer() {
  const { jobId } = useParams<{ jobId: string }>();
  const { toast } = useToast();
  const [projectId, setProjectId] = useState<string>('');
  
  // Window states
  const [tradesWindowOpen, setTradesWindowOpen] = useState(false);
  const [resourcesWindowOpen, setResourcesWindowOpen] = useState(false);
  const [priceListWindowOpen, setPriceListWindowOpen] = useState(false);
  const [analysisWindowOpen, setAnalysisWindowOpen] = useState(false);
  const [adjudicatorWindowOpen, setAdjudicatorWindowOpen] = useState(false);
  const [markupWindowOpen, setMarkupWindowOpen] = useState(false);
  const [tradeSummaryWindowOpen, setTradeSummaryWindowOpen] = useState(false);

  // Get project ID from job data
  useEffect(() => {
    if (jobId) {
      // For now, we'll use jobId as projectId since they're the same in this context
      setProjectId(jobId);
    }
  }, [jobId]);

  if (!jobId) {
    return <div>Loading...</div>;
  }

  return (
    <div className="h-full flex flex-col">
      <BOQViewer 
        jobId={jobId}
        onOpenTrades={() => setTradesWindowOpen(true)}
        onOpenResources={() => setResourcesWindowOpen(true)}
        onOpenPriceList={() => setPriceListWindowOpen(true)}
        onOpenAnalysis={() => setAnalysisWindowOpen(true)}
        onOpenAdjudicator={() => setAdjudicatorWindowOpen(true)}
        onOpenMarkup={() => setMarkupWindowOpen(true)}
        onOpenTradeSummary={() => setTradeSummaryWindowOpen(true)}
      />

      {/* Module Windows */}
      {tradesWindowOpen && (
        <TradesWindow
          projectId={projectId}
          open={tradesWindowOpen}
          onOpenChange={() => setTradesWindowOpen(false)}
        />
      )}

      {resourcesWindowOpen && (
        <ResourcesWindow
          projectId={projectId}
          onClose={() => setResourcesWindowOpen(false)}
        />
      )}

      {priceListWindowOpen && (
        <PriceListWindow
          projectId={projectId}
          onClose={() => setPriceListWindowOpen(false)}
        />
      )}

      {analysisWindowOpen && (
        <AnalysisWindow
          projectId={projectId}
          onClose={() => setAnalysisWindowOpen(false)}
        />
      )}

      {adjudicatorWindowOpen && (
        <AdjudicatorWindow
          projectId={projectId}
          onClose={() => setAdjudicatorWindowOpen(false)}
        />
      )}

      {markupWindowOpen && (
        <MarkupWindow
          projectId={projectId}
          onClose={() => setMarkupWindowOpen(false)}
        />
      )}

      {tradeSummaryWindowOpen && (
        <TradeSummaryWindow
          projectId={projectId}
          jobId={jobId}
          isOpen={tradeSummaryWindowOpen}
          onClose={() => setTradeSummaryWindowOpen(false)}
        />
      )}
    </div>
  );
}
