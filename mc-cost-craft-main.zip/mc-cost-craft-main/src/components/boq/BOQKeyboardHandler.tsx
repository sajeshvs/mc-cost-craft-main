
import { useEffect } from 'react';
import { BOQItem } from '@/types/mccost';

interface BOQKeyboardHandlerProps {
  editingCell: { rowId: string; field: keyof BOQItem } | null;
  selectedRows: Set<string>;
  handleDeleteSelected: () => void;
  handleInsertRow: (position: 'above' | 'below' | 'beginning' | 'end') => void;
  handleDuplicateSelected: () => void;
  clearSelection: () => void;
  handleCopy: () => void;
  handlePaste: () => void;
  canPaste: boolean;
}

export function BOQKeyboardHandler({
  editingCell,
  selectedRows,
  handleDeleteSelected,
  handleInsertRow,
  handleDuplicateSelected,
  clearSelection,
  handleCopy,
  handlePaste,
  canPaste
}: BOQKeyboardHandlerProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (editingCell) return;

      if (e.key === 'Delete' && selectedRows.size > 0) {
        e.preventDefault();
        handleDeleteSelected();
      } else if (e.key === 'Insert' || (e.ctrlKey && e.key === 'n')) {
        e.preventDefault();
        handleInsertRow('end');
      } else if (e.ctrlKey && e.key === 'd' && selectedRows.size > 0) {
        e.preventDefault();
        handleDuplicateSelected();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        clearSelection();
        (document.activeElement as HTMLElement)?.blur();
      } else if (e.ctrlKey && e.key === 'c' && selectedRows.size > 0) {
        e.preventDefault();
        handleCopy();
      } else if (e.ctrlKey && e.key === 'v' && canPaste) {
        e.preventDefault();
        handlePaste();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [selectedRows, editingCell, handleDeleteSelected, handleInsertRow, handleDuplicateSelected, clearSelection, handleCopy, handlePaste, canPaste]);

  return null; // This component only handles side effects
}
