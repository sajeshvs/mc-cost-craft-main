
import { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { BOQItem } from '@/types/mccost';

interface SmartLevelInputProps {
  value: BOQItem['level_type'];
  onChange: (value: BOQItem['level_type']) => void;
  onKeyDown?: (e: React.KeyboardEvent) => void;
  className?: string;
}

export function SmartLevelInput({ value, onChange, onKeyDown, className = "" }: SmartLevelInputProps) {
  const [inputValue, setInputValue] = useState(getDisplayValue(value));
  const inputRef = useRef<HTMLInputElement>(null);

  function getDisplayValue(levelType: BOQItem['level_type']): string {
    if (levelType === 'comment') return 'c';
    if (levelType === 'item') return '';
    if (levelType.startsWith('level_')) {
      return levelType.split('_')[1];
    }
    return '';
  }

  function parseLevelType(input: string): BOQItem['level_type'] {
    const trimmed = input.toLowerCase().trim();
    
    if (trimmed === 'c' || trimmed === 'comment') {
      return 'comment';
    }
    
    const num = parseInt(trimmed);
    if (!isNaN(num) && num >= 1 && num <= 9) {
      return `level_${num}` as BOQItem['level_type'];
    }
    
    return 'item';
  }

  useEffect(() => {
    setInputValue(getDisplayValue(value));
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setInputValue(newValue);
    
    // Auto-convert on each keystroke for immediate feedback
    const levelType = parseLevelType(newValue);
    onChange(levelType);
  };

  const handleBlur = () => {
    // Ensure display value matches the parsed level type
    setInputValue(getDisplayValue(value));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Prevent default arrow key behavior for number inputs
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault();
    }
    
    onKeyDown?.(e);
  };

  return (
    <Input
      ref={inputRef}
      value={inputValue}
      onChange={handleChange}
      onBlur={handleBlur}
      onKeyDown={handleKeyDown}
      className={`text-center font-mono ${className}`}
      placeholder="1-9,c"
      maxLength={1}
    />
  );
}
