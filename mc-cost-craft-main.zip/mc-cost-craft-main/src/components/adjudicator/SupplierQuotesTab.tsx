
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Download, Trash2, Check, Upload, FileDown, Lock, RefreshCw, Percent, Filter } from 'lucide-react';
import { useAdjudicationEntries } from './hooks/useAdjudicationEntries';
import { AdjudicationPackage, VendorColumn } from './types/adjudicator';
import { useToast } from '@/hooks/use-toast';

interface SupplierQuotesTabProps {
  packageData: AdjudicationPackage;
}

export function SupplierQuotesTab({ packageData }: SupplierQuotesTabProps) {
  const [vendorColumns, setVendorColumns] = useState<VendorColumn[]>([
    { id: '1', name: 'Supplier A', currency: 'USD', exchange_rate: 1 }
  ]);
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [divisionFilter, setDivisionFilter] = useState('all');
  const [usedInBOQFilter, setUsedInBOQFilter] = useState('all');
  const [bulkDiscount, setBulkDiscount] = useState('');
  const [bulkFactor, setBulkFactor] = useState('');
  const { toast } = useToast();
  
  const {
    entries,
    quotes,
    isLoading,
    createQuote,
    updateQuote,
    selectQuote,
    applyQuote,
    importFromResources
  } = useAdjudicationEntries(packageData.id);

  const handleImportFromResources = () => {
    if (packageData.trade_code) {
      importFromResources(packageData.trade_code);
    }
  };

  const addVendorColumn = () => {
    const newVendor: VendorColumn = {
      id: Date.now().toString(),
      name: `Supplier ${String.fromCharCode(65 + vendorColumns.length)}`,
      currency: 'USD',
      exchange_rate: 1
    };
    setVendorColumns([...vendorColumns, newVendor]);
  };

  const removeVendorColumn = (vendorId: string) => {
    setVendorColumns(vendorColumns.filter(v => v.id !== vendorId));
  };

  const updateVendorColumn = (vendorId: string, updates: Partial<VendorColumn>) => {
    setVendorColumns(vendorColumns.map(v => 
      v.id === vendorId ? { ...v, ...updates } : v
    ));
  };

  const getQuoteForEntryAndVendor = (entryId: string, vendorName: string) => {
    return quotes.find(q => q.entry_id === entryId && q.vendor_name === vendorName);
  };

  const handleQuoteChange = async (entryId: string, vendorName: string, field: string, value: any) => {
    const existingQuote = getQuoteForEntryAndVendor(entryId, vendorName);
    const entry = entries.find(e => e.id === entryId);
    
    if (!entry) return;

    const vendor = vendorColumns.find(v => v.name === vendorName);
    if (!vendor) return;

    let updateData: any = { [field]: value };
    
    // Calculate final rate and amount
    const quotedRate = field === 'quoted_rate' ? value : (existingQuote?.quoted_rate || 0);
    const discountPercent = field === 'discount_percent' ? value : (existingQuote?.discount_percent || 0);
    const factor = field === 'factor' ? value : (existingQuote?.factor || 1);
    const exchangeRate = vendor.exchange_rate;
    
    const finalRate = quotedRate * exchangeRate * (1 - discountPercent / 100) * factor;
    const amount = finalRate * entry.quantity;
    
    updateData.final_rate = finalRate;
    updateData.amount = amount;

    if (existingQuote) {
      await updateQuote(existingQuote.id, updateData);
    } else {
      await createQuote({
        entry_id: entryId,
        vendor_name: vendorName,
        currency: vendor.currency,
        exchange_rate: vendor.exchange_rate,
        quoted_rate: quotedRate,
        discount_percent: discountPercent,
        factor: factor,
        final_rate: finalRate,
        amount: amount,
        is_selected: false
      });
    }
  };

  const handleSelectQuote = (entryId: string, quoteId: string) => {
    selectQuote(entryId, quoteId);
  };

  const handleApplyQuote = (entryId: string, quoteId: string) => {
    applyQuote(entryId, quoteId);
  };

  const handleBulkDiscount = () => {
    if (!bulkDiscount) return;
    const discount = parseFloat(bulkDiscount);
    entries.forEach(entry => {
      vendorColumns.forEach(vendor => {
        const quote = getQuoteForEntryAndVendor(entry.id, vendor.name);
        if (quote && quote.quoted_rate > 0) {
          handleQuoteChange(entry.id, vendor.name, 'discount_percent', discount);
        }
      });
    });
    setBulkDiscount('');
    toast({
      title: 'Bulk Discount Applied',
      description: `Applied ${discount}% discount to all quotes`,
    });
  };

  const handleBulkFactor = () => {
    if (!bulkFactor) return;
    const factor = parseFloat(bulkFactor);
    entries.forEach(entry => {
      vendorColumns.forEach(vendor => {
        const quote = getQuoteForEntryAndVendor(entry.id, vendor.name);
        if (quote && quote.quoted_rate > 0) {
          handleQuoteChange(entry.id, vendor.name, 'factor', factor);
        }
      });
    });
    setBulkFactor('');
    toast({
      title: 'Bulk Factor Applied',
      description: `Applied factor ${factor} to all quotes`,
    });
  };

  const getLowestQuote = (entryId: string) => {
    const entryQuotes = quotes.filter(q => q.entry_id === entryId && q.final_rate > 0);
    if (entryQuotes.length === 0) return null;
    return entryQuotes.reduce((min, quote) => 
      quote.final_rate < min.final_rate ? quote : min
    );
  };

  const getVendorTotal = (vendorName: string) => {
    return quotes
      .filter(q => q.vendor_name === vendorName)
      .reduce((total, q) => total + q.amount, 0);
  };

  const exportToExcel = () => {
    toast({
      title: 'Export to Excel',
      description: 'Exporting supplier comparison table to Excel...',
    });
  };

  const importQuotes = () => {
    toast({
      title: 'Import Quotes',
      description: 'Supplier quote import functionality will be implemented',
    });
  };

  // Get unique categories and divisions for filtering
  const categories = [...new Set(entries.map(entry => entry.trade_code).filter(Boolean))];
  const divisions = [...new Set(entries.map(entry => entry.trade_code?.substring(0, 2)).filter(Boolean))];

  const filteredEntries = entries.filter(entry => {
    const matchesCategory = categoryFilter === 'all' || entry.trade_code === categoryFilter;
    const matchesDivision = divisionFilter === 'all' || entry.trade_code?.substring(0, 2) === divisionFilter;
    const matchesUsedInBOQ = usedInBOQFilter === 'all' || 
      (usedInBOQFilter === 'yes' && entry.quantity > 0) ||
      (usedInBOQFilter === 'no' && entry.quantity === 0);
    return matchesCategory && matchesDivision && matchesUsedInBOQ;
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading resource entries...</div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Enhanced Toolbar */}
      <div className="flex items-center justify-between gap-2 p-3 border-b bg-gray-50">
        <div className="flex items-center gap-2">
          <Button size="sm" onClick={handleImportFromResources}>
            <Download className="h-4 w-4 mr-1" />
            Import from Resources
          </Button>
          <Button size="sm" variant="outline" onClick={addVendorColumn}>
            <Plus className="h-4 w-4 mr-1" />
            Add Supplier
          </Button>
          <Button size="sm" variant="outline" onClick={importQuotes}>
            <Upload className="h-4 w-4 mr-1" />
            Import Quotes
          </Button>
          <Button size="sm" variant="outline" onClick={exportToExcel}>
            <FileDown className="h-4 w-4 mr-1" />
            Export to Excel
          </Button>
        </div>
        
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <Input
              placeholder="Discount %"
              value={bulkDiscount}
              onChange={(e) => setBulkDiscount(e.target.value)}
              className="w-20 h-8"
              type="number"
            />
            <Button size="sm" onClick={handleBulkDiscount}>
              <Percent className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex items-center gap-1">
            <Input
              placeholder="Factor"
              value={bulkFactor}
              onChange={(e) => setBulkFactor(e.target.value)}
              className="w-20 h-8"
              type="number"
              step="0.01"
            />
            <Button size="sm" onClick={handleBulkFactor}>
              Apply Factor
            </Button>
          </div>
          <Button size="sm" variant="outline">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Resource Filters */}
      <div className="flex items-center gap-4 p-3 border-b bg-gray-25">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <span className="text-sm font-medium">Filters:</span>
        </div>
        
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-32 h-8">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map(cat => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={divisionFilter} onValueChange={setDivisionFilter}>
          <SelectTrigger className="w-32 h-8">
            <SelectValue placeholder="Division" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Divisions</SelectItem>
            {divisions.map(div => (
              <SelectItem key={div} value={div}>{div}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={usedInBOQFilter} onValueChange={setUsedInBOQFilter}>
          <SelectTrigger className="w-32 h-8">
            <SelectValue placeholder="Used in BOQ" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Items</SelectItem>
            <SelectItem value="yes">Used in BOQ</SelectItem>
            <SelectItem value="no">Not Used</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Enhanced Table */}
      <ScrollArea className="flex-1">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">Select</TableHead>
              <TableHead className="w-32">Resource Code</TableHead>
              <TableHead className="min-w-[200px]">Description</TableHead>
              <TableHead className="w-24">Category</TableHead>
              <TableHead className="w-24">Division</TableHead>
              <TableHead className="w-16">Unit</TableHead>
              <TableHead className="w-24">Used Quantity</TableHead>
              <TableHead className="w-24">Offer Rate (R)</TableHead>
              
              {vendorColumns.map(vendor => (
                <TableHead key={vendor.id} className="text-center border-l min-w-[180px]">
                  <div className="space-y-1">
                    <Input
                      value={vendor.name}
                      onChange={(e) => updateVendorColumn(vendor.id, { name: e.target.value })}
                      className="h-6 text-xs text-center font-medium"
                    />
                    <div className="flex items-center gap-1 justify-center">
                      <Select
                        value={vendor.currency}
                        onValueChange={(value) => updateVendorColumn(vendor.id, { currency: value })}
                      >
                        <SelectTrigger className="h-6 w-16 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="USD">USD</SelectItem>
                          <SelectItem value="EUR">EUR</SelectItem>
                          <SelectItem value="GBP">GBP</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input
                        type="number"
                        value={vendor.exchange_rate}
                        onChange={(e) => updateVendorColumn(vendor.id, { exchange_rate: parseFloat(e.target.value) || 1 })}
                        className="h-6 text-xs w-16"
                        step="0.01"
                        placeholder="FX"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeVendorColumn(vendor.id)}
                        className="h-6 w-6 p-0"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </TableHead>
              ))}
              
              <TableHead className="w-24">Status</TableHead>
              <TableHead className="w-24">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredEntries.map((entry) => {
              const lowestQuote = getLowestQuote(entry.id);
              return (
                <TableRow key={entry.id}>
                  <TableCell>
                    <input type="checkbox" className="rounded" />
                  </TableCell>
                  <TableCell className="font-mono text-sm">{entry.source_id.slice(0, 8)}</TableCell>
                  <TableCell className="max-w-[200px]">
                    <div className="truncate" title={entry.description}>
                      {entry.description}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{entry.trade_code}</Badge>
                  </TableCell>
                  <TableCell>{entry.trade_code?.substring(0, 2)}</TableCell>
                  <TableCell>{entry.unit}</TableCell>
                  <TableCell className={entry.quantity > 0 ? 'text-green-600 font-medium' : 'text-gray-400'}>
                    {entry.quantity.toLocaleString()}
                  </TableCell>
                  <TableCell>${entry.base_rate.toFixed(2)}</TableCell>
                  
                  {vendorColumns.map(vendor => {
                    const quote = getQuoteForEntryAndVendor(entry.id, vendor.name);
                    const isLowest = lowestQuote && quote && quote.id === lowestQuote.id;
                    return (
                      <TableCell key={vendor.id} className={`border-l ${isLowest ? 'bg-green-50' : ''}`}>
                        <div className="space-y-1">
                          <Input
                            type="number"
                            value={quote?.quoted_rate || ''}
                            onChange={(e) => handleQuoteChange(entry.id, vendor.name, 'quoted_rate', parseFloat(e.target.value) || 0)}
                            placeholder="Quote Rate"
                            className="h-6 text-xs"
                            step="0.01"
                          />
                          <Input
                            type="number"
                            value={quote?.discount_percent || ''}
                            onChange={(e) => handleQuoteChange(entry.id, vendor.name, 'discount_percent', parseFloat(e.target.value) || 0)}
                            placeholder="Discount %"
                            className="h-6 text-xs"
                            step="0.1"
                          />
                          <Input
                            type="number"
                            value={quote?.factor || 1}
                            onChange={(e) => handleQuoteChange(entry.id, vendor.name, 'factor', parseFloat(e.target.value) || 1)}
                            placeholder="Factor"
                            className="h-6 text-xs"
                            step="0.01"
                          />
                          <div className={`text-xs font-medium text-center p-1 rounded ${isLowest ? 'bg-green-100 text-green-800' : ''}`}>
                            ${(quote?.final_rate || 0).toFixed(2)}
                          </div>
                          <div className="text-xs text-gray-500 text-center">
                            ${(quote?.amount || 0).toFixed(2)}
                          </div>
                        </div>
                      </TableCell>
                    );
                  })}
                  
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      {quotes
                        .filter(q => q.entry_id === entry.id)
                        .map(quote => (
                          <Button
                            key={quote.id}
                            variant={quote.is_selected ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleSelectQuote(entry.id, quote.id)}
                            className="h-6 text-xs"
                          >
                            {quote.is_selected ? <Check className="h-3 w-3" /> : quote.vendor_name.slice(0, 3)}
                          </Button>
                        ))}
                    </div>
                  </TableCell>
                  
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      {quotes
                        .filter(q => q.entry_id === entry.id && q.is_selected)
                        .map(quote => (
                          <Button
                            key={quote.id}
                            size="sm"
                            onClick={() => handleApplyQuote(entry.id, quote.id)}
                            disabled={!!quote.applied_at}
                            className="h-6 text-xs"
                          >
                            {quote.applied_at ? (
                              <>
                                <Lock className="h-3 w-3 mr-1" />
                                Applied
                              </>
                            ) : (
                              'Apply to R'
                            )}
                          </Button>
                        ))}
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
            
            {filteredEntries.length === 0 && (
              <TableRow>
                <TableCell colSpan={8 + vendorColumns.length + 2} className="text-center py-8">
                  No resource entries found. 
                  <Button variant="link" onClick={handleImportFromResources}>
                    Import from Resources
                  </Button>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ScrollArea>

      {/* Enhanced Totals Footer */}
      {filteredEntries.length > 0 && (
        <div className="border-t p-3 bg-gray-50">
          <div className="flex items-center justify-between">
            <div className="text-sm">
              <span className="font-medium">Resources: {filteredEntries.length}</span>
              <span className="ml-4 text-gray-600">Used in BOQ: {filteredEntries.filter(e => e.quantity > 0).length}</span>
            </div>
            <div className="flex items-center gap-4">
              {vendorColumns.map(vendor => {
                const total = getVendorTotal(vendor.name);
                const lowestTotal = Math.min(...vendorColumns.map(v => getVendorTotal(v.name)));
                const isLowest = total === lowestTotal && total > 0;
                return (
                  <div key={vendor.id} className={`text-sm ${isLowest ? 'font-bold text-green-600' : ''}`}>
                    <span className="font-medium">{vendor.name}:</span> 
                    <span className="ml-1">${total.toFixed(2)}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
