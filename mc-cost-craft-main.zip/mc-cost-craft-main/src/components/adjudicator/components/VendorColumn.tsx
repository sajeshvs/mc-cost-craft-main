
import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2 } from 'lucide-react';
import { VendorColumn as VendorColumnType } from '../types/adjudicator';

interface VendorColumnProps {
  vendor: VendorColumnType;
  onUpdate: (updates: Partial<VendorColumnType>) => void;
  onRemove: () => void;
  canRemove: boolean;
}

export function VendorColumn({ vendor, onUpdate, onRemove, canRemove }: VendorColumnProps) {
  return (
    <div className="space-y-1">
      <Input
        value={vendor.name}
        onChange={(e) => onUpdate({ name: e.target.value })}
        className="h-6 text-xs text-center font-medium"
        placeholder="Vendor Name"
      />
      <div className="flex items-center gap-1 justify-center">
        <Select
          value={vendor.currency}
          onValueChange={(value) => onUpdate({ currency: value })}
        >
          <SelectTrigger className="h-6 w-16 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="USD">USD</SelectItem>
            <SelectItem value="EUR">EUR</SelectItem>
            <SelectItem value="GBP">GBP</SelectItem>
            <SelectItem value="CAD">CAD</SelectItem>
            <SelectItem value="AUD">AUD</SelectItem>
            <SelectItem value="JPY">JPY</SelectItem>
            <SelectItem value="CNY">CNY</SelectItem>
            <SelectItem value="INR">INR</SelectItem>
          </SelectContent>
        </Select>
        <Input
          type="number"
          value={vendor.exchange_rate}
          onChange={(e) => onUpdate({ exchange_rate: parseFloat(e.target.value) || 1 })}
          className="h-6 text-xs w-16"
          step="0.001"
          placeholder="FX Rate"
          title="Exchange Rate to Base Currency"
        />
        {canRemove && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onRemove}
            className="h-6 w-6 p-0 hover:bg-red-100"
            title="Remove Vendor"
          >
            <Trash2 className="h-3 w-3 text-red-500" />
          </Button>
        )}
      </div>
    </div>
  );
}
