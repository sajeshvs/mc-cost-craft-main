
import React from 'react';
import { Input } from '@/components/ui/input';
import { AdjudicationQuote } from '../types/adjudicator';

interface QuoteCellProps {
  quote?: AdjudicationQuote;
  isLowest?: boolean;
  onQuoteChange: (field: string, value: any) => void;
  currency: string;
}

export function QuoteCell({ quote, isLowest, onQuoteChange, currency }: QuoteCellProps) {
  return (
    <div className={`space-y-1 ${isLowest ? 'bg-green-50' : ''}`}>
      <Input
        type="number"
        value={quote?.quoted_rate || ''}
        onChange={(e) => onQuoteChange('quoted_rate', parseFloat(e.target.value) || 0)}
        placeholder="Quote Rate"
        className="h-6 text-xs text-right"
        step="0.01"
      />
      <Input
        type="number"
        value={quote?.discount_percent || ''}
        onChange={(e) => onQuoteChange('discount_percent', parseFloat(e.target.value) || 0)}
        placeholder="Discount %"
        className="h-6 text-xs text-right"
        step="0.1"
        max="100"
      />
      <Input
        type="number"
        value={quote?.factor || 1}
        onChange={(e) => onQuoteChange('factor', parseFloat(e.target.value) || 1)}
        placeholder="Factor"
        className="h-6 text-xs text-right"
        step="0.01"
      />
      <div className={`text-xs font-medium text-center p-1 rounded ${
        isLowest ? 'bg-green-100 text-green-800' : 'bg-gray-100'
      }`}>
        {currency} {(quote?.final_rate || 0).toFixed(2)}
      </div>
      <div className="text-xs text-gray-500 text-center">
        Total: {currency} {(quote?.amount || 0).toFixed(2)}
      </div>
    </div>
  );
}
