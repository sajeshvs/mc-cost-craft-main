
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AdjudicationPackage } from '../types/adjudicator';

interface NewPackageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreatePackage: (packageData: Omit<AdjudicationPackage, 'id' | 'created_at' | 'updated_at' | 'created_by' | 'user_id'>) => void;
}

export function NewPackageDialog({ open, onOpenChange, onCreatePackage }: NewPackageDialogProps) {
  const [formData, setFormData] = useState({
    name: '',
    type: 'subcontractor' as 'subcontractor' | 'supplier',
    trade_code: '',
    status: 'draft' as 'draft' | 'finalized'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    onCreatePackage({
      name: formData.name.trim(),
      type: formData.type,
      trade_code: formData.trade_code || null,
      status: formData.status,
      project_id: '' // Will be set by parent
    });

    // Reset form
    setFormData({
      name: '',
      type: 'subcontractor',
      trade_code: '',
      status: 'draft'
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create New Adjudication Package</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Package Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter package name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Type</Label>
            <Select 
              value={formData.type} 
              onValueChange={(value: 'subcontractor' | 'supplier') => 
                setFormData(prev => ({ ...prev, type: value }))
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="subcontractor">Subcontractor</SelectItem>
                <SelectItem value="supplier">Supplier</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="trade_code">Trade Code (Optional)</Label>
            <Input
              id="trade_code"
              value={formData.trade_code}
              onChange={(e) => setFormData(prev => ({ ...prev, trade_code: e.target.value }))}
              placeholder="Enter trade code"
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Create Package</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
