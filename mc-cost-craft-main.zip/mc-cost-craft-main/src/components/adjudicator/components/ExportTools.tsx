
import React from 'react';
import { Button } from '@/components/ui/button';
import { Download, FileDown, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { AdjudicationEntry, AdjudicationQuote, VendorColumn } from '../types/adjudicator';

interface ExportToolsProps {
  entries: AdjudicationEntry[];
  quotes: AdjudicationQuote[];
  vendors: VendorColumn[];
  packageName: string;
  onImportQuotes: () => void;
}

export function ExportTools({ entries, quotes, vendors, packageName, onImportQuotes }: ExportToolsProps) {
  const { toast } = useToast();

  const exportToExcel = () => {
    try {
      // Create CSV content
      const headers = [
        'Trade Code', 'Page', 'Item No', 'Description', 'Unit', 'Quantity', 'Base Rate',
        ...vendors.flatMap(v => [`${v.name} Quote`, `${v.name} Discount`, `${v.name} Factor`, `${v.name} Final`, `${v.name} Amount`]),
        'Selected Vendor', 'Status'
      ];

      const rows = entries.map(entry => {
        const selectedQuote = quotes.find(q => q.entry_id === entry.id && q.is_selected);
        const row = [
          entry.trade_code || '',
          entry.page_ref || '',
          entry.source_id.slice(0, 8),
          entry.description,
          entry.unit,
          entry.quantity.toString(),
          entry.base_rate.toFixed(2),
        ];

        // Add vendor quote data
        vendors.forEach(vendor => {
          const quote = quotes.find(q => q.entry_id === entry.id && q.vendor_name === vendor.name);
          row.push(
            quote?.quoted_rate?.toFixed(2) || '',
            quote?.discount_percent?.toFixed(1) || '',
            quote?.factor?.toFixed(2) || '',
            quote?.final_rate?.toFixed(2) || '',
            quote?.amount?.toFixed(2) || ''
          );
        });

        row.push(selectedQuote?.vendor_name || '');
        row.push(selectedQuote?.applied_at ? 'Applied' : 'Draft');

        return row;
      });

      const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${packageName}_comparison.csv`;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: 'Export Complete',
        description: 'Quote comparison exported to CSV file',
      });
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: 'Export Error',
        description: 'Failed to export data',
        variant: 'destructive'
      });
    }
  };

  const exportSummary = () => {
    try {
      const summary = vendors.map(vendor => {
        const vendorQuotes = quotes.filter(q => q.vendor_name === vendor.name);
        const total = vendorQuotes.reduce((sum, q) => sum + q.amount, 0);
        const selectedCount = vendorQuotes.filter(q => q.is_selected).length;
        
        return {
          vendor: vendor.name,
          currency: vendor.currency,
          total: total.toFixed(2),
          selectedItems: selectedCount,
          totalItems: vendorQuotes.length
        };
      });

      const csvContent = [
        ['Vendor', 'Currency', 'Total Amount', 'Selected Items', 'Total Items'],
        ...summary.map(s => [s.vendor, s.currency, s.total, s.selectedItems.toString(), s.totalItems.toString()])
      ].map(row => row.join(',')).join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${packageName}_summary.csv`;
      a.click();
      URL.revokeObjectURL(url);

      toast({
        title: 'Summary Export Complete',
        description: 'Vendor summary exported to CSV file',
      });
    } catch (error) {
      console.error('Summary export error:', error);
      toast({
        title: 'Export Error',
        description: 'Failed to export summary',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Button size="sm" variant="outline" onClick={onImportQuotes}>
        <Upload className="h-4 w-4 mr-1" />
        Import Quotes
      </Button>
      <Button size="sm" variant="outline" onClick={exportToExcel}>
        <FileDown className="h-4 w-4 mr-1" />
        Export Comparison
      </Button>
      <Button size="sm" variant="outline" onClick={exportSummary}>
        <Download className="h-4 w-4 mr-1" />
        Export Summary
      </Button>
    </div>
  );
}
