import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface SupplierQuote {
  id: string;
  project_id: string;
  resource_id: string;
  vendor_name: string;
  quote_value: number;
  discount_percent: number;
  factor: number;
  final_rate: number;
  selected: boolean;
  inserted_to_resources: boolean;
  created_at: string;
  updated_at: string;
}

export function useSupplierQuotes(projectId: string) {
  const [quotes, setQuotes] = useState<SupplierQuote[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  const loadQuotes = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('supplier_quotes')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setQuotes(data || []);
    } catch (error: any) {
      console.error('Error loading supplier quotes:', error);
      toast({
        title: 'Error',
        description: 'Failed to load supplier quotes: ' + error.message,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const createQuote = async (quoteData: Partial<SupplierQuote>) => {
    try {
      const finalRate = calculateFinalRate(
        quoteData.quote_value || 0,
        quoteData.discount_percent || 0,
        quoteData.factor || 1
      );

      const { data, error } = await supabase
        .from('supplier_quotes')
        .insert({
          project_id: projectId,
          resource_id: quoteData.resource_id || '',
          vendor_name: quoteData.vendor_name || '',
          quote_value: quoteData.quote_value || 0,
          discount_percent: quoteData.discount_percent || 0,
          factor: quoteData.factor || 1,
          final_rate: finalRate,
          selected: quoteData.selected || false,
          inserted_to_resources: quoteData.inserted_to_resources || false
        })
        .select()
        .single();

      if (error) throw error;
      
      setQuotes(prev => [data, ...prev]);
      toast({
        title: 'Success',
        description: 'Supplier quote created successfully'
      });
    } catch (error: any) {
      console.error('Error creating supplier quote:', error);
      toast({
        title: 'Error',
        description: 'Failed to create supplier quote: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const updateQuote = async (id: string, updates: Partial<SupplierQuote>) => {
    try {
      const currentQuote = quotes.find(q => q.id === id);
      if (!currentQuote) return;

      const finalRate = calculateFinalRate(
        updates.quote_value ?? currentQuote.quote_value,
        updates.discount_percent ?? currentQuote.discount_percent,
        updates.factor ?? currentQuote.factor
      );

      const { data, error } = await supabase
        .from('supplier_quotes')
        .update({ ...updates, final_rate: finalRate })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      
      setQuotes(prev => prev.map(q => q.id === id ? data : q));
    } catch (error: any) {
      console.error('Error updating supplier quote:', error);
      toast({
        title: 'Error',
        description: 'Failed to update supplier quote: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const deleteQuote = async (id: string) => {
    try {
      const { error } = await supabase
        .from('supplier_quotes')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setQuotes(prev => prev.filter(q => q.id !== id));
      toast({
        title: 'Success',
        description: 'Supplier quote deleted successfully'
      });
    } catch (error: any) {
      console.error('Error deleting supplier quote:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete supplier quote: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const applyQuoteToResource = async (quoteId: string) => {
    try {
      const quote = quotes.find(q => q.id === quoteId);
      if (!quote) return;

      const { error: resourceError } = await supabase
        .from('resources')
        .update({ rate: quote.final_rate })
        .eq('id', quote.resource_id);

      if (resourceError) throw resourceError;

      const { error: quoteError } = await supabase
        .from('supplier_quotes')
        .update({ inserted_to_resources: true })
        .eq('id', quoteId);

      if (quoteError) throw quoteError;

      setQuotes(prev => prev.map(q => 
        q.id === quoteId ? { ...q, inserted_to_resources: true } : q
      ));

      toast({
        title: 'Success',
        description: 'Quote applied to resource successfully'
      });
    } catch (error: any) {
      console.error('Error applying quote to resource:', error);
      toast({
        title: 'Error',
        description: 'Failed to apply quote to resource: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const refreshQuotes = async () => {
    await loadQuotes();
  };

  useEffect(() => {
    loadQuotes();
  }, [projectId]);

  return {
    quotes,
    isLoading,
    createQuote,
    updateQuote,
    deleteQuote,
    applyQuoteToResource,
    refreshQuotes
  };
}

function calculateFinalRate(quoteValue: number, discountPercent: number, factor: number): number {
  const afterDiscount = quoteValue * (1 - discountPercent / 100);
  return afterDiscount * factor;
}
