import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface SubcontractorQuote {
  id: string;
  project_id: string;
  boq_item_id: string;
  trade_code: string;
  price_code?: string;
  description: string;
  quantity: number;
  base_rate: number;
  quote_vendor: string;
  quote_value: number;
  discount_percent: number;
  factor: number;
  final_rate: number;
  selected: boolean;
  inserted_to_boq: boolean;
  created_at: string;
  updated_at: string;
}

export function useSubcontractorQuotes(projectId: string) {
  const [quotes, setQuotes] = useState<SubcontractorQuote[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  const loadQuotes = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('subcontractor_quotes')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setQuotes(data || []);
    } catch (error: any) {
      console.error('Error loading subcontractor quotes:', error);
      toast({
        title: 'Error',
        description: 'Failed to load subcontractor quotes: ' + error.message,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const createQuote = async (quoteData: Partial<SubcontractorQuote>) => {
    try {
      const finalRate = calculateFinalRate(
        quoteData.quote_value || 0,
        quoteData.discount_percent || 0,
        quoteData.factor || 1
      );

      const { data, error } = await supabase
        .from('subcontractor_quotes')
        .insert({
          project_id: projectId,
          boq_item_id: quoteData.boq_item_id || '',
          trade_code: quoteData.trade_code || '',
          price_code: quoteData.price_code || null,
          description: quoteData.description || '',
          quantity: quoteData.quantity || 0,
          base_rate: quoteData.base_rate || 0,
          quote_vendor: quoteData.quote_vendor || '',
          quote_value: quoteData.quote_value || 0,
          discount_percent: quoteData.discount_percent || 0,
          factor: quoteData.factor || 1,
          final_rate: finalRate,
          selected: quoteData.selected || false,
          inserted_to_boq: quoteData.inserted_to_boq || false
        })
        .select()
        .single();

      if (error) throw error;
      
      setQuotes(prev => [data, ...prev]);
      toast({
        title: 'Success',
        description: 'Subcontractor quote created successfully'
      });
    } catch (error: any) {
      console.error('Error creating subcontractor quote:', error);
      toast({
        title: 'Error',
        description: 'Failed to create subcontractor quote: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const updateQuote = async (id: string, updates: Partial<SubcontractorQuote>) => {
    try {
      const currentQuote = quotes.find(q => q.id === id);
      if (!currentQuote) return;

      const finalRate = calculateFinalRate(
        updates.quote_value ?? currentQuote.quote_value,
        updates.discount_percent ?? currentQuote.discount_percent,
        updates.factor ?? currentQuote.factor
      );

      const { data, error } = await supabase
        .from('subcontractor_quotes')
        .update({ ...updates, final_rate: finalRate })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      
      setQuotes(prev => prev.map(q => q.id === id ? data : q));
    } catch (error: any) {
      console.error('Error updating subcontractor quote:', error);
      toast({
        title: 'Error',
        description: 'Failed to update subcontractor quote: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const deleteQuote = async (id: string) => {
    try {
      const { error } = await supabase
        .from('subcontractor_quotes')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setQuotes(prev => prev.filter(q => q.id !== id));
      toast({
        title: 'Success',
        description: 'Subcontractor quote deleted successfully'
      });
    } catch (error: any) {
      console.error('Error deleting subcontractor quote:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete subcontractor quote: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const applyQuoteToBOQ = async (quoteId: string) => {
    try {
      const quote = quotes.find(q => q.id === quoteId);
      if (!quote) return;

      const { error: boqError } = await supabase
        .from('boq_items')
        .update({ net_rate: quote.final_rate })
        .eq('id', quote.boq_item_id);

      if (boqError) throw boqError;

      const { error: quoteError } = await supabase
        .from('subcontractor_quotes')
        .update({ inserted_to_boq: true })
        .eq('id', quoteId);

      if (quoteError) throw quoteError;

      setQuotes(prev => prev.map(q => 
        q.id === quoteId ? { ...q, inserted_to_boq: true } : q
      ));

      toast({
        title: 'Success',
        description: 'Quote applied to BOQ successfully'
      });
    } catch (error: any) {
      console.error('Error applying quote to BOQ:', error);
      toast({
        title: 'Error',
        description: 'Failed to apply quote to BOQ: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const refreshQuotes = async () => {
    await loadQuotes();
  };

  useEffect(() => {
    loadQuotes();
  }, [projectId]);

  return {
    quotes,
    isLoading,
    createQuote,
    updateQuote,
    deleteQuote,
    applyQuoteToBOQ,
    refreshQuotes
  };
}

function calculateFinalRate(quoteValue: number, discountPercent: number, factor: number): number {
  const afterDiscount = quoteValue * (1 - discountPercent / 100);
  return afterDiscount * factor;
}
