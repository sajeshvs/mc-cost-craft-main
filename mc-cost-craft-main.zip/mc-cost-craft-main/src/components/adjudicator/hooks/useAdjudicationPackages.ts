
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { AdjudicationPackage } from '../types/adjudicator';

export function useAdjudicationPackages(projectId: string) {
  const [packages, setPackages] = useState<AdjudicationPackage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  const loadPackages = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('adjudication_packages')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      // Type assertion to match our interface
      setPackages((data || []).map(pkg => ({
        ...pkg,
        type: pkg.type as 'subcontractor' | 'supplier',
        status: pkg.status as 'draft' | 'finalized'
      })));
    } catch (error: any) {
      console.error('Error loading adjudication packages:', error);
      toast({
        title: 'Error',
        description: 'Failed to load adjudication packages: ' + error.message,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const createPackage = async (packageData: Omit<AdjudicationPackage, 'id' | 'created_at' | 'updated_at' | 'created_by' | 'user_id'>) => {
    try {
      const { data, error } = await supabase
        .from('adjudication_packages')
        .insert({
          ...packageData,
          project_id: projectId
        })
        .select()
        .single();

      if (error) throw error;
      
      const typedPackage = {
        ...data,
        type: data.type as 'subcontractor' | 'supplier',
        status: data.status as 'draft' | 'finalized'
      };
      
      setPackages(prev => [typedPackage, ...prev]);
      toast({
        title: 'Success',
        description: 'Adjudication package created successfully'
      });
      
      return typedPackage;
    } catch (error: any) {
      console.error('Error creating adjudication package:', error);
      toast({
        title: 'Error',
        description: 'Failed to create adjudication package: ' + error.message,
        variant: 'destructive'
      });
      throw error;
    }
  };

  const updatePackage = async (id: string, updates: Partial<AdjudicationPackage>) => {
    try {
      const { data, error } = await supabase
        .from('adjudication_packages')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      
      const typedPackage = {
        ...data,
        type: data.type as 'subcontractor' | 'supplier',
        status: data.status as 'draft' | 'finalized'
      };
      
      setPackages(prev => prev.map(pkg => pkg.id === id ? typedPackage : pkg));
      toast({
        title: 'Success',
        description: 'Package updated successfully'
      });
    } catch (error: any) {
      console.error('Error updating package:', error);
      toast({
        title: 'Error',
        description: 'Failed to update package: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const deletePackage = async (id: string) => {
    try {
      const { error } = await supabase
        .from('adjudication_packages')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setPackages(prev => prev.filter(pkg => pkg.id !== id));
      toast({
        title: 'Success',
        description: 'Package deleted successfully'
      });
    } catch (error: any) {
      console.error('Error deleting package:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete package: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const duplicatePackage = async (packageToDuplicate: AdjudicationPackage) => {
    try {
      const newPackage = {
        ...packageToDuplicate,
        name: `${packageToDuplicate.name} (Copy)`,
        status: 'draft' as const
      };
      delete (newPackage as any).id;
      delete (newPackage as any).created_at;
      delete (newPackage as any).updated_at;
      delete (newPackage as any).created_by;
      delete (newPackage as any).user_id;

      return await createPackage(newPackage);
    } catch (error) {
      console.error('Error duplicating package:', error);
      throw error;
    }
  };

  useEffect(() => {
    loadPackages();
  }, [projectId]);

  return {
    packages,
    isLoading,
    createPackage,
    updatePackage,
    deletePackage,
    duplicatePackage,
    refreshPackages: loadPackages
  };
}
