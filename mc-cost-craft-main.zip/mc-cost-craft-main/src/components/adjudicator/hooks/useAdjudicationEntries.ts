
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { AdjudicationEntry, AdjudicationQuote } from '../types/adjudicator';

export function useAdjudicationEntries(packageId: string) {
  const [entries, setEntries] = useState<AdjudicationEntry[]>([]);
  const [quotes, setQuotes] = useState<AdjudicationQuote[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const loadEntries = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('adjudication_entries')
        .select('*')
        .eq('package_id', packageId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      
      const typedEntries: AdjudicationEntry[] = (data || []).map(entry => ({
        ...entry,
        item_type: entry.item_type as 'BOQ' | 'Resource'
      }));
      
      setEntries(typedEntries);
    } catch (error: any) {
      console.error('Error loading entries:', error);
      toast({
        title: 'Error',
        description: 'Failed to load entries: ' + error.message,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadQuotes = async () => {
    try {
      const { data, error } = await supabase
        .from('adjudication_quotes')
        .select('*')
        .in('entry_id', entries.map(e => e.id))
        .order('created_at', { ascending: true });

      if (error) throw error;
      setQuotes(data || []);
    } catch (error: any) {
      console.error('Error loading quotes:', error);
    }
  };

  const createEntry = async (entryData: Omit<AdjudicationEntry, 'id' | 'created_at' | 'user_id'>) => {
    try {
      const { data, error } = await supabase
        .from('adjudication_entries')
        .insert({
          ...entryData,
          package_id: packageId
        })
        .select()
        .single();

      if (error) throw error;
      
      const typedEntry: AdjudicationEntry = {
        ...data,
        item_type: data.item_type as 'BOQ' | 'Resource'
      };
      
      setEntries(prev => [...prev, typedEntry]);
      return typedEntry;
    } catch (error: any) {
      console.error('Error creating entry:', error);
      toast({
        title: 'Error',
        description: 'Failed to create entry: ' + error.message,
        variant: 'destructive'
      });
      throw error;
    }
  };

  const createQuote = async (quoteData: Omit<AdjudicationQuote, 'id' | 'created_at' | 'updated_at' | 'user_id'>) => {
    try {
      const { data, error } = await supabase
        .from('adjudication_quotes')
        .insert(quoteData)
        .select()
        .single();

      if (error) throw error;
      setQuotes(prev => [...prev, data]);
      return data;
    } catch (error: any) {
      console.error('Error creating quote:', error);
      throw error;
    }
  };

  const updateQuote = async (quoteId: string, updates: Partial<AdjudicationQuote>) => {
    try {
      const { data, error } = await supabase
        .from('adjudication_quotes')
        .update(updates)
        .eq('id', quoteId)
        .select()
        .single();

      if (error) throw error;
      setQuotes(prev => prev.map(q => q.id === quoteId ? data : q));
      return data;
    } catch (error: any) {
      console.error('Error updating quote:', error);
      throw error;
    }
  };

  const selectQuote = async (entryId: string, quoteId: string) => {
    try {
      // First, deselect all quotes for this entry
      await supabase
        .from('adjudication_quotes')
        .update({ is_selected: false })
        .eq('entry_id', entryId);

      // Then select the chosen quote
      const { data, error } = await supabase
        .from('adjudication_quotes')
        .update({ is_selected: true })
        .eq('id', quoteId)
        .select()
        .single();

      if (error) throw error;
      
      // Update local state
      setQuotes(prev => prev.map(q => 
        q.entry_id === entryId ? { ...q, is_selected: q.id === quoteId } : q
      ));
      
      toast({
        title: 'Quote Selected',
        description: 'Quote has been selected for this item',
      });
    } catch (error: any) {
      console.error('Error selecting quote:', error);
      toast({
        title: 'Error',
        description: 'Failed to select quote: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const applyQuote = async (entryId: string, quoteId: string) => {
    try {
      const entry = entries.find(e => e.id === entryId);
      const quote = quotes.find(q => q.id === quoteId);
      
      if (!entry || !quote) throw new Error('Entry or quote not found');

      // Apply to BOQ or Resource based on entry type
      if (entry.item_type === 'BOQ') {
        await applyToBOQ(entry, quote);
      } else {
        await applyToResource(entry, quote);
      }

      // Mark quote as applied
      await updateQuote(quoteId, { applied_at: new Date().toISOString() });
      
      toast({
        title: 'Quote Applied',
        description: `Quote has been applied to ${entry.item_type}`,
      });
    } catch (error: any) {
      console.error('Error applying quote:', error);
      toast({
        title: 'Error',
        description: 'Failed to apply quote: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const applyToBOQ = async (entry: AdjudicationEntry, quote: AdjudicationQuote) => {
    const { error } = await supabase
      .from('boq_items')
      .update({ 
        net_rate: quote.final_rate,
        amount: quote.amount
      })
      .eq('id', entry.source_id);

    if (error) throw error;
  };

  const applyToResource = async (entry: AdjudicationEntry, quote: AdjudicationQuote) => {
    const { error } = await supabase
      .from('resources')
      .update({ 
        offer_rate: quote.final_rate,
        rate: quote.final_rate
      })
      .eq('id', entry.source_id);

    if (error) throw error;
  };

  const importFromBOQ = async (tradeCode: string) => {
    try {
      setIsLoading(true);
      
      // Get current package info
      const { data: packageData, error: packageError } = await supabase
        .from('adjudication_packages')
        .select('project_id')
        .eq('id', packageId)
        .single();

      if (packageError) throw packageError;

      // Fetch BOQ items for the trade code
      const { data: boqItems, error: boqError } = await supabase
        .from('boq_items')
        .select('*')
        .eq('job_id', packageData.project_id)
        .ilike('price_code', `${tradeCode}%`);

      if (boqError) throw boqError;

      // Create entries for each BOQ item
      const promises = boqItems.map(item => 
        createEntry({
          package_id: packageId,
          item_type: 'BOQ' as const,
          source_id: item.id,
          trade_code: tradeCode,
          page_ref: item.page_number?.toString() || '',
          description: item.description,
          quantity: item.quantity || 0,
          unit: item.unit,
          base_rate: item.net_rate || 0,
          price_code: item.price_code || ''
        })
      );

      await Promise.all(promises);

      toast({
        title: 'BOQ Import Complete',
        description: `Imported ${boqItems.length} BOQ items for trade ${tradeCode}`,
      });
    } catch (error: any) {
      console.error('Error importing from BOQ:', error);
      toast({
        title: 'Import Error',
        description: 'Failed to import from BOQ: ' + error.message,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const importFromResources = async (tradeCode: string) => {
    try {
      setIsLoading(true);
      
      // Get current package info
      const { data: packageData, error: packageError } = await supabase
        .from('adjudication_packages')
        .select('project_id')
        .eq('id', packageId)
        .single();

      if (packageError) throw packageError;

      // Fetch resources for the trade code
      const { data: resources, error: resourceError } = await supabase
        .from('resources')
        .select('*')
        .eq('project_id', packageData.project_id)
        .eq('category', tradeCode);

      if (resourceError) throw resourceError;

      // Create entries for each resource
      const promises = resources.map(resource => 
        createEntry({
          package_id: packageId,
          item_type: 'Resource' as const,
          source_id: resource.id,
          trade_code: tradeCode,
          page_ref: '',
          description: resource.resource_name,
          quantity: resource.used_quantity || 0,
          unit: resource.unit,
          base_rate: resource.offer_rate || 0,
          price_code: resource.resource_code
        })
      );

      await Promise.all(promises);

      toast({
        title: 'Resource Import Complete',
        description: `Imported ${resources.length} resources for trade ${tradeCode}`,
      });
    } catch (error: any) {
      console.error('Error importing from resources:', error);
      toast({
        title: 'Import Error',
        description: 'Failed to import from resources: ' + error.message,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (packageId) {
      loadEntries();
    }
  }, [packageId]);

  useEffect(() => {
    if (entries.length > 0) {
      loadQuotes();
    }
  }, [entries]);

  return {
    entries,
    quotes,
    isLoading,
    createEntry,
    createQuote,
    updateQuote,
    selectQuote,
    applyQuote,
    importFromBOQ,
    importFromResources,
    refreshEntries: loadEntries,
    refreshQuotes: loadQuotes
  };
}
