
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, RefreshCw, Upload, Download } from 'lucide-react';
import { useSubcontractorQuotes } from './hooks/useSubcontractorQuotes';
import { useBOQData } from '@/hooks/useBOQData';

interface SubcontractorAdjudicatorProps {
  projectId: string;
}

export function SubcontractorAdjudicator({ projectId }: SubcontractorAdjudicatorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  
  const {
    quotes,
    isLoading,
    createQuote,
    updateQuote,
    deleteQuote,
    applyQuoteToBOQ,
    refreshQuotes
  } = useSubcontractorQuotes(projectId);

  const { boqItems } = useBOQData(projectId);

  const handleAddQuote = async () => {
    if (boqItems.length === 0) return;
    
    const firstItem = boqItems[0];
    await createQuote({
      boq_item_id: firstItem.id,
      trade_code: 'GEN',
      description: firstItem.description,
      quantity: firstItem.quantity || 0,
      base_rate: firstItem.net_rate || 0,
      quote_vendor: 'New Vendor',
      quote_value: 0
    });
  };

  const handleUpdateQuote = async (quoteId: string, field: string, value: any) => {
    await updateQuote(quoteId, { [field]: value });
  };

  const handleDeleteSelected = async () => {
    await Promise.all(Array.from(selectedRows).map(id => deleteQuote(id)));
    setSelectedRows(new Set());
  };

  const handleSelectQuote = async (quoteId: string) => {
    // First deselect all other quotes for this BOQ item
    const quote = quotes.find(q => q.id === quoteId);
    if (!quote) return;
    
    const relatedQuotes = quotes.filter(q => q.boq_item_id === quote.boq_item_id);
    await Promise.all(relatedQuotes.map(q => 
      updateQuote(q.id, { selected: q.id === quoteId })
    ));
    
    await refreshQuotes();
  };

  const handleApplyToBOQ = async (quoteId: string) => {
    await applyQuoteToBOQ(quoteId);
  };

  const filteredQuotes = quotes.filter(quote =>
    searchTerm === '' || 
    quote.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    quote.trade_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    quote.quote_vendor.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const groupedQuotes = filteredQuotes.reduce((acc, quote) => {
    const key = `${quote.boq_item_id}-${quote.trade_code}`;
    if (!acc[key]) acc[key] = [];
    acc[key].push(quote);
    return acc;
  }, {} as Record<string, typeof quotes>);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-6 w-6 animate-spin mr-2" />
        <span>Loading subcontractor quotes...</span>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div className="flex items-center gap-2 p-3 border-b bg-muted/50">
        <Input
          placeholder="Search quotes, vendors, or trade codes..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-md"
        />
        
        <Button onClick={handleAddQuote} size="sm">
          <Plus className="h-4 w-4 mr-1" />
          Add Quote
        </Button>
        
        <Button 
          onClick={handleDeleteSelected} 
          variant="destructive" 
          size="sm"
          disabled={selectedRows.size === 0}
        >
          <Trash2 className="h-4 w-4 mr-1" />
          Delete ({selectedRows.size})
        </Button>
        
        <Button onClick={refreshQuotes} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-1" />
          Refresh
        </Button>
      </div>

      {/* Table */}
      <ScrollArea className="flex-1">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">Select</TableHead>
              <TableHead>Trade Code</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Unit</TableHead>
              <TableHead>Quantity</TableHead>
              <TableHead>Base Rate</TableHead>
              <TableHead>Vendor</TableHead>
              <TableHead>Quote Value</TableHead>
              <TableHead>Discount %</TableHead>
              <TableHead>Factor</TableHead>
              <TableHead>Final Rate</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {Object.entries(groupedQuotes).map(([key, quoteGroup]) => (
              <React.Fragment key={key}>
                {quoteGroup.map((quote, index) => (
                  <TableRow key={quote.id} className={quote.selected ? 'bg-green-50' : ''}>
                    <TableCell>
                      <input
                        type="radio"
                        name={`quote-${quote.boq_item_id}`}
                        checked={quote.selected}
                        onChange={() => handleSelectQuote(quote.id)}
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        value={quote.trade_code}
                        onChange={(e) => handleUpdateQuote(quote.id, 'trade_code', e.target.value)}
                        className="w-20"
                      />
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <div className="truncate" title={quote.description}>
                        {quote.description}
                      </div>
                    </TableCell>
                    <TableCell>EA</TableCell>
                    <TableCell>{quote.quantity.toLocaleString()}</TableCell>
                    <TableCell>
                      ${quote.base_rate.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell>
                      <Input
                        value={quote.quote_vendor}
                        onChange={(e) => handleUpdateQuote(quote.id, 'quote_vendor', e.target.value)}
                        className="w-32"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        value={quote.quote_value}
                        onChange={(e) => handleUpdateQuote(quote.id, 'quote_value', parseFloat(e.target.value) || 0)}
                        className="w-24"
                        step="0.01"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        value={quote.discount_percent}
                        onChange={(e) => handleUpdateQuote(quote.id, 'discount_percent', parseFloat(e.target.value) || 0)}
                        className="w-20"
                        step="0.1"
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        value={quote.factor}
                        onChange={(e) => handleUpdateQuote(quote.id, 'factor', parseFloat(e.target.value) || 1)}
                        className="w-20"
                        step="0.01"
                      />
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">
                        ${quote.final_rate.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={quote.inserted_to_boq ? 'default' : 'secondary'}>
                        {quote.inserted_to_boq ? 'Applied' : 'Pending'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button
                          onClick={() => handleApplyToBOQ(quote.id)}
                          disabled={!quote.selected || quote.inserted_to_boq}
                          size="sm"
                          variant="outline"
                        >
                          Apply to BOQ
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </React.Fragment>
            ))}
            
            {filteredQuotes.length === 0 && (
              <TableRow>
                <TableCell colSpan={13} className="text-center text-gray-500 py-8">
                  No subcontractor quotes found. Click "Add Quote" to create one.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </ScrollArea>

      {/* Footer */}
      <div className="p-3 border-t bg-muted/50">
        <div className="flex items-center justify-between text-sm">
          <span>{filteredQuotes.length} quotes total</span>
          <div className="flex items-center gap-4">
            <span>Selected: {Array.from(selectedRows).length}</span>
            <span>Applied: {filteredQuotes.filter(q => q.inserted_to_boq).length}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
