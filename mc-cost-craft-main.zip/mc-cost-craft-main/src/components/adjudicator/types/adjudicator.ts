
export interface AdjudicationPackage {
  id: string;
  project_id: string;
  name: string;
  type: 'subcontractor' | 'supplier';
  trade_code?: string;
  created_by: string;
  created_at: string;
  status: 'draft' | 'finalized';
  updated_at: string;
  user_id?: string;
}

export interface AdjudicationEntry {
  id: string;
  package_id: string;
  item_type: 'BOQ' | 'Resource';
  source_id: string;
  trade_code?: string;
  page_ref?: string;
  description: string;
  quantity: number;
  unit: string;
  base_rate: number;
  price_code?: string;
  created_at: string;
  user_id?: string;
}

export interface AdjudicationQuote {
  id: string;
  entry_id: string;
  vendor_name: string;
  currency: string;
  exchange_rate: number;
  quoted_rate: number;
  discount_percent: number;
  factor: number;
  final_rate: number;
  amount: number;
  is_selected: boolean;
  applied_at?: string;
  created_at: string;
  updated_at: string;
  user_id?: string;
}

export interface VendorColumn {
  id: string;
  name: string;
  currency: string;
  exchange_rate: number;
}
