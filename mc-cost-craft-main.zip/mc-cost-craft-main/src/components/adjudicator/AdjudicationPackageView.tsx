
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Download, Upload, Settings, Lock, RefreshCw } from 'lucide-react';
import { AdjudicationPackage } from './types/adjudicator';
import { SubcontractorQuotesTab } from './SubcontractorQuotesTab';
import { SupplierQuotesTab } from './SupplierQuotesTab';

interface AdjudicationPackageViewProps {
  packageData: AdjudicationPackage;
  onBack: () => void;
}

export function AdjudicationPackageView({ packageData, onBack }: AdjudicationPackageViewProps) {
  const [activeTab, setActiveTab] = useState(packageData.type === 'subcontractor' ? 'subcontractor' : 'supplier');

  const handleExportToExcel = () => {
    console.log('Export to Excel not implemented yet');
  };

  const handleImportQuotes = () => {
    console.log('Import quotes not implemented yet');
  };

  const handleLockAndFinalize = () => {
    console.log('Lock and finalize not implemented yet');
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h2 className="text-lg font-semibold">{packageData.name}</h2>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant={packageData.type === 'subcontractor' ? 'default' : 'secondary'}>
                {packageData.type}
              </Badge>
              <Badge variant={packageData.status === 'finalized' ? 'default' : 'secondary'}>
                {packageData.status}
              </Badge>
              {packageData.trade_code && (
                <Badge variant="outline">
                  Trade: {packageData.trade_code}
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExportToExcel}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button variant="outline" size="sm" onClick={handleImportQuotes}>
            <Upload className="h-4 w-4 mr-2" />
            Import
          </Button>
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleLockAndFinalize}
            disabled={packageData.status === 'finalized'}
          >
            <Lock className="h-4 w-4 mr-2" />
            {packageData.status === 'finalized' ? 'Finalized' : 'Finalize'}
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex-1 overflow-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="subcontractor">Subcontractor Quotes</TabsTrigger>
            <TabsTrigger value="supplier">Supplier Quotes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="subcontractor" className="flex-1 overflow-hidden">
            <SubcontractorQuotesTab packageData={packageData} />
          </TabsContent>
          
          <TabsContent value="supplier" className="flex-1 overflow-hidden">
            <SupplierQuotesTab packageData={packageData} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
