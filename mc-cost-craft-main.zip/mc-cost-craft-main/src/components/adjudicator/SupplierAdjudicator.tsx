
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Trash2, Plus, Check, X } from 'lucide-react';
import { useSupplierQuotes } from './hooks/useSupplierQuotes';
import { supabase } from '@/integrations/supabase/client';

interface Resource {
  id: string;
  resource_code: string;
  resource_name: string;
  category: string;
  unit: string;
  rate: number;
  used_quantity: number;
}

interface SupplierAdjudicatorProps {
  projectId: string;
}

export function SupplierAdjudicator({ projectId }: SupplierAdjudicatorProps) {
  const [resources, setResources] = useState<Resource[]>([]);
  const [isLoadingResources, setIsLoadingResources] = useState(true);
  const [selectedResourceId, setSelectedResourceId] = useState<string | null>(null);
  const { quotes, isLoading, createQuote, updateQuote, deleteQuote, applyQuoteToResource, refreshQuotes } = useSupplierQuotes(projectId);

  const loadResources = async () => {
    try {
      setIsLoadingResources(true);
      const { data, error } = await supabase
        .from('resources')
        .select('*')
        .eq('project_id', projectId)
        .order('resource_code');

      if (error) throw error;
      setResources(data || []);
    } catch (error) {
      console.error('Error loading resources:', error);
    } finally {
      setIsLoadingResources(false);
    }
  };

  useEffect(() => {
    loadResources();
  }, [projectId]);

  const handleAddQuote = () => {
    if (!selectedResourceId) return;

    const resource = resources.find(r => r.id === selectedResourceId);
    if (!resource) return;

    createQuote({
      resource_id: selectedResourceId,
      vendor_name: 'New Vendor',
      quote_value: 0,
      discount_percent: 0,
      factor: 1
    });
  };

  const handleUpdateQuote = (id: string, field: string, value: any) => {
    updateQuote(id, { [field]: value });
  };

  const handleSelectQuote = (quoteId: string) => {
    const quote = quotes.find(q => q.id === quoteId);
    if (!quote) return;

    // Unselect all other quotes for this resource
    quotes
      .filter(q => q.resource_id === quote.resource_id && q.id !== quoteId)
      .forEach(q => updateQuote(q.id, { selected: false }));

    // Select this quote
    updateQuote(quoteId, { selected: true });
  };

  const handleApplyQuote = (quoteId: string) => {
    applyQuoteToResource(quoteId);
  };

  const getResourceQuotes = (resourceId: string) => {
    return quotes.filter(q => q.resource_id === resourceId);
  };

  const getSelectedQuote = (resourceId: string) => {
    return quotes.find(q => q.resource_id === resourceId && q.selected);
  };

  if (isLoadingResources || isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading resources and quotes...</div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-semibold">Supplier Quote Comparison</h2>
        <div className="flex items-center gap-2">
          <select
            value={selectedResourceId || ''}
            onChange={(e) => setSelectedResourceId(e.target.value || null)}
            className="px-3 py-2 border rounded-md"
          >
            <option value="">Select Resource</option>
            {resources.map(resource => (
              <option key={resource.id} value={resource.id}>
                {resource.resource_code} - {resource.resource_name}
              </option>
            ))}
          </select>
          <Button
            onClick={handleAddQuote}
            disabled={!selectedResourceId}
            size="sm"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Quote
          </Button>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <div className="space-y-4 p-4">
          {resources.map(resource => {
            const resourceQuotes = getResourceQuotes(resource.id);
            const selectedQuote = getSelectedQuote(resource.id);

            if (resourceQuotes.length === 0) return null;

            return (
              <div key={resource.id} className="border rounded-lg p-4 bg-white">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-medium text-lg">{resource.resource_code}</h3>
                    <p className="text-sm text-gray-600">{resource.resource_name}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                      <span>Category: {resource.category}</span>
                      <span>Unit: {resource.unit}</span>
                      <span>Base Rate: ${resource.rate.toFixed(2)}</span>
                      <span>Used Qty: {resource.used_quantity}</span>
                    </div>
                  </div>
                  {selectedQuote && (
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Selected: ${selectedQuote.final_rate.toFixed(2)}
                    </Badge>
                  )}
                </div>

                <div className="grid gap-3">
                  {resourceQuotes.map(quote => (
                    <div
                      key={quote.id}
                      className={`border rounded-lg p-3 ${
                        quote.selected ? 'border-green-500 bg-green-50' : 'border-gray-200'
                      }`}
                    >
                      <div className="grid grid-cols-8 gap-3 items-center">
                        <div className="col-span-2">
                          <Input
                            value={quote.vendor_name}
                            onChange={(e) => handleUpdateQuote(quote.id, 'vendor_name', e.target.value)}
                            placeholder="Vendor Name"
                            className="h-8"
                          />
                        </div>
                        <div>
                          <Input
                            type="number"
                            value={quote.quote_value}
                            onChange={(e) => handleUpdateQuote(quote.id, 'quote_value', parseFloat(e.target.value) || 0)}
                            placeholder="Quote Value"
                            className="h-8"
                          />
                        </div>
                        <div>
                          <Input
                            type="number"
                            value={quote.discount_percent}
                            onChange={(e) => handleUpdateQuote(quote.id, 'discount_percent', parseFloat(e.target.value) || 0)}
                            placeholder="Discount %"
                            className="h-8"
                          />
                        </div>
                        <div>
                          <Input
                            type="number"
                            value={quote.factor}
                            onChange={(e) => handleUpdateQuote(quote.id, 'factor', parseFloat(e.target.value) || 1)}
                            placeholder="Factor"
                            className="h-8"
                          />
                        </div>
                        <div className="font-medium">
                          ${quote.final_rate.toFixed(2)}
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            variant={quote.selected ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleSelectQuote(quote.id)}
                            className="h-8 px-2"
                          >
                            {quote.selected ? <Check className="h-3 w-3" /> : "Select"}
                          </Button>
                          {quote.selected && !quote.inserted_to_resources && (
                            <Button
                              onClick={() => handleApplyQuote(quote.id)}
                              size="sm"
                              className="h-8 px-2 bg-green-600 hover:bg-green-700"
                            >
                              Apply
                            </Button>
                          )}
                          {quote.inserted_to_resources && (
                            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                              Applied
                            </Badge>
                          )}
                        </div>
                        <div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteQuote(quote.id)}
                            className="h-8 px-2 text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
