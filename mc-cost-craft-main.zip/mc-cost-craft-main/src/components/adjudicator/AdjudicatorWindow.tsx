
import React from 'react';
import { AdjudicatorModule } from './AdjudicatorModule';

interface AdjudicatorWindowProps {
  projectId: string;
  onClose: () => void;
}

export function AdjudicatorWindow({ projectId, onClose }: AdjudicatorWindowProps) {
  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col">
      <AdjudicatorModule projectId={projectId} onClose={onClose} />
    </div>
  );
}
