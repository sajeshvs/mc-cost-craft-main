
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AdjudicationPackage } from './types/adjudicator';

interface NewPackageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreatePackage: (packageData: Omit<AdjudicationPackage, 'id' | 'created_at' | 'updated_at' | 'created_by' | 'user_id'>) => void;
}

export function NewPackageDialog({ open, onOpenChange, onCreatePackage }: NewPackageDialogProps) {
  const [formData, setFormData] = useState({
    name: '',
    type: 'subcontractor' as 'subcontractor' | 'supplier',
    trade_code: '',
    status: 'draft' as 'draft' | 'finalized'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    onCreatePackage({
      project_id: '', // This will be set by the parent component
      name: formData.name.trim(),
      type: formData.type,
      trade_code: formData.trade_code.trim() || undefined,
      status: formData.status
    });

    // Reset form
    setFormData({
      name: '',
      type: 'subcontractor',
      trade_code: '',
      status: 'draft'
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Adjudication Package</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Package Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Enter package name"
              required
            />
          </div>

          <div>
            <Label htmlFor="type">Package Type</Label>
            <Select
              value={formData.type}
              onValueChange={(value: 'subcontractor' | 'supplier') => 
                setFormData(prev => ({ ...prev, type: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="subcontractor">Subcontractor</SelectItem>
                <SelectItem value="supplier">Supplier</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="trade_code">Trade Code (Optional)</Label>
            <Input
              id="trade_code"
              value={formData.trade_code}
              onChange={(e) => setFormData(prev => ({ ...prev, trade_code: e.target.value }))}
              placeholder="e.g., 03, 05, 09"
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">
              Create Package
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
