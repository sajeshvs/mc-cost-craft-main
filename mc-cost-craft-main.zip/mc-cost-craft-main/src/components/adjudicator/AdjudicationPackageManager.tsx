
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, FileText, Copy, Trash2, Edit2, Package, Search, Filter, X } from 'lucide-react';
import { useAdjudicationPackages } from './hooks/useAdjudicationPackages';
import { AdjudicationPackage } from './types/adjudicator';
import { NewPackageDialog } from './components/NewPackageDialog';
import { formatDistance } from 'date-fns';

interface AdjudicationPackageManagerProps {
  projectId: string;
  onOpenPackage: (packageData: AdjudicationPackage) => void;
  onClose: () => void;
}

export function AdjudicationPackageManager({ projectId, onOpenPackage, onClose }: AdjudicationPackageManagerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewPackageDialog, setShowNewPackageDialog] = useState(false);
  const [typeFilter, setTypeFilter] = useState<'all' | 'subcontractor' | 'supplier'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'draft' | 'finalized'>('all');
  const { packages, isLoading, createPackage, updatePackage, deletePackage, duplicatePackage } = useAdjudicationPackages(projectId);

  const filteredPackages = packages.filter(pkg => {
    const matchesSearch = pkg.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pkg.trade_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pkg.type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || pkg.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || pkg.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  const handleCreatePackage = async (packageData: Omit<AdjudicationPackage, 'id' | 'created_at' | 'updated_at' | 'created_by' | 'user_id'>) => {
    try {
      const newPackage = await createPackage({
        ...packageData,
        project_id: projectId
      });
      setShowNewPackageDialog(false);
      onOpenPackage(newPackage);
    } catch (error) {
      console.error('Error creating package:', error);
    }
  };

  const handleDuplicatePackage = async (pkg: AdjudicationPackage) => {
    try {
      const duplicatedPackage = await duplicatePackage(pkg);
      onOpenPackage(duplicatedPackage);
    } catch (error) {
      console.error('Error duplicating package:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-yellow-100 text-yellow-800';
      case 'finalized': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'subcontractor': return 'bg-blue-100 text-blue-800';
      case 'supplier': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading adjudication packages...</div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b bg-white">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Adjudication Package Manager</h1>
          <p className="text-gray-600 mt-1">Manage quote comparison sessions for subcontractors and suppliers</p>
        </div>
        <div className="flex items-center gap-3">
          <Button onClick={() => setShowNewPackageDialog(true)} size="lg">
            <Plus className="h-5 w-5 mr-2" />
            New Package
          </Button>
          <Button variant="outline" onClick={onClose}>
            <X className="h-4 w-4 mr-2" />
            Close
          </Button>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="flex items-center gap-4 p-6 border-b bg-gray-50">
        <div className="flex items-center gap-2">
          <Search className="h-4 w-4 text-gray-500" />
          <Input
            placeholder="Search packages..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-64"
          />
        </div>
        
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as any)}
            className="px-3 py-2 border rounded-md text-sm"
          >
            <option value="all">All Types</option>
            <option value="subcontractor">Subcontractor</option>
            <option value="supplier">Supplier</option>
          </select>
          
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-2 border rounded-md text-sm"
          >
            <option value="all">All Status</option>
            <option value="draft">Draft</option>
            <option value="finalized">Finalized</option>
          </select>
        </div>

        <div className="flex-1" />
        
        <div className="text-sm text-gray-600">
          {filteredPackages.length} of {packages.length} packages
        </div>
      </div>

      {/* Package Table */}
      <div className="flex-1 overflow-auto">
        {filteredPackages.length === 0 ? (
          <div className="text-center py-16">
            <Package className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No adjudication packages found</h3>
            <p className="text-gray-600 mb-6">Create your first package to start comparing quotes</p>
            <Button onClick={() => setShowNewPackageDialog(true)} size="lg">
              <Plus className="h-5 w-5 mr-2" />
              Create Package
            </Button>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-32">Package ID</TableHead>
                <TableHead>Title</TableHead>
                <TableHead className="w-32">Type</TableHead>
                <TableHead className="w-32">Trade Code</TableHead>
                <TableHead className="w-32">Status</TableHead>
                <TableHead className="w-32">Created By</TableHead>
                <TableHead className="w-40">Last Modified</TableHead>
                <TableHead className="w-32">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPackages.map((pkg) => (
                <TableRow key={pkg.id}>
                  <TableCell className="font-mono text-sm">{pkg.id.slice(0, 8)}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-gray-400" />
                      <span className="font-medium">{pkg.name}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getTypeColor(pkg.type)}>{pkg.type}</Badge>
                  </TableCell>
                  <TableCell>
                    {pkg.trade_code ? (
                      <Badge variant="outline">{pkg.trade_code}</Badge>
                    ) : (
                      <span className="text-gray-400">No trade</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(pkg.status)}>{pkg.status}</Badge>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-gray-600">{pkg.created_by}</span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-gray-600">
                      {formatDistance(new Date(pkg.updated_at), new Date(), { addSuffix: true })}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onOpenPackage(pkg)}
                        title="Open Package"
                      >
                        <FileText className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDuplicatePackage(pkg)}
                        title="Duplicate Package"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deletePackage(pkg.id)}
                        title="Delete Package"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      <NewPackageDialog
        open={showNewPackageDialog}
        onOpenChange={setShowNewPackageDialog}
        onCreatePackage={handleCreatePackage}
      />
    </div>
  );
}
