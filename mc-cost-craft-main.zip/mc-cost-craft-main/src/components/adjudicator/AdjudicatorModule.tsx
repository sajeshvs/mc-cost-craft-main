
import React, { useState } from 'react';
import { AdjudicationPackageManager } from './AdjudicationPackageManager';
import { QuoteComparisonView } from './QuoteComparisonView';
import { AdjudicationPackage } from './types/adjudicator';

interface AdjudicatorModuleProps {
  projectId: string;
  onClose: () => void;
}

export function AdjudicatorModule({ projectId, onClose }: AdjudicatorModuleProps) {
  const [currentView, setCurrentView] = useState<'packages' | 'comparison'>('packages');
  const [selectedPackage, setSelectedPackage] = useState<AdjudicationPackage | null>(null);

  const handleOpenPackage = (packageData: AdjudicationPackage) => {
    setSelectedPackage(packageData);
    setCurrentView('comparison');
  };

  const handleBackToPackages = () => {
    setCurrentView('packages');
    setSelectedPackage(null);
  };

  return (
    <div className="h-full flex flex-col">
      {currentView === 'packages' ? (
        <AdjudicationPackageManager 
          projectId={projectId} 
          onOpenPackage={handleOpenPackage}
          onClose={onClose}
        />
      ) : (
        selectedPackage && (
          <QuoteComparisonView
            packageData={selectedPackage}
            onBack={handleBackToPackages}
          />
        )
      )}
    </div>
  );
}
