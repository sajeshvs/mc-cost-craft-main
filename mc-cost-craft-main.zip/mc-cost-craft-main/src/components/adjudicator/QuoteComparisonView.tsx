
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Download, Upload, Settings, Lock, RefreshCw, Search } from 'lucide-react';
import { AdjudicationPackage } from './types/adjudicator';
import { SubcontractorQuoteComparison } from './SubcontractorQuoteComparison';
import { SupplierQuoteComparison } from './SupplierQuoteComparison';

interface QuoteComparisonViewProps {
  packageData: AdjudicationPackage;
  onBack: () => void;
}

export function QuoteComparisonView({ packageData, onBack }: QuoteComparisonViewProps) {
  const [activeTab, setActiveTab] = useState(packageData.type === 'subcontractor' ? 'subcontractor' : 'supplier');
  const [searchTerm, setSearchTerm] = useState('');

  const handleExportToExcel = () => {
    console.log('Export to Excel functionality');
  };

  const handleImportQuotes = () => {
    console.log('Import quotes functionality');
  };

  const handleLockAndFinalize = () => {
    console.log('Lock and finalize functionality');
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-white">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Packages
          </Button>
          <div>
            <h2 className="text-lg font-semibold text-gray-900">{packageData.name}</h2>
            <div className="flex items-center gap-2 mt-1">
              <Badge variant={packageData.type === 'subcontractor' ? 'default' : 'secondary'}>
                {packageData.type === 'subcontractor' ? 'Subcontractor' : 'Supplier'}
              </Badge>
              <Badge variant={packageData.status === 'finalized' ? 'default' : 'secondary'}>
                {packageData.status === 'draft' ? 'Draft' : packageData.status === 'finalized' ? 'Finalized' : 'Completed'}
              </Badge>
              {packageData.trade_code && (
                <Badge variant="outline">
                  Trade: {packageData.trade_code}
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Search and Actions */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search quotes, vendors, or trade codes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          
          <Button variant="outline" size="sm" onClick={handleExportToExcel}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button variant="outline" size="sm" onClick={handleImportQuotes}>
            <Upload className="h-4 w-4 mr-2" />
            Import
          </Button>
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleLockAndFinalize}
            disabled={packageData.status === 'finalized'}
          >
            <Lock className="h-4 w-4 mr-2" />
            {packageData.status === 'finalized' ? 'Finalized' : 'Finalize'}
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex-1 overflow-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <TabsList className="grid w-full grid-cols-2 bg-gray-50 mx-4 mt-2">
            <TabsTrigger value="subcontractor">Subcontractor Quotes</TabsTrigger>
            <TabsTrigger value="supplier">Supplier Quotes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="subcontractor" className="flex-1 overflow-hidden mt-0">
            <SubcontractorQuoteComparison 
              packageData={packageData} 
              searchTerm={searchTerm}
            />
          </TabsContent>
          
          <TabsContent value="supplier" className="flex-1 overflow-hidden mt-0">
            <SupplierQuoteComparison 
              packageData={packageData} 
              searchTerm={searchTerm}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
