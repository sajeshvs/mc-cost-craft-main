
import React from 'react';
import { X, Minus, Maximize2, Minimize2, Package } from 'lucide-react';
import { ResourcesSpreadsheetTable } from './ResourcesSpreadsheetTable';
import { Button } from '@/components/ui/button';

interface ResourcesWindowProps {
  projectId: string;
  onClose: () => void;
}

export function ResourcesWindow({ projectId, onClose }: ResourcesWindowProps) {
  const [isMinimized, setIsMinimized] = React.useState(false);
  const [isMaximized, setIsMaximized] = React.useState(false);
  const [windowSize, setWindowSize] = React.useState({ width: 1200, height: 800 });
  const [position, setPosition] = React.useState({ x: 100, y: 100 });
  const [isDragging, setIsDragging] = React.useState(false);
  const [isResizing, setIsResizing] = React.useState(false);
  const dragRef = React.useRef<HTMLDivElement>(null);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (isMaximized) return;
    
    setIsDragging(true);
    const rect = dragRef.current?.getBoundingClientRect();
    if (rect) {
      const offsetX = e.clientX - rect.left;
      const offsetY = e.clientY - rect.top;

      const handleMouseMove = (e: MouseEvent) => {
        setPosition({
          x: e.clientX - offsetX,
          y: e.clientY - offsetY
        });
      };

      const handleMouseUp = () => {
        setIsDragging(false);
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }
  };

  const handleResize = (e: React.MouseEvent, direction: 'se' | 'e' | 's' | 'w' | 'n') => {
    if (isMaximized) return;
    
    e.preventDefault();
    setIsResizing(true);
    const startX = e.clientX;
    const startY = e.clientY;
    const startWidth = windowSize.width;
    const startHeight = windowSize.height;
    const startPos = position;

    const handleMouseMove = (e: MouseEvent) => {
      const deltaX = e.clientX - startX;
      const deltaY = e.clientY - startY;

      let newWidth = startWidth;
      let newHeight = startHeight;
      let newX = startPos.x;
      let newY = startPos.y;

      if (direction.includes('e')) {
        newWidth = Math.max(600, startWidth + deltaX);
      }
      if (direction.includes('w')) {
        newWidth = Math.max(600, startWidth - deltaX);
        newX = startPos.x + deltaX;
      }
      if (direction.includes('s')) {
        newHeight = Math.max(400, startHeight + deltaY);
      }
      if (direction.includes('n')) {
        newHeight = Math.max(400, startHeight - deltaY);
        newY = startPos.y + deltaY;
      }

      setWindowSize({ width: newWidth, height: newHeight });
      setPosition({ x: newX, y: newY });
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const windowStyle = isMaximized
    ? { position: 'fixed' as const, top: 0, left: 0, right: 0, bottom: 0, zIndex: 50 }
    : { 
        position: 'fixed' as const, 
        top: position.y, 
        left: position.x, 
        zIndex: 50,
        width: isMinimized ? '320px' : `${windowSize.width}px`,
        height: isMinimized ? '60px' : `${windowSize.height}px`
      };

  return (
    <div style={windowStyle} className="bg-white border shadow-lg rounded-lg flex flex-col overflow-hidden">
      {/* Title Bar */}
      <div
        ref={dragRef}
        className="flex items-center justify-between p-2 border-b bg-gray-50 cursor-move select-none"
        onMouseDown={handleMouseDown}
      >
        <div className="flex items-center gap-2">
          <Package className="h-4 w-4 text-green-600" />
          <span className="font-medium text-sm">Resource List</span>
        </div>
        
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMinimized(!isMinimized)}
            className="h-6 w-6 p-0"
          >
            <Minus className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsMaximized(!isMaximized)}
            className="h-6 w-6 p-0"
          >
            {isMaximized ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </div>

      {/* Content */}
      {!isMinimized && (
        <div className="flex-1 overflow-hidden">
          <ResourcesSpreadsheetTable projectId={projectId} />
        </div>
      )}

      {/* Resize handles */}
      {!isMinimized && !isMaximized && (
        <>
          {/* Corner resize handles */}
          <div
            className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize bg-gray-300 hover:bg-gray-400 transition-colors opacity-50 hover:opacity-100"
            onMouseDown={(e) => handleResize(e, 'se')}
            style={{
              background: 'linear-gradient(-45deg, transparent 0%, transparent 30%, currentColor 30%, currentColor 40%, transparent 40%, transparent 60%, currentColor 60%, currentColor 70%, transparent 70%)'
            }}
          />
          
          {/* Edge resize handles */}
          <div
            className="absolute top-8 right-0 bottom-4 w-2 cursor-e-resize hover:bg-blue-200 transition-colors opacity-0 hover:opacity-50"
            onMouseDown={(e) => handleResize(e, 'e')}
          />
          <div
            className="absolute bottom-0 left-0 right-4 h-2 cursor-s-resize hover:bg-blue-200 transition-colors opacity-0 hover:opacity-50"
            onMouseDown={(e) => handleResize(e, 's')}
          />
          <div
            className="absolute top-8 left-0 bottom-4 w-2 cursor-w-resize hover:bg-blue-200 transition-colors opacity-0 hover:opacity-50"
            onMouseDown={(e) => handleResize(e, 'w')}
          />
          <div
            className="absolute top-0 left-4 right-4 h-2 cursor-n-resize hover:bg-blue-200 transition-colors opacity-0 hover:opacity-50"
            onMouseDown={(e) => handleResize(e, 'n')}
          />
        </>
      )}
    </div>
  );
}
