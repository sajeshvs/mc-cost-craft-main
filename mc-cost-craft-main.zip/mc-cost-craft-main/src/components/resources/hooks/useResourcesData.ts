
import { useState, useEffect } from 'react';
import { Resource, RESOURCE_CATEGORIES, UFGS_DIVISIONS } from '@/types/resources';
import { resourcesService } from '@/services/resources';
import { useToast } from '@/hooks/use-toast';

interface GroupedResources {
  [category: string]: {
    [division: string]: Resource[];
  };
}

export function useResourcesData(projectId: string) {
  const [resources, setResources] = useState<Resource[]>([]);
  const [groupedResources, setGroupedResources] = useState<GroupedResources>({});
  const [isLoading, setIsLoading] = useState(true);
  const [isCreatingResources, setIsCreatingResources] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadResources();
  }, [projectId]);

  useEffect(() => {
    // Group resources by category and division
    const grouped: GroupedResources = {};
    
    // Initialize all categories and divisions
    Object.keys(RESOURCE_CATEGORIES).forEach(category => {
      grouped[category] = {};
      UFGS_DIVISIONS.forEach(division => {
        grouped[category][division.code] = [];
      });
    });

    // Group existing resources
    resources.forEach(resource => {
      if (grouped[resource.category] && grouped[resource.category][resource.division]) {
        grouped[resource.category][resource.division].push(resource);
      }
    });

    setGroupedResources(grouped);
  }, [resources]);

  const loadResources = async () => {
    try {
      setIsLoading(true);
      console.log('Loading resources for project:', projectId);
      
      let data = await resourcesService.getByProject(projectId);
      
      // If no resources exist, create comprehensive default ones
      if (data.length === 0) {
        console.log('No resources found, creating comprehensive UFGS default resources...');
        setIsCreatingResources(true);
        
        try {
          await resourcesService.createDefaultResources(projectId);
          data = await resourcesService.getByProject(projectId);
          console.log(`Created ${data.length} default resources`);
          
          toast({
            title: 'Success',
            description: `Loaded ${data.length} UFGS-compliant default resources`
          });
        } catch (createError) {
          console.error('Error creating default resources:', createError);
          toast({
            title: 'Error',
            description: 'Failed to create default resources: ' + (createError as Error).message,
            variant: 'destructive'
          });
        } finally {
          setIsCreatingResources(false);
        }
      }
      
      setResources(data);
      
    } catch (error: any) {
      console.error('Error loading resources:', error);
      toast({
        title: 'Error',
        description: 'Failed to load resources: ' + error.message,
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateResource = async (id: string, updates: Partial<Resource>) => {
    try {
      await resourcesService.update(id, updates);
      setResources(prev => prev.map(r => r.id === id ? { ...r, ...updates } : r));
      toast({
        title: 'Success',
        description: 'Resource updated successfully'
      });
    } catch (error: any) {
      console.error('Error updating resource:', error);
      toast({
        title: 'Error',
        description: 'Failed to update resource: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const handleAddResource = async (category: string, division: string) => {
    try {
      const resourceCode = await resourcesService.generateResourceCode(projectId, category, division);
      const newResource = await resourcesService.create({
        project_id: projectId,
        resource_code: resourceCode,
        category: category as 'P' | 'M' | 'E' | 'S' | 'C',
        division,
        resource_name: 'New Resource',
        unit: category === 'P' ? 'HR' : category === 'M' ? 'EA' : category === 'E' ? 'DAY' : 'LS',
        offer_rate: 0,
        offer_currency: 'USD',
        bid_rate: 0,
        discount_percent: 0,
        usage_quantity: 0,
        wastage_percent: category === 'M' ? 5 : 0,
        linked_price_codes: [],
        sort_order: resources.length * 5 + 5
      });
      
      setResources(prev => [...prev, newResource]);
      toast({
        title: 'Success',
        description: 'Resource added successfully'
      });
    } catch (error: any) {
      console.error('Error adding resource:', error);
      toast({
        title: 'Error',
        description: 'Failed to add resource: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  return {
    resources,
    setResources,
    groupedResources,
    isLoading,
    isCreatingResources,
    loadResources,
    handleUpdateResource,
    handleAddResource
  };
}
