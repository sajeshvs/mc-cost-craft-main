
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Resource } from '@/types/resources';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, ChevronDown, ChevronRight, ExternalLink, Calculator } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ResourcesJobCostTableProps {
  resources: Resource[];
  onUpdateResource: (id: string, updates: Partial<Resource>) => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
  selectedRows: Set<string>;
  onRowSelectionChange: (selectedRows: Set<string>) => void;
}

type FilterType = 'all' | 'used' | 'unused';

interface CellPosition {
  rowIndex: number;
  columnIndex: number;
}

export function ResourcesJobCostTable({
  resources,
  onUpdateResource,
  searchTerm,
  onSearchChange,
  selectedRows,
  onRowSelectionChange
}: ResourcesJobCostTableProps) {
  const { toast } = useToast();
  const [filter, setFilter] = useState<FilterType>('all');
  const [collapsedCategories, setCollapsedCategories] = useState<Set<string>>(new Set());
  const [editingCell, setEditingCell] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [focusedCell, setFocusedCell] = useState<CellPosition | null>(null);
  
  const inputRef = useRef<HTMLInputElement>(null);

  const columns = [
    { key: 'checkbox', label: '', width: 50, editable: false },
    { key: 'resource_code', label: 'Resource Code', width: 120, editable: false },
    { key: 'resource_name', label: 'Resource Name', width: 300, editable: true },
    { key: 'unit', label: 'Unit', width: 80, editable: true },
    { key: 'offer_rate', label: 'Base Rate', width: 100, editable: true },
    { key: 'discount_percent', label: 'Discount %', width: 100, editable: true },
    { key: 'final_rate', label: 'Final Rate', width: 100, editable: false },
    { key: 'used_quantity', label: 'Used Quantity', width: 120, editable: false },
    { key: 'used_amount', label: 'Used Amount', width: 120, editable: false },
    { key: 'wastage_percent', label: 'Wastage %', width: 100, editable: true },
    { key: 'wastage_amount', label: 'Wastage Amount', width: 120, editable: false },
    { key: 'total_amount', label: 'Total Amount', width: 120, editable: false },
    { key: 'linked_price_codes', label: 'Price Code Ref', width: 150, editable: false }
  ];

  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.resource_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         resource.resource_name.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!matchesSearch) return false;
    
    switch (filter) {
      case 'used':
        return (resource.used_quantity || 0) > 0;
      case 'unused':
        return (resource.used_quantity || 0) === 0;
      default:
        return true;
    }
  });

  const groupedResources = filteredResources.reduce((acc, resource) => {
    if (!acc[resource.category]) {
      acc[resource.category] = [];
    }
    acc[resource.category].push(resource);
    return acc;
  }, {} as Record<string, Resource[]>);

  const categoryTotals = Object.entries(groupedResources).reduce((acc, [category, categoryResources]) => {
    acc[category] = categoryResources.reduce((sum, resource) => sum + (resource.total_amount || 0), 0);
    return acc;
  }, {} as Record<string, number>);

  const grandTotal = Object.values(categoryTotals).reduce((sum, total) => sum + total, 0);

  const handleCellClick = useCallback((rowIndex: number, columnIndex: number, resource: Resource) => {
    const column = columns[columnIndex];
    if (column.key === 'checkbox' || column.key === 'linked_price_codes') return;

    setFocusedCell({ rowIndex, columnIndex });
    
    if (column.editable) {
      const cellId = `${resource.id}-${column.key}`;
      setEditingCell(cellId);
      setEditValue(String(resource[column.key as keyof Resource] || ''));
    }
  }, []);

  const handleCellSubmit = useCallback((resource: Resource, columnKey: string) => {
    if (!editingCell) return;

    let parsedValue: any = editValue;
    
    if (['offer_rate', 'discount_percent', 'wastage_percent'].includes(columnKey)) {
      parsedValue = parseFloat(editValue) || 0;
    }

    const updates: Partial<Resource> = { [columnKey]: parsedValue };
    onUpdateResource(resource.id, updates);
    
    setEditingCell(null);
    setEditValue('');
  }, [editingCell, editValue, onUpdateResource]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent, resource: Resource, columnKey: string) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleCellSubmit(resource, columnKey);
    } else if (e.key === 'Escape') {
      setEditingCell(null);
      setEditValue('');
    } else if (e.key === 'Tab') {
      e.preventDefault();
      handleCellSubmit(resource, columnKey);
      // Navigate to next editable cell
      navigateCell(e.shiftKey ? 'left' : 'right');
    }
  }, [handleCellSubmit]);

  const navigateCell = useCallback((direction: 'up' | 'down' | 'left' | 'right') => {
    if (!focusedCell) return;

    let { rowIndex, columnIndex } = focusedCell;
    
    switch (direction) {
      case 'up':
        rowIndex = Math.max(0, rowIndex - 1);
        break;
      case 'down':
        rowIndex = Math.min(filteredResources.length - 1, rowIndex + 1);
        break;
      case 'left':
        columnIndex = Math.max(1, columnIndex - 1);
        break;
      case 'right':
        columnIndex = Math.min(columns.length - 1, columnIndex + 1);
        break;
    }

    setFocusedCell({ rowIndex, columnIndex });
  }, [focusedCell, filteredResources.length]);

  const toggleCategory = useCallback((category: string) => {
    setCollapsedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(category)) {
        newSet.delete(category);
      } else {
        newSet.add(category);
      }
      return newSet;
    });
  }, []);

  const formatCurrency = useCallback((value: number | undefined) => {
    if (value === undefined || value === null) return '$0.00';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value);
  }, []);

  const renderPriceCodeLinks = useCallback((codes: string[]) => {
    if (!codes || codes.length === 0) return <span className="text-gray-400">-</span>;
    
    return (
      <div className="flex flex-wrap gap-1">
        {codes.slice(0, 2).map(code => (
          <Button
            key={code}
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-xs text-blue-600 hover:text-blue-800"
          >
            {code}
            <ExternalLink className="h-3 w-3 ml-1" />
          </Button>
        ))}
        {codes.length > 2 && (
          <span className="text-xs text-gray-500">+{codes.length - 2}</span>
        )}
      </div>
    );
  }, []);

  useEffect(() => {
    if (editingCell && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editingCell]);

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center gap-4 p-4 bg-gray-50 border-b">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search resources..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10 w-64"
          />
        </div>
        
        <Select value={filter} onValueChange={(value: FilterType) => setFilter(value)}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Resources</SelectItem>
            <SelectItem value="used">Used Only</SelectItem>
            <SelectItem value="unused">Unused Only</SelectItem>
          </SelectContent>
        </Select>

        <div className="flex items-center gap-2 ml-auto">
          <Calculator className="h-4 w-4 text-blue-600" />
          <span className="text-sm font-medium">Grand Total:</span>
          <span className="text-lg font-bold text-green-700">
            {formatCurrency(grandTotal)}
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse">
          <thead className="sticky top-0 bg-blue-100 z-10">
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="border border-gray-300 p-2 text-center text-sm font-bold text-gray-900 bg-blue-100"
                  style={{ width: column.width, minWidth: column.width }}
                >
                  {column.key === 'checkbox' ? (
                    <Checkbox
                      checked={selectedRows.size === filteredResources.length && filteredResources.length > 0}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          onRowSelectionChange(new Set(filteredResources.map(r => r.id)));
                        } else {
                          onRowSelectionChange(new Set());
                        }
                      }}
                    />
                  ) : (
                    column.label
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Object.entries(groupedResources).map(([category, categoryResources]) => {
              const isCollapsed = collapsedCategories.has(category);
              const categoryNames = {
                P: 'People (Labor & Staff)',
                M: 'Materials',
                E: 'Equipment',
                S: 'Subcontractors',
                C: 'Consultants'
              };
              
              return (
                <React.Fragment key={category}>
                  {/* Category Header */}
                  <tr className="bg-yellow-100 font-bold border-b-2 border-yellow-300">
                    <td className="border border-gray-300 p-2 text-center">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleCategory(category)}
                        className="p-0 h-6 w-6"
                      >
                        {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </td>
                    <td className="border border-gray-300 p-2 text-center font-bold">
                      {category}
                    </td>
                    <td className="border border-gray-300 p-2 text-left font-bold">
                      {categoryNames[category as keyof typeof categoryNames]}
                    </td>
                    <td colSpan={9} className="border border-gray-300 p-2"></td>
                    <td className="border border-gray-300 p-2 text-center font-bold text-green-700">
                      {formatCurrency(categoryTotals[category])}
                    </td>
                  </tr>

                  {/* Category Resources */}
                  {!isCollapsed && categoryResources.map((resource, rowIndex) => {
                    const globalRowIndex = filteredResources.indexOf(resource);
                    
                    return (
                      <tr
                        key={resource.id}
                        className={`hover:bg-gray-50 ${selectedRows.has(resource.id) ? 'bg-blue-50' : ''}`}
                      >
                        {columns.map((column, columnIndex) => {
                          const cellId = `${resource.id}-${column.key}`;
                          const isEditing = editingCell === cellId;
                          const isFocused = focusedCell?.rowIndex === globalRowIndex && focusedCell?.columnIndex === columnIndex;
                          
                          return (
                            <td
                              key={column.key}
                              className={`border border-gray-300 p-1 text-sm text-center ${
                                isFocused ? 'ring-2 ring-blue-500' : ''
                              } ${column.editable ? 'cursor-pointer hover:bg-gray-100' : ''}`}
                              style={{ width: column.width, minWidth: column.width }}
                              onClick={() => handleCellClick(globalRowIndex, columnIndex, resource)}
                            >
                              {column.key === 'checkbox' ? (
                                <Checkbox
                                  checked={selectedRows.has(resource.id)}
                                  onCheckedChange={(checked) => {
                                    const newSelected = new Set(selectedRows);
                                    if (checked) {
                                      newSelected.add(resource.id);
                                    } else {
                                      newSelected.delete(resource.id);
                                    }
                                    onRowSelectionChange(newSelected);
                                  }}
                                />
                              ) : column.key === 'linked_price_codes' ? (
                                renderPriceCodeLinks(resource.linked_price_codes || [])
                              ) : isEditing ? (
                                <Input
                                  ref={inputRef}
                                  value={editValue}
                                  onChange={(e) => setEditValue(e.target.value)}
                                  onBlur={() => handleCellSubmit(resource, column.key)}
                                  onKeyDown={(e) => handleKeyDown(e, resource, column.key)}
                                  className="h-8 text-sm border-0 p-1 focus:ring-0 text-center"
                                  type={['offer_rate', 'discount_percent', 'wastage_percent'].includes(column.key) ? 'number' : 'text'}
                                  step={column.key.includes('percent') ? '0.1' : '0.01'}
                                />
                              ) : (
                                <div className="p-1 min-h-[32px] flex items-center justify-center">
                                  {column.key.includes('rate') || column.key.includes('amount') ? 
                                    formatCurrency(resource[column.key as keyof Resource] as number) :
                                    column.key.includes('percent') ?
                                    `${resource[column.key as keyof Resource] || 0}%` :
                                    String(resource[column.key as keyof Resource] || '')
                                  }
                                </div>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Summary Panel */}
      <div className="border-t bg-gray-50 p-4">
        <div className="flex justify-between items-center">
          <div className="flex gap-6">
            {Object.entries(categoryTotals).map(([category, total]) => (
              <div key={category} className="text-sm">
                <span className="font-medium">{category}:</span>
                <span className="ml-1 font-bold text-blue-700">{formatCurrency(total)}</span>
              </div>
            ))}
          </div>
          <div className="text-lg font-bold">
            <span className="text-gray-700">Total: </span>
            <span className="text-green-700">{formatCurrency(grandTotal)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
