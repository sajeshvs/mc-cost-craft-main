
import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';

interface ResourceSettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ResourceSettingsDialog({ open, onOpenChange }: ResourceSettingsDialogProps) {
  const [settings, setSettings] = useState({
    autoCalculate: true,
    showWastage: true,
    defaultWastagePercent: 5,
    autoSave: true,
    showResourceCodes: true,
    compactView: false,
    showTotals: true
  });

  const handleSave = () => {
    // TODO: Save settings to global settings
    console.log('Saving resource settings:', settings);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Resource Settings</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="auto-calculate">Auto Calculate Totals</Label>
              <Switch
                id="auto-calculate"
                checked={settings.autoCalculate}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({ ...prev, autoCalculate: checked }))
                }
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="show-wastage">Show Wastage Columns</Label>
              <Switch
                id="show-wastage"
                checked={settings.showWastage}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({ ...prev, showWastage: checked }))
                }
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="auto-save">Auto Save Changes</Label>
              <Switch
                id="auto-save"
                checked={settings.autoSave}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({ ...prev, autoSave: checked }))
                }
              />
            </div>
          </div>

          <Separator />

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="show-codes">Show Resource Codes</Label>
              <Switch
                id="show-codes"
                checked={settings.showResourceCodes}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({ ...prev, showResourceCodes: checked }))
                }
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="compact-view">Compact View</Label>
              <Switch
                id="compact-view"
                checked={settings.compactView}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({ ...prev, compactView: checked }))
                }
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="show-totals">Show Total Columns</Label>
              <Switch
                id="show-totals"
                checked={settings.showTotals}
                onCheckedChange={(checked) => 
                  setSettings(prev => ({ ...prev, showTotals: checked }))
                }
              />
            </div>
          </div>

          <Separator />

          <div className="space-y-2">
            <Label htmlFor="default-wastage">Default Wastage % (Materials)</Label>
            <Input
              id="default-wastage"
              type="number"
              value={settings.defaultWastagePercent}
              onChange={(e) => 
                setSettings(prev => ({ ...prev, defaultWastagePercent: parseInt(e.target.value) || 0 }))
              }
              min="0"
              max="100"
            />
          </div>
        </div>

        <div className="flex justify-end gap-2 mt-6">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Save Settings
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
