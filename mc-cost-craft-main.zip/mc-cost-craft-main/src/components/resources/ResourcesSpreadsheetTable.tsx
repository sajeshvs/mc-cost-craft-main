
import React, { useState } from 'react';
import { RefreshCw, ChevronDown, ChevronRight } from 'lucide-react';
import { ResourcesTable } from './ResourcesTable';
import { ResourcesSpreadsheetToolbar } from './ResourcesSpreadsheetToolbar';
import { useResourcesData } from './hooks/useResourcesData';
import { useToast } from '@/hooks/use-toast';
import { RESOURCE_CATEGORIES } from '@/types/resources';

interface ResourcesSpreadsheetTableProps {
  projectId: string;
}

export function ResourcesSpreadsheetTable({ projectId }: ResourcesSpreadsheetTableProps) {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [collapsedCategories, setCollapsedCategories] = useState<Set<string>>(new Set());
  
  const {
    resources,
    setResources,
    groupedResources,
    isLoading,
    isCreatingResources,
    loadResources,
    handleUpdateResource,
    handleAddResource
  } = useResourcesData(projectId);

  const handleDeleteResources = async (ids: string[]) => {
    try {
      const { resourcesService } = await import('@/services/resources');
      await resourcesService.deleteMultiple(ids);
      setResources(prev => prev.filter(r => !ids.includes(r.id)));
      setSelectedRows(new Set()); // Clear selection after delete
      toast({
        title: 'Success',
        description: `${ids.length} resource(s) deleted successfully`
      });
    } catch (error: any) {
      console.error('Error deleting resources:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete resources: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const handleDeleteSelected = () => {
    if (selectedRows.size > 0) {
      handleDeleteResources(Array.from(selectedRows));
    }
  };

  const handleAddResourceToCategory = async () => {
    // Default to adding to first category
    await handleAddResource('P', '01');
  };

  const handleImportCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      toast({
        title: 'Import',
        description: 'CSV import functionality will be available soon'
      });
    }
  };

  const handleExportCSV = () => {
    toast({
      title: 'Export',
      description: 'CSV export functionality will be available soon'
    });
  };

  const handleRecreateResources = async () => {
    try {
      const { resourcesService } = await import('@/services/resources');
      await resourcesService.clearAllResources(projectId);
      await resourcesService.createDefaultResources(projectId);
      await loadResources();
      toast({
        title: 'Success',
        description: 'Default UFGS resources recreated successfully'
      });
    } catch (error: any) {
      console.error('Error recreating resources:', error);
      toast({
        title: 'Error',
        description: 'Failed to recreate resources: ' + error.message,
        variant: 'destructive'
      });
    }
  };

  const handleCalculateTotals = () => {
    toast({
      title: 'Calculate',
      description: 'Recalculating all resource totals...'
    });
  };

  const toggleCategoryCollapse = (categoryKey: string) => {
    setCollapsedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryKey)) {
        newSet.delete(categoryKey);
      } else {
        newSet.add(categoryKey);
      }
      return newSet;
    });
  };

  const handleExpandAll = () => {
    setCollapsedCategories(new Set());
  };

  const handleCollapseAll = () => {
    setCollapsedCategories(new Set(Object.keys(RESOURCE_CATEGORIES)));
  };

  if (isLoading || isCreatingResources) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex items-center gap-2 text-gray-500">
          <RefreshCw className="h-4 w-4 animate-spin" />
          <span>
            {isCreatingResources 
              ? 'Creating comprehensive UFGS resources...' 
              : 'Loading resources...'
            }
          </span>
        </div>
      </div>
    );
  }

  const filteredResources = resources.filter(resource =>
    searchTerm === '' || 
    resource.resource_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    resource.resource_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col">
      {/* Updated toolbar with correct props */}
      <ResourcesSpreadsheetToolbar
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        onAddResource={handleAddResourceToCategory}
        onDeleteSelected={handleDeleteSelected}
        selectedCount={selectedRows.size}
        onRefresh={loadResources}
        onImportCSV={handleImportCSV}
        onExportCSV={handleExportCSV}
        onExpandAll={handleExpandAll}
        onCollapseAll={handleCollapseAll}
        onCalculateTotals={handleCalculateTotals}
        onRecreateResources={handleRecreateResources}
      />
      
      {/* Resources organized by category with proper headings */}
      <div className="flex-1 overflow-auto">
        {Object.entries(RESOURCE_CATEGORIES).map(([categoryKey, categoryName]) => {
          const categoryResources = filteredResources.filter(r => r.category === categoryKey);
          const isCollapsed = collapsedCategories.has(categoryKey);

          if (categoryResources.length === 0) return null;

          return (
            <div key={categoryKey} className="mb-0">
              {/* Resources Table for this category with custom heading */}
              <ResourcesTable
                resources={categoryResources}
                onUpdateResource={handleUpdateResource}
                onDeleteResources={handleDeleteResources}
                onAddResource={() => handleAddResource(categoryKey, '01')}
                searchTerm=""
                onSearchChange={() => {}}
                showHeader={false}
                selectedRows={selectedRows}
                onRowSelectionChange={setSelectedRows}
                categoryKey={categoryKey}
                categoryName={categoryName}
                isCollapsed={isCollapsed}
                onToggleCollapse={() => toggleCategoryCollapse(categoryKey)}
              />
            </div>
          );
        })}

        {/* Show message if no resources match search */}
        {filteredResources.length === 0 && resources.length > 0 && (
          <div className="flex items-center justify-center h-64 text-gray-500">
            <div className="text-center">
              <p className="text-lg font-medium">No resources match your search</p>
              <p className="text-sm">Try a different search term</p>
            </div>
          </div>
        )}

        {resources.length === 0 && (
          <div className="flex items-center justify-center h-64 text-gray-500">
            <div className="text-center">
              <p className="text-lg font-medium">No resources found</p>
              <p className="text-sm">Click "Recreate UFGS" to create default resources</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
