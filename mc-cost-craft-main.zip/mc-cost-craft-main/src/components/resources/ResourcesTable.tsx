
import React, { useState, useRef, useEffect, Dispatch, SetStateAction } from 'react';
import { Resource } from '@/types/resources';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Search, Plus, Trash2, ChevronDown, ChevronRight, ExternalLink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ResourcesTableProps {
  resources: Resource[];
  onUpdateResource: (id: string, updates: Partial<Resource>) => void;
  onDeleteResources: (ids: string[]) => void;
  onAddResource: () => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
  showHeader?: boolean;
  selectedRows?: Set<string>;
  onRowSelectionChange?: Dispatch<SetStateAction<Set<string>>>;
  categoryKey?: string;
  categoryName?: string;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

interface CellPosition {
  rowIndex: number;
  columnIndex: number;
}

export function ResourcesTable({
  resources,
  onUpdateResource,
  onDeleteResources,
  onAddResource,
  searchTerm,
  onSearchChange,
  showHeader = true,
  selectedRows = new Set(),
  onRowSelectionChange,
  categoryKey,
  categoryName,
  isCollapsed = false,
  onToggleCollapse
}: ResourcesTableProps) {
  const { toast } = useToast();
  const [editingCell, setEditingCell] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<string>('');
  const [focusedCell, setFocusedCell] = useState<CellPosition | null>(null);
  
  const inputRef = useRef<HTMLInputElement>(null);

  const columns = [
    { key: 'checkbox', label: '', width: 50, editable: false },
    { key: 'resource_code', label: 'Resource Code', width: 120, editable: true },
    { key: 'resource_name', label: 'Description', width: 300, editable: true },
    { key: 'unit', label: 'Unit', width: 80, editable: true },
    { key: 'offer_rate', label: 'Offer Rate', width: 100, editable: true },
    { key: 'offer_currency', label: 'Offer Currency', width: 100, editable: true },
    { key: 'bid_rate', label: 'Bid Rate', width: 100, editable: true },
    { key: 'discount_percent', label: 'Discount %', width: 100, editable: true },
    { key: 'final_rate', label: 'Final Rate', width: 100, editable: false },
    { key: 'usage_quantity', label: 'Usage Quantity', width: 120, editable: true },
    { key: 'used_amount', label: 'Used Amount', width: 120, editable: false },
    { key: 'wastage_percent', label: 'Wastage %', width: 100, editable: true },
    { key: 'wastage_amount', label: 'Wastage Amount', width: 120, editable: false },
    { key: 'total_amount', label: 'Total Amount', width: 120, editable: false },
    { key: 'linked_price_codes', label: 'Price Code Ref', width: 150, editable: false }
  ];

  const filteredResources = resources.filter(resource =>
    resource.resource_code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    resource.resource_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCellClick = (rowIndex: number, columnIndex: number, resource: Resource) => {
    const cellId = `${resource.id}-${columns[columnIndex].key}`;
    const column = columns[columnIndex];
    
    if (column.key === 'checkbox' || column.key === 'linked_price_codes') return;

    setFocusedCell({ rowIndex, columnIndex });
    
    if (column.editable) {
      setEditingCell(cellId);
      setEditValue(String(resource[column.key as keyof Resource] || ''));
    }
  };

  const handleCellDoubleClick = (resource: Resource, columnKey: string) => {
    const column = columns.find(col => col.key === columnKey);
    if (column?.editable) {
      const cellId = `${resource.id}-${columnKey}`;
      setEditingCell(cellId);
      setEditValue(String(resource[columnKey as keyof Resource] || ''));
    }
  };

  const handleCellChange = (value: string) => {
    setEditValue(value);
  };

  const handleCellSubmit = (resource: Resource, columnKey: string) => {
    if (!editingCell) return;

    let parsedValue: any = editValue;
    
    if (['offer_rate', 'bid_rate', 'usage_quantity', 'discount_percent', 'wastage_percent'].includes(columnKey)) {
      parsedValue = parseFloat(editValue) || 0;
    }

    const updates: Partial<Resource> = { [columnKey]: parsedValue };
    
    onUpdateResource(resource.id, updates);
    setEditingCell(null);
    setEditValue('');
  };

  const handleKeyDown = (e: React.KeyboardEvent, resource: Resource, columnKey: string) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleCellSubmit(resource, columnKey);
    } else if (e.key === 'Escape') {
      setEditingCell(null);
      setEditValue('');
    } else if (e.key === 'Tab') {
      e.preventDefault();
      handleCellSubmit(resource, columnKey);
      navigateCell(e.shiftKey ? 'left' : 'right');
    }
  };

  const navigateCell = (direction: 'up' | 'down' | 'left' | 'right') => {
    if (!focusedCell) return;

    let { rowIndex, columnIndex } = focusedCell;
    
    switch (direction) {
      case 'up':
        rowIndex = Math.max(0, rowIndex - 1);
        break;
      case 'down':
        rowIndex = Math.min(filteredResources.length - 1, rowIndex + 1);
        break;
      case 'left':
        columnIndex = Math.max(1, columnIndex - 1);
        break;
      case 'right':
        columnIndex = Math.min(columns.length - 1, columnIndex + 1);
        break;
    }

    setFocusedCell({ rowIndex, columnIndex });
  };

  const handleRowSelect = (resourceId: string, selected: boolean) => {
    if (!onRowSelectionChange) return;
    
    const newSelected = new Set(selectedRows);
    if (selected) {
      newSelected.add(resourceId);
    } else {
      newSelected.delete(resourceId);
    }
    onRowSelectionChange(newSelected);
  };

  const handleSelectAll = (checked: boolean) => {
    if (!onRowSelectionChange) return;
    
    if (checked) {
      onRowSelectionChange(new Set(filteredResources.map(r => r.id)));
    } else {
      onRowSelectionChange(new Set());
    }
  };

  const handleDeleteSelected = () => {
    if (selectedRows.size > 0) {
      onDeleteResources(Array.from(selectedRows));
    }
  };

  const formatCurrency = (value: number | undefined, currency: string = 'USD') => {
    if (value === undefined || value === null) return '$0.00';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(value);
  };

  const renderPriceCodeLinks = (codes: string[]) => {
    if (!codes || codes.length === 0) return <span className="text-gray-400">-</span>;
    
    return (
      <div className="flex flex-wrap gap-1">
        {codes.slice(0, 2).map(code => (
          <Button
            key={code}
            variant="ghost"
            size="sm"
            className="h-6 px-2 text-xs text-blue-600 hover:text-blue-800"
          >
            {code}
            <ExternalLink className="h-3 w-3 ml-1" />
          </Button>
        ))}
        {codes.length > 2 && (
          <span className="text-xs text-gray-500">+{codes.length - 2}</span>
        )}
      </div>
    );
  };

  useEffect(() => {
    if (editingCell && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editingCell]);

  return (
    <div className="flex flex-col">
      {/* Only show search toolbar if showHeader is true */}
      {showHeader && (
        <div className="flex items-center gap-2 p-4 bg-gray-50 border-b">
          <div className="flex items-center gap-2 flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search resources..."
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Button onClick={onAddResource} size="sm" className="gap-2">
              <Plus className="h-4 w-4" />
              Add Resource
            </Button>
            {selectedRows.size > 0 && (
              <Button
                onClick={handleDeleteSelected}
                variant="destructive"
                size="sm"
                className="gap-2"
              >
                <Trash2 className="h-4 w-4" />
                Delete ({selectedRows.size})
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Table with sticky column headers */}
      <div className="overflow-auto">
        <table className="w-full border-collapse">
          {/* Sticky Column Headers */}
          <thead className="sticky top-0 bg-yellow-200 z-20">
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="border border-gray-200 p-2 text-center text-sm font-bold text-gray-900"
                  style={{ width: column.width, minWidth: column.width }}
                >
                  {column.key === 'checkbox' ? (
                    <Checkbox
                      checked={selectedRows.size === filteredResources.length && filteredResources.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  ) : (
                    column.label
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {/* Category Header Row */}
            {categoryKey && categoryName && (
              <tr className="bg-white border-b">
                <td className="border border-gray-200 p-1 text-sm text-center">
                  <button
                    onClick={onToggleCollapse}
                    className="flex items-center justify-center w-full h-full"
                  >
                    {isCollapsed ? (
                      <ChevronRight className="h-4 w-4 text-gray-600" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-gray-600" />
                    )}
                  </button>
                </td>
                <td className="border border-gray-200 p-1 text-sm text-center font-bold">
                  {categoryKey}
                </td>
                <td className="border border-gray-200 p-1 text-sm text-center font-bold">
                  {categoryName}
                </td>
                <td colSpan={11} className="border border-gray-200 p-1 text-sm text-center"></td>
                <td className="border border-gray-200 p-1 text-sm text-center font-bold">
                  {formatCurrency(filteredResources.reduce((sum, r) => sum + (r.total_amount || 0), 0))}
                </td>
              </tr>
            )}
            
            {/* Resource Rows - only show when not collapsed */}
            {!isCollapsed && filteredResources.map((resource, rowIndex) => (
              <tr
                key={resource.id}
                className={`hover:bg-gray-50 ${selectedRows.has(resource.id) ? 'bg-blue-50' : ''}`}
              >
                {columns.map((column, columnIndex) => {
                  const cellId = `${resource.id}-${column.key}`;
                  const isEditing = editingCell === cellId;
                  const isFocused = focusedCell?.rowIndex === rowIndex && focusedCell?.columnIndex === columnIndex;
                  
                  return (
                    <td
                      key={column.key}
                      className={`border border-gray-200 p-1 text-sm text-center ${
                        isFocused ? 'ring-2 ring-blue-500' : ''
                      } ${column.editable ? 'cursor-pointer' : ''}`}
                      style={{ width: column.width, minWidth: column.width }}
                      onClick={() => handleCellClick(rowIndex, columnIndex, resource)}
                      onDoubleClick={() => handleCellDoubleClick(resource, column.key)}
                    >
                      {column.key === 'checkbox' ? (
                        <Checkbox
                          checked={selectedRows.has(resource.id)}
                          onCheckedChange={(checked) => handleRowSelect(resource.id, checked as boolean)}
                        />
                      ) : column.key === 'linked_price_codes' ? (
                        renderPriceCodeLinks(resource.linked_price_codes || [])
                      ) : isEditing ? (
                        <Input
                          ref={inputRef}
                          value={editValue}
                          onChange={(e) => handleCellChange(e.target.value)}
                          onBlur={() => handleCellSubmit(resource, column.key)}
                          onKeyDown={(e) => handleKeyDown(e, resource, column.key)}
                          className="h-8 text-sm border-0 p-1 focus:ring-0 text-center"
                          type={['offer_rate', 'bid_rate', 'usage_quantity', 'discount_percent', 'wastage_percent'].includes(column.key) ? 'number' : 'text'}
                          step={column.key.includes('percent') ? '0.1' : '0.01'}
                        />
                      ) : (
                        <div className="p-1 min-h-[32px] flex items-center justify-center">
                          {column.key.includes('rate') || column.key.includes('amount') ? 
                            formatCurrency(resource[column.key as keyof Resource] as number, resource.offer_currency) :
                            column.key.includes('percent') ?
                            `${resource[column.key as keyof Resource] || 0}%` :
                            String(resource[column.key as keyof Resource] || '')
                          }
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
