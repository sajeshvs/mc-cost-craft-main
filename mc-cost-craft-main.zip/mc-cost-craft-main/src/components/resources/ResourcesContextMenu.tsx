
import React, { useEffect, useRef } from 'react';
import { Copy, Clipboard, Trash2 } from 'lucide-react';

interface ResourcesContextMenuProps {
  x: number;
  y: number;
  onClose: () => void;
  onCopy: () => void;
  onPaste: () => void;
  onDelete: () => void;
  canPaste: boolean;
  selectedCount: number;
}

export function ResourcesContextMenu({
  x,
  y,
  onClose,
  onCopy,
  onPaste,
  onDelete,
  canPaste,
  selectedCount
}: ResourcesContextMenuProps) {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [onClose]);

  const menuItems = [
    {
      icon: Copy,
      label: 'Copy',
      onClick: () => { onCopy(); onClose(); },
      disabled: selectedCount === 0
    },
    {
      icon: Clipboard,
      label: 'Paste',
      onClick: () => { onPaste(); onClose(); },
      disabled: !canPaste
    },
    {
      icon: Trash2,
      label: 'Delete',
      onClick: () => { onDelete(); onClose(); },
      disabled: selectedCount === 0,
      danger: true
    }
  ];

  return (
    <div
      ref={menuRef}
      className="fixed bg-white border border-gray-200 rounded-md shadow-lg py-1 z-50 min-w-32"
      style={{ left: x, top: y }}
    >
      {menuItems.map((item, index) => (
        <button
          key={index}
          onClick={item.onClick}
          disabled={item.disabled}
          className={`w-full flex items-center gap-2 px-3 py-2 text-sm text-left hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed ${
            item.danger ? 'text-red-600 hover:bg-red-50' : 'text-gray-700'
          }`}
        >
          <item.icon className="h-4 w-4" />
          {item.label}
        </button>
      ))}
    </div>
  );
}
