
import React, { useState, Dispatch, SetStateAction } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Trash2, RefreshCw, Plus, Download, Upload, Expand, Shrink, Calculator, Settings, RotateCcw, Search } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { ResourceSettingsDialog } from './ResourceSettingsDialog';

interface ResourcesSpreadsheetToolbarProps {
  searchTerm: string;
  onSearchChange: Dispatch<SetStateAction<string>>;
  onAddResource: () => Promise<void>;
  onDeleteSelected: () => void;
  selectedCount: number;
  onRefresh: () => Promise<void>;
  onImportCSV: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onExportCSV: () => void;
  onExpandAll: () => void;
  onCollapseAll: () => void;
  onCalculateTotals: () => void;
  onRecreateResources: () => void;
}

export function ResourcesSpreadsheetToolbar({
  searchTerm,
  onSearchChange,
  onAddResource,
  onDeleteSelected,
  selectedCount,
  onRefresh,
  onImportCSV,
  onExportCSV,
  onExpandAll,
  onCollapseAll,
  onCalculateTotals,
  onRecreateResources
}: ResourcesSpreadsheetToolbarProps) {
  const [showSettings, setShowSettings] = useState(false);

  return (
    <>
      <div className="flex items-center gap-2 p-3 bg-gray-50 border-b border-gray-200 overflow-x-auto min-w-fit">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search resources..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-10 w-64 h-8"
          />
        </div>

        <div className="h-6 w-px bg-gray-300" />

        {/* Primary Actions */}
        <Button
          variant="outline"
          size="sm"
          onClick={onRefresh}
          className="h-8 whitespace-nowrap gap-2"
        >
          <RefreshCw className="h-4 w-4" />
          Refresh
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={onAddResource}
          className="h-8 whitespace-nowrap gap-2"
        >
          <Plus className="h-4 w-4" />
          Add
        </Button>
        
        {selectedCount > 0 && (
          <Button
            variant="outline"
            size="sm"
            onClick={onDeleteSelected}
            className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50 whitespace-nowrap gap-2"
          >
            <Trash2 className="h-4 w-4" />
            Delete ({selectedCount})
          </Button>
        )}

        <div className="h-6 w-px bg-gray-300" />

        {/* View Controls */}
        <Button
          variant="outline"
          size="sm"
          onClick={onExpandAll}
          className="h-8 whitespace-nowrap gap-2"
        >
          <Expand className="h-4 w-4" />
          Expand All
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={onCollapseAll}
          className="h-8 whitespace-nowrap gap-2"
        >
          <Shrink className="h-4 w-4" />
          Collapse All
        </Button>

        <div className="h-6 w-px bg-gray-300" />

        {/* File Operations */}
        <input
          type="file"
          accept=".csv"
          onChange={onImportCSV}
          className="hidden"
          id="resource-csv-import"
        />
        <label htmlFor="resource-csv-import">
          <Button variant="outline" size="sm" className="h-8 whitespace-nowrap gap-2" asChild>
            <span>
              <Upload className="h-4 w-4" />
              Import
            </span>
          </Button>
        </label>

        <Button
          variant="outline"
          size="sm"
          onClick={onExportCSV}
          className="h-8 whitespace-nowrap gap-2"
        >
          <Download className="h-4 w-4" />
          Export
        </Button>

        <div className="h-6 w-px bg-gray-300" />

        {/* Calculation Tools */}
        <Button
          variant="outline"
          size="sm"
          onClick={onCalculateTotals}
          className="h-8 whitespace-nowrap gap-2"
        >
          <Calculator className="h-4 w-4" />
          Calculate
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={onRecreateResources}
          className="h-8 whitespace-nowrap gap-2 text-orange-600 hover:text-orange-700 hover:bg-orange-50"
        >
          <RotateCcw className="h-4 w-4" />
          Recreate UFGS
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 gap-2">
              <Settings className="h-4 w-4" />
              More
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setShowSettings(true)}>
              <Settings className="h-4 w-4 mr-2" />
              Resource Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onCalculateTotals}>
              <Calculator className="h-4 w-4 mr-2" />
              Recalculate All
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onRecreateResources}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Recreate Default Resources
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <ResourceSettingsDialog 
        open={showSettings}
        onOpenChange={setShowSettings}
      />
    </>
  );
}
