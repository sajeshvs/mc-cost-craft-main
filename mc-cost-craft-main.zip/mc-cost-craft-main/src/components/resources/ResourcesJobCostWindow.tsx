
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Maximize2, Minimize2, X, Move } from 'lucide-react';
import { ResourcesJobCostTable } from './ResourcesJobCostTable';
import { useResourcesData } from './hooks/useResourcesData';

interface ResourcesJobCostWindowProps {
  projectId: string;
  isOpen: boolean;
  onClose: () => void;
}

export function ResourcesJobCostWindow({ projectId, isOpen, onClose }: ResourcesJobCostWindowProps) {
  const [isMaximized, setIsMaximized] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());

  const {
    resources,
    isLoading,
    handleUpdateResource
  } = useResourcesData(projectId);

  if (!isOpen || isMinimized) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent 
        className={`${
          isMaximized 
            ? 'max-w-[95vw] max-h-[95vh] w-[95vw] h-[95vh]' 
            : 'max-w-[1400px] max-h-[800px] w-[1400px] h-[800px]'
        } p-0 gap-0`}
      >
        {/* Window Header */}
        <DialogHeader className="flex flex-row items-center justify-between p-4 border-b bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <div className="flex items-center gap-2">
            <Move className="h-4 w-4 cursor-move" />
            <DialogTitle className="text-white">
              Resources - Job Cost Summary ({resources.length} items)
            </DialogTitle>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMinimized(true)}
              className="text-white hover:bg-white/20 h-8 w-8 p-0"
            >
              <Minimize2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMaximized(!isMaximized)}
              className="text-white hover:bg-white/20 h-8 w-8 p-0"
            >
              <Maximize2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-white hover:bg-white/20 h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        {/* Content */}
        <div className="flex-1 min-h-0">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p>Loading resources...</p>
              </div>
            </div>
          ) : (
            <ResourcesJobCostTable
              resources={resources}
              onUpdateResource={handleUpdateResource}
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              selectedRows={selectedRows}
              onRowSelectionChange={setSelectedRows}
            />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
