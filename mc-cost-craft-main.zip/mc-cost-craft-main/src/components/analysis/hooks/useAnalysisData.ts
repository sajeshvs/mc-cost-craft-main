
import { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { priceCodeAnalysisService } from '@/services/priceCodeAnalysis';
import { priceCodeVersionsService } from '@/services/priceCodeVersions';
import { priceListService } from '@/services/priceList';
import { resourceLibraryService } from '@/services/resourceLibrary';
import { useToast } from '@/hooks/use-toast';

export interface AnalysisRow {
  id: string;
  priceCode: string;
  description: string;
  division: string;
  resourceCode: string;
  resourceName: string;
  category: 'P' | 'M' | 'E' | 'S' | 'C';
  unit: string;
  quantity: number;
  unitRate: number;
  wastagePercent: number;
  finalRate: number;
  amount: number;
  status: 'draft' | 'submitted' | 'approved';
  versionNumber: number;
  versionId?: string;
  hasAnalysis: boolean;
}

export function useAnalysisData(projectId: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [divisionFilter, setDivisionFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());

  // Load price list
  const { data: priceList = [] } = useQuery({
    queryKey: ['price-list', projectId],
    queryFn: () => priceListService.getByProject(projectId),
    enabled: !!projectId
  });

  // Load resource library for resource lookups
  const { data: resourceLibrary = [] } = useQuery({
    queryKey: ['resource-library'],
    queryFn: () => resourceLibraryService.getAll()
  });

  // Create a comprehensive analysis data set
  const { data: analysisData = [], isLoading, refetch } = useQuery({
    queryKey: ['analysis-data', projectId],
    queryFn: async () => {
      if (!projectId) return [];
      
      const allAnalysisData: AnalysisRow[] = [];
      
      // For each price code, either show existing analysis or create placeholder rows
      for (const priceItem of priceList) {
        try {
          // Try to get current version
          const currentVersion = await priceCodeVersionsService.getCurrentVersion(projectId, priceItem.price_code);
          
          if (currentVersion) {
            // Get analysis resources for this version
            const resources = await priceCodeAnalysisService.getByVersion(currentVersion.id);
            
            if (resources.length > 0) {
              // Add rows for existing analysis
              resources.forEach(resource => {
                const finalRate = resource.unit_rate * (1 + resource.wastage_percent / 100);
                const amount = resource.quantity * finalRate;
                
                allAnalysisData.push({
                  id: resource.id,
                  priceCode: resource.price_code,
                  description: priceItem.description,
                  division: priceItem.division,
                  resourceCode: resource.resource_code,
                  resourceName: resource.resource_name,
                  category: resource.category,
                  unit: resource.unit,
                  quantity: resource.quantity,
                  unitRate: resource.unit_rate,
                  wastagePercent: resource.wastage_percent,
                  finalRate,
                  amount,
                  status: currentVersion.status,
                  versionNumber: currentVersion.version_number,
                  versionId: currentVersion.id,
                  hasAnalysis: true
                });
              });
            } else {
              // Add placeholder row for price code with no resources
              allAnalysisData.push({
                id: `placeholder-${priceItem.price_code}`,
                priceCode: priceItem.price_code,
                description: priceItem.description,
                division: priceItem.division,
                resourceCode: '',
                resourceName: 'No resources added',
                category: 'M',
                unit: priceItem.unit,
                quantity: 0,
                unitRate: 0,
                wastagePercent: 0,
                finalRate: 0,
                amount: 0,
                status: currentVersion.status,
                versionNumber: currentVersion.version_number,
                versionId: currentVersion.id,
                hasAnalysis: false
              });
            }
          } else {
            // Add placeholder row for price code with no version
            allAnalysisData.push({
              id: `no-version-${priceItem.price_code}`,
              priceCode: priceItem.price_code,
              description: priceItem.description,
              division: priceItem.division,
              resourceCode: '',
              resourceName: 'Analysis not started',
              category: 'M',
              unit: priceItem.unit,
              quantity: 0,
              unitRate: 0,
              wastagePercent: 0,
              finalRate: 0,
              amount: 0,
              status: 'draft',
              versionNumber: 0,
              hasAnalysis: false
            });
          }
        } catch (error) {
          console.error(`Error loading analysis for price code ${priceItem.price_code}:`, error);
          // Add error placeholder
          allAnalysisData.push({
            id: `error-${priceItem.price_code}`,
            priceCode: priceItem.price_code,
            description: priceItem.description,
            division: priceItem.division,
            resourceCode: '',
            resourceName: 'Error loading analysis',
            category: 'M',
            unit: priceItem.unit,
            quantity: 0,
            unitRate: 0,
            wastagePercent: 0,
            finalRate: 0,
            amount: 0,
            status: 'draft',
            versionNumber: 0,
            hasAnalysis: false
          });
        }
      }
      
      return allAnalysisData.sort((a, b) => a.priceCode.localeCompare(b.priceCode));
    },
    enabled: !!projectId && priceList.length > 0
  });

  // Filter data
  const filteredData = useMemo(() => {
    return analysisData.filter(row => {
      const matchesSearch = !searchTerm || 
        row.priceCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.resourceCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.resourceName.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesDivision = divisionFilter === 'all' || row.division === divisionFilter;
      const matchesCategory = categoryFilter === 'all' || row.category === categoryFilter;
      const matchesStatus = statusFilter === 'all' || row.status === statusFilter;
      
      return matchesSearch && matchesDivision && matchesCategory && matchesStatus;
    });
  }, [analysisData, searchTerm, divisionFilter, categoryFilter, statusFilter]);

  // Calculate totals
  const totals = useMemo(() => {
    const calculatedTotals = {
      labor: 0,
      material: 0,
      equipment: 0,
      subcontractor: 0,
      consultant: 0,
      netRate: 0
    };

    filteredData.forEach(row => {
      if (row.hasAnalysis) {
        switch (row.category) {
          case 'P':
            calculatedTotals.labor += row.amount;
            break;
          case 'M':
            calculatedTotals.material += row.amount;
            break;
          case 'E':
            calculatedTotals.equipment += row.amount;
            break;
          case 'S':
            calculatedTotals.subcontractor += row.amount;
            break;
          case 'C':
            calculatedTotals.consultant += row.amount;
            break;
        }
      }
    });

    calculatedTotals.netRate = Object.values(calculatedTotals).reduce((sum, val) => sum + val, 0) - calculatedTotals.netRate;

    return calculatedTotals;
  }, [filteredData]);

  // Get unique values for filters
  const uniqueDivisions = useMemo(() => 
    Array.from(new Set(analysisData.map(row => row.division))).sort(),
    [analysisData]
  );

  const totalPriceCodes = useMemo(() => 
    new Set(analysisData.map(row => row.priceCode)).size,
    [analysisData]
  );

  // Update row mutation
  const updateRowMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<AnalysisRow> }) => {
      const updateData: any = {};
      
      if (updates.quantity !== undefined) updateData.quantity = updates.quantity;
      if (updates.unitRate !== undefined) updateData.unit_rate = updates.unitRate;
      if (updates.wastagePercent !== undefined) updateData.wastage_percent = updates.wastagePercent;
      
      // Calculate new total_amount
      const row = analysisData.find(r => r.id === id);
      if (row) {
        const newQuantity = updates.quantity ?? row.quantity;
        const newUnitRate = updates.unitRate ?? row.unitRate;
        const newWastagePercent = updates.wastagePercent ?? row.wastagePercent;
        const finalRate = newUnitRate * (1 + newWastagePercent / 100);
        updateData.total_amount = newQuantity * finalRate;
      }
      
      return await priceCodeAnalysisService.update(id, updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['analysis-data', projectId] });
      toast({
        title: 'Success',
        description: 'Row updated successfully'
      });
    },
    onError: (error: any) => {
      console.error('Error updating row:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to update row',
        variant: 'destructive'
      });
    }
  });

  // Delete rows mutation
  const deleteRowsMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      // Filter out placeholder IDs
      const realIds = ids.filter(id => !id.startsWith('placeholder-') && !id.startsWith('no-version-') && !id.startsWith('error-'));
      if (realIds.length > 0) {
        await Promise.all(realIds.map(id => priceCodeAnalysisService.delete(id)));
      }
    },
    onSuccess: (_, ids) => {
      setSelectedRows(new Set());
      queryClient.invalidateQueries({ queryKey: ['analysis-data', projectId] });
      toast({
        title: 'Success',
        description: `${ids.length} row(s) deleted successfully`
      });
    },
    onError: (error: any) => {
      console.error('Error deleting rows:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete rows',
        variant: 'destructive'
      });
    }
  });

  const handleUpdateRow = async (id: string, updates: Partial<AnalysisRow>) => {
    updateRowMutation.mutate({ id, updates });
  };

  const handleDeleteRows = async (ids: string[]) => {
    deleteRowsMutation.mutate(ids);
  };

  const handleDuplicateRow = async (id: string) => {
    const row = analysisData.find(r => r.id === id);
    if (!row || !row.hasAnalysis) return;

    try {
      const newResourceData = {
        project_id: projectId,
        price_code: row.priceCode,
        resource_code: row.resourceCode + '_copy',
        resource_name: row.resourceName + ' (Copy)',
        category: row.category,
        unit: row.unit,
        quantity: row.quantity,
        unit_rate: row.unitRate,
        wastage_percent: row.wastagePercent,
        total_amount: row.amount,
        sort_order: analysisData.length,
        version_id: row.versionId
      };

      await priceCodeAnalysisService.create(newResourceData);
      queryClient.invalidateQueries({ queryKey: ['analysis-data', projectId] });
      
      toast({
        title: 'Success',
        description: 'Row duplicated successfully'
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to duplicate row',
        variant: 'destructive'
      });
    }
  };

  const handleExportCSV = () => {
    const csvContent = [
      ['Price Code', 'Description', 'Division', 'Resource Code', 'Resource Name', 'Category', 'Unit', 'Quantity', 'Unit Rate', 'Wastage %', 'Final Rate', 'Amount', 'Status', 'Version'].join(','),
      ...filteredData.map(row => [
        row.priceCode,
        `"${row.description}"`,
        row.division,
        row.resourceCode,
        `"${row.resourceName}"`,
        row.category,
        row.unit,
        row.quantity,
        row.unitRate,
        row.wastagePercent,
        row.finalRate.toFixed(2),
        row.amount.toFixed(2),
        row.status,
        row.versionNumber
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analysis-export-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportCSV = async (file: File) => {
    try {
      const text = await file.text();
      const lines = text.split('\n');
      const headers = lines[0].split(',');
      
      const requiredHeaders = ['Price Code', 'Resource Code', 'Resource Name', 'Category', 'Unit', 'Quantity', 'Unit Rate', 'Wastage %'];
      const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));
      
      if (missingHeaders.length > 0) {
        throw new Error(`Missing required columns: ${missingHeaders.join(', ')}`);
      }

      const importData = [];
      for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        
        const values = lines[i].split(',');
        const rowData: any = {};
        
        headers.forEach((header, index) => {
          rowData[header.trim()] = values[index]?.replace(/"/g, '').trim();
        });

        const priceItem = priceList.find(p => p.price_code === rowData['Price Code']);
        if (!priceItem) {
          console.warn(`Price code ${rowData['Price Code']} not found in price list`);
          continue;
        }

        let version = await priceCodeVersionsService.getCurrentVersion(projectId, rowData['Price Code']);
        if (!version) {
          version = await priceCodeVersionsService.createVersion({
            price_code: rowData['Price Code'],
            project_id: projectId,
            status: 'draft',
            created_by: '', // Will be set by service
          });
        }

        importData.push({
          project_id: projectId,
          price_code: rowData['Price Code'],
          resource_code: rowData['Resource Code'],
          resource_name: rowData['Resource Name'],
          category: rowData['Category'],
          unit: rowData['Unit'],
          quantity: parseFloat(rowData['Quantity']) || 0,
          unit_rate: parseFloat(rowData['Unit Rate']) || 0,
          wastage_percent: parseFloat(rowData['Wastage %']) || 0,
          total_amount: 0,
          sort_order: i - 1,
          version_id: version.id
        });
      }

      if (importData.length > 0) {
        await priceCodeAnalysisService.bulkCreate(importData);
        queryClient.invalidateQueries({ queryKey: ['analysis-data', projectId] });
        
        toast({
          title: 'Success',
          description: `Imported ${importData.length} analysis records`
        });
      }
    } catch (error: any) {
      console.error('Import error:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to import CSV',
        variant: 'destructive'
      });
    }
  };

  const refreshData = () => {
    refetch();
  };

  return {
    data: filteredData,
    isLoading,
    searchTerm,
    setSearchTerm,
    divisionFilter,
    setDivisionFilter,
    categoryFilter,
    setCategoryFilter,
    statusFilter,
    setStatusFilter,
    selectedRows,
    setSelectedRows,
    totals,
    uniqueDivisions,
    totalPriceCodes,
    handleUpdateRow,
    handleDeleteRows,
    handleDuplicateRow,
    handleExportCSV,
    handleImportCSV,
    refreshData
  };
}
