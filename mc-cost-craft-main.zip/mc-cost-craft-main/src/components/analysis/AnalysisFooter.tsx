
import React from 'react';
import { Badge } from '@/components/ui/badge';

interface AnalysisFooterProps {
  totals: {
    labor: number;
    material: number;
    equipment: number;
    subcontractor: number;
    consultant: number;
    netRate: number;
  };
}

export function AnalysisFooter({ totals }: AnalysisFooterProps) {
  return (
    <div className="border-t bg-gray-50 p-4">
      <div className="grid grid-cols-6 gap-4">
        <div className="text-center">
          <div className="text-xs text-gray-600 mb-1">Labor (P)</div>
          <Badge className="bg-blue-100 text-blue-800 text-sm">
            ${totals.labor.toFixed(2)}
          </Badge>
        </div>
        
        <div className="text-center">
          <div className="text-xs text-gray-600 mb-1">Material (M)</div>
          <Badge className="bg-green-100 text-green-800 text-sm">
            ${totals.material.toFixed(2)}
          </Badge>
        </div>
        
        <div className="text-center">
          <div className="text-xs text-gray-600 mb-1">Equipment (E)</div>
          <Badge className="bg-yellow-100 text-yellow-800 text-sm">
            ${totals.equipment.toFixed(2)}
          </Badge>
        </div>
        
        <div className="text-center">
          <div className="text-xs text-gray-600 mb-1">Subcontractor (S)</div>
          <Badge className="bg-purple-100 text-purple-800 text-sm">
            ${totals.subcontractor.toFixed(2)}
          </Badge>
        </div>
        
        <div className="text-center">
          <div className="text-xs text-gray-600 mb-1">Consultant (C)</div>
          <Badge className="bg-red-100 text-red-800 text-sm">
            ${totals.consultant.toFixed(2)}
          </Badge>
        </div>
        
        <div className="text-center">
          <div className="text-xs text-gray-600 mb-1">Net Rate Total</div>
          <Badge className="bg-gray-900 text-white text-lg font-bold">
            ${totals.netRate.toFixed(2)}
          </Badge>
        </div>
      </div>
    </div>
  );
}
