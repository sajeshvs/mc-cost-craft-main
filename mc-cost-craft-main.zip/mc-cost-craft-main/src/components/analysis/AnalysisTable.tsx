
import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, Edit, Copy, Trash2, History, Plus } from 'lucide-react';
import { AnalysisRow } from './hooks/useAnalysisData';

interface AnalysisTableProps {
  data: AnalysisRow[];
  isLoading: boolean;
  selectedRows: Set<string>;
  setSelectedRows: (rows: Set<string>) => void;
  handleUpdateRow: (id: string, updates: Partial<AnalysisRow>) => void;
  handleDuplicateRow: (id: string) => void;
  onShowVersionHistory?: (priceCode: string) => void;
}

export function AnalysisTable({
  data,
  isLoading,
  selectedRows,
  setSelectedRows,
  handleUpdateRow,
  handleDuplicateRow,
  onShowVersionHistory
}: AnalysisTableProps) {
  const [editingCell, setEditingCell] = useState<{id: string, field: string} | null>(null);
  const [editValue, setEditValue] = useState('');

  const handleCellEdit = (id: string, field: string, currentValue: number) => {
    // Don't allow editing placeholder rows
    const row = data.find(r => r.id === id);
    if (!row?.hasAnalysis) return;
    
    setEditingCell({ id, field });
    setEditValue(currentValue.toString());
  };

  const handleCellSave = () => {
    if (!editingCell) return;
    
    const numValue = parseFloat(editValue);
    if (!isNaN(numValue)) {
      const updates: Partial<AnalysisRow> = {};
      
      switch (editingCell.field) {
        case 'quantity':
          updates.quantity = numValue;
          break;
        case 'unitRate':
          updates.unitRate = numValue;
          break;
        case 'wastagePercent':
          updates.wastagePercent = numValue;
          break;
      }
      
      handleUpdateRow(editingCell.id, updates);
    }
    
    setEditingCell(null);
    setEditValue('');
  };

  const handleCellCancel = () => {
    setEditingCell(null);
    setEditValue('');
  };

  const handleRowSelect = (id: string, checked: boolean) => {
    const newSelection = new Set(selectedRows);
    if (checked) {
      newSelection.add(id);
    } else {
      newSelection.delete(id);
    }
    setSelectedRows(newSelection);
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedRows(new Set(data.map(row => row.id)));
    } else {
      setSelectedRows(new Set());
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'P': return 'bg-blue-100 text-blue-800';
      case 'M': return 'bg-green-100 text-green-800';
      case 'E': return 'bg-yellow-100 text-yellow-800';
      case 'S': return 'bg-purple-100 text-purple-800';
      case 'C': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-yellow-100 text-yellow-800';
      case 'submitted': return 'bg-blue-100 text-blue-800';
      case 'approved': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading analysis data...</div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Table container with both horizontal and vertical scrolling */}
      <div className="flex-1 overflow-auto border border-gray-200">
        <table className="w-full border-collapse min-w-[1400px]">
          {/* Sticky header */}
          <thead className="bg-gray-50 sticky top-0 z-10">
            <tr>
              <th className="border border-gray-200 p-2 text-left w-12">
                <Checkbox
                  checked={selectedRows.size === data.length && data.length > 0}
                  onCheckedChange={handleSelectAll}
                />
              </th>
              <th className="border border-gray-200 p-2 text-left w-32">Price Code</th>
              <th className="border border-gray-200 p-2 text-left w-48">Description</th>
              <th className="border border-gray-200 p-2 text-left w-20">Division</th>
              <th className="border border-gray-200 p-2 text-left w-32">Resource Code</th>
              <th className="border border-gray-200 p-2 text-left w-48">Resource Name</th>
              <th className="border border-gray-200 p-2 text-left w-20">Category</th>
              <th className="border border-gray-200 p-2 text-left w-16">Unit</th>
              <th className="border border-gray-200 p-2 text-left w-24">Qty/Prod</th>
              <th className="border border-gray-200 p-2 text-left w-24">Unit Rate</th>
              <th className="border border-gray-200 p-2 text-left w-24">Wastage %</th>
              <th className="border border-gray-200 p-2 text-left w-24">Final Rate</th>
              <th className="border border-gray-200 p-2 text-left w-24">Amount</th>
              <th className="border border-gray-200 p-2 text-left w-32">Status</th>
              <th className="border border-gray-200 p-2 text-left w-20">Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((row) => (
              <tr 
                key={row.id} 
                className={`hover:bg-gray-50 ${!row.hasAnalysis ? 'bg-gray-50' : ''}`}
              >
                <td className="border border-gray-200 p-2">
                  <Checkbox
                    checked={selectedRows.has(row.id)}
                    onCheckedChange={(checked) => handleRowSelect(row.id, checked as boolean)}
                  />
                </td>
                <td className="border border-gray-200 p-2 font-mono text-sm">
                  <div className="flex items-center gap-2">
                    {row.priceCode}
                    {onShowVersionHistory && row.hasAnalysis && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onShowVersionHistory(row.priceCode)}
                        className="h-4 w-4 p-0 opacity-0 group-hover:opacity-100"
                      >
                        <History className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </td>
                <td className="border border-gray-200 p-2 text-sm">
                  {row.description}
                </td>
                <td className="border border-gray-200 p-2 text-sm text-center">
                  {row.division}
                </td>
                <td className="border border-gray-200 p-2 font-mono text-sm">
                  {row.resourceCode || (
                    <span className="text-gray-400 italic">
                      {row.hasAnalysis ? 'No code' : 'Add resource'}
                    </span>
                  )}
                </td>
                <td className="border border-gray-200 p-2 text-sm">
                  <div className="flex items-center gap-2">
                    {row.resourceName}
                    {!row.hasAnalysis && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 text-green-600 hover:text-green-700"
                        title="Add resource"
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                </td>
                <td className="border border-gray-200 p-2 text-center">
                  {row.hasAnalysis ? (
                    <Badge className={getCategoryColor(row.category)}>
                      {row.category}
                    </Badge>
                  ) : (
                    <span className="text-gray-400">-</span>
                  )}
                </td>
                <td className="border border-gray-200 p-2 text-sm text-center">
                  {row.unit}
                </td>
                <td className="border border-gray-200 p-2">
                  {row.hasAnalysis ? (
                    editingCell?.id === row.id && editingCell?.field === 'quantity' ? (
                      <Input
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={handleCellSave}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleCellSave();
                          if (e.key === 'Escape') handleCellCancel();
                        }}
                        className="h-6 text-xs"
                        autoFocus
                      />
                    ) : (
                      <div
                        className="cursor-pointer hover:bg-gray-100 p-1 rounded text-sm text-right"
                        onClick={() => handleCellEdit(row.id, 'quantity', row.quantity)}
                      >
                        {row.quantity.toFixed(2)}
                      </div>
                    )
                  ) : (
                    <span className="text-gray-400">0.00</span>
                  )}
                </td>
                <td className="border border-gray-200 p-2">
                  {row.hasAnalysis ? (
                    editingCell?.id === row.id && editingCell?.field === 'unitRate' ? (
                      <Input
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={handleCellSave}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleCellSave();
                          if (e.key === 'Escape') handleCellCancel();
                        }}
                        className="h-6 text-xs"
                        autoFocus
                      />
                    ) : (
                      <div
                        className="cursor-pointer hover:bg-gray-100 p-1 rounded text-sm text-right"
                        onClick={() => handleCellEdit(row.id, 'unitRate', row.unitRate)}
                      >
                        ${row.unitRate.toFixed(2)}
                      </div>
                    )
                  ) : (
                    <span className="text-gray-400">$0.00</span>
                  )}
                </td>
                <td className="border border-gray-200 p-2">
                  {row.hasAnalysis ? (
                    editingCell?.id === row.id && editingCell?.field === 'wastagePercent' ? (
                      <Input
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={handleCellSave}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleCellSave();
                          if (e.key === 'Escape') handleCellCancel();
                        }}
                        className="h-6 text-xs"
                        autoFocus
                      />
                    ) : (
                      <div
                        className="cursor-pointer hover:bg-gray-100 p-1 rounded text-sm text-right"
                        onClick={() => handleCellEdit(row.id, 'wastagePercent', row.wastagePercent)}
                      >
                        {row.wastagePercent.toFixed(1)}%
                      </div>
                    )
                  ) : (
                    <span className="text-gray-400">0.0%</span>
                  )}
                </td>
                <td className="border border-gray-200 p-2 text-sm text-right">
                  {row.hasAnalysis ? `$${row.finalRate.toFixed(2)}` : <span className="text-gray-400">$0.00</span>}
                </td>
                <td className="border border-gray-200 p-2 text-sm text-right font-medium">
                  {row.hasAnalysis ? `$${row.amount.toFixed(2)}` : <span className="text-gray-400">$0.00</span>}
                </td>
                <td className="border border-gray-200 p-2 text-center">
                  <Badge className={getStatusColor(row.status)}>
                    {row.status} {row.versionNumber > 0 && `v${row.versionNumber}`}
                  </Badge>
                </td>
                <td className="border border-gray-200 p-2">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                        <MoreHorizontal className="h-3 w-3" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      {row.hasAnalysis ? (
                        <>
                          <DropdownMenuItem onClick={() => handleCellEdit(row.id, 'quantity', row.quantity)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleDuplicateRow(row.id)}>
                            <Copy className="h-4 w-4 mr-2" />
                            Duplicate
                          </DropdownMenuItem>
                          {onShowVersionHistory && (
                            <DropdownMenuItem onClick={() => onShowVersionHistory(row.priceCode)}>
                              <History className="h-4 w-4 mr-2" />
                              History
                            </DropdownMenuItem>
                          )}
                        </>
                      ) : (
                        <DropdownMenuItem>
                          <Plus className="h-4 w-4 mr-2" />
                          Add Resource
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
        {data.length === 0 && (
          <div className="flex items-center justify-center h-64 text-gray-500">
            <div className="text-center">
              <p className="text-lg font-medium">No analysis data found</p>
              <p className="text-sm">Create price codes and rate analysis to see data here</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
