
import React, { useState } from 'react';
import { X, Minus, Maximize2, Minimize2, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AnalysisTable } from './AnalysisTable';
import { AnalysisToolbar } from './AnalysisToolbar';
import { AnalysisFooter } from './AnalysisFooter';
import { VersionHistoryDialog } from './VersionHistoryDialog';
import { useAnalysisData } from './hooks/useAnalysisData';

interface AnalysisWindowProps {
  projectId: string;
  onClose: () => void;
}

export function AnalysisWindow({ projectId, onClose }: AnalysisWindowProps) {
  const [isMinimized, setIsMinimized] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [windowSize, setWindowSize] = useState({ width: 1400, height: 900 });
  const [position, setPosition] = useState({ x: 50, y: 50 });
  const [isDragging, setIsDragging] = useState(false);
  const [versionHistoryDialog, setVersionHistoryDialog] = useState<{
    isOpen: boolean;
    priceCode: string;
  }>({ isOpen: false, priceCode: '' });
  
  const dragRef = React.useRef<HTMLDivElement>(null);

  const analysisData = useAnalysisData(projectId);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (isMaximized) return;
    
    setIsDragging(true);
    const rect = dragRef.current?.getBoundingClientRect();
    if (rect) {
      const offsetX = e.clientX - rect.left;
      const offsetY = e.clientY - rect.top;

      const handleMouseMove = (e: MouseEvent) => {
        setPosition({
          x: Math.max(0, Math.min(window.innerWidth - 400, e.clientX - offsetX)),
          y: Math.max(0, Math.min(window.innerHeight - 100, e.clientY - offsetY))
        });
      };

      const handleMouseUp = () => {
        setIsDragging(false);
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }
  };

  const handleShowVersionHistory = (priceCode: string) => {
    setVersionHistoryDialog({ isOpen: true, priceCode });
  };

  const windowStyle = isMaximized
    ? { position: 'fixed' as const, top: 0, left: 0, right: 0, bottom: 0, zIndex: 50 }
    : { 
        position: 'fixed' as const, 
        top: position.y, 
        left: position.x, 
        zIndex: 50,
        width: isMinimized ? '400px' : `${windowSize.width}px`,
        height: isMinimized ? '60px' : `${windowSize.height}px`
      };

  return (
    <>
      <div style={windowStyle} className="bg-white border shadow-lg rounded-lg flex flex-col overflow-hidden">
        {/* Title Bar */}
        <div
          ref={dragRef}
          className="flex items-center justify-between p-2 border-b bg-blue-50 cursor-move select-none"
          onMouseDown={handleMouseDown}
        >
          <div className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4 text-blue-600" />
            <span className="font-medium text-sm">Analysis Module - Global Rate Analysis Manager</span>
            <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
              {analysisData.totalPriceCodes} Price Codes • {analysisData.data.length} Resources
            </span>
          </div>
          
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMinimized(!isMinimized)}
              className="h-6 w-6 p-0"
            >
              <Minus className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMaximized(!isMaximized)}
              className="h-6 w-6 p-0"
            >
              {isMaximized ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
        </div>

        {/* Content */}
        {!isMinimized && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <AnalysisToolbar 
              {...analysisData}
              handleImportCSV={analysisData.handleImportCSV}
              refreshData={analysisData.refreshData}
            />
            <div className="flex-1 overflow-hidden">
              <AnalysisTable 
                {...analysisData} 
                handleDuplicateRow={analysisData.handleDuplicateRow}
                onShowVersionHistory={handleShowVersionHistory}
              />
            </div>
            <AnalysisFooter totals={analysisData.totals} />
          </div>
        )}
      </div>

      <VersionHistoryDialog
        isOpen={versionHistoryDialog.isOpen}
        onClose={() => setVersionHistoryDialog({ isOpen: false, priceCode: '' })}
        projectId={projectId}
        priceCode={versionHistoryDialog.priceCode}
      />
    </>
  );
}
