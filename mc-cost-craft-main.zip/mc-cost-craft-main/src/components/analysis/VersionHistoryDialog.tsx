
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { priceCodeVersionsService } from '@/services/priceCodeVersions';

interface VersionHistoryDialogProps {
  isOpen: boolean;
  onClose: () => void;
  projectId: string;
  priceCode: string;
}

export function VersionHistoryDialog({
  isOpen,
  onClose,
  projectId,
  priceCode
}: VersionHistoryDialogProps) {
  const { data: versions = [], isLoading } = useQuery({
    queryKey: ['price-code-versions', projectId, priceCode],
    queryFn: () => priceCodeVersionsService.getByPriceCode(projectId, priceCode),
    enabled: isOpen && !!projectId && !!priceCode
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-yellow-100 text-yellow-800';
      case 'submitted': return 'bg-blue-100 text-blue-800';
      case 'approved': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Version History - {priceCode}</DialogTitle>
        </DialogHeader>
        
        <div className="max-h-96 overflow-auto">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="text-gray-500">Loading version history...</div>
            </div>
          ) : versions.length > 0 ? (
            <div className="space-y-4">
              {versions.map((version) => (
                <div key={version.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">Version {version.version_number}</span>
                      <Badge className={getStatusColor(version.status)}>
                        {version.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-500">
                      {new Date(version.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  
                  {version.change_summary && (
                    <div className="text-sm text-gray-600 mb-2">
                      <span className="font-medium">Changes: </span>
                      {version.change_summary}
                    </div>
                  )}
                  
                  <div className="text-xs text-gray-500">
                    Created: {new Date(version.created_at).toLocaleString()}
                    {version.approved_at && (
                      <> • Approved: {new Date(version.approved_at).toLocaleString()}</>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No version history found for this price code
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
