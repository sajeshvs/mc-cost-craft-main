
import React, { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Download, Trash2, RefreshCw, Filter, Upload } from 'lucide-react';

interface AnalysisToolbarProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  divisionFilter: string;
  setDivisionFilter: (division: string) => void;
  categoryFilter: string;
  setCategoryFilter: (category: string) => void;
  statusFilter: string;
  setStatusFilter: (status: string) => void;
  selectedRows: Set<string>;
  uniqueDivisions: string[];
  handleDeleteRows: (ids: string[]) => void;
  handleExportCSV: () => void;
  handleImportCSV: (file: File) => void;
  refreshData: () => void;
}

export function AnalysisToolbar({
  searchTerm,
  setSearchTerm,
  divisionFilter,
  setDivisionFilter,
  categoryFilter,
  setCategoryFilter,
  statusFilter,
  setStatusFilter,
  selectedRows,
  uniqueDivisions,
  handleDeleteRows,
  handleExportCSV,
  handleImportCSV,
  refreshData
}: AnalysisToolbarProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleImportCSV(file);
    }
    // Reset input value to allow re-importing the same file
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="flex items-center gap-2 p-3 bg-gray-50 border-b border-gray-200 overflow-x-auto min-w-fit">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          placeholder="Search price codes, resources..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 w-80 h-8"
        />
      </div>

      <div className="h-6 w-px bg-gray-300" />

      {/* Filters */}
      <div className="flex items-center gap-2">
        <Filter className="h-4 w-4 text-gray-500" />
        
        <Select value={divisionFilter} onValueChange={setDivisionFilter}>
          <SelectTrigger className="w-32 h-8">
            <SelectValue placeholder="Division" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Divisions</SelectItem>
            {uniqueDivisions.map(division => (
              <SelectItem key={division} value={division}>
                {division}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-32 h-8">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="P">Labor (P)</SelectItem>
            <SelectItem value="M">Material (M)</SelectItem>
            <SelectItem value="E">Equipment (E)</SelectItem>
            <SelectItem value="S">Subcontractor (S)</SelectItem>
            <SelectItem value="C">Consultant (C)</SelectItem>
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-32 h-8">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="submitted">Submitted</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="h-6 w-px bg-gray-300" />

      {/* Actions */}
      <Button
        variant="outline"
        size="sm"
        onClick={refreshData}
        className="h-8 whitespace-nowrap gap-2"
      >
        <RefreshCw className="h-4 w-4" />
        Refresh
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={handleImportClick}
        className="h-8 whitespace-nowrap gap-2"
      >
        <Upload className="h-4 w-4" />
        Import CSV
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={handleExportCSV}
        className="h-8 whitespace-nowrap gap-2"
      >
        <Download className="h-4 w-4" />
        Export CSV
      </Button>

      {selectedRows.size > 0 && (
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleDeleteRows(Array.from(selectedRows))}
          className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50 whitespace-nowrap gap-2"
        >
          <Trash2 className="h-4 w-4" />
          Delete ({selectedRows.size})
        </Button>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".csv"
        onChange={handleFileChange}
        className="hidden"
      />
    </div>
  );
}
