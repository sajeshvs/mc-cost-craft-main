
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';
import { TradeSummaryFilters as TradeSummaryFiltersType, SummaryMode } from '@/types/tradeSummary';
import { Trade } from '@/types/trades';

interface TradeSummaryFiltersProps {
  mode: SummaryMode;
  filters: TradeSummaryFiltersType;
  trades: Trade[];
  onFiltersChange: (filters: Partial<TradeSummaryFiltersType>) => void;
}

export function TradeSummaryFilters({ 
  mode, 
  filters, 
  trades,
  onFiltersChange 
}: TradeSummaryFiltersProps) {

  const handleTradeToggle = (tradeCode: string, selected: boolean) => {
    const newSelectedTrades = selected 
      ? [...filters.selectedTrades, tradeCode]
      : filters.selectedTrades.filter(t => t !== tradeCode);
    
    onFiltersChange({ selectedTrades: newSelectedTrades });
  };

  const handleLevelToggle = (level: number, selected: boolean) => {
    const newSelectedLevels = selected
      ? [...filters.selectedLevels, level]
      : filters.selectedLevels.filter(l => l !== level);
    
    onFiltersChange({ selectedLevels: newSelectedLevels });
  };

  const clearTradeSelection = (tradeCode: string) => {
    onFiltersChange({ 
      selectedTrades: filters.selectedTrades.filter(t => t !== tradeCode) 
    });
  };

  const clearLevelSelection = (level: number) => {
    onFiltersChange({ 
      selectedLevels: filters.selectedLevels.filter(l => l !== level) 
    });
  };

  return (
    <div className="p-3 border-b bg-gray-50 space-y-3">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Trade/Level Selection */}
        {mode === 'trade' ? (
          <div className="space-y-2">
            <Label className="text-sm font-medium">Selected Trades</Label>
            <Select onValueChange={(tradeCode) => handleTradeToggle(tradeCode, true)}>
              <SelectTrigger className="h-8">
                <SelectValue placeholder="Select trades..." />
              </SelectTrigger>
              <SelectContent>
                {trades.filter(trade => !filters.selectedTrades.includes(trade.trade_code)).map(trade => (
                  <SelectItem key={trade.id} value={trade.trade_code}>
                    {trade.trade_code} - {trade.description}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex flex-wrap gap-1">
              {filters.selectedTrades.map(tradeCode => {
                const trade = trades.find(t => t.trade_code === tradeCode);
                return (
                  <Badge key={tradeCode} variant="secondary" className="text-xs">
                    {trade?.trade_code || tradeCode}
                    <X 
                      className="h-3 w-3 ml-1 cursor-pointer" 
                      onClick={() => clearTradeSelection(tradeCode)}
                    />
                  </Badge>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            <Label className="text-sm font-medium">Selected Levels</Label>
            <div className="flex flex-wrap gap-2">
              {[1, 2, 3, 4, 5].map(level => (
                <div key={level} className="flex items-center space-x-1">
                  <Checkbox
                    id={`level-${level}`}
                    checked={filters.selectedLevels.includes(level)}
                    onCheckedChange={(checked) => handleLevelToggle(level, checked as boolean)}
                  />
                  <Label htmlFor={`level-${level}`} className="text-sm">
                    Level {level}
                  </Label>
                </div>
              ))}
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="include-admin"
                checked={filters.includeAdminRows}
                onCheckedChange={(checked) => onFiltersChange({ includeAdminRows: checked as boolean })}
              />
              <Label htmlFor="include-admin" className="text-sm">
                Include Admin (C) Rows
              </Label>
            </div>
          </div>
        )}

        {/* Description Filter */}
        <div className="space-y-2">
          <Label className="text-sm font-medium">Description Filter</Label>
          <Input
            placeholder="Search description..."
            value={filters.descriptionFilter}
            onChange={(e) => onFiltersChange({ descriptionFilter: e.target.value })}
            className="h-8"
          />
        </div>

        {/* BOQ Reference Range */}
        <div className="space-y-2">
          <Label className="text-sm font-medium">BOQ Reference Range</Label>
          <div className="flex gap-1">
            <Input
              placeholder="From"
              value={filters.boqRefRange.start || ''}
              onChange={(e) => onFiltersChange({ 
                boqRefRange: { ...filters.boqRefRange, start: e.target.value } 
              })}
              className="h-8 text-xs"
            />
            <Input
              placeholder="To"
              value={filters.boqRefRange.end || ''}
              onChange={(e) => onFiltersChange({ 
                boqRefRange: { ...filters.boqRefRange, end: e.target.value } 
              })}
              className="h-8 text-xs"
            />
          </div>
        </div>

        {/* Sort Options */}
        <div className="space-y-2">
          <Label className="text-sm font-medium">Sort By</Label>
          <div className="flex gap-1">
            <Select value={filters.sortBy} onValueChange={(value: any) => onFiltersChange({ sortBy: value })}>
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="code">Code</SelectItem>
                <SelectItem value="description">Description</SelectItem>
                <SelectItem value="totalCost">Total Cost</SelectItem>
                <SelectItem value="boqRef">BOQ Ref</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filters.sortOrder} onValueChange={(value: any) => onFiltersChange({ sortOrder: value })}>
              <SelectTrigger className="h-8 w-20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="asc">↑</SelectItem>
                <SelectItem value="desc">↓</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
}
