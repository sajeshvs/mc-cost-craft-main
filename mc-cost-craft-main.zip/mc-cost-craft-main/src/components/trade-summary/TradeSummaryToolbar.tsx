
import React from 'react';
import { Button } from '@/components/ui/button';
import { Download, ToggleLeft, ToggleRight } from 'lucide-react';
import { SummaryMode } from '@/types/tradeSummary';

interface TradeSummaryToolbarProps {
  mode: SummaryMode;
  onModeChange: (mode: SummaryMode) => void;
  onExport: () => void;
  isLoading: boolean;
}

export function TradeSummaryToolbar({ 
  mode, 
  onModeChange, 
  onExport, 
  isLoading 
}: TradeSummaryToolbarProps) {
  
  return (
    <div className="flex items-center justify-between p-3 border-b bg-white">
      <div className="flex items-center gap-3">
        {/* Mode Toggle */}
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">View Mode:</span>
          <Button
            variant={mode === 'trade' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onModeChange('trade')}
            className="h-8 px-3"
          >
            {mode === 'trade' ? (
              <ToggleRight className="h-4 w-4 mr-1" />
            ) : (
              <ToggleLeft className="h-4 w-4 mr-1" />
            )}
            Trade View
          </Button>
          
          <Button
            variant={mode === 'level' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onModeChange('level')}
            className="h-8 px-3"
          >
            {mode === 'level' ? (
              <ToggleRight className="h-4 w-4 mr-1" />
            ) : (
              <ToggleLeft className="h-4 w-4 mr-1" />
            )}
            Level View
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={onExport}
          disabled={isLoading}
          className="h-8 px-3 gap-1"
        >
          <Download className="h-4 w-4" />
          Export Excel
        </Button>
      </div>
    </div>
  );
}
