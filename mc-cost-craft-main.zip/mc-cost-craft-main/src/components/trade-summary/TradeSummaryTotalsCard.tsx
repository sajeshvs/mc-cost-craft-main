
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { TradeSummaryTotals } from '@/types/tradeSummary';

interface TradeSummaryTotalsCardProps {
  totals: TradeSummaryTotals;
}

export function TradeSummaryTotalsCard({ totals }: TradeSummaryTotalsCardProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatHours = (hours: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 1
    }).format(hours);
  };

  return (
    <Card className="mx-3 my-2">
      <CardContent className="p-3">
        <div className="grid grid-cols-4 md:grid-cols-8 gap-2 text-center">
          <div className="bg-blue-50 p-2 rounded">
            <div className="text-xs text-blue-600 font-medium">Labor Hours</div>
            <div className="text-sm font-bold text-blue-900">
              {formatHours(totals.totalLaborManhours)}
            </div>
          </div>
          
          <div className="bg-blue-50 p-2 rounded">
            <div className="text-xs text-blue-600 font-medium">Labor</div>
            <div className="text-sm font-bold text-blue-900">
              {formatCurrency(totals.totalLaborAmount)}
            </div>
          </div>
          
          <div className="bg-green-50 p-2 rounded">
            <div className="text-xs text-green-600 font-medium">Material</div>
            <div className="text-sm font-bold text-green-900">
              {formatCurrency(totals.totalMaterialAmount)}
            </div>
          </div>
          
          <div className="bg-yellow-50 p-2 rounded">
            <div className="text-xs text-yellow-600 font-medium">Equipment</div>
            <div className="text-sm font-bold text-yellow-900">
              {formatCurrency(totals.totalEquipmentAmount)}
            </div>
          </div>
          
          <div className="bg-purple-50 p-2 rounded">
            <div className="text-xs text-purple-600 font-medium">Subcontractor</div>
            <div className="text-sm font-bold text-purple-900">
              {formatCurrency(totals.totalSubcontractorAmount)}
            </div>
          </div>
          
          <div className="bg-red-50 p-2 rounded">
            <div className="text-xs text-red-600 font-medium">Consultant</div>
            <div className="text-sm font-bold text-red-900">
              {formatCurrency(totals.totalConsultantAmount)}
            </div>
          </div>
          
          <div className="bg-gray-50 p-2 rounded">
            <div className="text-xs text-gray-600 font-medium">Indirect</div>
            <div className="text-sm font-bold text-gray-900">
              {formatCurrency(totals.totalIndirectCost)}
            </div>
          </div>
          
          <div className="bg-orange-50 p-2 rounded">
            <div className="text-xs text-orange-600 font-medium">Grand Total</div>
            <div className="text-sm font-bold text-orange-900">
              {formatCurrency(totals.grandTotal)}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
