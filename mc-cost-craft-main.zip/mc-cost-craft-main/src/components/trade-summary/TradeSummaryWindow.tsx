
import React, { useState } from 'react';
import { X, Minimize2, Maximize2, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { useTradeSummary } from '@/hooks/useTradeSummary';
import { TradeSummaryToolbar } from './TradeSummaryToolbar';
import { TradeSummaryTable } from './TradeSummaryTable';
import { TradeSummaryFilters } from './TradeSummaryFilters';
import { TradeSummaryTotalsCard } from './TradeSummaryTotalsCard';

interface TradeSummaryWindowProps {
  projectId: string;
  jobId: string;
  isOpen: boolean;
  onClose: () => void;
}

export function TradeSummaryWindow({ 
  projectId, 
  jobId, 
  isOpen, 
  onClose 
}: TradeSummaryWindowProps) {
  const [isMinimized, setIsMinimized] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  
  const {
    mode,
    setMode,
    filters,
    updateFilters,
    summaries,
    totals,
    trades,
    isLoading,
    exportToExcel
  } = useTradeSummary(projectId, jobId);

  const handleMinimize = () => {
    setIsMinimized(!isMinimized);
  };

  const handleMaximize = () => {
    setIsMaximized(!isMaximized);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent 
        className={`
          ${isMaximized ? 'max-w-[95vw] max-h-[95vh]' : 'max-w-6xl max-h-[90vh]'} 
          ${isMinimized ? 'h-16' : 'h-auto'} 
          p-0 overflow-hidden
        `}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b bg-gray-50">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-blue-600" />
            <span className="font-semibold text-gray-900">
              Trade Summary - {mode === 'trade' ? 'Trade View' : 'Level View'}
            </span>
          </div>
          
          <div className="flex items-center gap-1">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleMinimize}
              className="h-8 w-8 p-0"
            >
              <Minimize2 className="h-4 w-4" />
            </Button>
            
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleMaximize}
              className="h-8 w-8 p-0"
            >
              <Maximize2 className="h-4 w-4" />
            </Button>
            
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Content */}
        {!isMinimized && (
          <div className="flex flex-col h-full">
            {/* Toolbar */}
            <TradeSummaryToolbar
              mode={mode}
              onModeChange={setMode}
              onExport={exportToExcel}
              isLoading={isLoading}
            />

            {/* Filters */}
            <TradeSummaryFilters
              mode={mode}
              filters={filters}
              trades={trades}
              onFiltersChange={updateFilters}
            />

            {/* Totals Card */}
            <TradeSummaryTotalsCard totals={totals} />

            {/* Table */}
            <div className="flex-1 overflow-hidden">
              <TradeSummaryTable
                summaries={summaries}
                totals={totals}
                mode={mode}
                isLoading={isLoading}
                sortBy={filters.sortBy}
                sortOrder={filters.sortOrder}
                onSort={(sortBy, sortOrder) => updateFilters({ sortBy: sortBy as 'code' | 'description' | 'totalCost' | 'boqRef', sortOrder })}
              />
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
