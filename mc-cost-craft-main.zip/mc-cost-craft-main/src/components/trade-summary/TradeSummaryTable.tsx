
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { ChevronUp, ChevronDown, Loader2 } from 'lucide-react';
import { TradeSummaryItem, TradeSummaryTotals, SummaryMode } from '@/types/tradeSummary';

interface TradeSummaryTableProps {
  summaries: TradeSummaryItem[];
  totals: TradeSummaryTotals;
  mode: SummaryMode;
  isLoading: boolean;
  sortBy: string;
  sortOrder: 'asc' | 'desc';
  onSort: (sortBy: string, sortOrder: 'asc' | 'desc') => void;
}

export function TradeSummaryTable({ 
  summaries, 
  totals, 
  mode, 
  isLoading, 
  sortBy, 
  sortOrder, 
  onSort 
}: TradeSummaryTableProps) {

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const formatHours = (hours: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 1
    }).format(hours);
  };

  const formatPercentage = (percentage: number) => {
    return `${percentage.toFixed(1)}%`;
  };

  const handleSort = (field: string) => {
    const newSortOrder = sortBy === field && sortOrder === 'asc' ? 'desc' : 'asc';
    onSort(field, newSortOrder);
  };

  const SortButton = ({ field, children }: { field: string; children: React.ReactNode }) => (
    <Button
      variant="ghost"
      size="sm"
      onClick={() => handleSort(field)}
      className="h-6 p-0 font-semibold hover:bg-transparent"
    >
      <span className="flex items-center gap-1">
        {children}
        {sortBy === field && (
          sortOrder === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />
        )}
      </span>
    </Button>
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex items-center gap-2">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Loading trade summary...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full overflow-auto">
      <Table>
        <TableHeader className="sticky top-0 bg-white z-10">
          <TableRow>
            <TableHead className="w-24">
              <SortButton field="code">
                {mode === 'trade' ? 'Trade Code' : 'Level'}
              </SortButton>
            </TableHead>
            <TableHead>
              <SortButton field="description">Description</SortButton>
            </TableHead>
            <TableHead className="w-20 text-right">Qty</TableHead>
            <TableHead className="w-24 text-right">Labor Hours</TableHead>
            <TableHead className="w-24 text-right">Labor</TableHead>
            <TableHead className="w-24 text-right">Material</TableHead>
            <TableHead className="w-24 text-right">Equipment</TableHead>
            <TableHead className="w-24 text-right">Subcontractor</TableHead>
            <TableHead className="w-24 text-right">Consultant</TableHead>
            <TableHead className="w-24 text-right">Direct Cost</TableHead>
            <TableHead className="w-24 text-right">Indirect</TableHead>
            <TableHead className="w-24 text-right">Profit</TableHead>
            <TableHead className="w-24 text-right">
              <SortButton field="totalCost">Final Total</SortButton>
            </TableHead>
            <TableHead className="w-16 text-right">% Project</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {summaries.length === 0 ? (
            <TableRow>
              <TableCell colSpan={14} className="text-center py-8 text-gray-500">
                {mode === 'trade' 
                  ? 'No trades selected. Please select trades from the filter above.'
                  : 'No levels selected. Please select levels from the filter above.'
                }
              </TableCell>
            </TableRow>
          ) : (
            summaries.map((summary) => (
              <TableRow key={summary.code} className="hover:bg-gray-50">
                <TableCell className="font-medium">{summary.code}</TableCell>
                <TableCell>{summary.description}</TableCell>
                <TableCell className="text-right">
                  {summary.totalQuantity.toLocaleString()}
                </TableCell>
                <TableCell className="text-right text-blue-700">
                  {formatHours(summary.laborManhours)}
                </TableCell>
                <TableCell className="text-right text-blue-700">
                  {formatCurrency(summary.laborAmount)}
                </TableCell>
                <TableCell className="text-right text-green-700">
                  {formatCurrency(summary.materialAmount)}
                </TableCell>
                <TableCell className="text-right text-yellow-700">
                  {formatCurrency(summary.equipmentAmount)}
                </TableCell>
                <TableCell className="text-right text-purple-700">
                  {formatCurrency(summary.subcontractorAmount)}
                </TableCell>
                <TableCell className="text-right text-red-700">
                  {formatCurrency(summary.consultantAmount)}
                </TableCell>
                <TableCell className="text-right font-semibold">
                  {formatCurrency(summary.totalDirectCost)}
                </TableCell>
                <TableCell className="text-right text-gray-700">
                  {formatCurrency(summary.indirectCost)}
                </TableCell>
                <TableCell className="text-right text-orange-700">
                  {formatCurrency(summary.profit)}
                </TableCell>
                <TableCell className="text-right font-bold text-orange-800">
                  {formatCurrency(summary.totalFinalValue)}
                </TableCell>
                <TableCell className="text-right text-sm">
                  {formatPercentage(summary.percentOfProject)}
                </TableCell>
              </TableRow>
            ))
          )}
          
          {/* Totals Row */}
          {summaries.length > 0 && (
            <TableRow className="border-t-2 border-gray-300 bg-gray-100 font-semibold">
              <TableCell colSpan={2} className="font-bold">Project Totals</TableCell>
              <TableCell className="text-right">
                {totals.totalQuantity.toLocaleString()}
              </TableCell>
              <TableCell className="text-right text-blue-800">
                {formatHours(totals.totalLaborManhours)}
              </TableCell>
              <TableCell className="text-right text-blue-800">
                {formatCurrency(totals.totalLaborAmount)}
              </TableCell>
              <TableCell className="text-right text-green-800">
                {formatCurrency(totals.totalMaterialAmount)}
              </TableCell>
              <TableCell className="text-right text-yellow-800">
                {formatCurrency(totals.totalEquipmentAmount)}
              </TableCell>
              <TableCell className="text-right text-purple-800">
                {formatCurrency(totals.totalSubcontractorAmount)}
              </TableCell>
              <TableCell className="text-right text-red-800">
                {formatCurrency(totals.totalConsultantAmount)}
              </TableCell>
              <TableCell className="text-right font-bold">
                {formatCurrency(totals.totalDirectCost)}
              </TableCell>
              <TableCell className="text-right text-gray-800">
                {formatCurrency(totals.totalIndirectCost)}
              </TableCell>
              <TableCell className="text-right text-orange-800">
                {formatCurrency(totals.totalProfit)}
              </TableCell>
              <TableCell className="text-right font-bold text-orange-900">
                {formatCurrency(totals.grandTotal)}
              </TableCell>
              <TableCell className="text-right">100.0%</TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
