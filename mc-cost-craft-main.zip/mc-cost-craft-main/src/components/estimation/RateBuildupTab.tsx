
import { BOQItem } from '@/types/mccost';
import { EstimationResource, RESOURCE_TYPES } from '@/types/estimation';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

interface RateBuildupTabProps {
  boqItem: BOQItem;
  resources: EstimationResource[];
  totalRate: number;
}

export function RateBuildupTab({ boqItem, resources, totalRate }: RateBuildupTabProps) {
  const getResourceTypeStyle = (type: EstimationResource['resource_type']) => {
    const typeConfig = RESOURCE_TYPES.find(t => t.value === type);
    return typeConfig?.color || 'bg-gray-50 text-gray-700';
  };

  const resourceSummary = RESOURCE_TYPES.map(type => {
    const typeResources = resources.filter(r => r.resource_type === type.value);
    const total = typeResources.reduce((sum, r) => sum + r.total, 0);
    return {
      ...type,
      count: typeResources.length,
      total
    };
  }).filter(type => type.count > 0);

  return (
    <div className="space-y-4">
      <div className="p-4 bg-gray-50 rounded-lg">
        <h4 className="font-medium mb-2">Rate Build-up Summary</h4>
        <p className="text-sm text-gray-600">
          Item: {boqItem.item_no} - {boqItem.description}
        </p>
        <p className="text-sm text-gray-600">
          Unit: {boqItem.unit} | Quantity: {boqItem.quantity?.toLocaleString()}
        </p>
      </div>

      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Resource Type</TableHead>
              <TableHead>Resources Count</TableHead>
              <TableHead>Sub-total</TableHead>
              <TableHead>% of Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {resourceSummary.map((type) => (
              <TableRow key={type.value}>
                <TableCell>
                  <Badge className={type.color}>
                    {type.label}
                  </Badge>
                </TableCell>
                <TableCell>{type.count} item(s)</TableCell>
                <TableCell className="font-medium">
                  ${type.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </TableCell>
                <TableCell>
                  {totalRate > 0 ? ((type.total / totalRate) * 100).toFixed(1) : 0}%
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <div className="p-4 bg-green-50 rounded-lg">
        <div className="flex justify-between items-center">
          <span className="font-medium">Total Rate per {boqItem.unit}:</span>
          <span className="text-xl font-bold text-green-700">
            ${totalRate.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </span>
        </div>
        <div className="flex justify-between items-center mt-2">
          <span className="font-medium">Total Amount ({boqItem.quantity?.toLocaleString()} {boqItem.unit}):</span>
          <span className="text-xl font-bold text-green-700">
            ${((boqItem.quantity || 0) * totalRate).toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </span>
        </div>
      </div>
    </div>
  );
}
