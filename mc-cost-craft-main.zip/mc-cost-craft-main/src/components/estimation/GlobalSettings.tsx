
import { useState, useEffect } from 'react';
import { useSupabaseQuery } from '@/hooks/useSupabaseQuery';
import { useSupabaseMutation } from '@/hooks/useSupabaseQuery';
import { globalSettingsService } from '@/services/globalSettings';
import { CURRENCIES } from '@/types/estimation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Settings, DollarSign, Globe, Percent } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function GlobalSettings() {
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    base_currency: 'USD',
    currency_symbol: '$',
    decimal_precision: 2,
    exchange_rates: {} as { [key: string]: number }
  });

  const { data: allSettings = [] } = useSupabaseQuery(
    ['global_settings'],
    globalSettingsService.getAllSettings
  );

  const updateSettingMutation = useSupabaseMutation(
    ({ key, value }: { key: string; value: any }) => globalSettingsService.setSetting(key, value),
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Settings updated successfully' });
      },
      invalidateKeys: [['global_settings']]
    }
  );

  useEffect(() => {
    // Load existing settings
    const currencySetting = allSettings.find(s => s.setting_key === 'currency');
    const precisionSetting = allSettings.find(s => s.setting_key === 'decimal_precision');
    const exchangeSetting = allSettings.find(s => s.setting_key === 'exchange_rates');

    if (currencySetting?.setting_value) {
      setSettings(prev => ({
        ...prev,
        base_currency: currencySetting.setting_value.base_currency || 'USD',
        currency_symbol: currencySetting.setting_value.currency_symbol || '$'
      }));
    }

    if (precisionSetting?.setting_value) {
      setSettings(prev => ({
        ...prev,
        decimal_precision: precisionSetting.setting_value.precision || 2
      }));
    }

    if (exchangeSetting?.setting_value) {
      setSettings(prev => ({
        ...prev,
        exchange_rates: exchangeSetting.setting_value.rates || {}
      }));
    }
  }, [allSettings]);

  const handleCurrencyChange = (currencyCode: string) => {
    const currency = CURRENCIES.find(c => c.code === currencyCode);
    if (currency) {
      const newSettings = {
        ...settings,
        base_currency: currency.code,
        currency_symbol: currency.symbol
      };
      setSettings(newSettings);
      updateSettingMutation.mutate({
        key: 'currency',
        value: {
          base_currency: currency.code,
          currency_symbol: currency.symbol,
          currency_name: currency.name
        }
      });
    }
  };

  const handlePrecisionChange = (precision: number) => {
    const newSettings = { ...settings, decimal_precision: precision };
    setSettings(newSettings);
    updateSettingMutation.mutate({
      key: 'decimal_precision',
      value: { precision }
    });
  };

  const handleExchangeRateChange = (currencyCode: string, rate: number) => {
    const newRates = { ...settings.exchange_rates, [currencyCode]: rate };
    const newSettings = { ...settings, exchange_rates: newRates };
    setSettings(newSettings);
    updateSettingMutation.mutate({
      key: 'exchange_rates',
      value: { rates: newRates }
    });
  };

  const formatCurrency = (amount: number, currencyCode?: string) => {
    const currency = CURRENCIES.find(c => c.code === (currencyCode || settings.base_currency));
    const symbol = currency?.symbol || settings.currency_symbol;
    return `${symbol}${amount.toLocaleString(undefined, { 
      minimumFractionDigits: settings.decimal_precision,
      maximumFractionDigits: settings.decimal_precision 
    })}`;
  };

  const convertCurrency = (amount: number, fromCurrency: string, toCurrency: string): number => {
    if (fromCurrency === toCurrency) return amount;
    
    const rate = settings.exchange_rates[toCurrency];
    if (!rate) return amount;
    
    return amount * rate;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Settings className="h-6 w-6" />
        <h2 className="text-2xl font-bold">Global Estimation Settings</h2>
      </div>

      {/* Currency Settings */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            <CardTitle>Currency Settings</CardTitle>
          </div>
          <CardDescription>
            Configure your base currency and display preferences
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Base Currency</Label>
              <Select
                value={settings.base_currency}
                onValueChange={handleCurrencyChange}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CURRENCIES.map(currency => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.symbol} {currency.code} - {currency.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Decimal Precision</Label>
              <Select
                value={settings.decimal_precision.toString()}
                onValueChange={(value) => handlePrecisionChange(parseInt(value))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">0 decimals (1000)</SelectItem>
                  <SelectItem value="1">1 decimal (1000.0)</SelectItem>
                  <SelectItem value="2">2 decimals (1000.00)</SelectItem>
                  <SelectItem value="3">3 decimals (1000.000)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="p-4 bg-gray-50 rounded-lg">
            <Label className="text-sm font-medium">Preview</Label>
            <div className="mt-2 space-y-1">
              <p className="text-lg font-semibold">{formatCurrency(1234.567)}</p>
              <p className="text-sm text-gray-600">Sample amount formatting</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Exchange Rates */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            <CardTitle>Exchange Rates</CardTitle>
          </div>
          <CardDescription>
            Set exchange rates for currency conversion (relative to {settings.base_currency})
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {CURRENCIES
                .filter(currency => currency.code !== settings.base_currency)
                .map(currency => (
                  <div key={currency.code} className="space-y-2">
                    <Label className="flex items-center gap-2">
                      <span>{currency.symbol}</span>
                      <span>{currency.code}</span>
                    </Label>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-500">1 {settings.base_currency} =</span>
                      <Input
                        type="number"
                        step="0.0001"
                        placeholder="Rate"
                        value={settings.exchange_rates[currency.code] || ''}
                        onChange={(e) => handleExchangeRateChange(currency.code, parseFloat(e.target.value) || 0)}
                        className="w-24"
                      />
                      <span className="text-sm text-gray-500">{currency.code}</span>
                    </div>
                  </div>
                ))}
            </div>

            <Separator />

            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium mb-3">Currency Conversion Example</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Amount in {settings.base_currency}:</span>
                  <span className="font-semibold">{formatCurrency(1000)}</span>
                </div>
                {Object.entries(settings.exchange_rates)
                  .filter(([, rate]) => rate > 0)
                  .slice(0, 3)
                  .map(([currencyCode, rate]) => {
                    const convertedAmount = convertCurrency(1000, settings.base_currency, currencyCode);
                    return (
                      <div key={currencyCode} className="flex justify-between">
                        <span>Equivalent in {currencyCode}:</span>
                        <span className="font-semibold">{formatCurrency(convertedAmount, currencyCode)}</span>
                      </div>
                    );
                  })}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Additional Settings */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Percent className="h-5 w-5" />
            <CardTitle>Additional Settings</CardTitle>
          </div>
          <CardDescription>
            Other estimation preferences and configurations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                Additional settings like tax rates, markup percentages, and custom calculation rules can be added here in future updates.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
