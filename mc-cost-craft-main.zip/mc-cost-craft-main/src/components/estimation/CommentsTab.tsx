
import { useState } from 'react';
import { BOQItem } from '@/types/mccost';
import { EstimationSheet } from '@/types/estimation';
import { useSupabaseMutation } from '@/hooks/useSupabaseQuery';
import { supabase } from '@/integrations/supabase/client';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Save, FileText, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CommentsTabProps {
  boqItem: BOQItem;
  estimationSheet?: EstimationSheet;
}

export function CommentsTab({ boqItem, estimationSheet }: CommentsTabProps) {
  const { toast } = useToast();
  const [notes, setNotes] = useState(estimationSheet?.notes || '');

  const updateSheetMutation = useSupabaseMutation(
    async (newNotes: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      if (estimationSheet) {
        // Update existing sheet
        const { data, error } = await supabase
          .from('estimation_sheets')
          .update({ 
            notes: newNotes,
            updated_at: new Date().toISOString()
          })
          .eq('id', estimationSheet.id)
          .select()
          .single();
        
        if (error) throw error;
        return data;
      } else {
        // Create new sheet with notes
        const { data, error } = await supabase
          .from('estimation_sheets')
          .insert({
            boq_item_id: boqItem.id,
            total_rate: 0,
            total_amount: 0,
            currency: 'USD',
            notes: newNotes,
            user_id: user.id
          })
          .select()
          .single();
        
        if (error) throw error;
        return data;
      }
    },
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Comments saved successfully' });
      },
      invalidateKeys: [['estimation_sheets', boqItem.id]]
    }
  );

  const handleSave = () => {
    updateSheetMutation.mutate(notes);
  };

  const handleFileUpload = async (file: File) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const fileName = `${Date.now()}-${file.name}`;
      const filePath = `${user.id}/sheets/${estimationSheet?.id || boqItem.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('estimation-attachments')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Save attachment record
      const { error: dbError } = await supabase
        .from('estimation_attachments')
        .insert({
          estimation_sheet_id: estimationSheet?.id,
          file_name: file.name,
          file_size: file.size,
          file_type: file.type,
          storage_path: filePath,
          user_id: user.id
        });

      if (dbError) throw dbError;

      toast({ title: 'Success', description: 'File uploaded successfully' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-4">
      <div className="p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <FileText className="h-5 w-5" />
          <h4 className="font-medium">Estimation Notes & Documentation</h4>
        </div>
        <p className="text-sm text-gray-600">
          Add comments, assumptions, rate justifications, or any other notes related to this estimation.
          You can also attach supporting documents like quotations, specifications, or reference materials.
        </p>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">Comments & Notes</label>
        <Textarea
          placeholder="Enter your comments, assumptions, rate justifications, or any other notes related to this estimation..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={8}
          className="min-h-[200px]"
        />
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <label className="cursor-pointer">
            <input
              type="file"
              className="hidden"
              multiple
              accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
              onChange={(e) => {
                const files = Array.from(e.target.files || []);
                files.forEach(file => handleFileUpload(file));
              }}
            />
            <Button variant="outline" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Upload Attachments
            </Button>
          </label>
          <span className="text-xs text-gray-500">
            Supports: PDF, Word, Excel, Images
          </span>
        </div>

        <Button 
          onClick={handleSave} 
          className="flex items-center gap-2"
          disabled={updateSheetMutation.isPending}
        >
          <Save className="h-4 w-4" />
          {updateSheetMutation.isPending ? 'Saving...' : 'Save Comments'}
        </Button>
      </div>

      <div className="p-3 bg-blue-50 rounded border-l-4 border-blue-400">
        <p className="text-sm text-blue-700">
          <strong>Tip:</strong> Use the comments section to document your estimation methodology, 
          reference sources, assumptions made, and any special considerations. This helps with 
          future reviews and provides transparency in your cost calculations.
        </p>
      </div>
    </div>
  );
}
