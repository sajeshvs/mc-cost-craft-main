
import { useState } from 'react';
import { BOQItem } from '@/types/mccost';
import { EstimationSheet as EstimationSheetType, EstimationResource } from '@/types/estimation';
import { useSupabaseQuery } from '@/hooks/useSupabaseQuery';
import { supabase } from '@/integrations/supabase/client';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Calculator, FileText, MessageSquare, History, BarChart3, Settings } from 'lucide-react';
import { ResourceBreakdownTab } from './ResourceBreakdownTab';
import { RateBuildupTab } from './RateBuildupTab';
import { CommentsTab } from './CommentsTab';
import { HistoryTab } from './HistoryTab';
import { CostSummary } from './CostSummary';
import { GlobalSettings } from './GlobalSettings';
import { ScrollArea } from '@/components/ui/scroll-area';

interface EstimationSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  boqItem: BOQItem;
  estimationSheet?: EstimationSheetType;
  resources?: EstimationResource[];
}

export function EstimationSheet({
  open,
  onOpenChange,
  boqItem,
  estimationSheet,
  resources = []
}: EstimationSheetProps) {
  const [activeTab, setActiveTab] = useState('resources');

  const { data: fetchedResources = [] } = useSupabaseQuery<EstimationResource[]>(
    ['estimation_resources', boqItem.id],
    async (): Promise<EstimationResource[]> => {
      const { data, error } = await supabase
        .from('estimation_resources')
        .select('*')
        .eq('boq_item_id', boqItem.id)
        .order('sort_order');
      
      if (error) throw error;
      if (!Array.isArray(data)) return [];
      
      // Type guard to ensure data matches EstimationResource structure
      const validResources: EstimationResource[] = data.map((item: any) => ({
        id: item.id,
        estimation_sheet_id: item.estimation_sheet_id,
        boq_item_id: item.boq_item_id,
        resource_type: ['Labor', 'Material', 'Equipment', 'Subcontract', 'Others'].includes(item.resource_type) 
          ? item.resource_type as EstimationResource['resource_type']
          : 'Others' as EstimationResource['resource_type'],
        resource_name: item.resource_name,
        unit: item.unit,
        rate: item.rate,
        coefficient: item.coefficient,
        total: item.total,
        comments: item.comments || null,
        sort_order: item.sort_order,
        user_id: item.user_id || null,
        created_at: item.created_at,
        updated_at: item.updated_at
      }));
      
      return validResources;
    },
    { enabled: open }
  );

  // Fetch estimation sheet for this BOQ item
  const { data: fetchedSheet } = useSupabaseQuery<EstimationSheetType | null>(
    ['estimation_sheets', boqItem.id],
    async (): Promise<EstimationSheetType | null> => {
      const { data, error } = await supabase
        .from('estimation_sheets')
        .select('*')
        .eq('boq_item_id', boqItem.id)
        .maybeSingle();
      
      if (error) throw error;
      if (!data || typeof data !== 'object') return null;
      
      // Type guard to ensure data matches EstimationSheet structure
      if ('boq_item_id' in data && 'total_rate' in data && 'total_amount' in data) {
        return data as EstimationSheetType;
      }
      
      return null;
    },
    { enabled: open }
  );

  const currentSheet = estimationSheet || fetchedSheet;
  const currentResources = resources.length > 0 ? resources : fetchedResources;
  const totalRate = (currentSheet && !Array.isArray(currentSheet)) ? currentSheet.total_rate : 0;
  const totalAmount = (boqItem.quantity || 0) * totalRate;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-[900px] sm:max-w-[900px] flex flex-col p-0">
        <SheetHeader className="p-6 pb-4 border-b">
          <SheetTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5" />
            Estimation Sheet
          </SheetTitle>
          <SheetDescription>
            Detailed cost estimation for BOQ item
          </SheetDescription>
        </SheetHeader>

        <ScrollArea className="flex-1">
          <div className="p-6 space-y-4">
            {/* BOQ Item Info */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Item No.</label>
                  <p className="font-mono text-sm">{boqItem.item_no}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Unit</label>
                  <p className="text-sm">{boqItem.unit}</p>
                </div>
                <div className="col-span-2">
                  <label className="text-sm font-medium text-gray-500">Description</label>
                  <p className="text-sm">{boqItem.description}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Quantity</label>
                  <p className="text-sm font-semibold">{boqItem.quantity?.toLocaleString()}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Total Amount</label>
                  <p className="text-lg font-bold text-green-600">
                    ${totalAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                </div>
              </div>
            </div>

            {/* Rate Summary */}
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <span className="text-sm font-medium">Item Rate per {boqItem.unit}</span>
              <Badge variant="secondary" className="text-lg px-3 py-1">
                ${totalRate.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </Badge>
            </div>

            {/* Tabs */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="resources" className="flex items-center gap-1">
                  <Calculator className="h-3 w-3" />
                  <span className="hidden sm:inline">Resources</span>
                </TabsTrigger>
                <TabsTrigger value="buildup" className="flex items-center gap-1">
                  <FileText className="h-3 w-3" />
                  <span className="hidden sm:inline">Build-up</span>
                </TabsTrigger>
                <TabsTrigger value="comments" className="flex items-center gap-1">
                  <MessageSquare className="h-3 w-3" />
                  <span className="hidden sm:inline">Comments</span>
                </TabsTrigger>
                <TabsTrigger value="history" className="flex items-center gap-1">
                  <History className="h-3 w-3" />
                  <span className="hidden sm:inline">History</span>
                </TabsTrigger>
                <TabsTrigger value="summary" className="flex items-center gap-1">
                  <BarChart3 className="h-3 w-3" />
                  <span className="hidden sm:inline">Summary</span>
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-1">
                  <Settings className="h-3 w-3" />
                  <span className="hidden sm:inline">Settings</span>
                </TabsTrigger>
              </TabsList>

              <div className="mt-4">
                <TabsContent value="resources" className="mt-0">
                  <ScrollArea className="h-[400px]">
                    <ResourceBreakdownTab
                      boqItem={boqItem}
                      estimationSheet={currentSheet && !Array.isArray(currentSheet) ? currentSheet : undefined}
                      resources={currentResources}
                    />
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="buildup" className="mt-0">
                  <ScrollArea className="h-[400px]">
                    <RateBuildupTab
                      boqItem={boqItem}
                      resources={currentResources}
                      totalRate={totalRate}
                    />
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="comments" className="mt-0">
                  <ScrollArea className="h-[400px]">
                    <CommentsTab
                      boqItem={boqItem}
                      estimationSheet={currentSheet && !Array.isArray(currentSheet) ? currentSheet : undefined}
                    />
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="history" className="mt-0">
                  <ScrollArea className="h-[400px]">
                    <HistoryTab
                      boqItem={boqItem}
                      estimationSheet={currentSheet && !Array.isArray(currentSheet) ? currentSheet : undefined}
                    />
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="summary" className="mt-0">
                  <ScrollArea className="h-[400px]">
                    <CostSummary jobId={boqItem.job_id} />
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="settings" className="mt-0">
                  <ScrollArea className="h-[400px]">
                    <GlobalSettings />
                  </ScrollArea>
                </TabsContent>
              </div>
            </Tabs>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
