
import { useState } from 'react';
import { BOQItem } from '@/types/mccost';
import { EstimationSheet, EstimationHistory } from '@/types/estimation';
import { useSupabaseQuery } from '@/hooks/useSupabaseQuery';
import { estimationHistoryService } from '@/services/estimationHistory';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { History, Eye, RotateCcw } from 'lucide-react';
import { format } from 'date-fns';

interface HistoryTabProps {
  boqItem: BOQItem;
  estimationSheet?: EstimationSheet;
}

export function HistoryTab({ boqItem, estimationSheet }: HistoryTabProps) {
  const [selectedVersion, setSelectedVersion] = useState<EstimationHistory | null>(null);

  const { data: history = [], isLoading } = useSupabaseQuery(
    ['estimation_history', boqItem.id],
    () => estimationHistoryService.getHistory(boqItem.id)
  );

  const handleViewVersion = (version: EstimationHistory) => {
    setSelectedVersion(version);
  };

  const handleRestoreVersion = (version: EstimationHistory) => {
    // TODO: Implement version restoration
    console.log('Restoring version:', version);
  };

  const VersionDetailDialog = ({ version }: { version: EstimationHistory }) => (
    <Dialog open={!!selectedVersion} onOpenChange={() => setSelectedVersion(null)}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Version {version.version_number} Details</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-500">Date</label>
              <p className="text-sm">{format(new Date(version.created_at), 'PPpp')}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">Version</label>
              <p className="text-sm font-semibold">#{version.version_number}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">Total Rate</label>
              <p className="text-lg font-bold text-green-600">
                ${version.total_rate.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-500">Total Amount</label>
              <p className="text-lg font-bold text-blue-600">
                ${version.total_amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>
          
          {version.change_summary && (
            <div>
              <label className="text-sm font-medium text-gray-500">Change Summary</label>
              <p className="text-sm bg-gray-50 p-3 rounded">{version.change_summary}</p>
            </div>
          )}

          {version.snapshot_data && (
            <div>
              <label className="text-sm font-medium text-gray-500">Snapshot Data</label>
              <pre className="text-xs bg-gray-50 p-3 rounded overflow-auto max-h-60">
                {JSON.stringify(version.snapshot_data, null, 2)}
              </pre>
            </div>
          )}

          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => setSelectedVersion(null)}>
              Close
            </Button>
            <Button onClick={() => handleRestoreVersion(version)} className="flex items-center gap-2">
              <RotateCcw className="h-4 w-4" />
              Restore This Version
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="text-center">
          <History className="h-8 w-8 mx-auto text-gray-400 mb-2" />
          <p className="text-gray-500">Loading history...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <History className="h-5 w-5" />
          <h4 className="font-medium">Estimation History</h4>
        </div>
        <p className="text-sm text-gray-600">
          Track all changes made to this estimation. Each save creates a new version with timestamp and change summary.
        </p>
      </div>

      {history.length === 0 ? (
        <div className="text-center py-8">
          <History className="h-12 w-12 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No History Yet</h3>
          <p className="text-gray-500">
            History will appear here once you start making changes to the estimation.
          </p>
        </div>
      ) : (
        <div className="border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Version</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Total Rate</TableHead>
                <TableHead>Total Amount</TableHead>
                <TableHead>Change Summary</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-32">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.map((version) => (
                <TableRow key={version.id}>
                  <TableCell>
                    <Badge variant={version.version_number === 1 ? "default" : "secondary"}>
                      v{version.version_number}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm">
                    {format(new Date(version.created_at), 'MMM dd, yyyy HH:mm')}
                  </TableCell>
                  <TableCell className="font-semibold">
                    ${version.total_rate.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </TableCell>
                  <TableCell className="font-semibold">
                    ${version.total_amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </TableCell>
                  <TableCell className="max-w-48">
                    <div className="text-sm text-gray-600 truncate" title={version.change_summary}>
                      {version.change_summary || 'No summary provided'}
                    </div>
                  </TableCell>
                  <TableCell>
                    {version.version_number === history[0]?.version_number ? (
                      <Badge variant="default">Current</Badge>
                    ) : (
                      <Badge variant="outline">Historical</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewVersion(version)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      {version.version_number !== history[0]?.version_number && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRestoreVersion(version)}
                        >
                          <RotateCcw className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {selectedVersion && <VersionDetailDialog version={selectedVersion} />}
    </div>
  );
}
