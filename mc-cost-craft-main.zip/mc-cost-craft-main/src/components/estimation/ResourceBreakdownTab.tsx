
import { useState } from 'react';
import { BOQItem } from '@/types/mccost';
import { EstimationSheet, EstimationResource, ResourceLibrary } from '@/types/estimation';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useEstimationMutations } from '@/hooks/useEstimationMutations';
import { ResourceLibraryManager } from './ResourceLibraryManager';
import { ResourceForm } from './resource-breakdown/ResourceForm';
import { ResourceTable } from './resource-breakdown/ResourceTable';
import { ResourceEditDialog } from './resource-breakdown/ResourceEditDialog';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ResourceBreakdownTabProps {
  boqItem: BOQItem;
  estimationSheet?: EstimationSheet;
  resources: EstimationResource[];
}

export function ResourceBreakdownTab({ boqItem, estimationSheet, resources }: ResourceBreakdownTabProps) {
  const { toast } = useToast();
  const [editingResourceData, setEditingResourceData] = useState<EstimationResource | null>(null);
  const [showLibraryPicker, setShowLibraryPicker] = useState(false);

  const { createResourceMutation, updateResourceMutation, deleteResourceMutation } = useEstimationMutations(boqItem.id);

  const handleAddResource = (resourceData: Omit<EstimationResource, 'id' | 'estimation_sheet_id' | 'boq_item_id' | 'created_at' | 'updated_at' | 'user_id' | 'total' | 'sort_order'>) => {
    const total = resourceData.rate * resourceData.coefficient;
    
    createResourceMutation.mutate({
      boq_item_id: boqItem.id,
      estimation_sheet_id: estimationSheet?.id || '',
      ...resourceData,
      total,
      sort_order: resources.length
    });
  };

  const handleSelectFromLibrary = (libraryResource: ResourceLibrary) => {
    const resourceData = {
      resource_type: libraryResource.resource_type,
      resource_name: libraryResource.resource_name,
      unit: libraryResource.unit,
      rate: libraryResource.default_rate,
      coefficient: libraryResource.default_productivity,
      comments: libraryResource.notes || ''
    };
    
    handleAddResource(resourceData);
    setShowLibraryPicker(false);
  };

  const handleUpdateResource = (resourceId: string, updates: Partial<EstimationResource>) => {
    const resource = resources.find(r => r.id === resourceId);
    if (!resource) return;

    const rate = updates.rate ?? resource.rate;
    const coefficient = updates.coefficient ?? resource.coefficient;
    const total = rate * coefficient;

    updateResourceMutation.mutate({
      id: resourceId,
      ...updates,
      total
    });
    setEditingResourceData(null);
  };

  const handleEditResourceChange = (updates: Partial<EstimationResource>) => {
    if (editingResourceData) {
      setEditingResourceData({ ...editingResourceData, ...updates });
    }
  };

  const handleFileUpload = async (resourceId: string, file: File) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const fileName = `${Date.now()}-${file.name}`;
      const filePath = `${user.id}/${resourceId}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('estimation-attachments')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Save attachment record
      const { error: dbError } = await supabase
        .from('estimation_attachments')
        .insert({
          estimation_resource_id: resourceId,
          estimation_sheet_id: estimationSheet?.id,
          file_name: file.name,
          file_size: file.size,
          file_type: file.type,
          storage_path: filePath,
          user_id: user.id
        });

      if (dbError) throw dbError;

      toast({ title: 'Success', description: 'File uploaded successfully' });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const totalResourceCost = resources.reduce((sum, resource) => sum + resource.total, 0);

  return (
    <div className="space-y-4">
      {/* Add New Resource Form */}
      <ResourceForm
        onAddResource={handleAddResource}
        onShowLibrary={() => setShowLibraryPicker(true)}
      />

      {/* Resources Table */}
      <ResourceTable
        resources={resources}
        onEditResource={setEditingResourceData}
        onDeleteResource={(id) => deleteResourceMutation.mutate(id)}
        onFileUpload={handleFileUpload}
      />

      {/* Total Summary */}
      <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
        <span className="font-medium">Total Resource Cost per {boqItem.unit}:</span>
        <span className="text-xl font-bold text-blue-700">
          ${totalResourceCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
        </span>
      </div>

      {/* Resource Library Picker Dialog */}
      <Dialog open={showLibraryPicker} onOpenChange={setShowLibraryPicker}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Select from Resource Library</DialogTitle>
          </DialogHeader>
          <ResourceLibraryManager
            mode="picker"
            onSelectResource={handleSelectFromLibrary}
          />
        </DialogContent>
      </Dialog>

      {/* Resource Edit Dialog */}
      <ResourceEditDialog
        resource={editingResourceData}
        onClose={() => setEditingResourceData(null)}
        onSave={handleUpdateResource}
        onChange={handleEditResourceChange}
      />
    </div>
  );
}
