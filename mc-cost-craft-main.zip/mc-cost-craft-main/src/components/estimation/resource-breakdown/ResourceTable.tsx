
import { EstimationResource, RESOURCE_TYPES } from '@/types/estimation';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Edit3, Trash2, Paperclip } from 'lucide-react';

interface ResourceTableProps {
  resources: EstimationResource[];
  onEditResource: (resource: EstimationResource) => void;
  onDeleteResource: (id: string) => void;
  onFileUpload: (resourceId: string, file: File) => void;
}

export function ResourceTable({ resources, onEditResource, onDeleteResource, onFileUpload }: ResourceTableProps) {
  const getResourceTypeStyle = (type: EstimationResource['resource_type']) => {
    const typeConfig = RESOURCE_TYPES.find(t => t.value === type);
    return typeConfig?.color || 'bg-gray-50 text-gray-700';
  };

  return (
    <div className="border rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Type</TableHead>
            <TableHead>Resource Name</TableHead>
            <TableHead>Unit</TableHead>
            <TableHead>Rate</TableHead>
            <TableHead>Coefficient</TableHead>
            <TableHead>Total</TableHead>
            <TableHead>Comments</TableHead>
            <TableHead>Files</TableHead>
            <TableHead className="w-20"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {resources.map((resource) => (
            <TableRow key={resource.id}>
              <TableCell>
                <Badge className={getResourceTypeStyle(resource.resource_type)}>
                  {resource.resource_type}
                </Badge>
              </TableCell>
              <TableCell className="font-medium">{resource.resource_name}</TableCell>
              <TableCell>{resource.unit}</TableCell>
              <TableCell>${resource.rate.toLocaleString()}</TableCell>
              <TableCell>{resource.coefficient}</TableCell>
              <TableCell className="font-semibold">
                ${resource.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </TableCell>
              <TableCell className="max-w-32">
                <div className="text-sm text-gray-600 truncate" title={resource.comments || ''}>
                  {resource.comments}
                </div>
              </TableCell>
              <TableCell>
                <label className="cursor-pointer">
                  <input
                    type="file"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) onFileUpload(resource.id, file);
                    }}
                  />
                  <Paperclip className="h-4 w-4 text-gray-400 hover:text-gray-600" />
                </label>
              </TableCell>
              <TableCell>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEditResource(resource)}
                  >
                    <Edit3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDeleteResource(resource.id)}
                  >
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
          {resources.length === 0 && (
            <TableRow>
              <TableCell colSpan={9} className="text-center py-8 text-gray-500">
                No resources added yet. Add your first resource above.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
}
