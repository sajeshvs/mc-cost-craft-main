
import { EstimationResource, RESOURCE_TYPES } from '@/types/estimation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

interface ResourceEditDialogProps {
  resource: EstimationResource | null;
  onClose: () => void;
  onSave: (resourceId: string, updates: Partial<EstimationResource>) => void;
  onChange: (updates: Partial<EstimationResource>) => void;
}

export function ResourceEditDialog({ resource, onClose, onSave, onChange }: ResourceEditDialogProps) {
  if (!resource) return null;

  const handleSave = () => {
    onSave(resource.id, resource);
  };

  return (
    <Dialog open={!!resource} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Resource</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Resource Type</Label>
            <Select
              value={resource.resource_type}
              onValueChange={(value: EstimationResource['resource_type']) =>
                onChange({ resource_type: value })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {RESOURCE_TYPES.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Resource Name</Label>
            <Input
              value={resource.resource_name || ''}
              onChange={(e) => onChange({ resource_name: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label>Unit</Label>
              <Input
                value={resource.unit || ''}
                onChange={(e) => onChange({ unit: e.target.value })}
              />
            </div>
            <div>
              <Label>Rate</Label>
              <Input
                type="number"
                value={resource.rate || 0}
                onChange={(e) => onChange({ rate: parseFloat(e.target.value) || 0 })}
              />
            </div>
          </div>
          <div>
            <Label>Coefficient</Label>
            <Input
              type="number"
              step="0.01"
              value={resource.coefficient || 1}
              onChange={(e) => onChange({ coefficient: parseFloat(e.target.value) || 1 })}
            />
          </div>
          <div>
            <Label>Comments</Label>
            <Textarea
              value={resource.comments || ''}
              onChange={(e) => onChange({ comments: e.target.value })}
              rows={3}
            />
          </div>
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleSave}>
              Update
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
