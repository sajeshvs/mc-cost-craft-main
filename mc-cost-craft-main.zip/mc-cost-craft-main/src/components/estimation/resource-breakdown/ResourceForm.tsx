
import { useState } from 'react';
import { EstimationResource, RESOURCE_TYPES } from '@/types/estimation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Library } from 'lucide-react';

interface ResourceFormProps {
  onAddResource: (resource: Omit<EstimationResource, 'id' | 'estimation_sheet_id' | 'boq_item_id' | 'created_at' | 'updated_at' | 'user_id' | 'total' | 'sort_order'>) => void;
  onShowLibrary: () => void;
}

export function ResourceForm({ onAddResource, onShowLibrary }: ResourceFormProps) {
  const [newResource, setNewResource] = useState({
    resource_type: 'Labor' as EstimationResource['resource_type'],
    resource_name: '',
    unit: '',
    rate: 0,
    coefficient: 1,
    comments: ''
  });

  const handleAdd = () => {
    if (!newResource.resource_name || !newResource.unit) return;
    
    onAddResource(newResource);
    setNewResource({
      resource_type: 'Labor',
      resource_name: '',
      unit: '',
      rate: 0,
      coefficient: 1,
      comments: ''
    });
  };

  const handleLibraryResource = (libraryResource: any) => {
    setNewResource({
      resource_type: libraryResource.resource_type,
      resource_name: libraryResource.resource_name,
      unit: libraryResource.unit,
      rate: libraryResource.default_rate,
      coefficient: libraryResource.default_productivity,
      comments: libraryResource.notes || ''
    });
  };

  return (
    <div className="p-4 border rounded-lg bg-gray-50">
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-medium">Add New Resource</h4>
        <Button
          variant="outline"
          size="sm"
          onClick={onShowLibrary}
          className="flex items-center gap-2"
        >
          <Library className="h-4 w-4" />
          From Library
        </Button>
      </div>
      <div className="grid grid-cols-12 gap-2">
        <div className="col-span-2">
          <Select
            value={newResource.resource_type}
            onValueChange={(value: EstimationResource['resource_type']) =>
              setNewResource({ ...newResource, resource_type: value })
            }
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {RESOURCE_TYPES.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <Input
          className="col-span-3"
          placeholder="Resource Name"
          value={newResource.resource_name}
          onChange={(e) => setNewResource({ ...newResource, resource_name: e.target.value })}
        />
        
        <Input
          className="col-span-1"
          placeholder="Unit"
          value={newResource.unit}
          onChange={(e) => setNewResource({ ...newResource, unit: e.target.value })}
        />
        
        <Input
          className="col-span-2"
          type="number"
          placeholder="Rate"
          value={newResource.rate}
          onChange={(e) => setNewResource({ ...newResource, rate: parseFloat(e.target.value) || 0 })}
        />
        
        <Input
          className="col-span-1"
          type="number"
          placeholder="Coeff"
          step="0.01"
          value={newResource.coefficient}
          onChange={(e) => setNewResource({ ...newResource, coefficient: parseFloat(e.target.value) || 1 })}
        />

        <Input
          className="col-span-2"
          placeholder="Comments"
          value={newResource.comments}
          onChange={(e) => setNewResource({ ...newResource, comments: e.target.value })}
        />
        
        <Button className="col-span-1" onClick={handleAdd} size="sm">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
