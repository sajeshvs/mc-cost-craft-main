
import { useState } from 'react';
import { useSupabaseQuery } from '@/hooks/useSupabaseQuery';
import { supabase } from '@/integrations/supabase/client';
import { RESOURCE_TYPES } from '@/types/estimation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { TrendingUp, TrendingDown, Target, DollarSign } from 'lucide-react';

interface CostSummaryProps {
  jobId: string;
}

interface ResourceSummary {
  resource_type: string;
  total_cost: number;
  resource_count: number;
  avg_rate: number;
}

interface CostComparison {
  resource_type: string;
  actual_cost: number;
  target_cost: number;
  variance_percent: number;
  status: 'under' | 'over' | 'on-target';
}

export function CostSummary({ jobId }: CostSummaryProps) {
  const [targetRates, setTargetRates] = useState<{ [key: string]: number }>({});

  // Fetch resource summary by type
  const { data: resourceSummary = [] } = useSupabaseQuery(
    ['cost_summary', jobId],
    async () => {
      const { data, error } = await supabase
        .from('estimation_resources' as any)
        .select(`
          resource_type,
          total,
          rate,
          estimation_sheet_id,
          estimation_sheets!inner(boq_item_id, boq_items!inner(job_id))
        `)
        .eq('estimation_sheets.boq_items.job_id', jobId);

      if (error) throw error;

      // Group by resource type
      const grouped = (data || []).reduce((acc: any, item: any) => {
        const type = item.resource_type;
        if (!acc[type]) {
          acc[type] = {
            resource_type: type,
            total_cost: 0,
            resource_count: 0,
            total_rate: 0
          };
        }
        acc[type].total_cost += item.total || 0;
        acc[type].resource_count += 1;
        acc[type].total_rate += item.rate || 0;
        return acc;
      }, {});

      return Object.values(grouped).map((item: any) => ({
        ...item,
        avg_rate: item.resource_count > 0 ? item.total_rate / item.resource_count : 0
      })) as ResourceSummary[];
    }
  );

  const totalProjectCost = resourceSummary.reduce((sum, item) => sum + item.total_cost, 0);

  const handleTargetRateChange = (resourceType: string, value: number) => {
    setTargetRates(prev => ({ ...prev, [resourceType]: value }));
  };

  const getCostComparison = (): CostComparison[] => {
    return resourceSummary.map(item => {
      const targetCost = targetRates[item.resource_type] || 0;
      const actualCost = item.total_cost;
      const variance = targetCost > 0 ? ((actualCost - targetCost) / targetCost) * 100 : 0;
      
      let status: 'under' | 'over' | 'on-target' = 'on-target';
      if (Math.abs(variance) <= 5) status = 'on-target';
      else if (variance > 0) status = 'over';
      else status = 'under';

      return {
        resource_type: item.resource_type,
        actual_cost: actualCost,
        target_cost: targetCost,
        variance_percent: variance,
        status
      };
    });
  };

  const getResourceTypeStyle = (type: string) => {
    const typeConfig = RESOURCE_TYPES.find(t => t.value === type);
    return typeConfig?.color || 'bg-gray-50 text-gray-700';
  };

  const getStatusColor = (status: CostComparison['status']) => {
    switch (status) {
      case 'under': return 'text-green-600';
      case 'over': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: CostComparison['status']) => {
    switch (status) {
      case 'under': return <TrendingDown className="h-4 w-4 text-green-600" />;
      case 'over': return <TrendingUp className="h-4 w-4 text-red-600" />;
      default: return <Target className="h-4 w-4 text-gray-600" />;
    }
  };

  const pieChartData = resourceSummary.map((item, index) => ({
    name: item.resource_type,
    value: item.total_cost,
    color: `hsl(${index * 60}, 70%, 50%)`
  }));

  const barChartData = getCostComparison().map(item => ({
    resource_type: item.resource_type,
    actual: item.actual_cost,
    target: item.target_cost
  }));

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Project Cost</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${totalProjectCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">
              Across {resourceSummary.reduce((sum, item) => sum + item.resource_count, 0)} resources
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Resource Types</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{resourceSummary.length}</div>
            <p className="text-xs text-muted-foreground">
              Different resource categories
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Cost Variance</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {getCostComparison().length > 0 ? 
                (getCostComparison().reduce((sum, item) => sum + Math.abs(item.variance_percent), 0) / getCostComparison().length).toFixed(1) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              From target costs
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Cost Distribution by Resource Type</CardTitle>
            <CardDescription>Breakdown of total costs across resource categories</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => [`$${value.toLocaleString()}`, 'Cost']} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Actual vs Target Costs</CardTitle>
            <CardDescription>Comparison of actual costs against target benchmarks</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={barChartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="resource_type" />
                <YAxis />
                <Tooltip formatter={(value: number) => `$${value.toLocaleString()}`} />
                <Legend />
                <Bar dataKey="actual" fill="#3b82f6" name="Actual Cost" />
                <Bar dataKey="target" fill="#ef4444" name="Target Cost" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Summary Table */}
      <Card>
        <CardHeader>
          <CardTitle>Resource Type Summary</CardTitle>
          <CardDescription>Detailed breakdown with target comparison and variance analysis</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Resource Type</TableHead>
                  <TableHead>Count</TableHead>
                  <TableHead>Total Cost</TableHead>
                  <TableHead>Avg Rate</TableHead>
                  <TableHead>Target Cost</TableHead>
                  <TableHead>Variance</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>% of Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {resourceSummary.map((item) => {
                  const comparison = getCostComparison().find(c => c.resource_type === item.resource_type);
                  const percentage = totalProjectCost > 0 ? (item.total_cost / totalProjectCost) * 100 : 0;
                  
                  return (
                    <TableRow key={item.resource_type}>
                      <TableCell>
                        <Badge className={getResourceTypeStyle(item.resource_type)}>
                          {item.resource_type}
                        </Badge>
                      </TableCell>
                      <TableCell>{item.resource_count}</TableCell>
                      <TableCell className="font-semibold">
                        ${item.total_cost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        ${item.avg_rate.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          placeholder="Set target"
                          value={targetRates[item.resource_type] || ''}
                          onChange={(e) => handleTargetRateChange(item.resource_type, parseFloat(e.target.value) || 0)}
                          className="w-32"
                        />
                      </TableCell>
                      <TableCell>
                        {comparison && (
                          <span className={getStatusColor(comparison.status)}>
                            {comparison.variance_percent > 0 ? '+' : ''}
                            {comparison.variance_percent.toFixed(1)}%
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {comparison && getStatusIcon(comparison.status)}
                          {comparison?.status || 'N/A'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={percentage} className="w-16" />
                          <span className="text-sm">{percentage.toFixed(1)}%</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
                {resourceSummary.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                      No estimation data available for this job yet.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
