
import { useState } from 'react';
import { useSupabaseQuery } from '@/hooks/useSupabaseQuery';
import { useSupabaseMutation } from '@/hooks/useSupabaseQuery';
import { resourceLibraryService } from '@/services/resourceLibrary';
import { ResourceLibrary, RESOURCE_TYPES } from '@/types/estimation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Plus, Edit, Trash2, Search, Library } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface ResourceLibraryManagerProps {
  onSelectResource?: (resource: ResourceLibrary) => void;
  mode?: 'standalone' | 'picker';
}

export function ResourceLibraryManager({ onSelectResource, mode = 'standalone' }: ResourceLibraryManagerProps) {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingResource, setEditingResource] = useState<ResourceLibrary | null>(null);
  const [newResource, setNewResource] = useState({
    resource_code: '',
    resource_name: '',
    resource_type: 'Labor' as ResourceLibrary['resource_type'],
    unit: '',
    default_rate: 0,
    default_productivity: 1,
    notes: ''
  });

  const { data: resources = [], isLoading } = useSupabaseQuery(
    ['resource_library'],
    () => searchQuery ? resourceLibraryService.search(searchQuery) : resourceLibraryService.getAll()
  );

  const createMutation = useSupabaseMutation(
    resourceLibraryService.create,
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Resource added to library' });
        setShowAddDialog(false);
        setNewResource({
          resource_code: '',
          resource_name: '',
          resource_type: 'Labor',
          unit: '',
          default_rate: 0,
          default_productivity: 1,
          notes: ''
        });
      },
      invalidateKeys: [['resource_library']]
    }
  );

  const updateMutation = useSupabaseMutation(
    ({ id, ...data }: { id: string } & Partial<ResourceLibrary>) => 
      resourceLibraryService.update(id, data),
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Resource updated' });
        setEditingResource(null);
      },
      invalidateKeys: [['resource_library']]
    }
  );

  const deleteMutation = useSupabaseMutation(
    resourceLibraryService.delete,
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Resource deleted' });
      },
      invalidateKeys: [['resource_library']]
    }
  );

  const handleAddResource = () => {
    if (!newResource.resource_code || !newResource.resource_name || !newResource.unit) {
      toast({ title: 'Error', description: 'Please fill in all required fields' });
      return;
    }
    createMutation.mutate(newResource);
  };

  const handleUpdateResource = () => {
    if (!editingResource) return;
    updateMutation.mutate({
      id: editingResource.id,
      ...editingResource
    });
  };

  const getResourceTypeStyle = (type: ResourceLibrary['resource_type']) => {
    const typeConfig = RESOURCE_TYPES.find(t => t.value === type);
    return typeConfig?.color || 'bg-gray-50 text-gray-700';
  };

  const ResourceDialog = ({ resource, onSave, onClose }: {
    resource: Partial<ResourceLibrary>;
    onSave: () => void;
    onClose: () => void;
  }) => (
    <DialogContent className="max-w-md">
      <DialogHeader>
        <DialogTitle>{resource.id ? 'Edit Resource' : 'Add New Resource'}</DialogTitle>
      </DialogHeader>
      <div className="space-y-4">
        <div>
          <Label>Resource Code *</Label>
          <Input
            value={resource.resource_code || ''}
            onChange={(e) => resource.id ? 
              setEditingResource({ ...editingResource!, resource_code: e.target.value }) :
              setNewResource({ ...newResource, resource_code: e.target.value })
            }
            placeholder="e.g., LAB001"
          />
        </div>
        <div>
          <Label>Resource Name *</Label>
          <Input
            value={resource.resource_name || ''}
            onChange={(e) => resource.id ? 
              setEditingResource({ ...editingResource!, resource_name: e.target.value }) :
              setNewResource({ ...newResource, resource_name: e.target.value })
            }
            placeholder="e.g., Skilled Carpenter"
          />
        </div>
        <div>
          <Label>Type *</Label>
          <Select
            value={resource.resource_type || 'Labor'}
            onValueChange={(value: ResourceLibrary['resource_type']) =>
              resource.id ? 
                setEditingResource({ ...editingResource!, resource_type: value }) :
                setNewResource({ ...newResource, resource_type: value })
            }
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {RESOURCE_TYPES.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Unit *</Label>
          <Input
            value={resource.unit || ''}
            onChange={(e) => resource.id ? 
              setEditingResource({ ...editingResource!, unit: e.target.value }) :
              setNewResource({ ...newResource, unit: e.target.value })
            }
            placeholder="e.g., Hour, Day, m3"
          />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label>Default Rate</Label>
            <Input
              type="number"
              value={resource.default_rate || 0}
              onChange={(e) => resource.id ? 
                setEditingResource({ ...editingResource!, default_rate: parseFloat(e.target.value) || 0 }) :
                setNewResource({ ...newResource, default_rate: parseFloat(e.target.value) || 0 })
              }
            />
          </div>
          <div>
            <Label>Productivity</Label>
            <Input
              type="number"
              step="0.01"
              value={resource.default_productivity || 1}
              onChange={(e) => resource.id ? 
                setEditingResource({ ...editingResource!, default_productivity: parseFloat(e.target.value) || 1 }) :
                setNewResource({ ...newResource, default_productivity: parseFloat(e.target.value) || 1 })
              }
            />
          </div>
        </div>
        <div>
          <Label>Notes</Label>
          <Textarea
            value={resource.notes || ''}
            onChange={(e) => resource.id ? 
              setEditingResource({ ...editingResource!, notes: e.target.value }) :
              setNewResource({ ...newResource, notes: e.target.value })
            }
            rows={3}
          />
        </div>
        <div className="flex gap-2 justify-end">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={onSave}>Save</Button>
        </div>
      </div>
    </DialogContent>
  );

  if (mode === 'picker') {
    return (
      <div className="space-y-4">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search resources..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <div className="max-h-60 overflow-y-auto border rounded">
          {resources.map((resource) => (
            <div
              key={resource.id}
              className="p-3 border-b hover:bg-gray-50 cursor-pointer flex justify-between items-center"
              onClick={() => onSelectResource?.(resource)}
            >
              <div>
                <div className="flex items-center gap-2">
                  <Badge className={getResourceTypeStyle(resource.resource_type)}>
                    {resource.resource_type}
                  </Badge>
                  <span className="font-medium">{resource.resource_name}</span>
                </div>
                <div className="text-sm text-gray-500">
                  {resource.resource_code} • {resource.unit} • ${resource.default_rate}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Library className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Resource Library</h3>
        </div>
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Resource
            </Button>
          </DialogTrigger>
          <ResourceDialog
            resource={newResource}
            onSave={handleAddResource}
            onClose={() => setShowAddDialog(false)}
          />
        </Dialog>
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search resources..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Code</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Unit</TableHead>
              <TableHead>Rate</TableHead>
              <TableHead>Productivity</TableHead>
              <TableHead className="w-20"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {resources.map((resource) => (
              <TableRow key={resource.id}>
                <TableCell className="font-mono text-sm">{resource.resource_code}</TableCell>
                <TableCell className="font-medium">{resource.resource_name}</TableCell>
                <TableCell>
                  <Badge className={getResourceTypeStyle(resource.resource_type)}>
                    {resource.resource_type}
                  </Badge>
                </TableCell>
                <TableCell>{resource.unit}</TableCell>
                <TableCell>${resource.default_rate.toLocaleString()}</TableCell>
                <TableCell>{resource.default_productivity}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setEditingResource(resource)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteMutation.mutate(resource.id)}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {resources.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                  {searchQuery ? 'No resources found matching your search.' : 'No resources in library yet.'}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {editingResource && (
        <Dialog open={!!editingResource} onOpenChange={() => setEditingResource(null)}>
          <ResourceDialog
            resource={editingResource}
            onSave={handleUpdateResource}
            onClose={() => setEditingResource(null)}
          />
        </Dialog>
      )}
    </div>
  );
}
