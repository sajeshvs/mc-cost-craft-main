
import { useParams } from 'react-router-dom';
import { BOQContainer } from '@/components/boq/BOQContainer';

export function BOQPage() {
  const { jobId } = useParams<{ jobId: string }>();
  
  if (!jobId) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Job ID Required</h2>
          <p className="text-muted-foreground">Please select a job to view its BOQ.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col">
      <BOQContainer />
    </div>
  );
}
