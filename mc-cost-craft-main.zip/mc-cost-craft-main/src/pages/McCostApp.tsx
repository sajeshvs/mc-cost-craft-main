import { Routes, Route, Navigate } from 'react-router-dom';
import { SimplifiedLayout } from '@/components/layout/SimplifiedLayout';
import { CompanyManager } from '@/components/company/CompanyManager';
import { JobManager } from '@/components/job/JobManager';
import { BOQImporter } from '@/components/boq/BOQImporter';
import { BOQPage } from './BOQPage';

function McCostApp() {
  return (
    <Routes>
      <Route path="/" element={<SimplifiedLayout />}>
        <Route index element={<Navigate to="companies" replace />} />
        <Route path="companies" element={<CompanyManager />} />
        <Route path="companies/:companyId/jobs" element={<JobManager />} />
        <Route path="jobs/:jobId/import-boq" element={<BOQImporter />} />
        <Route path="jobs/:jobId/boq" element={<BOQPage />} />
      </Route>
    </Routes>
  );
}

export default McCostApp;
