
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Building2, Briefcase, FileSpreadsheet, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Start() {
  const steps = [
    {
      number: 1,
      label: "Create Company",
      description: "Manage your company profile with currency and location",
      icon: Building2,
      href: "/mccost/companies",
      buttonLabel: "Go to Companies"
    },
    {
      number: 2,
      label: "Add Project",
      description: "Create a new job and define client, location, and currency",
      icon: Briefcase,
      href: "/mccost/jobs",
      buttonLabel: "Go to Jobs"
    },
    {
      number: 3,
      label: "Import BOQ",
      description: "Upload and map Excel BOQ with drag-and-drop ordering",
      icon: FileSpreadsheet,
      href: "/mccost/import-boq",
      buttonLabel: "Import BOQ"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to McCost</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Get started with your construction cost estimation in three simple steps
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {steps.map((step, index) => (
            <Card key={step.number} className="relative h-full">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <step.icon className="w-8 h-8 text-white" />
                </div>
                <div className="absolute top-4 left-4 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {step.number}
                </div>
                <CardTitle className="text-xl">{step.label}</CardTitle>
                <CardDescription className="text-center">
                  {step.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <Button asChild className="w-full">
                  <Link to={step.href}>
                    {step.buttonLabel}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-10 text-center">
          <p className="text-gray-600 mb-4">
            Already have everything set up?
          </p>
          <Button variant="outline" asChild>
            <Link to="/mccost/companies">
              Go to Dashboard
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
