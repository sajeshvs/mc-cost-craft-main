
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/components/auth/AuthProvider";
import { LoginForm } from "@/components/auth/LoginForm";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import McCostApp from "./pages/McCostApp";

const queryClient = new QueryClient();

function AuthenticatedApp() {
  const { user, loading } = useAuth();

  console.log('AuthenticatedApp: Auth state:', { user: user?.id, loading });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div>Loading authentication...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    console.log('AuthenticatedApp: No user found, showing login form');
    return <LoginForm />;
  }

  return (
    <Routes>
      <Route path="/" element={<Navigate to="/mccost/companies" replace />} />
      <Route path="/start" element={<Navigate to="/mccost/companies" replace />} />
      <Route path="/index" element={<Index />} />
      <Route path="/mccost/*" element={<McCostApp />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <AuthenticatedApp />
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
