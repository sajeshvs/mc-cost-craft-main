
import { supabase } from '@/integrations/supabase/client';
import { GlobalSettings } from '@/types/estimation';

export const globalSettingsService = {
  async getSetting(key: string): Promise<GlobalSettings | null> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('global_settings')
      .select('*')
      .eq('setting_key', key)
      .eq('user_id', user.id)
      .single();
    
    if (error && error.code !== 'PGRST116') throw error;
    if (!data || typeof data !== 'object') return null;
    
    return data as GlobalSettings;
  },

  async setSetting(key: string, value: any): Promise<GlobalSettings> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('global_settings')
      .upsert({ 
        setting_key: key, 
        setting_value: value, 
        user_id: user.id,
        updated_at: new Date().toISOString()
      })
      .select()
      .single();
    
    if (error) throw error;
    if (!data || typeof data !== 'object') throw new Error('Invalid response data');
    
    return data as GlobalSettings;
  },

  async getAllSettings(): Promise<GlobalSettings[]> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('global_settings')
      .select('*')
      .eq('user_id', user.id);
    
    if (error) throw error;
    if (!Array.isArray(data)) return [];
    
    return data as GlobalSettings[];
  }
};
