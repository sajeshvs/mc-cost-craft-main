
import { BOQItem } from '@/types/mccost';
import { Trade } from '@/types/trades';
import { PriceListItem } from '@/types/priceList';
import { PriceCodeAnalysisResource } from '@/services/priceCodeAnalysis';
import { MarkupLine } from '@/types/markup';
import { TradeSummaryItem, LevelSummaryItem, TradeSummaryTotals } from '@/types/tradeSummary';

export class TradeSummaryService {
  
  static calculateTradeSummary(
    boqItems: BOQItem[],
    trades: Trade[],
    priceList: PriceListItem[],
    analysisResources: PriceCodeAnalysisResource[],
    markupLines: MarkupLine[],
    selectedTrades: string[]
  ): TradeSummaryItem[] {
    
    if (!boqItems.length || !trades.length || !selectedTrades.length) {
      return [];
    }

    const tradeMap = new Map(trades.map(t => [t.trade_code, t]));
    const priceMap = new Map(priceList.map(p => [p.price_code, p]));
    const analysisMap = new Map<string, PriceCodeAnalysisResource[]>();
    
    // Group analysis resources by price code
    analysisResources.forEach(resource => {
      if (!analysisMap.has(resource.price_code)) {
        analysisMap.set(resource.price_code, []);
      }
      analysisMap.get(resource.price_code)!.push(resource);
    });
    
    const tradeSummaries = new Map<string, TradeSummaryItem>();
    
    // Process each selected trade
    selectedTrades.forEach(tradeCode => {
      const trade = tradeMap.get(tradeCode);
      if (!trade) return;
      
      const tradeItems = boqItems.filter(item => {
        if (item.level_type !== 'item') return false;
        const priceItem = item.price_code ? priceMap.get(item.price_code) : null;
        return priceItem && priceItem.trade_code === tradeCode;
      });
      
      if (tradeItems.length === 0) return;
      
      const summary = this.calculateItemSummary(
        tradeCode,
        trade.description,
        tradeItems,
        priceMap,
        analysisMap,
        markupLines,
        'trade'
      );
      
      if (summary) {
        tradeSummaries.set(tradeCode, summary);
      }
    });
    
    return Array.from(tradeSummaries.values());
  }
  
  static calculateLevelSummary(
    boqItems: BOQItem[],
    priceList: PriceListItem[],
    analysisResources: PriceCodeAnalysisResource[],
    markupLines: MarkupLine[],
    selectedLevels: number[],
    includeAdminRows: boolean
  ): LevelSummaryItem[] {
    
    if (!boqItems.length || !selectedLevels.length) {
      return [];
    }

    const priceMap = new Map(priceList.map(p => [p.price_code, p]));
    const analysisMap = new Map<string, PriceCodeAnalysisResource[]>();
    
    analysisResources.forEach(resource => {
      if (!analysisMap.has(resource.price_code)) {
        analysisMap.set(resource.price_code, []);
      }
      analysisMap.get(resource.price_code)!.push(resource);
    });
    
    const levelSummaries: LevelSummaryItem[] = [];
    
    selectedLevels.forEach(level => {
      const levelItems = this.getLevelItems(boqItems, level, includeAdminRows);
      
      if (levelItems.length > 0) {
        const levelHeader = boqItems.find(item => 
          item.level_type === `level_${level}` && 
          this.isLevelParent(boqItems, item, levelItems)
        );
        
        const workItems = levelItems.filter(item => item.level_type === 'item');
        const adminItems = levelItems.filter(item => item.level_type === 'comment');
        
        const summary = this.calculateItemSummary(
          `Level ${level}`,
          levelHeader?.description || `Level ${level}`,
          workItems,
          priceMap,
          analysisMap,
          markupLines,
          'level'
        );
        
        if (summary) {
          const levelSummary: LevelSummaryItem = {
            ...summary,
            level,
            hasAdminRow: adminItems.length > 0,
            adminDescription: adminItems.length > 0 ? adminItems[0].description : undefined
          };
          
          levelSummaries.push(levelSummary);
        }
      }
    });
    
    return levelSummaries;
  }
  
  private static getLevelItems(boqItems: BOQItem[], level: number, includeAdminRows: boolean): BOQItem[] {
    const items: BOQItem[] = [];
    let inLevel = false;
    
    for (let i = 0; i < boqItems.length; i++) {
      const item = boqItems[i];
      
      if (item.level_type?.startsWith('level_')) {
        const itemLevel = parseInt(item.level_type.replace('level_', ''));
        
        if (itemLevel === level) {
          inLevel = true;
          continue;
        } else if (itemLevel <= level && inLevel) {
          break;
        }
      }
      
      if (inLevel) {
        if (item.level_type === 'item' || (includeAdminRows && item.level_type === 'comment')) {
          items.push(item);
        }
      }
    }
    
    return items;
  }
  
  private static isLevelParent(boqItems: BOQItem[], levelItem: BOQItem, childItems: BOQItem[]): boolean {
    const levelIndex = boqItems.findIndex(item => item.id === levelItem.id);
    return childItems.some(child => {
      const childIndex = boqItems.findIndex(item => item.id === child.id);
      return childIndex > levelIndex;
    });
  }
  
  private static calculateItemSummary(
    code: string,
    description: string,
    items: BOQItem[],
    priceMap: Map<string, PriceListItem>,
    analysisMap: Map<string, PriceCodeAnalysisResource[]>,
    markupLines: MarkupLine[],
    type: 'trade' | 'level'
  ): TradeSummaryItem | null {
    
    if (items.length === 0) return null;
    
    let totalQuantity = 0;
    let laborManhours = 0;
    let laborAmount = 0;
    let materialAmount = 0;
    let equipmentAmount = 0;
    let subcontractorAmount = 0;
    let consultantAmount = 0;
    
    items.forEach(item => {
      const quantity = item.quantity || 0;
      totalQuantity += quantity;
      
      if (item.price_code) {
        const resources = analysisMap.get(item.price_code) || [];
        
        resources.forEach(resource => {
          const resourceQuantity = resource.quantity || 0;
          const resourceRate = resource.unit_rate || 0;
          const resourceTotal = (resourceQuantity * resourceRate) * quantity;
          
          switch (resource.category) {
            case 'P':
              laborAmount += resourceTotal;
              // Calculate manhours (assuming quantity represents hours per unit)
              laborManhours += resourceQuantity * quantity;
              break;
            case 'M':
              materialAmount += resourceTotal;
              break;
            case 'E':
              equipmentAmount += resourceTotal;
              break;
            case 'S':
              subcontractorAmount += resourceTotal;
              break;
            case 'C':
              consultantAmount += resourceTotal;
              break;
          }
        });
      }
    });
    
    const totalDirectCost = laborAmount + materialAmount + equipmentAmount + subcontractorAmount + consultantAmount;
    
    // Apply markup calculations
    const markup = markupLines.find(line => line.ref_id === code) || markupLines[0];
    let indirectCost = 0;
    let profit = 0;
    
    if (markup) {
      const overheadPercent = (markup.site_overhead_percent || 0) + (markup.ho_ga_percent || 0);
      indirectCost = totalDirectCost * (overheadPercent / 100);
      profit = (totalDirectCost + indirectCost) * ((markup.profit_percent || 0) / 100);
    }
    
    const totalFinalValue = totalDirectCost + indirectCost + profit;
    
    return {
      code,
      description,
      totalQuantity,
      laborManhours,
      laborAmount,
      materialAmount,
      equipmentAmount,
      subcontractorAmount,
      consultantAmount,
      totalDirectCost,
      indirectCost,
      profit,
      totalFinalValue,
      percentOfProject: 0, // Will be calculated after all summaries
      type,
      boqItems: items.map(item => item.id)
    };
  }
  
  static calculateTotals(summaries: TradeSummaryItem[]): TradeSummaryTotals {
    return summaries.reduce((totals, item) => ({
      totalQuantity: totals.totalQuantity + item.totalQuantity,
      totalLaborManhours: totals.totalLaborManhours + item.laborManhours,
      totalLaborAmount: totals.totalLaborAmount + item.laborAmount,
      totalMaterialAmount: totals.totalMaterialAmount + item.materialAmount,
      totalEquipmentAmount: totals.totalEquipmentAmount + item.equipmentAmount,
      totalSubcontractorAmount: totals.totalSubcontractorAmount + item.subcontractorAmount,
      totalConsultantAmount: totals.totalConsultantAmount + item.consultantAmount,
      totalDirectCost: totals.totalDirectCost + item.totalDirectCost,
      totalIndirectCost: totals.totalIndirectCost + item.indirectCost,
      totalProfit: totals.totalProfit + item.profit,
      grandTotal: totals.grandTotal + item.totalFinalValue
    }), {
      totalQuantity: 0,
      totalLaborManhours: 0,
      totalLaborAmount: 0,
      totalMaterialAmount: 0,
      totalEquipmentAmount: 0,
      totalSubcontractorAmount: 0,
      totalConsultantAmount: 0,
      totalDirectCost: 0,
      totalIndirectCost: 0,
      totalProfit: 0,
      grandTotal: 0
    });
  }
  
  static updatePercentages(summaries: TradeSummaryItem[], totals: TradeSummaryTotals): TradeSummaryItem[] {
    return summaries.map(item => ({
      ...item,
      percentOfProject: totals.grandTotal > 0 ? (item.totalFinalValue / totals.grandTotal) * 100 : 0
    }));
  }
}
