
import { supabase } from '@/integrations/supabase/client';
import { MarkupItem, MarkupEntry, MarkupConfig, MarkupVersion, MarkupLine, TradeMarkupData, ItemMarkupData } from '@/types/markup';

export const markupService = {
  // Version management
  async getMarkupVersions(projectId: string, mode: 'trade' | 'item'): Promise<MarkupVersion[]> {
    const { data, error } = await supabase
      .from('markup_versions')
      .select('*')
      .eq('project_id', projectId)
      .eq('mode', mode)
      .order('version_number', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async getCurrentVersion(projectId: string, mode: 'trade' | 'item'): Promise<MarkupVersion | null> {
    const { data, error } = await supabase
      .from('markup_versions')
      .select('*')
      .eq('project_id', projectId)
      .eq('mode', mode)
      .in('status', ['draft', 'submitted'])
      .order('version_number', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async getApprovedVersion(projectId: string, mode: 'trade' | 'item'): Promise<MarkupVersion | null> {
    const { data, error } = await supabase
      .from('markup_versions')
      .select('*')
      .eq('project_id', projectId)
      .eq('mode', mode)
      .eq('status', 'approved')
      .order('version_number', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;
    return data;
  },

  async createVersion(projectId: string, mode: 'trade' | 'item', remarks?: string): Promise<MarkupVersion> {
    const { data: user } = await supabase.auth.getUser();
    
    // Get the next version number
    const { data: latestVersion } = await supabase
      .from('markup_versions')
      .select('version_number')
      .eq('project_id', projectId)
      .eq('mode', mode)
      .order('version_number', { ascending: false })
      .limit(1)
      .maybeSingle();

    const nextVersionNumber = latestVersion ? latestVersion.version_number + 1 : 1;
    
    const { data, error } = await supabase
      .from('markup_versions')
      .insert({
        project_id: projectId,
        mode,
        remarks: remarks || '',
        user_id: user.user?.id || '',
        status: 'draft' as const,
        version_number: nextVersionNumber
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateVersionStatus(versionId: string, status: 'submitted' | 'approved' | 'archived', remarks?: string): Promise<MarkupVersion> {
    const updates: any = { status, remarks };
    
    if (status === 'approved') {
      const { data: user } = await supabase.auth.getUser();
      updates.approved_by = user.user?.id;
      updates.approved_at = new Date().toISOString();
    }

    const { data, error } = await supabase
      .from('markup_versions')
      .update(updates)
      .eq('id', versionId)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Markup lines management
  async getMarkupLines(versionId: string): Promise<MarkupLine[]> {
    const { data, error } = await supabase
      .from('markup_lines')
      .select('*')
      .eq('version_id', versionId)
      .order('ref_id');

    if (error) throw error;
    return (data || []).map(line => ({
      ...line,
      base_amount: line.base_rate || 0 // Add base_amount field
    }));
  },

  async saveMarkupLines(versionId: string, lines: Omit<MarkupLine, 'id' | 'version_id' | 'created_at' | 'updated_at'>[]): Promise<void> {
    // Delete existing lines
    const { error: deleteError } = await supabase
      .from('markup_lines')
      .delete()
      .eq('version_id', versionId);

    if (deleteError) throw deleteError;

    // Insert new lines
    const { error: insertError } = await supabase
      .from('markup_lines')
      .insert(
        lines.map(line => ({
          ...line,
          version_id: versionId,
          user_id: line.user_id
        }))
      );

    if (insertError) throw insertError;
  },

  async updateMarkupLine(lineId: string, updates: Partial<MarkupLine>): Promise<MarkupLine> {
    const { data, error } = await supabase
      .from('markup_lines')
      .update(updates)
      .eq('id', lineId)
      .select()
      .single();

    if (error) throw error;
    return {
      ...data,
      base_amount: data.base_rate || 0
    };
  },

  // Legacy methods for backward compatibility
  async getMarkupItems(projectId: string): Promise<MarkupItem[]> {
    const { data, error } = await supabase
      .from('markup_items')
      .select('*')
      .eq('project_id', projectId)
      .order('created_at', { ascending: true });

    if (error) throw error;
    return (data || []).map(item => ({
      ...item,
      ref_type: item.ref_type as 'trade' | 'item',
      markup_type: item.markup_type as 'Site Overhead' | 'H.O G&A' | 'Profit' | 'Contingencies' | 'Escalation' | 'Tax' | 'Other'
    }));
  },

  async getMarkupEntries(projectId: string): Promise<MarkupEntry[]> {
    // This would query a new markup_entries table in real implementation
    // For now, return mock data with new structure
    return [];
  },

  async getMarkupConfigs(projectId: string): Promise<MarkupConfig[]> {
    // This would query a new markup_configs table in real implementation
    // For now, return mock data
    return [];
  },

  async createMarkupEntry(entryData: Omit<MarkupEntry, 'id' | 'created_at' | 'updated_at'>): Promise<MarkupEntry> {
    // This would create a new markup entry in the database
    // For now, return mock data with new structure
    return {
      ...entryData,
      id: `entry_${Date.now()}`,
      site_overhead_percent: entryData.site_overhead_percent || 0,
      ho_ga_percent: entryData.ho_ga_percent || 0,
      profit_percent: entryData.profit_percent || 0,
      contingencies_percent: entryData.contingencies_percent || 0,
      escalation_percent: entryData.escalation_percent || 0,
      tax_percent: entryData.tax_percent || 0,
      tax_amount: entryData.tax_amount || 0,
      final_total: entryData.final_total || 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
  },

  async updateMarkupEntry(id: string, updates: Partial<MarkupEntry>): Promise<MarkupEntry> {
    // This would update the markup entry in the database
    // For now, return mock data with new structure
    const mockEntry: MarkupEntry = {
      id,
      project_id: updates.project_id || '',
      ref_type: updates.ref_type || 'trade',
      ref_id: updates.ref_id || '',
      ref_description: updates.ref_description || '',
      base_amount: updates.base_amount || 0,
      site_overhead_percent: updates.site_overhead_percent || 0,
      ho_ga_percent: updates.ho_ga_percent || 0,
      profit_percent: updates.profit_percent || 0,
      contingencies_percent: updates.contingencies_percent || 0,
      escalation_percent: updates.escalation_percent || 0,
      tax_percent: updates.tax_percent || 0,
      custom_markups: updates.custom_markups || {},
      total_markup_value: updates.total_markup_value || 0,
      grand_total: updates.grand_total || 0,
      tax_amount: updates.tax_amount || 0,
      final_total: updates.final_total || 0,
      remarks: updates.remarks || '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    return mockEntry;
  },

  async createMarkupConfig(configData: Omit<MarkupConfig, 'id' | 'created_at' | 'updated_at'>): Promise<MarkupConfig> {
    // This would create a new markup config in the database
    // For now, return mock data
    return {
      ...configData,
      id: `config_${Date.now()}`,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
  },

  async createMarkupItem(markupData: Omit<MarkupItem, 'id' | 'created_at' | 'updated_at'>): Promise<MarkupItem> {
    const { data, error } = await supabase
      .from('markup_items')
      .insert({
        ...markupData,
        user_id: (await supabase.auth.getUser()).data.user?.id
      })
      .select()
      .single();

    if (error) throw error;
    return {
      ...data,
      ref_type: data.ref_type as 'trade' | 'item',
      markup_type: data.markup_type as 'Site Overhead' | 'H.O G&A' | 'Profit' | 'Contingencies' | 'Escalation' | 'Tax' | 'Other'
    };
  },

  async updateMarkupItem(id: string, updates: Partial<MarkupItem>): Promise<MarkupItem> {
    const { data, error } = await supabase
      .from('markup_items')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return {
      ...data,
      ref_type: data.ref_type as 'trade' | 'item',
      markup_type: data.markup_type as 'Site Overhead' | 'H.O G&A' | 'Profit' | 'Contingencies' | 'Escalation' | 'Tax' | 'Other'
    };
  },

  async deleteMarkupItem(id: string): Promise<void> {
    const { error } = await supabase
      .from('markup_items')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async getTradeMarkupData(projectId: string): Promise<TradeMarkupData[]> {
    // Get BOQ items grouped by trade code
    const { data, error } = await supabase
      .from('boq_items')
      .select(`
        price_code,
        amount,
        description
      `)
      .eq('job_id', projectId)
      .not('price_code', 'is', null)
      .not('amount', 'is', null);

    if (error) throw error;

    // Group by trade code and calculate totals
    const tradeMap = new Map<string, TradeMarkupData>();
    
    (data || []).forEach(item => {
      const tradeCode = item.price_code || 'UNASSIGNED';
      const amount = item.amount || 0;
      
      if (tradeMap.has(tradeCode)) {
        const existing = tradeMap.get(tradeCode)!;
        existing.base_amount += amount;
        existing.item_count += 1;
      } else {
        tradeMap.set(tradeCode, {
          trade_code: tradeCode,
          division: tradeCode.substring(0, 2), // Extract division from trade code
          description: item.description || tradeCode,
          base_amount: amount,
          item_count: 1
        });
      }
    });

    return Array.from(tradeMap.values());
  },

  async getItemMarkupData(projectId: string): Promise<ItemMarkupData[]> {
    const { data, error } = await supabase
      .from('boq_items')
      .select(`
        id,
        item_no,
        description,
        amount,
        price_code
      `)
      .eq('job_id', projectId)
      .not('amount', 'is', null);

    if (error) throw error;

    return (data || []).map(item => ({
      item_id: item.id,
      item_no: item.item_no,
      description: item.description,
      base_amount: item.amount || 0,
      trade_code: item.price_code,
      division: item.price_code?.substring(0, 2)
    }));
  },

  async bulkDeleteMarkupItems(ids: string[]): Promise<void> {
    const { error } = await supabase
      .from('markup_items')
      .delete()
      .in('id', ids);

    if (error) throw error;
  },

  async exportMarkupToExcel(projectId: string, mode: 'trade' | 'item'): Promise<void> {
    // This would implement Excel export functionality
    console.log('Exporting markup data to Excel...', { projectId, mode });
  }
};
