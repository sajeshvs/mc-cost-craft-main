
import { supabase } from '@/integrations/supabase/client';

export interface DoDStandardsResult {
  priceCount: number;
  resourceCount: number;
  message: string;
}

// Comprehensive UFGS divisions with real sections
const COMPREHENSIVE_UFGS_DIVISIONS = {
  '01': {
    name: 'General Requirements',
    sections: [
      'General Requirements for All Construction',
      'Project Management and Coordination',
      'Quality Control and Assurance',
      'Safety Requirements',
      'Environmental Protection',
      'Temporary Facilities and Controls',
      'Project Closeout',
      'Construction Submittal Procedures',
      'Sustainable Design Requirements',
      'Material and Equipment'
    ]
  },
  '02': {
    name: 'Existing Conditions',
    sections: [
      'Hazardous Material Abatement',
      'Selective Demolition',
      'Structure Moving',
      'Environmental Remediation',
      'Subsurface Investigation',
      'Site Preparation',
      'Clearing and Grubbing',
      'Dewatering',
      'Excavation Support and Protection',
      'Contaminated Site Material Removal'
    ]
  },
  '03': {
    name: 'Concrete',
    sections: [
      'Concrete Forming and Accessories',
      'Concrete Reinforcement',
      'Cast-in-Place Concrete',
      'Precast Concrete',
      'Concrete Restoration and Cleaning',
      'Concrete Cutting and Boring',
      'Mass Concrete',
      'Concrete Curing',
      'Concrete Surface Treatments',
      'Architectural Concrete'
    ]
  },
  '04': {
    name: 'Masonry',
    sections: [
      'Unit Masonry',
      'Stone',
      'Masonry Restoration and Cleaning',
      'Concrete Block',
      'Brick Masonry',
      'Stone Masonry',
      'Masonry Accessories',
      'Mortar and Grout',
      'Masonry Assemblies',
      'Refractory Masonry'
    ]
  },
  '05': {
    name: 'Metals',
    sections: [
      'Structural Metal Framing',
      'Metal Joists',
      'Metal Decking',
      'Cold-Formed Metal Framing',
      'Metal Fabrications',
      'Expansion Control',
      'Ornamental Metal',
      'Welding',
      'Metal Coatings',
      'Structural Steel'
    ]
  },
  '06': {
    name: 'Wood, Plastics, and Composites',
    sections: [
      'Rough Carpentry',
      'Heavy Timber Construction',
      'Glued-Laminated Construction',
      'Structural Composites',
      'Finish Carpentry',
      'Architectural Woodwork',
      'Prefabricated Structural Wood',
      'Wood Treatment',
      'Structural Plastics',
      'Plastic Fabrications'
    ]
  },
  '07': {
    name: 'Thermal and Moisture Protection',
    sections: [
      'Waterproofing',
      'Dampproofing',
      'Building Insulation',
      'Membrane Roofing',
      'Modified Bituminous Membrane Roofing',
      'Steep-Slope Roofing',
      'Roof Specialties and Accessories',
      'Sealants and Caulking',
      'Weather Barriers',
      'Vapor Retarders'
    ]
  },
  '08': {
    name: 'Openings',
    sections: [
      'Metal Doors and Frames',
      'Wood Doors',
      'Specialty Doors',
      'Entrances and Storefronts',
      'Windows',
      'Skylights',
      'Hardware',
      'Glazing',
      'Louvers and Vents',
      'Door and Window Accessories'
    ]
  },
  '09': {
    name: 'Finishes',
    sections: [
      'Metal Support Assemblies',
      'Plaster and Gypsum Board',
      'Tiling',
      'Terrazzo',
      'Acoustical Treatment',
      'Wood Flooring',
      'Resilient Flooring',
      'Carpet',
      'Painting',
      'Wall Coverings'
    ]
  },
  '10': {
    name: 'Specialties',
    sections: [
      'Visual Display Boards',
      'Compartments and Cubicles',
      'Louvers and Vents',
      'Grilles and Screens',
      'Wall and Corner Guards',
      'Access Flooring',
      'Pest Control',
      'Fireplaces and Stoves',
      'Flagpoles',
      'Identifying Devices'
    ]
  },
  '11': {
    name: 'Equipment',
    sections: [
      'Maintenance Equipment',
      'Security and Vault Equipment',
      'Teller and Service Equipment',
      'Ecclesiastical Equipment',
      'Library Equipment',
      'Theater and Stage Equipment',
      'Instrumental Equipment',
      'Registration Equipment',
      'Checkroom Equipment',
      'Mercantile Equipment'
    ]
  },
  '12': {
    name: 'Furnishings',
    sections: [
      'Artwork',
      'Manufactured Casework',
      'Window Treatments',
      'Fabrics',
      'Furniture',
      'Rugs and Mats',
      'Multiple Seating',
      'Interior Plants and Planters',
      'Furnishing Accessories',
      'Furniture and Accessories'
    ]
  },
  '13': {
    name: 'Special Construction',
    sections: [
      'Air-Supported Structures',
      'Building Automation and Control',
      'Facility Instrumentation',
      'Special Purpose Rooms',
      'Radiation Protection',
      'Lightning Protection',
      'Cathodic Protection',
      'Swimming Pools',
      'Ice Rinks',
      'Kennels and Animal Shelters'
    ]
  },
  '14': {
    name: 'Conveying Equipment',
    sections: [
      'Dumbwaiters',
      'Elevators',
      'Escalators and Moving Walks',
      'Lifts',
      'Material Handling',
      'Hoists and Cranes',
      'Turntables',
      'Scaffolding',
      'Transportation',
      'Conveying Systems'
    ]
  },
  '21': {
    name: 'Fire Suppression',
    sections: [
      'Fire-Suppression Water-Service Piping',
      'Fire-Suppression Standpipes',
      'Fire-Suppression Sprinkler Systems',
      'Fire-Suppression Water Spray Systems',
      'Gaseous Fire-Suppression Systems',
      'Fire-Suppression Foam Systems',
      'Fire-Suppression Dry Chemical Systems',
      'Fire Pumps',
      'Fire Detection and Alarm',
      'Mass Notification Systems'
    ]
  },
  '22': {
    name: 'Plumbing',
    sections: [
      'Plumbing Piping',
      'Plumbing Equipment',
      'Plumbing Fixtures',
      'Water Heaters',
      'Pool and Fountain Plumbing Systems',
      'Fuel-Fired Domestic Water Heaters',
      'Drinking Water Treatment Equipment',
      'Plumbing Specialties',
      'Facility Water Distribution',
      'Plumbing Piping Systems'
    ]
  },
  '23': {
    name: 'Heating Ventilating and Air Conditioning',
    sections: [
      'HVAC Piping and Pumps',
      'HVAC Air Distribution',
      'HVAC Equipment',
      'HVAC Terminal and Package Units',
      'HVAC Controls and Instrumentation',
      'Heat Generation',
      'Cooling Generation',
      'Decentralized Energy Equipment',
      'HVAC Systems Testing',
      'Central Cooling Equipment'
    ]
  },
  '25': {
    name: 'Integrated Automation',
    sections: [
      'Integrated Automation Network Equipment',
      'Integrated Automation Software',
      'Integrated Automation Instrumentation and Terminal Devices',
      'Integrated Automation Control and Monitoring',
      'Electrical Power Monitoring and Control',
      'Electronic Safety and Security',
      'Mass Notification Systems',
      'Integrated Automation Facility Controls',
      'Sequence of Operations for HVAC Controls',
      'Testing, Adjusting, and Balancing for HVAC'
    ]
  },
  '26': {
    name: 'Electrical',
    sections: [
      'Electrical Service and Distribution',
      'Wiring Methods',
      'Low-Voltage Electrical Power Conductors and Cables',
      'Electrical Equipment',
      'Lighting',
      'Electrical Systems',
      'Communications',
      'Electronic Safety and Security',
      'Electrical Testing',
      'Electrical Power Monitoring and Control'
    ]
  },
  '27': {
    name: 'Communications',
    sections: [
      'Communications Horizontal Cabling',
      'Communications Equipment Room Fittings',
      'Communications Backbone Cabling',
      'Communications Terminal Equipment',
      'Audio-Video Systems',
      'Distributed Communications and Monitoring Systems',
      'Communications Specialties',
      'Wireless Communications',
      'Communications Infrastructure',
      'Audio and Video Equipment'
    ]
  },
  '28': {
    name: 'Electronic Safety and Security',
    sections: [
      'Electronic Surveillance',
      'Electronic Detection and Alarm',
      'Electronic Access Control',
      'Electronic Monitoring and Control',
      'Electronic Barriers and Safeguards',
      'Radiation Detection and Alarm',
      'Vibration Detection and Alarm',
      'Perimeter Security',
      'Security Management Systems',
      'Electronic Safety and Security Integration'
    ]
  },
  '31': {
    name: 'Earthwork',
    sections: [
      'Earth Moving',
      'Excavation and Fill',
      'Embankments, Dikes, and Dams',
      'Soil Stabilization',
      'Excavation Support and Protection',
      'Special Foundations and Load-Bearing Elements',
      'Geostructural Systems',
      'Earthwork Methods',
      'Soil Treatment',
      'Earthwork Restoration and Rehabilitation'
    ]
  },
  '32': {
    name: 'Exterior Improvements',
    sections: [
      'Bases, Ballasts, and Paving',
      'Concrete Paving',
      'Unit Paving',
      'Curbs, Gutters, Sidewalks, and Driveways',
      'Landscape Irrigation',
      'Planting',
      'Exterior Improvements',
      'Exterior Enclosures',
      'Site Improvements',
      'Recreational Facilities'
    ]
  },
  '33': {
    name: 'Utilities',
    sections: [
      'Water Utilities',
      'Wastewater Utilities',
      'Thermal Utilities',
      'Electrical Utilities',
      'Communications Utilities',
      'Fuel Distribution',
      'Utility Transmission and Distribution',
      'Utility Structures',
      'Utility Equipment Installation',
      'Utility Restoration and Rehabilitation'
    ]
  },
  '34': {
    name: 'Transportation',
    sections: [
      'Transportation Equipment',
      'Fabricated Bridges',
      'Pedestrian Bridges',
      'Transportation Structures',
      'Waterway and Marine Transportation',
      'Transportation Surfacing',
      'Transportation Electrical and Communications',
      'Transportation Signaling and Control Equipment',
      'Transportation Specialized Construction',
      'Transportation Maintenance'
    ]
  },
  '35': {
    name: 'Waterway and Marine Construction',
    sections: [
      'Waterway and Marine Piping',
      'Waterway and Marine Equipment',
      'Dredging',
      'Shoreline Protection',
      'Waterway Construction and Equipment',
      'Marine Construction',
      'Waterway Structures',
      'Marine Structures',
      'Underwater Construction',
      'Coastal Construction'
    ]
  },
  '40': {
    name: 'Process Integration',
    sections: [
      'Process Instrumentation',
      'Process Control Systems',
      'Process Integration Systems',
      'Process Piping Systems',
      'Process Electrical Systems',
      'Process Safety Systems',
      'Process Monitoring Systems',
      'Process Data Management',
      'Process Communication Systems',
      'Process Testing and Commissioning'
    ]
  },
  '41': {
    name: 'Material Processing and Handling Equipment',
    sections: [
      'Material Storage',
      'Material Handling',
      'Bulk Material Processing Equipment',
      'Conveyors',
      'Cranes and Hoists',
      'Material Processing Equipment',
      'Pneumatic Material Handling',
      'Screening and Sieving Equipment',
      'Magnetic Separators',
      'Packaging Equipment'
    ]
  },
  '42': {
    name: 'Process Heating, Cooling, and Drying Equipment',
    sections: [
      'Process Heating Equipment',
      'Process Cooling Equipment',
      'Process Drying Equipment',
      'Heat Exchangers',
      'Process Furnaces',
      'Process Boilers',
      'Process Chillers',
      'Process Cooling Towers',
      'Process Thermal Systems',
      'Process Temperature Control'
    ]
  },
  '43': {
    name: 'Process Gas and Liquid Handling, Purification, and Storage Equipment',
    sections: [
      'Gas Handling Equipment',
      'Liquid Handling Equipment',
      'Purification Equipment',
      'Storage Equipment',
      'Process Pumps',
      'Process Compressors',
      'Process Filtration',
      'Process Separators',
      'Process Mixers',
      'Process Vessels'
    ]
  },
  '44': {
    name: 'Pollution Control Equipment',
    sections: [
      'Air Pollution Control',
      'Water Pollution Control',
      'Noise Control',
      'Vibration Control',
      'Emission Control',
      'Waste Treatment Equipment',
      'Environmental Monitoring',
      'Pollution Prevention',
      'Remediation Equipment',
      'Environmental Compliance'
    ]
  },
  '45': {
    name: 'Industry-Specific Manufacturing Equipment',
    sections: [
      'Food Processing Equipment',
      'Pharmaceutical Equipment',
      'Chemical Processing Equipment',
      'Textile Manufacturing Equipment',
      'Paper Manufacturing Equipment',
      'Metal Processing Equipment',
      'Automotive Manufacturing Equipment',
      'Electronic Manufacturing Equipment',
      'Plastics Processing Equipment',
      'Wood Processing Equipment'
    ]
  },
  '46': {
    name: 'Water and Wastewater Equipment',
    sections: [
      'Water Treatment Equipment',
      'Wastewater Treatment Equipment',
      'Water Supply Equipment',
      'Water Distribution Equipment',
      'Wastewater Collection Equipment',
      'Water Storage Equipment',
      'Water Pumping Equipment',
      'Water Filtration Equipment',
      'Water Disinfection Equipment',
      'Water Quality Monitoring'
    ]
  },
  '47': {
    name: 'Electrical Power Generation',
    sections: [
      'Electrical Power Generation Equipment',
      'Fossil Fuel Power Generation Equipment',
      'Nuclear Power Generation Equipment',
      'Renewable Energy Generation Equipment',
      'Power Generation Electrical Systems',
      'Power Generation Control Systems',
      'Power Generation Auxiliary Systems',
      'Power Generation Maintenance Equipment',
      'Power Generation Testing Equipment',
      'Power Generation Commissioning'
    ]
  },
  '48': {
    name: 'Electrical Power Transmission',
    sections: [
      'Electrical Power Transmission Equipment',
      'High-Voltage Transmission Equipment',
      'Power Transmission Structures',
      'Power Transmission Protection Systems',
      'Power Transmission Control Systems',
      'Power Transmission Monitoring Systems',
      'Power Transmission Maintenance Equipment',
      'Power Transmission Testing Equipment',
      'Power Transmission Commissioning',
      'Power Transmission Integration'
    ]
  }
};

// Comprehensive DoD Standard Resources
const DOD_STANDARD_RESOURCES = [
  // People (Labor) - Davis-Bacon Based
  { code: 'P001', name: 'Construction Laborer', type: 'P', unit: 'HR', rate: 28.50, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P002', name: 'Equipment Operator (Heavy)', type: 'P', unit: 'HR', rate: 45.75, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P003', name: 'Carpenter', type: 'P', unit: 'HR', rate: 42.25, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P004', name: 'Concrete Finisher', type: 'P', unit: 'HR', rate: 38.90, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P005', name: 'Ironworker', type: 'P', unit: 'HR', rate: 49.80, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P006', name: 'Electrician', type: 'P', unit: 'HR', rate: 52.35, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P007', name: 'Plumber', type: 'P', unit: 'HR', rate: 51.20, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P008', name: 'HVAC Technician', type: 'P', unit: 'HR', rate: 48.65, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P009', name: 'Welder', type: 'P', unit: 'HR', rate: 46.40, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P010', name: 'Painter', type: 'P', unit: 'HR', rate: 35.80, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P011', name: 'Roofer', type: 'P', unit: 'HR', rate: 41.70, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P012', name: 'Tile Setter', type: 'P', unit: 'HR', rate: 39.85, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P013', name: 'Bricklayer', type: 'P', unit: 'HR', rate: 44.20, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P014', name: 'Glazier', type: 'P', unit: 'HR', rate: 43.60, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P015', name: 'Insulation Worker', type: 'P', unit: 'HR', rate: 37.90, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P016', name: 'Demolition Worker', type: 'P', unit: 'HR', rate: 32.15, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P017', name: 'Surveyor', type: 'P', unit: 'HR', rate: 55.25, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P018', name: 'Foreman', type: 'P', unit: 'HR', rate: 58.90, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P019', name: 'Project Manager', type: 'P', unit: 'HR', rate: 85.50, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },
  { code: 'P020', name: 'Quality Control Inspector', type: 'P', unit: 'HR', rate: 62.75, productivity: 1.0, reference: 'Davis-Bacon WD 2024-01' },

  // Materials (M) - UFGS Based
  { code: 'M001', name: 'Ready-Mix Concrete 3000 PSI', type: 'M', unit: 'CY', rate: 145.00, productivity: 1.0, reference: 'UFGS 03 30 00' },
  { code: 'M002', name: 'Reinforcing Steel #4 Bar', type: 'M', unit: 'LB', rate: 0.85, productivity: 1.0, reference: 'UFGS 03 20 00' },
  { code: 'M003', name: 'Structural Steel A992', type: 'M', unit: 'LB', rate: 1.25, productivity: 1.0, reference: 'UFGS 05 12 00' },
  { code: 'M004', name: 'Masonry Cement', type: 'M', unit: 'BAG', rate: 8.50, productivity: 1.0, reference: 'UFGS 04 01 00' },
  { code: 'M005', name: 'Pressure Treated Lumber 2x10', type: 'M', unit: 'LF', rate: 4.85, productivity: 1.0, reference: 'UFGS 06 10 00' },
  { code: 'M006', name: 'Face Brick', type: 'M', unit: 'M', rate: 485.00, productivity: 1.0, reference: 'UFGS 04 21 00' },
  { code: 'M007', name: 'Concrete Masonry Unit 8"', type: 'M', unit: 'EA', rate: 2.35, productivity: 1.0, reference: 'UFGS 04 22 00' },
  { code: 'M008', name: 'Asphalt Shingles', type: 'M', unit: 'SQ', rate: 125.00, productivity: 1.0, reference: 'UFGS 07 31 00' },
  { code: 'M009', name: 'Gypsum Board 1/2"', type: 'M', unit: 'SF', rate: 0.65, productivity: 1.0, reference: 'UFGS 09 29 00' },
  { code: 'M010', name: 'Ceramic Tile', type: 'M', unit: 'SF', rate: 8.50, productivity: 1.0, reference: 'UFGS 09 30 00' },
  { code: 'M011', name: 'Vinyl Composite Tile', type: 'M', unit: 'SF', rate: 3.25, productivity: 1.0, reference: 'UFGS 09 65 00' },
  { code: 'M012', name: 'Latex Paint', type: 'M', unit: 'GAL', rate: 45.00, productivity: 1.0, reference: 'UFGS 09 91 00' },
  { code: 'M013', name: 'Steel Door Frame', type: 'M', unit: 'EA', rate: 185.00, productivity: 1.0, reference: 'UFGS 08 11 00' },
  { code: 'M014', name: 'Aluminum Window', type: 'M', unit: 'SF', rate: 28.50, productivity: 1.0, reference: 'UFGS 08 51 00' },
  { code: 'M015', name: 'Insulation Batt R-19', type: 'M', unit: 'SF', rate: 0.85, productivity: 1.0, reference: 'UFGS 07 21 00' },
  { code: 'M016', name: 'Waterproofing Membrane', type: 'M', unit: 'SF', rate: 4.25, productivity: 1.0, reference: 'UFGS 07 11 00' },
  { code: 'M017', name: 'Electrical Wire 12 AWG', type: 'M', unit: 'LF', rate: 0.45, productivity: 1.0, reference: 'UFGS 26 05 00' },
  { code: 'M018', name: 'PVC Pipe 4"', type: 'M', unit: 'LF', rate: 8.75, productivity: 1.0, reference: 'UFGS 22 11 00' },
  { code: 'M019', name: 'Copper Tubing 3/4"', type: 'M', unit: 'LF', rate: 6.50, productivity: 1.0, reference: 'UFGS 22 11 00' },
  { code: 'M020', name: 'Ductwork Galvanized', type: 'M', unit: 'LB', rate: 2.85, productivity: 1.0, reference: 'UFGS 23 31 00' },
  { code: 'M021', name: 'Aggregate Base Course', type: 'M', unit: 'TON', rate: 25.00, productivity: 1.0, reference: 'UFGS 32 11 00' },
  { code: 'M022', name: 'Asphalt Concrete', type: 'M', unit: 'TON', rate: 85.00, productivity: 1.0, reference: 'UFGS 32 12 00' },
  { code: 'M023', name: 'Geotextile Fabric', type: 'M', unit: 'SY', rate: 1.25, productivity: 1.0, reference: 'UFGS 31 05 00' },
  { code: 'M024', name: 'Topsoil', type: 'M', unit: 'CY', rate: 35.00, productivity: 1.0, reference: 'UFGS 32 91 00' },
  { code: 'M025', name: 'Seeding Mix', type: 'M', unit: 'LB', rate: 4.50, productivity: 1.0, reference: 'UFGS 32 92 00' },

  // Equipment (E) - USACE EP 1110-1-8 Based
  { code: 'E001', name: 'Excavator 320 HP', type: 'E', unit: 'HR', rate: 125.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E002', name: 'Bulldozer 200 HP', type: 'E', unit: 'HR', rate: 98.50, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E003', name: 'Dump Truck 10 CY', type: 'E', unit: 'HR', rate: 75.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E004', name: 'Concrete Mixer Truck', type: 'E', unit: 'HR', rate: 85.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E005', name: 'Concrete Pump', type: 'E', unit: 'HR', rate: 165.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E006', name: 'Tower Crane', type: 'E', unit: 'HR', rate: 185.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E007', name: 'Backhoe Loader', type: 'E', unit: 'HR', rate: 68.50, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E008', name: 'Compactor Vibratory', type: 'E', unit: 'HR', rate: 55.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E009', name: 'Grader Motor', type: 'E', unit: 'HR', rate: 92.50, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E010', name: 'Paver Asphalt', type: 'E', unit: 'HR', rate: 115.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E011', name: 'Concrete Saw', type: 'E', unit: 'HR', rate: 45.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E012', name: 'Welding Machine', type: 'E', unit: 'HR', rate: 25.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E013', name: 'Air Compressor 375 CFM', type: 'E', unit: 'HR', rate: 38.50, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E014', name: 'Generator 100 KW', type: 'E', unit: 'HR', rate: 42.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E015', name: 'Scissor Lift', type: 'E', unit: 'HR', rate: 32.50, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E016', name: 'Forklift 5000 LB', type: 'E', unit: 'HR', rate: 28.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E017', name: 'Water Pump 6"', type: 'E', unit: 'HR', rate: 35.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E018', name: 'Pile Driver', type: 'E', unit: 'HR', rate: 155.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E019', name: 'Trencher', type: 'E', unit: 'HR', rate: 78.00, productivity: 1.0, reference: 'USACE EP 1110-1-8' },
  { code: 'E020', name: 'Roller Pneumatic', type: 'E', unit: 'HR', rate: 62.50, productivity: 1.0, reference: 'USACE EP 1110-1-8' },

  // Subcontractors (S) - Specialty Trades
  { code: 'S001', name: 'Structural Steel Erection', type: 'S', unit: 'TON', rate: 1850.00, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S002', name: 'Roofing System Installation', type: 'S', unit: 'SF', rate: 8.50, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S003', name: 'Elevator Installation', type: 'S', unit: 'EA', rate: 85000.00, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S004', name: 'Fire Sprinkler System', type: 'S', unit: 'SF', rate: 4.25, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S005', name: 'Security System Installation', type: 'S', unit: 'SF', rate: 6.75, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S006', name: 'Kitchen Equipment Installation', type: 'S', unit: 'LS', rate: 25000.00, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S007', name: 'Landscaping', type: 'S', unit: 'SF', rate: 3.50, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S008', name: 'Asbestos Abatement', type: 'S', unit: 'SF', rate: 12.50, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S009', name: 'Hazardous Material Removal', type: 'S', unit: 'SF', rate: 15.00, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S010', name: 'Specialized Coatings', type: 'S', unit: 'SF', rate: 8.25, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S011', name: 'Window Installation', type: 'S', unit: 'SF', rate: 35.00, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S012', name: 'Flooring Installation', type: 'S', unit: 'SF', rate: 12.00, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S013', name: 'Excavation Subcontractor', type: 'S', unit: 'CY', rate: 8.50, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S014', name: 'Utility Installation', type: 'S', unit: 'LF', rate: 25.00, productivity: 1.0, reference: 'DoD Trade Standards' },
  { code: 'S015', name: 'Paving Subcontractor', type: 'S', unit: 'SF', rate: 4.75, productivity: 1.0, reference: 'DoD Trade Standards' },

  // Consultants (C) - Professional Services
  { code: 'C001', name: 'Structural Engineer', type: 'C', unit: 'HR', rate: 165.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C002', name: 'Geotechnical Engineer', type: 'C', unit: 'HR', rate: 155.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C003', name: 'Environmental Engineer', type: 'C', unit: 'HR', rate: 148.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C004', name: 'MEP Engineer', type: 'C', unit: 'HR', rate: 152.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C005', name: 'Construction Materials Testing', type: 'C', unit: 'TEST', rate: 285.00, productivity: 1.0, reference: 'DoD Testing Standards' },
  { code: 'C006', name: 'Surveying Services', type: 'C', unit: 'HR', rate: 125.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C007', name: 'Commissioning Agent', type: 'C', unit: 'HR', rate: 175.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C008', name: 'BIM Coordinator', type: 'C', unit: 'HR', rate: 95.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C009', name: 'Quality Assurance Inspector', type: 'C', unit: 'HR', rate: 85.00, productivity: 1.0, reference: 'DoD QA Standards' },
  { code: 'C010', name: 'Environmental Compliance', type: 'C', unit: 'HR', rate: 135.00, productivity: 1.0, reference: 'DoD Environmental' },
  { code: 'C011', name: 'Security Consultant', type: 'C', unit: 'HR', rate: 185.00, productivity: 1.0, reference: 'DoD Security Standards' },
  { code: 'C012', name: 'Fire Protection Engineer', type: 'C', unit: 'HR', rate: 165.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C013', name: 'Acoustic Consultant', type: 'C', unit: 'HR', rate: 145.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C014', name: 'Code Compliance Review', type: 'C', unit: 'HR', rate: 125.00, productivity: 1.0, reference: 'DoD A-E Services' },
  { code: 'C015', name: 'Project Controls Specialist', type: 'C', unit: 'HR', rate: 115.00, productivity: 1.0, reference: 'DoD A-E Services' }
];

export const doDStandardsService = {
  async initializeDoDStandards(): Promise<DoDStandardsResult> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Clear existing resource library for this user
      await supabase
        .from('resource_library')
        .delete()
        .eq('user_id', user.id);

      // Insert comprehensive DoD standard resources
      const resourcesToInsert = DOD_STANDARD_RESOURCES.map(resource => ({
        user_id: user.id,
        resource_code: resource.code,
        resource_name: resource.name,
        resource_type: resource.type,
        unit: resource.unit,
        default_rate: resource.rate,
        default_productivity: resource.productivity,
        dod_reference: resource.reference,
        notes: `Standard DoD resource per ${resource.reference}`
      }));

      const { error: resourceError } = await supabase
        .from('resource_library')
        .insert(resourcesToInsert);

      if (resourceError) {
        throw new Error(`Failed to create resource library: ${resourceError.message}`);
      }

      return {
        priceCount: 0,
        resourceCount: DOD_STANDARD_RESOURCES.length,
        message: `Successfully initialized comprehensive DoD standards with ${DOD_STANDARD_RESOURCES.length} resources`
      };
    } catch (error) {
      console.error('Error initializing DoD standards:', error);
      throw error;
    }
  },

  async createComprehensivePriceList(projectId: string): Promise<DoDStandardsResult> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Clear existing price list for this project
      await supabase
        .from('price_list')
        .delete()
        .eq('project_id', projectId)
        .eq('user_id', user.id);

      const priceItemsToInsert = [];
      let totalItems = 0;

      // Generate comprehensive UFGS price items
      for (const [divisionCode, divisionData] of Object.entries(COMPREHENSIVE_UFGS_DIVISIONS)) {
        const subtradeLetters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
        
        divisionData.sections.forEach((section, sectionIndex) => {
          const subtradeLetter = subtradeLetters[sectionIndex % subtradeLetters.length];
          const serialNumber = (sectionIndex + 1).toString().padStart(4, '0');
          const priceCode = `${divisionCode}${subtradeLetter}-${serialNumber}`;
          
          // Calculate realistic base rates based on division
          const baseRate = this.calculateDivisionBaseRate(divisionCode, section);
          const splitRates = this.calculateDoDSplitRates(divisionCode, baseRate);
          
          priceItemsToInsert.push({
            project_id: projectId,
            user_id: user.id,
            division: divisionCode,
            price_code: priceCode,
            description: `${section} per UFGS ${divisionCode} ${(sectionIndex + 1).toString().padStart(2, '0')} 00`,
            unit: this.getDivisionUnit(divisionCode, section),
            unit_rate: baseRate,
            split_labor: splitRates.labor,
            split_material: splitRates.material,
            split_equipment: splitRates.equipment,
            split_subcontractor: splitRates.subcontractor,
            split_consultant: splitRates.consultant,
            trade_code: `${divisionCode}${subtradeLetter}`,
            sort_order: totalItems,
            boq_reference: []
          });
          
          totalItems++;
        });
      }

      // Insert all price items in batches
      const batchSize = 100;
      for (let i = 0; i < priceItemsToInsert.length; i += batchSize) {
        const batch = priceItemsToInsert.slice(i, i + batchSize);
        const { error } = await supabase
          .from('price_list')
          .insert(batch);

        if (error) {
          throw new Error(`Failed to insert price items batch: ${error.message}`);
        }
      }

      return {
        priceCount: totalItems,
        resourceCount: 0,
        message: `Successfully created comprehensive UFGS price list with ${totalItems} items across all divisions`
      };
    } catch (error) {
      console.error('Error creating comprehensive price list:', error);
      throw error;
    }
  },

  calculateDivisionBaseRate(divisionCode: string, section: string): number {
    const divisionRates: { [key: string]: number } = {
      '01': 125,    // General Requirements
      '02': 85,     // Existing Conditions
      '03': 450,    // Concrete
      '04': 380,    // Masonry
      '05': 650,    // Metals
      '06': 285,    // Wood, Plastics, Composites
      '07': 195,    // Thermal and Moisture Protection
      '08': 320,    // Openings
      '09': 240,    // Finishes
      '10': 180,    // Specialties
      '11': 850,    // Equipment
      '12': 220,    // Furnishings
      '13': 750,    // Special Construction
      '14': 1200,   // Conveying Equipment
      '21': 680,    // Fire Suppression
      '22': 425,    // Plumbing
      '23': 580,    // HVAC
      '25': 920,    // Integrated Automation
      '26': 485,    // Electrical
      '27': 650,    // Communications
      '28': 1150,   // Electronic Safety and Security
      '31': 35,     // Earthwork
      '32': 125,    // Exterior Improvements
      '33': 285,    // Utilities
      '34': 750,    // Transportation
      '35': 950,    // Waterway and Marine
      '40': 1200,   // Process Integration
      '41': 1850,   // Material Processing
      '42': 2100,   // Process Heating/Cooling
      '43': 1650,   // Process Gas/Liquid
      '44': 1350,   // Pollution Control
      '45': 2500,   // Industry-Specific Manufacturing
      '46': 1450,   // Water/Wastewater Equipment
      '47': 3500,   // Electrical Power Generation
      '48': 2800    // Electrical Power Transmission
    };

    const baseRate = divisionRates[divisionCode] || 250;
    
    // Apply section-specific modifiers
    const sectionModifiers = {
      'equipment': 1.8,
      'specialized': 1.5,
      'complex': 1.4,
      'standard': 1.0,
      'basic': 0.7
    };

    const sectionLower = section.toLowerCase();
    let modifier = 1.0;
    
    if (sectionLower.includes('equipment') || sectionLower.includes('machinery')) {
      modifier = sectionModifiers.equipment;
    } else if (sectionLower.includes('specialized') || sectionLower.includes('complex')) {
      modifier = sectionModifiers.specialized;
    } else if (sectionLower.includes('advanced') || sectionLower.includes('sophisticated')) {
      modifier = sectionModifiers.complex;
    }

    return Math.round(baseRate * modifier * 100) / 100;
  },

  calculateDoDSplitRates(divisionCode: string, totalRate: number): {
    labor: number;
    material: number;
    equipment: number;
    subcontractor: number;
    consultant: number;
  } {
    // DoD-standard split percentages by division per UFC 3-701-01
    const splitPercentages: { [key: string]: { P: number; M: number; E: number; S: number; C: number } } = {
      '01': { P: 0.60, M: 0.15, E: 0.15, S: 0.05, C: 0.05 },  // General Requirements
      '02': { P: 0.35, M: 0.10, E: 0.45, S: 0.05, C: 0.05 },  // Existing Conditions
      '03': { P: 0.45, M: 0.35, E: 0.15, S: 0.03, C: 0.02 },  // Concrete
      '04': { P: 0.55, M: 0.35, E: 0.05, S: 0.03, C: 0.02 },  // Masonry
      '05': { P: 0.40, M: 0.45, E: 0.10, S: 0.03, C: 0.02 },  // Metals
      '06': { P: 0.50, M: 0.40, E: 0.05, S: 0.03, C: 0.02 },  // Wood, Plastics, Composites
      '07': { P: 0.45, M: 0.40, E: 0.10, S: 0.03, C: 0.02 },  // Thermal and Moisture Protection
      '08': { P: 0.40, M: 0.45, E: 0.05, S: 0.08, C: 0.02 },  // Openings
      '09': { P: 0.55, M: 0.35, E: 0.05, S: 0.03, C: 0.02 },  // Finishes
      '10': { P: 0.45, M: 0.40, E: 0.05, S: 0.08, C: 0.02 },  // Specialties
      '11': { P: 0.15, M: 0.65, E: 0.05, S: 0.12, C: 0.03 },  // Equipment
      '12': { P: 0.25, M: 0.65, E: 0.02, S: 0.06, C: 0.02 },  // Furnishings
      '13': { P: 0.35, M: 0.45, E: 0.08, S: 0.10, C: 0.02 },  // Special Construction
      '14': { P: 0.20, M: 0.60, E: 0.05, S: 0.12, C: 0.03 },  // Conveying Equipment
      '21': { P: 0.35, M: 0.50, E: 0.03, S: 0.10, C: 0.02 },  // Fire Suppression
      '22': { P: 0.40, M: 0.45, E: 0.05, S: 0.08, C: 0.02 },  // Plumbing
      '23': { P: 0.35, M: 0.50, E: 0.05, S: 0.08, C: 0.02 },  // HVAC
      '25': { P: 0.25, M: 0.55, E: 0.03, S: 0.12, C: 0.05 },  // Integrated Automation
      '26': { P: 0.40, M: 0.45, E: 0.05, S: 0.08, C: 0.02 },  // Electrical
      '27': { P: 0.35, M: 0.50, E: 0.03, S: 0.10, C: 0.02 },  // Communications
      '28': { P: 0.25, M: 0.55, E: 0.03, S: 0.12, C: 0.05 },  // Electronic Safety and Security
      '31': { P: 0.25, M: 0.15, E: 0.55, S: 0.03, C: 0.02 },  // Earthwork
      '32': { P: 0.35, M: 0.35, E: 0.25, S: 0.03, C: 0.02 },  // Exterior Improvements
      '33': { P: 0.30, M: 0.45, E: 0.20, S: 0.03, C: 0.02 },  // Utilities
      '34': { P: 0.25, M: 0.50, E: 0.20, S: 0.03, C: 0.02 },  // Transportation
      '35': { P: 0.30, M: 0.45, E: 0.20, S: 0.03, C: 0.02 },  // Waterway and Marine
      '40': { P: 0.20, M: 0.60, E: 0.05, S: 0.10, C: 0.05 },  // Process Integration
      '41': { P: 0.15, M: 0.65, E: 0.05, S: 0.12, C: 0.03 },  // Material Processing
      '42': { P: 0.18, M: 0.62, E: 0.05, S: 0.12, C: 0.03 },  // Process Heating/Cooling
      '43': { P: 0.20, M: 0.60, E: 0.05, S: 0.12, C: 0.03 },  // Process Gas/Liquid
      '44': { P: 0.22, M: 0.58, E: 0.05, S: 0.12, C: 0.03 },  // Pollution Control
      '45': { P: 0.15, M: 0.70, E: 0.03, S: 0.10, C: 0.02 },  // Industry-Specific Manufacturing
      '46': { P: 0.18, M: 0.62, E: 0.05, S: 0.12, C: 0.03 },  // Water/Wastewater Equipment
      '47': { P: 0.12, M: 0.73, E: 0.03, S: 0.10, C: 0.02 },  // Electrical Power Generation
      '48': { P: 0.15, M: 0.70, E: 0.03, S: 0.10, C: 0.02 }   // Electrical Power Transmission
    };

    const splits = splitPercentages[divisionCode] || { P: 0.40, M: 0.40, E: 0.10, S: 0.08, C: 0.02 };

    return {
      labor: Math.round(totalRate * splits.P * 100) / 100,
      material: Math.round(totalRate * splits.M * 100) / 100,
      equipment: Math.round(totalRate * splits.E * 100) / 100,
      subcontractor: Math.round(totalRate * splits.S * 100) / 100,
      consultant: Math.round(totalRate * splits.C * 100) / 100
    };
  },

  getDivisionUnit(divisionCode: string, section: string): string {
    const divisionUnits: { [key: string]: string } = {
      '01': 'LS',    // General Requirements
      '02': 'SF',    // Existing Conditions
      '03': 'CY',    // Concrete
      '04': 'SF',    // Masonry
      '05': 'LB',    // Metals
      '06': 'MBF',   // Wood, Plastics, Composites
      '07': 'SF',    // Thermal and Moisture Protection
      '08': 'EA',    // Openings
      '09': 'SF',    // Finishes
      '10': 'EA',    // Specialties
      '11': 'EA',    // Equipment
      '12': 'EA',    // Furnishings
      '13': 'LS',    // Special Construction
      '14': 'EA',    // Conveying Equipment
      '21': 'SF',    // Fire Suppression
      '22': 'SF',    // Plumbing
      '23': 'SF',    // HVAC
      '25': 'SF',    // Integrated Automation
      '26': 'SF',    // Electrical
      '27': 'SF',    // Communications
      '28': 'SF',    // Electronic Safety and Security
      '31': 'CY',    // Earthwork
      '32': 'SF',    // Exterior Improvements
      '33': 'LF',    // Utilities
      '34': 'SF',    // Transportation
      '35': 'SF',    // Waterway and Marine
      '40': 'LS',    // Process Integration
      '41': 'EA',    // Material Processing
      '42': 'EA',    // Process Heating/Cooling
      '43': 'EA',    // Process Gas/Liquid
      '44': 'EA',    // Pollution Control
      '45': 'EA',    // Industry-Specific Manufacturing
      '46': 'EA',    // Water/Wastewater Equipment
      '47': 'EA',    // Electrical Power Generation
      '48': 'EA'     // Electrical Power Transmission
    };

    const baseUnit = divisionUnits[divisionCode] || 'EA';
    
    // Adjust unit based on section content
    const sectionLower = section.toLowerCase();
    if (sectionLower.includes('piping') || sectionLower.includes('conduit')) {
      return 'LF';
    } else if (sectionLower.includes('area') || sectionLower.includes('surface')) {
      return 'SF';
    } else if (sectionLower.includes('volume') || sectionLower.includes('concrete')) {
      return 'CY';
    } else if (sectionLower.includes('weight') || sectionLower.includes('steel')) {
      return 'LB';
    }
    
    return baseUnit;
  }
};
