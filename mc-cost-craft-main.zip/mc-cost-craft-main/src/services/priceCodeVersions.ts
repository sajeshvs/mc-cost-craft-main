
import { supabase } from '@/integrations/supabase/client';

export interface PriceCodeVersion {
  id: string;
  price_code: string;
  project_id: string;
  version_number: number;
  status: 'draft' | 'submitted' | 'approved';
  change_summary?: string;
  created_by: string;
  created_at: string;
  approved_by?: string;
  approved_at?: string;
}

// Type guard function
function isValidStatus(status: string): status is 'draft' | 'submitted' | 'approved' {
  return ['draft', 'submitted', 'approved'].includes(status);
}

export const priceCodeVersionsService = {
  async getByPriceCode(projectId: string, priceCode: string): Promise<PriceCodeVersion[]> {
    const { data, error } = await supabase
      .from('price_code_versions')
      .select('*')
      .eq('project_id', projectId)
      .eq('price_code', priceCode)
      .order('version_number', { ascending: false });

    if (error) throw error;
    
    return (data || []).map((item: any) => ({
      ...item,
      status: isValidStatus(item.status) ? item.status : 'draft' as 'draft' | 'submitted' | 'approved'
    }));
  },

  async getCurrentVersion(projectId: string, priceCode: string): Promise<PriceCodeVersion | null> {
    const { data, error } = await supabase
      .from('price_code_versions')
      .select('*')
      .eq('project_id', projectId)
      .eq('price_code', priceCode)
      .order('version_number', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;
    
    if (!data) return null;
    
    return {
      ...data,
      status: isValidStatus(data.status) ? data.status : 'draft' as 'draft' | 'submitted' | 'approved'
    };
  },

  async createVersion(data: Omit<PriceCodeVersion, 'id' | 'created_at' | 'version_number'>): Promise<PriceCodeVersion> {
    // Get the next version number
    const { data: existingVersions } = await supabase
      .from('price_code_versions')
      .select('version_number')
      .eq('project_id', data.project_id)
      .eq('price_code', data.price_code)
      .order('version_number', { ascending: false })
      .limit(1);

    const nextVersionNumber = existingVersions && existingVersions.length > 0 
      ? existingVersions[0].version_number + 1 
      : 1;

    const { data: newVersion, error } = await supabase
      .from('price_code_versions')
      .insert({
        ...data,
        version_number: nextVersionNumber
      })
      .select()
      .single();

    if (error) throw error;
    
    return {
      ...newVersion,
      status: isValidStatus(newVersion.status) ? newVersion.status : 'draft' as 'draft' | 'submitted' | 'approved'
    };
  },

  async updateVersion(id: string, updates: Partial<PriceCodeVersion>): Promise<PriceCodeVersion> {
    const { data, error } = await supabase
      .from('price_code_versions')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    
    return {
      ...data,
      status: isValidStatus(data.status) ? data.status : 'draft' as 'draft' | 'submitted' | 'approved'
    };
  },

  async submitForApproval(id: string, changeSummary?: string): Promise<PriceCodeVersion> {
    return this.updateVersion(id, {
      status: 'submitted',
      change_summary: changeSummary
    });
  },

  async approve(id: string, approvedBy: string): Promise<PriceCodeVersion> {
    return this.updateVersion(id, {
      status: 'approved',
      approved_by: approvedBy,
      approved_at: new Date().toISOString()
    });
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('price_code_versions')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }
};
