
import { supabase } from '@/integrations/supabase/client';
import { ResourceLibrary } from '@/types/estimation';

export const resourceLibraryService = {
  async getAll(): Promise<ResourceLibrary[]> {
    const { data, error } = await supabase
      .from('resource_library')
      .select('*')
      .order('resource_code');
    
    if (error) throw error;
    if (!Array.isArray(data)) return [];
    
    return data as ResourceLibrary[];
  },

  async create(resource: Omit<ResourceLibrary, 'id' | 'created_at' | 'updated_at'>): Promise<ResourceLibrary> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('resource_library')
      .insert({ ...resource, user_id: user.id })
      .select()
      .single();
    
    if (error) throw error;
    if (!data || typeof data !== 'object') throw new Error('Invalid response data');
    
    return data as ResourceLibrary;
  },

  async update(id: string, updates: Partial<ResourceLibrary>): Promise<ResourceLibrary> {
    const { data, error } = await supabase
      .from('resource_library')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    if (!data || typeof data !== 'object') throw new Error('Invalid response data');
    
    return data as ResourceLibrary;
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('resource_library')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  async search(query: string): Promise<ResourceLibrary[]> {
    const { data, error } = await supabase
      .from('resource_library')
      .select('*')
      .or(`resource_name.ilike.%${query}%,resource_code.ilike.%${query}%,notes.ilike.%${query}%`)
      .order('resource_code');
    
    if (error) throw error;
    if (!Array.isArray(data)) return [];
    
    return data as ResourceLibrary[];
  }
};
