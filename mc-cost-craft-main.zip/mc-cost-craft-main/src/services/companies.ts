
import { supabase } from '@/integrations/supabase/client';
import { Company } from '@/types/mccost';

const handleAuthError = async (error: any) => {
  if (error?.code === 'PGRST301' || error?.message?.includes('JWT expired')) {
    console.log('JWT expired, attempting to refresh session...');
    try {
      const { data: { session }, error: refreshError } = await supabase.auth.refreshSession();
      if (refreshError) {
        console.error('Failed to refresh session:', refreshError);
        throw new Error('Authentication expired. Please sign in again.');
      }
      console.log('Session refreshed successfully');
      return session;
    } catch (refreshError) {
      console.error('Session refresh failed:', refreshError);
      throw new Error('Authentication expired. Please sign in again.');
    }
  }
  throw error;
};

export const companiesService = {
  async getAll(): Promise<Company[]> {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error: any) {
      await handleAuthError(error);
      // Retry after token refresh
      const { data, error: retryError } = await supabase
        .from('companies')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (retryError) throw retryError;
      return data || [];
    }
  },

  async getById(id: string): Promise<Company> {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return data;
    } catch (error: any) {
      await handleAuthError(error);
      // Retry after token refresh
      const { data, error: retryError } = await supabase
        .from('companies')
        .select('*')
        .eq('id', id)
        .single();
      
      if (retryError) throw retryError;
      return data;
    }
  },

  async create(company: Omit<Company, 'id' | 'created_at' | 'updated_at'>): Promise<Company> {
    try {
      const { data, error } = await supabase
        .from('companies')
        .insert({
          ...company,
          user_id: (await supabase.auth.getUser()).data.user?.id
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error: any) {
      await handleAuthError(error);
      // Retry after token refresh
      const { data, error: retryError } = await supabase
        .from('companies')
        .insert({
          ...company,
          user_id: (await supabase.auth.getUser()).data.user?.id
        })
        .select()
        .single();
      
      if (retryError) throw retryError;
      return data;
    }
  },

  async update(id: string, updates: Partial<Company>): Promise<Company> {
    try {
      const { data, error } = await supabase
        .from('companies')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error: any) {
      await handleAuthError(error);
      // Retry after token refresh
      const { data, error: retryError } = await supabase
        .from('companies')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (retryError) throw retryError;
      return data;
    }
  },

  async delete(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('companies')
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (error: any) {
      await handleAuthError(error);
      // Retry after token refresh
      const { error: retryError } = await supabase
        .from('companies')
        .delete()
        .eq('id', id);
      
      if (retryError) throw retryError;
    }
  }
};
