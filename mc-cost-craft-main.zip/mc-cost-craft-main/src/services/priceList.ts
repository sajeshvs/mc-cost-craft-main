
import { supabase } from '@/integrations/supabase/client';
import { PriceListItem, UFGS_DIVISIONS } from '@/types/priceList';

// Extended type that includes the new split rate columns
type ExtendedPriceListRow = {
  id: string;
  project_id: string;
  division: string;
  trade_code?: string;
  price_code: string;
  description: string;
  unit: string;
  unit_rate: number;
  split_labor?: number;
  split_material?: number;
  split_equipment?: number;
  split_subcontractor?: number;
  split_consultant?: number;
  boq_reference: any;
  sort_order: number;
  user_id?: string;
  created_at: string;
  updated_at: string;
};

export const priceListService = {
  async getByProject(projectId: string): Promise<PriceListItem[]> {
    const { data, error } = await supabase
      .from('price_list')
      .select('*')
      .eq('project_id', projectId)
      .order('division', { ascending: true })
      .order('sort_order', { ascending: true });

    if (error) throw error;
    
    // Convert the Supabase data to our PriceListItem type with safe property access
    return (data || []).map(item => {
      const extendedItem = item as any; // Type assertion to access new columns
      return {
        ...item,
        split_labor: extendedItem.split_labor || 0,
        split_material: extendedItem.split_material || 0,
        split_equipment: extendedItem.split_equipment || 0,
        split_subcontractor: extendedItem.split_subcontractor || 0,
        split_consultant: extendedItem.split_consultant || 0,
        boq_reference: Array.isArray(item.boq_reference) 
          ? item.boq_reference.filter((ref): ref is string => typeof ref === 'string')
          : []
      } as PriceListItem;
    });
  },

  async create(item: Omit<PriceListItem, 'id' | 'created_at' | 'updated_at'>): Promise<PriceListItem> {
    const { data: { user } } = await supabase.auth.getUser();
    
    const { data, error } = await supabase
      .from('price_list')
      .insert([{
        ...item,
        user_id: user?.id
      }])
      .select()
      .single();

    if (error) throw error;
    
    const extendedData = data as any;
    return {
      ...data,
      split_labor: extendedData.split_labor || 0,
      split_material: extendedData.split_material || 0,
      split_equipment: extendedData.split_equipment || 0,
      split_subcontractor: extendedData.split_subcontractor || 0,
      split_consultant: extendedData.split_consultant || 0,
      boq_reference: Array.isArray(data.boq_reference) 
        ? data.boq_reference.filter((ref): ref is string => typeof ref === 'string')
        : []
    } as PriceListItem;
  },

  async bulkCreate(items: Omit<PriceListItem, 'id' | 'created_at' | 'updated_at'>[]): Promise<PriceListItem[]> {
    const { data: { user } } = await supabase.auth.getUser();
    
    const itemsWithUser = items.map(item => ({
      ...item,
      user_id: user?.id
    }));

    // Insert in batches to avoid timeout
    const batchSize = 100;
    const results: PriceListItem[] = [];
    
    for (let i = 0; i < itemsWithUser.length; i += batchSize) {
      const batch = itemsWithUser.slice(i, i + batchSize);
      const { data, error } = await supabase
        .from('price_list')
        .insert(batch)
        .select();

      if (error) throw error;
      
      const processedBatch = (data || []).map(item => {
        const extendedItem = item as any;
        return {
          ...item,
          split_labor: extendedItem.split_labor || 0,
          split_material: extendedItem.split_material || 0,
          split_equipment: extendedItem.split_equipment || 0,
          split_subcontractor: extendedItem.split_subcontractor || 0,
          split_consultant: extendedItem.split_consultant || 0,
          boq_reference: Array.isArray(item.boq_reference) 
            ? item.boq_reference.filter((ref): ref is string => typeof ref === 'string')
            : []
        } as PriceListItem;
      });
      
      results.push(...processedBatch);
    }
    
    return results;
  },

  async update(id: string, updates: Partial<PriceListItem>): Promise<PriceListItem> {
    const { data, error } = await supabase
      .from('price_list')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    
    const extendedData = data as any;
    return {
      ...data,
      split_labor: extendedData.split_labor || 0,
      split_material: extendedData.split_material || 0,
      split_equipment: extendedData.split_equipment || 0,
      split_subcontractor: extendedData.split_subcontractor || 0,
      split_consultant: extendedData.split_consultant || 0,
      boq_reference: Array.isArray(data.boq_reference) 
        ? data.boq_reference.filter((ref): ref is string => typeof ref === 'string')
        : []
    } as PriceListItem;
  },

  async updateWithSplitRates(id: string, netRate: number, splitRates: {
    labor: number;
    material: number;
    equipment: number;
    subcontractor: number;
    consultant: number;
  }): Promise<PriceListItem> {
    const updates = {
      unit_rate: netRate,
      split_labor: splitRates.labor,
      split_material: splitRates.material,
      split_equipment: splitRates.equipment,
      split_subcontractor: splitRates.subcontractor,
      split_consultant: splitRates.consultant
    };

    return this.update(id, updates);
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('price_list')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async deleteMultiple(ids: string[]): Promise<void> {
    const { error } = await supabase
      .from('price_list')
      .delete()
      .in('id', ids);

    if (error) throw error;
  },

  async clearAllPrices(projectId: string): Promise<void> {
    const { error } = await supabase
      .from('price_list')
      .delete()
      .eq('project_id', projectId);

    if (error) throw error;
  },

  async createDefaultPrices(projectId: string): Promise<void> {
    const { data: { user } } = await supabase.auth.getUser();
    const defaultPrices = this.generateDoDStandardPrices(projectId, user?.id);

    // Insert in batches to avoid timeout
    const batchSize = 100;
    for (let i = 0; i < defaultPrices.length; i += batchSize) {
      const batch = defaultPrices.slice(i, i + batchSize);
      const { error } = await supabase
        .from('price_list')
        .insert(batch);

      if (error) throw error;
    }
  },

  generateDoDStandardPrices(projectId: string, userId?: string): any[] {
    const prices: any[] = [];
    let globalSortOrder = 0;

    // Generate comprehensive DoD/UFGS-based price items with realistic rates
    Object.entries(UFGS_DIVISIONS).forEach(([divisionCode, divisionName]) => {
      const divisionItems = this.getDoDItemsForDivision(divisionCode, divisionName);
      
      divisionItems.forEach((item, index) => {
        const subtradeLetter = String.fromCharCode(65 + (index % 26)); // A, B, C, etc.
        const serialNumber = String((index + 1)).padStart(4, '0');
        const priceCode = `${divisionCode}${subtradeLetter}-${serialNumber}`;

        prices.push({
          project_id: projectId,
          division: divisionCode,
          price_code: priceCode,
          description: item.description,
          unit: item.unit,
          unit_rate: item.baseRate,
          split_labor: item.splitRates?.labor || 0,
          split_material: item.splitRates?.material || 0,
          split_equipment: item.splitRates?.equipment || 0,
          split_subcontractor: item.splitRates?.subcontractor || 0,
          split_consultant: item.splitRates?.consultant || 0,
          sort_order: globalSortOrder++,
          user_id: userId,
          boq_reference: []
        });
      });
    });

    return prices;
  },

  getDoDItemsForDivision(divisionCode: string, divisionName: string): Array<{
    description: string; 
    unit: string; 
    baseRate: number;
    splitRates?: {
      labor: number;
      material: number;
      equipment: number;
      subcontractor: number;
      consultant: number;
    };
  }> {
    // Enhanced DoD-standard division items with realistic cost breakdown
    const doDDivisionItems: Record<string, Array<{
      description: string; 
      unit: string; 
      baseRate: number;
      splitRates?: {
        labor: number;
        material: number;
        equipment: number;
        subcontractor: number;
        consultant: number;
      };
    }>> = {
      '01': [
        { 
          description: 'General Requirements - Project Management per UFC 3-701-01', 
          unit: 'LS', 
          baseRate: 15000,
          splitRates: { labor: 8000, material: 1000, equipment: 2000, subcontractor: 3000, consultant: 1000 }
        },
        { 
          description: 'Temporary Facilities and Controls per DoD Standards', 
          unit: 'LS', 
          baseRate: 8500,
          splitRates: { labor: 3500, material: 4000, equipment: 1000, subcontractor: 0, consultant: 0 }
        },
        { 
          description: 'Quality Control Testing per M-CACES Standards', 
          unit: 'LS', 
          baseRate: 5200,
          splitRates: { labor: 2200, material: 500, equipment: 500, subcontractor: 2000, consultant: 0 }
        },
        { 
          description: 'Construction Progress Documentation per NAVFAC P-445', 
          unit: 'LS', 
          baseRate: 3800,
          splitRates: { labor: 2800, material: 200, equipment: 300, subcontractor: 0, consultant: 500 }
        },
        { 
          description: 'Safety and Environmental Compliance per USACE EM 385-1-1', 
          unit: 'LS', 
          baseRate: 4500,
          splitRates: { labor: 2500, material: 800, equipment: 200, subcontractor: 1000, consultant: 0 }
        }
      ],
      '02': [
        { 
          description: 'Building Demolition per UFC 3-701-01 Standards', 
          unit: 'SF', 
          baseRate: 8.75,
          splitRates: { labor: 3.50, material: 0.25, equipment: 4.00, subcontractor: 1.00, consultant: 0 }
        },
        { 
          description: 'Selective Demolition with Hazmat Considerations', 
          unit: 'SF', 
          baseRate: 12.50,
          splitRates: { labor: 4.50, material: 0.50, equipment: 2.50, subcontractor: 5.00, consultant: 0 }
        },
        { 
          description: 'Site Clearing per USACE Standard Practice', 
          unit: 'AC', 
          baseRate: 4200,
          splitRates: { labor: 800, material: 200, equipment: 3000, subcontractor: 200, consultant: 0 }
        },
        { 
          description: 'Tree Removal with Environmental Protection', 
          unit: 'EA', 
          baseRate: 285,
          splitRates: { labor: 120, material: 15, equipment: 100, subcontractor: 50, consultant: 0 }
        },
        { 
          description: 'Hazardous Material Abatement per EPA/DoD Standards', 
          unit: 'SF', 
          baseRate: 15.25,
          splitRates: { labor: 5.25, material: 2.00, equipment: 1.00, subcontractor: 7.00, consultant: 0 }
        }
      ],
      '03': [
        { 
          description: 'Cast-in-Place Concrete Footings per ACI 318/DoD', 
          unit: 'CY', 
          baseRate: 685,
          splitRates: { labor: 185, material: 420, equipment: 65, subcontractor: 15, consultant: 0 }
        },
        { 
          description: 'Reinforced Concrete Slabs per UFC 3-320-02N', 
          unit: 'CY', 
          baseRate: 595,
          splitRates: { labor: 165, material: 375, equipment: 45, subcontractor: 10, consultant: 0 }
        },
        { 
          description: 'Concrete Block Masonry per TM 5-809-3', 
          unit: 'SF', 
          baseRate: 18.95,
          splitRates: { labor: 8.45, material: 9.50, equipment: 0.75, subcontractor: 0.25, consultant: 0 }
        },
        { 
          description: 'Precast Concrete Panels per PCI/DoD Standards', 
          unit: 'SF', 
          baseRate: 28.50,
          splitRates: { labor: 6.50, material: 18.00, equipment: 2.00, subcontractor: 2.00, consultant: 0 }
        },
        { 
          description: 'Concrete Finishing per ACI 302.1R', 
          unit: 'SF', 
          baseRate: 4.25,
          splitRates: { labor: 3.25, material: 0.75, equipment: 0.25, subcontractor: 0, consultant: 0 }
        }
      ],
      // Continue for other divisions...
      '04': [
        { 
          description: 'Clay Brick Masonry per TM 5-809-3/DoD Standards', 
          unit: 'SF', 
          baseRate: 22.85,
          splitRates: { labor: 9.85, material: 11.50, equipment: 0.75, subcontractor: 0.75, consultant: 0 }
        },
        { 
          description: 'Concrete Masonry Units (CMU) per ASTM C90', 
          unit: 'SF', 
          baseRate: 16.75,
          splitRates: { labor: 7.25, material: 8.50, equipment: 0.50, subcontractor: 0.50, consultant: 0 }
        }
      ],
      '05': [
        { 
          description: 'Structural Steel Framing per AISC/DoD Standards', 
          unit: 'TON', 
          baseRate: 4850,
          splitRates: { labor: 1650, material: 2800, equipment: 300, subcontractor: 100, consultant: 0 }
        },
        { 
          description: 'Steel Joists and Decking per SJI Standards', 
          unit: 'SF', 
          baseRate: 12.85,
          splitRates: { labor: 4.85, material: 7.00, equipment: 0.75, subcontractor: 0.25, consultant: 0 }
        }
      ],
      '26': [
        { 
          description: 'Electrical Service and Distribution per UFC 3-520-01', 
          unit: 'EA', 
          baseRate: 5200,
          splitRates: { labor: 2200, material: 2500, equipment: 300, subcontractor: 200, consultant: 0 }
        },
        { 
          description: 'Wiring Methods per NEC/DoD Standards', 
          unit: 'LF', 
          baseRate: 3.85,
          splitRates: { labor: 1.85, material: 1.75, equipment: 0.15, subcontractor: 0.10, consultant: 0 }
        }
      ],
      '31': [
        { 
          description: 'Site Clearing per USACE EM 1110-2-2300', 
          unit: 'AC', 
          baseRate: 3800,
          splitRates: { labor: 600, material: 200, equipment: 2800, subcontractor: 200, consultant: 0 }
        },
        { 
          description: 'Excavation and Fill per UFC 3-220-01N', 
          unit: 'CY', 
          baseRate: 18.50,
          splitRates: { labor: 4.50, material: 2.00, equipment: 11.00, subcontractor: 1.00, consultant: 0 }
        }
      ]
    };

    return doDDivisionItems[divisionCode] || [
      { 
        description: `${divisionName} - Standard DoD Activity`, 
        unit: 'LS', 
        baseRate: 1000,
        splitRates: { labor: 400, material: 350, equipment: 150, subcontractor: 100, consultant: 0 }
      }
    ];
  },

  // Method to import from CSV or bulk data
  async importFromCSV(projectId: string, csvData: string): Promise<number> {
    const lines = csvData.split('\n');
    const headers = lines[0].split(',').map(h => h.trim());
    
    const items = lines.slice(1)
      .filter(line => line.trim())
      .map((line, index) => {
        const values = line.split(',').map(v => v.trim());
        const item: any = { project_id: projectId };
        
        headers.forEach((header, i) => {
          const value = values[i] || '';
          switch (header.toLowerCase()) {
            case 'price_code':
              item.price_code = value;
              break;
            case 'description':
              item.description = value;
              break;
            case 'unit':
              item.unit = value;
              break;
            case 'unit_rate':
              item.unit_rate = parseFloat(value) || 0;
              break;
            case 'division':
              item.division = value;
              break;
            case 'split_labor':
              item.split_labor = parseFloat(value) || 0;
              break;
            case 'split_material':
              item.split_material = parseFloat(value) || 0;
              break;
            case 'split_equipment':
              item.split_equipment = parseFloat(value) || 0;
              break;
            case 'split_subcontractor':
              item.split_subcontractor = parseFloat(value) || 0;
              break;
            case 'split_consultant':
              item.split_consultant = parseFloat(value) || 0;
              break;
            default:
              // Handle other fields
              break;
          }
        });
        
        item.sort_order = index;
        item.boq_reference = [];
        
        return item;
      });

    await this.bulkCreate(items);
    return items.length;
  },

  // Method to export to CSV
  async exportToCSV(projectId: string): Promise<string> {
    const items = await this.getByProject(projectId);
    
    const headers = [
      'price_code', 'description', 'unit', 'unit_rate', 'division',
      'split_labor', 'split_material', 'split_equipment', 
      'split_subcontractor', 'split_consultant'
    ];
    
    const csvRows = [
      headers.join(','),
      ...items.map(item => [
        item.price_code,
        `"${item.description.replace(/"/g, '""')}"`,
        item.unit,
        item.unit_rate,
        item.division,
        item.split_labor,
        item.split_material,
        item.split_equipment,
        item.split_subcontractor,
        item.split_consultant
      ].join(','))
    ];
    
    return csvRows.join('\n');
  }
};
