import { supabase } from '@/integrations/supabase/client';
import { Resource, ResourceInsert, DEFAULT_RESOURCES } from '@/types/resources';

export const resourcesService = {
  async getByProject(projectId: string): Promise<Resource[]> {
    console.log('Fetching resources for project:', projectId);
    
    const { data, error } = await supabase
      .from('resources')
      .select('*')
      .eq('project_id', projectId)
      .order('category')
      .order('division')
      .order('sort_order');
    
    if (error) {
      console.error('Error fetching resources:', error);
      throw error;
    }
    
    const resources = (data || []).map(item => {
      // Map database fields to interface with proper fallbacks
      const offerRate = item.offer_rate || item.rate || 0;
      const bidRate = item.bid_rate || item.rate || 0;
      const discountPercent = (item as any).discount_percent || 0;
      const finalRate = (item as any).final_rate || (offerRate * (1 - discountPercent / 100));
      const usageQuantity = item.usage_quantity || item.used_quantity || 0;
      const usedAmount = (item as any).used_amount || (finalRate * usageQuantity);
      const wastagePercent = item.wastage_percent || 0;
      const wastageQuantity = item.wastage_quantity || ((usageQuantity * wastagePercent) / 100);
      const wastageAmount = (item as any).wastage_amount || (finalRate * wastageQuantity);
      const totalAmount = (item as any).total_amount || (usedAmount + wastageAmount);
      const linkedPriceCodes = (item as any).linked_price_codes || [];
      
      return {
        id: item.id,
        project_id: item.project_id,
        resource_code: item.resource_code,
        category: item.category as 'P' | 'M' | 'E' | 'S' | 'C',
        division: item.division,
        resource_name: item.resource_name,
        unit: item.unit,
        offer_rate: offerRate,
        offer_currency: item.offer_currency || 'USD',
        bid_rate: bidRate,
        discount_percent: discountPercent,
        final_rate: finalRate,
        usage_quantity: usageQuantity,
        used_quantity: item.used_quantity || usageQuantity,
        used_amount: usedAmount,
        wastage_percent: wastagePercent,
        wastage_quantity: wastageQuantity,
        wastage_amount: wastageAmount,
        total_quantity: usageQuantity + wastageQuantity,
        total_amount: totalAmount,
        linked_price_codes: Array.isArray(linkedPriceCodes) ? linkedPriceCodes : [],
        sort_order: item.sort_order,
        user_id: item.user_id,
        created_at: item.created_at,
        updated_at: item.updated_at
      };
    });
    
    console.log(`Loaded ${resources.length} resources`);
    return resources;
  },

  async create(resource: ResourceInsert): Promise<Resource> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const dbInsert = {
      project_id: resource.project_id,
      resource_code: resource.resource_code,
      category: resource.category,
      division: resource.division,
      resource_name: resource.resource_name,
      unit: resource.unit,
      rate: resource.bid_rate, // Backward compatibility
      offer_rate: resource.offer_rate,
      offer_currency: resource.offer_currency,
      bid_rate: resource.bid_rate,
      discount_percent: resource.discount_percent,
      usage_quantity: resource.usage_quantity,
      used_quantity: resource.usage_quantity, // Backward compatibility
      wastage_percent: resource.wastage_percent,
      linked_price_codes: resource.linked_price_codes,
      sort_order: resource.sort_order,
      user_id: user.id
    };

    const { data, error } = await supabase
      .from('resources')
      .insert(dbInsert)
      .select()
      .single();
    
    if (error) throw error;
    
    const offerRate = data.offer_rate || data.rate || 0;
    const bidRate = data.bid_rate || data.rate || 0;
    const discountPercent = (data as any).discount_percent || 0;
    const finalRate = (data as any).final_rate || (offerRate * (1 - discountPercent / 100));
    const usageQuantity = data.usage_quantity || data.used_quantity || 0;
    const usedAmount = (data as any).used_amount || (finalRate * usageQuantity);
    const wastagePercent = data.wastage_percent || 0;
    const wastageQuantity = data.wastage_quantity || ((usageQuantity * wastagePercent) / 100);
    const wastageAmount = (data as any).wastage_amount || (finalRate * wastageQuantity);
    const totalAmount = (data as any).total_amount || (usedAmount + wastageAmount);
    const linkedPriceCodes = (data as any).linked_price_codes || [];
    
    return {
      id: data.id,
      project_id: data.project_id,
      resource_code: data.resource_code,
      category: data.category as 'P' | 'M' | 'E' | 'S' | 'C',
      division: data.division,
      resource_name: data.resource_name,
      unit: data.unit,
      offer_rate: offerRate,
      offer_currency: data.offer_currency || 'USD',
      bid_rate: bidRate,
      discount_percent: discountPercent,
      final_rate: finalRate,
      usage_quantity: usageQuantity,
      used_quantity: data.used_quantity || usageQuantity,
      used_amount: usedAmount,
      wastage_percent: wastagePercent,
      wastage_quantity: wastageQuantity,
      wastage_amount: wastageAmount,
      total_quantity: usageQuantity + wastageQuantity,
      total_amount: totalAmount,
      linked_price_codes: Array.isArray(linkedPriceCodes) ? linkedPriceCodes : [],
      sort_order: data.sort_order,
      user_id: data.user_id,
      created_at: data.created_at,
      updated_at: data.updated_at
    };
  },

  async update(id: string, updates: Partial<Resource>): Promise<Resource> {
    const dbUpdates: any = {
      updated_at: new Date().toISOString()
    };

    // Map interface fields to database fields
    if (updates.resource_code !== undefined) dbUpdates.resource_code = updates.resource_code;
    if (updates.resource_name !== undefined) dbUpdates.resource_name = updates.resource_name;
    if (updates.unit !== undefined) dbUpdates.unit = updates.unit;
    if (updates.offer_rate !== undefined) {
      dbUpdates.offer_rate = updates.offer_rate;
      dbUpdates.rate = updates.offer_rate; // Backward compatibility
    }
    if (updates.offer_currency !== undefined) dbUpdates.offer_currency = updates.offer_currency;
    if (updates.bid_rate !== undefined) {
      dbUpdates.bid_rate = updates.bid_rate;
      dbUpdates.rate = updates.bid_rate; // Backward compatibility
    }
    if (updates.discount_percent !== undefined) dbUpdates.discount_percent = updates.discount_percent;
    if (updates.usage_quantity !== undefined) {
      dbUpdates.usage_quantity = updates.usage_quantity;
      dbUpdates.used_quantity = updates.usage_quantity; // Backward compatibility
    }
    if (updates.wastage_percent !== undefined) dbUpdates.wastage_percent = updates.wastage_percent;
    if (updates.linked_price_codes !== undefined) dbUpdates.linked_price_codes = updates.linked_price_codes;

    const { data, error } = await supabase
      .from('resources')
      .update(dbUpdates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    
    const offerRate = data.offer_rate || data.rate || 0;
    const bidRate = data.bid_rate || data.rate || 0;
    const discountPercent = (data as any).discount_percent || 0;
    const finalRate = (data as any).final_rate || (offerRate * (1 - discountPercent / 100));
    const usageQuantity = data.usage_quantity || data.used_quantity || 0;
    const usedAmount = (data as any).used_amount || (finalRate * usageQuantity);
    const wastagePercent = data.wastage_percent || 0;
    const wastageQuantity = data.wastage_quantity || ((usageQuantity * wastagePercent) / 100);
    const wastageAmount = (data as any).wastage_amount || (finalRate * wastageQuantity);
    const totalAmount = (data as any).total_amount || (usedAmount + wastageAmount);
    const linkedPriceCodes = (data as any).linked_price_codes || [];
    
    return {
      id: data.id,
      project_id: data.project_id,
      resource_code: data.resource_code,
      category: data.category as 'P' | 'M' | 'E' | 'S' | 'C',
      division: data.division,
      resource_name: data.resource_name,
      unit: data.unit,
      offer_rate: offerRate,
      offer_currency: data.offer_currency || 'USD',
      bid_rate: bidRate,
      discount_percent: discountPercent,
      final_rate: finalRate,
      usage_quantity: usageQuantity,
      used_quantity: data.used_quantity || usageQuantity,
      used_amount: usedAmount,
      wastage_percent: wastagePercent,
      wastage_quantity: wastageQuantity,
      wastage_amount: wastageAmount,
      total_quantity: usageQuantity + wastageQuantity,
      total_amount: totalAmount,
      linked_price_codes: Array.isArray(linkedPriceCodes) ? linkedPriceCodes : [],
      sort_order: data.sort_order,
      user_id: data.user_id,
      created_at: data.created_at,
      updated_at: data.updated_at
    };
  },

  async getById(id: string): Promise<Resource> {
    const { data, error } = await supabase
      .from('resources')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) throw error;
    
    const offerRate = data.offer_rate || data.rate || 0;
    const bidRate = data.bid_rate || data.rate || 0;
    const discountPercent = (data as any).discount_percent || 0;
    const finalRate = (data as any).final_rate || (offerRate * (1 - discountPercent / 100));
    const usageQuantity = data.usage_quantity || data.used_quantity || 0;
    const usedAmount = (data as any).used_amount || (finalRate * usageQuantity);
    const wastagePercent = data.wastage_percent || 0;
    const wastageQuantity = data.wastage_quantity || ((usageQuantity * wastagePercent) / 100);
    const wastageAmount = (data as any).wastage_amount || (finalRate * wastageQuantity);
    const totalAmount = (data as any).total_amount || (usedAmount + wastageAmount);
    const linkedPriceCodes = (data as any).linked_price_codes || [];
    
    return {
      id: data.id,
      project_id: data.project_id,
      resource_code: data.resource_code,
      category: data.category as 'P' | 'M' | 'E' | 'S' | 'C',
      division: data.division,
      resource_name: data.resource_name,
      unit: data.unit,
      offer_rate: offerRate,
      offer_currency: data.offer_currency || 'USD',
      bid_rate: bidRate,
      discount_percent: discountPercent,
      final_rate: finalRate,
      usage_quantity: usageQuantity,
      used_quantity: data.used_quantity || usageQuantity,
      used_amount: usedAmount,
      wastage_percent: wastagePercent,
      wastage_quantity: wastageQuantity,
      wastage_amount: wastageAmount,
      total_quantity: usageQuantity + wastageQuantity,
      total_amount: totalAmount,
      linked_price_codes: Array.isArray(linkedPriceCodes) ? linkedPriceCodes : [],
      sort_order: data.sort_order,
      user_id: data.user_id,
      created_at: data.created_at,
      updated_at: data.updated_at
    };
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('resources')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  async deleteMultiple(ids: string[]): Promise<void> {
    const { error } = await supabase
      .from('resources')
      .delete()
      .in('id', ids);
    
    if (error) throw error;
  },

  async generateResourceCode(projectId: string, category: string, division: string): Promise<string> {
    const { data, error } = await supabase
      .from('resources')
      .select('resource_code')
      .eq('project_id', projectId)
      .eq('category', category)
      .eq('division', division)
      .order('resource_code', { ascending: false })
      .limit(1);

    if (error) throw error;

    let nextSerial = 5;
    if (data && data.length > 0) {
      const lastCode = data[0].resource_code;
      const serialPart = lastCode.split('-')[1];
      const lastSerial = parseInt(serialPart);
      nextSerial = lastSerial + 5;
    }

    const serialFormatted = nextSerial.toString().padStart(4, '0');
    return `${category}${division}-${serialFormatted}`;
  },

  async createDefaultResources(projectId: string): Promise<void> {
    console.log('Creating comprehensive UFGS default resources for project:', projectId);
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    // Check if resources already exist for this project
    const { data: existing, error: checkError } = await supabase
      .from('resources')
      .select('id')
      .eq('project_id', projectId)
      .limit(1);

    if (checkError) throw checkError;
    if (existing && existing.length > 0) {
      console.log('Resources already exist for this project');
      return;
    }

    console.log('Creating comprehensive UFGS default resources...');
    const resources: any[] = [];
    let globalSortOrder = 0;

    // Process each category and division from DEFAULT_RESOURCES
    for (const [categoryKey, divisions] of Object.entries(DEFAULT_RESOURCES)) {
      console.log(`Processing category: ${categoryKey}`);
      
      for (const [divisionKey, resourceNames] of Object.entries(divisions)) {
        console.log(`Processing division: ${divisionKey} with ${resourceNames.length} resources`);
        
        for (let i = 0; i < resourceNames.length; i++) {
          const resourceName = resourceNames[i];
          globalSortOrder += 5;
          
          // Generate proper resource code
          const serial = (i + 1) * 5;
          const resourceCode = `${categoryKey}${divisionKey}-${serial.toString().padStart(4, '0')}`;
          
          // Determine appropriate unit and defaults based on category
          let unit = 'EA';
          let defaultRate = 0;
          let wastagePercent = 0;
          
          if (categoryKey === 'P') {
            unit = 'HR';
            defaultRate = categoryKey === 'P' && divisionKey === '01' ? 25 : 35;
          } else if (categoryKey === 'M') {
            wastagePercent = 5;
            if (divisionKey === '03') {
              unit = 'CY';
              defaultRate = 150;
            } else if (['05', '06'].includes(divisionKey)) {
              unit = 'LB';
              defaultRate = 2.50;
            } else if (['07', '08', '09'].includes(divisionKey)) {
              unit = 'SF';
              defaultRate = 8;
            } else if (['22', '23', '26'].includes(divisionKey)) {
              unit = 'LF';
              defaultRate = 12;
            } else {
              unit = 'EA';
              defaultRate = 50;
            }
          } else if (categoryKey === 'E') {
            unit = 'DAY';
            defaultRate = 200;
          } else if (categoryKey === 'S') {
            unit = 'LS';
            defaultRate = 1000;
          } else if (categoryKey === 'C') {
            unit = 'LS'; 
            defaultRate = 500;
          }
          
          resources.push({
            project_id: projectId,
            resource_code: resourceCode,
            category: categoryKey as 'P' | 'M' | 'E' | 'S' | 'C',
            division: divisionKey,
            resource_name: resourceName,
            unit,
            rate: defaultRate, // Backward compatibility
            offer_rate: defaultRate,
            offer_currency: 'USD',
            bid_rate: defaultRate,
            discount_percent: 0,
            usage_quantity: 0,
            used_quantity: 0, // Backward compatibility
            wastage_percent: wastagePercent,
            linked_price_codes: [],
            sort_order: globalSortOrder,
            user_id: user.id
          });
        }
      }
    }

    console.log(`Total resources to create: ${resources.length}`);

    if (resources.length > 0) {
      // Insert in smaller batches to avoid timeout
      const batchSize = 50;
      for (let i = 0; i < resources.length; i += batchSize) {
        const batch = resources.slice(i, i + batchSize);
        console.log(`Inserting batch ${Math.floor(i/batchSize) + 1}/${Math.ceil(resources.length/batchSize)} (${batch.length} resources)`);
        
        const { error } = await supabase
          .from('resources')
          .insert(batch);

        if (error) {
          console.error('Error inserting resource batch:', error);
          throw error;
        }
        
        // Small delay between batches
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      console.log(`Successfully created ${resources.length} UFGS-compliant default resources`);
    }
  },

  async updateResourceUsage(projectId: string, priceCode: string, resourceUpdates: Array<{
    resourceCode: string;
    quantity: number;
    category: string;
  }>): Promise<void> {
    console.log('Updating resource usage from price code analysis:', priceCode);
    
    for (const update of resourceUpdates) {
      // Get current linked_price_codes
      const { data: currentResource, error: fetchError } = await supabase
        .from('resources')
        .select('*')
        .eq('project_id', projectId)
        .eq('resource_code', update.resourceCode)
        .single();

      if (fetchError) {
        console.error('Error fetching current resource:', fetchError);
        continue;
      }

      const currentPriceCodes = (currentResource as any).linked_price_codes || [];
      const updatedPriceCodes = [...currentPriceCodes];
      
      // Add price code if not already present
      if (!updatedPriceCodes.includes(priceCode)) {
        updatedPriceCodes.push(priceCode);
      }

      const { error } = await supabase
        .from('resources')
        .update({
          used_quantity: update.quantity,
          usage_quantity: update.quantity,
          linked_price_codes: updatedPriceCodes
        })
        .eq('project_id', projectId)
        .eq('resource_code', update.resourceCode);

      if (error) {
        console.error('Error updating resource usage:', error);
        throw error;
      }
    }
  },

  async clearAllResources(projectId: string): Promise<void> {
    console.log('Clearing all existing resources for project:', projectId);
    const { error } = await supabase
      .from('resources')
      .delete()
      .eq('project_id', projectId);
    
    if (error) throw error;
    console.log('All resources cleared successfully');
  }
};
