
import { supabase } from '@/integrations/supabase/client';
import { Trade, DEFAULT_UFGS_SUBTRADES } from '@/types/trades';

export const tradesService = {
  async getByProject(projectId: string): Promise<Trade[]> {
    const { data, error } = await supabase
      .from('trades')
      .select('*')
      .eq('project_id', projectId)
      .order('division')
      .order('subtrade_letter');

    if (error) throw error;
    
    // If no trades exist, initialize with defaults
    if (!data || data.length === 0) {
      console.log('No trades found, initializing defaults...');
      await this.initializeDefaultTrades(projectId);
      
      // Fetch again after initialization
      const { data: newData, error: newError } = await supabase
        .from('trades')
        .select('*')
        .eq('project_id', projectId)
        .order('division')
        .order('subtrade_letter');
      
      if (newError) throw newError;
      return newData || [];
    }
    
    return data || [];
  },

  async create(projectId: string, tradeData: Omit<Trade, 'id' | 'created_at' | 'updated_at' | 'trade_code'>): Promise<Trade> {
    const tradeCode = `${tradeData.division}${tradeData.subtrade_letter}`;
    
    const { data, error } = await supabase
      .from('trades')
      .insert({
        ...tradeData,
        project_id: projectId,
        trade_code: tradeCode,
        user_id: (await supabase.auth.getUser()).data.user?.id
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<Trade>): Promise<Trade> {
    // If division or subtrade_letter is being updated, recalculate trade_code
    if (updates.division || updates.subtrade_letter) {
      const { data: existing } = await supabase
        .from('trades')
        .select('division, subtrade_letter')
        .eq('id', id)
        .single();
      
      if (existing) {
        const division = updates.division || existing.division;
        const subtradeLetter = updates.subtrade_letter || existing.subtrade_letter;
        updates.trade_code = `${division}${subtradeLetter}`;
      }
    }

    const { data, error } = await supabase
      .from('trades')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('trades')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async initializeDefaultTrades(projectId: string): Promise<void> {
    console.log('Initializing default trades for project:', projectId);
    
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) throw new Error('User not authenticated');

    const defaultTrades = [];
    let sortOrder = 0;

    // Generate default trades for all UFGS divisions
    for (const [division, subtrades] of Object.entries(DEFAULT_UFGS_SUBTRADES)) {
      for (const subtrade of subtrades) {
        defaultTrades.push({
          project_id: projectId,
          division,
          subtrade_letter: subtrade.letter,
          trade_code: `${division}${subtrade.letter}`,
          description: subtrade.description,
          color_code: subtrade.color,
          sort_order: sortOrder++,
          user_id: userId
        });
      }
    }

    console.log('Inserting', defaultTrades.length, 'default trades');

    const { error } = await supabase
      .from('trades')
      .insert(defaultTrades);

    if (error) {
      console.error('Error inserting default trades:', error);
      throw error;
    }
    
    console.log('Default trades initialized successfully');
  },

  async copyFromProject(sourceProjectId: string, targetProjectId: string): Promise<void> {
    const sourceTrades = await this.getByProject(sourceProjectId);
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) throw new Error('User not authenticated');

    const tradesToCopy = sourceTrades.map(trade => ({
      project_id: targetProjectId,
      division: trade.division,
      subtrade_letter: trade.subtrade_letter,
      trade_code: trade.trade_code,
      description: trade.description,
      color_code: trade.color_code,
      sort_order: trade.sort_order,
      user_id: userId
    }));

    // Clear existing trades first
    await supabase
      .from('trades')
      .delete()
      .eq('project_id', targetProjectId);

    // Insert copied trades
    const { error } = await supabase
      .from('trades')
      .insert(tradesToCopy);

    if (error) throw error;
  },

  async importFromCSV(projectId: string, csvData: any[]): Promise<void> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    if (!userId) throw new Error('User not authenticated');

    // Clear existing trades first
    await supabase
      .from('trades')
      .delete()
      .eq('project_id', projectId);

    const tradesToImport = csvData.map((row, index) => ({
      project_id: projectId,
      division: row.division,
      subtrade_letter: row.subtrade_letter,
      trade_code: `${row.division}${row.subtrade_letter}`,
      description: row.description,
      color_code: row.color_code || '#3b82f6',
      sort_order: index,
      user_id: userId
    }));

    const { error } = await supabase
      .from('trades')
      .insert(tradesToImport);

    if (error) throw error;
  }
};
