
import { supabase } from '@/integrations/supabase/client';
import { BOQItem } from '@/types/mccost';

export const boqItemsService = {
  async getByJob(jobId: string): Promise<BOQItem[]> {
    console.log('Fetching BOQ items for job:', jobId);
    
    const { data: { user } } = await supabase.auth.getUser();
    console.log('Current user:', user?.id);
    
    if (!user) {
      console.error('No authenticated user found');
      throw new Error('User not authenticated');
    }

    const { data, error } = await supabase
      .from('boq_items')
      .select('*')
      .eq('job_id', jobId)
      .order('sort_order');
    
    console.log('BOQ query result:', { data: data?.length, error: error?.message });
    
    if (error) throw error;
    return (data || []) as BOQItem[];
  },

  async create(item: Omit<BOQItem, 'id' | 'created_at' | 'updated_at' | 'user_id'>): Promise<BOQItem> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('boq_items')
      .insert({ ...item, user_id: user.id })
      .select()
      .single();
    
    if (error) throw error;
    return data as BOQItem;
  },

  async bulkCreate(items: Omit<BOQItem, 'id' | 'created_at' | 'updated_at' | 'user_id'>[]): Promise<BOQItem[]> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const itemsWithUserId = items.map(item => ({ ...item, user_id: user.id }));

    const { data, error } = await supabase
      .from('boq_items')
      .insert(itemsWithUserId)
      .select();
    
    if (error) throw error;
    return (data || []) as BOQItem[];
  },

  async update(id: string, item: Partial<BOQItem>): Promise<BOQItem> {
    const { data, error } = await supabase
      .from('boq_items')
      .update({ ...item, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data as BOQItem;
  },

  async updateSortOrder(items: { id: string; sort_order: number }[]): Promise<void> {
    const promises = items.map(item =>
      supabase
        .from('boq_items')
        .update({ sort_order: item.sort_order })
        .eq('id', item.id)
    );
    
    await Promise.all(promises);
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('boq_items')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  }
};
