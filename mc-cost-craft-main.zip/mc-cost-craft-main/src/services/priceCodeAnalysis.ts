
import { supabase } from '@/integrations/supabase/client';

export interface PriceCodeAnalysisResource {
  id: string;
  project_id: string;
  price_code: string;
  resource_code: string;
  resource_name: string;
  category: 'P' | 'M' | 'E' | 'S' | 'C';
  unit: string;
  quantity: number;
  unit_rate: number;
  wastage_percent: number;
  total_amount: number;
  sort_order: number;
  version_id?: string;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export interface PriceCodeAnalysisWithVersion extends PriceCodeAnalysisResource {
  version_number: number;
  status: 'draft' | 'submitted' | 'approved';
}

// Type guard functions
function isValidCategory(category: string): category is 'P' | 'M' | 'E' | 'S' | 'C' {
  return ['P', 'M', 'E', 'S', 'C'].includes(category);
}

function isValidStatus(status: string): status is 'draft' | 'submitted' | 'approved' {
  return ['draft', 'submitted', 'approved'].includes(status);
}

export const priceCodeAnalysisService = {
  async getByPriceCode(projectId: string, priceCode: string): Promise<PriceCodeAnalysisResource[]> {
    const { data, error } = await supabase
      .rpc('get_price_code_analysis', {
        p_project_id: projectId,
        p_price_code: priceCode
      });

    if (error) throw error;
    
    return (data || []).map((item: any) => ({
      ...item,
      category: isValidCategory(item.category) ? item.category : 'M' as 'P' | 'M' | 'E' | 'S' | 'C'
    }));
  },

  async getActiveAnalysis(projectId: string, priceCode: string): Promise<PriceCodeAnalysisWithVersion[]> {
    const { data, error } = await supabase
      .rpc('get_active_rate_analysis', {
        p_project_id: projectId,
        p_price_code: priceCode
      });

    if (error) throw error;
    
    return (data || []).map((item: any) => ({
      ...item,
      category: isValidCategory(item.category) ? item.category : 'M' as 'P' | 'M' | 'E' | 'S' | 'C',
      status: isValidStatus(item.status) ? item.status : 'draft' as 'draft' | 'submitted' | 'approved'
    }));
  },

  async getDraftAnalysis(projectId: string, priceCode: string): Promise<PriceCodeAnalysisWithVersion[]> {
    const { data, error } = await supabase
      .rpc('get_draft_rate_analysis', {
        p_project_id: projectId,
        p_price_code: priceCode
      });

    if (error) throw error;
    
    return (data || []).map((item: any) => ({
      ...item,
      category: isValidCategory(item.category) ? item.category : 'M' as 'P' | 'M' | 'E' | 'S' | 'C',
      status: isValidStatus(item.status) ? item.status : 'draft' as 'draft' | 'submitted' | 'approved'
    }));
  },

  async getByVersion(versionId: string): Promise<PriceCodeAnalysisResource[]> {
    const { data, error } = await supabase
      .from('price_code_analysis')
      .select('*')
      .eq('version_id', versionId)
      .order('sort_order');

    if (error) throw error;
    
    return (data || []).map((item: any) => ({
      ...item,
      category: isValidCategory(item.category) ? item.category : 'M' as 'P' | 'M' | 'E' | 'S' | 'C'
    }));
  },

  async create(data: Omit<PriceCodeAnalysisResource, 'id' | 'created_at' | 'updated_at'>): Promise<PriceCodeAnalysisResource> {
    const { data: newResource, error } = await supabase
      .from('price_code_analysis')
      .insert({
        ...data,
        user_id: (await supabase.auth.getUser()).data.user?.id
      })
      .select()
      .single();

    if (error) throw error;
    
    return {
      ...newResource,
      category: isValidCategory(newResource.category) ? newResource.category : 'M' as 'P' | 'M' | 'E' | 'S' | 'C'
    };
  },

  async update(id: string, updates: Partial<PriceCodeAnalysisResource>): Promise<PriceCodeAnalysisResource> {
    const { data, error } = await supabase
      .from('price_code_analysis')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    
    return {
      ...data,
      category: isValidCategory(data.category) ? data.category : 'M' as 'P' | 'M' | 'E' | 'S' | 'C'
    };
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('price_code_analysis')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async deleteByVersion(versionId: string): Promise<void> {
    const { error } = await supabase
      .from('price_code_analysis')
      .delete()
      .eq('version_id', versionId);

    if (error) throw error;
  },

  async bulkCreate(resources: Omit<PriceCodeAnalysisResource, 'id' | 'created_at' | 'updated_at'>[]): Promise<PriceCodeAnalysisResource[]> {
    const userId = (await supabase.auth.getUser()).data.user?.id;
    const resourcesWithUserId = resources.map(resource => ({
      ...resource,
      user_id: userId
    }));

    const { data, error } = await supabase
      .from('price_code_analysis')
      .insert(resourcesWithUserId)
      .select();

    if (error) throw error;
    
    return (data || []).map((item: any) => ({
      ...item,
      category: isValidCategory(item.category) ? item.category : 'M' as 'P' | 'M' | 'E' | 'S' | 'C'
    }));
  }
};
