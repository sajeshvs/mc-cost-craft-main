
import { supabase } from '@/integrations/supabase/client';
import { EstimationHistory } from '@/types/estimation';

export const estimationHistoryService = {
  async getHistory(boqItemId: string): Promise<EstimationHistory[]> {
    const { data, error } = await supabase
      .from('estimation_history')
      .select('*')
      .eq('boq_item_id', boqItemId)
      .order('version_number', { ascending: false });
    
    if (error) throw error;
    if (!Array.isArray(data)) return [];
    
    return data as EstimationHistory[];
  },

  async createVersion(
    sheetId: string,
    boqItemId: string,
    totalRate: number,
    totalAmount: number,
    changeSummary: string,
    snapshotData?: any
  ): Promise<EstimationHistory> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    // Get the next version number
    const { data: existingVersions } = await supabase
      .from('estimation_history')
      .select('version_number')
      .eq('estimation_sheet_id', sheetId)
      .order('version_number', { ascending: false })
      .limit(1);

    const nextVersion = Array.isArray(existingVersions) && existingVersions.length > 0 
      ? (existingVersions[0] as any).version_number + 1 
      : 1;

    const { data, error } = await supabase
      .from('estimation_history')
      .insert({
        estimation_sheet_id: sheetId,
        boq_item_id: boqItemId,
        version_number: nextVersion,
        total_rate: totalRate,
        total_amount: totalAmount,
        change_summary: changeSummary,
        snapshot_data: snapshotData,
        user_id: user.id
      })
      .select()
      .single();
    
    if (error) throw error;
    if (!data || typeof data !== 'object') throw new Error('Invalid response data');
    
    return data as EstimationHistory;
  }
};
