export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      adjudication_entries: {
        Row: {
          base_rate: number
          created_at: string
          description: string
          id: string
          item_type: string
          package_id: string
          page_ref: string | null
          price_code: string | null
          quantity: number
          source_id: string
          trade_code: string | null
          unit: string
          user_id: string | null
        }
        Insert: {
          base_rate?: number
          created_at?: string
          description: string
          id?: string
          item_type: string
          package_id: string
          page_ref?: string | null
          price_code?: string | null
          quantity?: number
          source_id: string
          trade_code?: string | null
          unit: string
          user_id?: string | null
        }
        Update: {
          base_rate?: number
          created_at?: string
          description?: string
          id?: string
          item_type?: string
          package_id?: string
          page_ref?: string | null
          price_code?: string | null
          quantity?: number
          source_id?: string
          trade_code?: string | null
          unit?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "adjudication_entries_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "adjudication_packages"
            referencedColumns: ["id"]
          },
        ]
      }
      adjudication_packages: {
        Row: {
          created_at: string
          created_by: string
          id: string
          name: string
          project_id: string
          status: string
          trade_code: string | null
          type: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string
          id?: string
          name: string
          project_id: string
          status?: string
          trade_code?: string | null
          type: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          name?: string
          project_id?: string
          status?: string
          trade_code?: string | null
          type?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      adjudication_quotes: {
        Row: {
          amount: number
          applied_at: string | null
          created_at: string
          currency: string
          discount_percent: number
          entry_id: string
          exchange_rate: number
          factor: number
          final_rate: number
          id: string
          is_selected: boolean
          quoted_rate: number
          updated_at: string
          user_id: string | null
          vendor_name: string
        }
        Insert: {
          amount?: number
          applied_at?: string | null
          created_at?: string
          currency?: string
          discount_percent?: number
          entry_id: string
          exchange_rate?: number
          factor?: number
          final_rate?: number
          id?: string
          is_selected?: boolean
          quoted_rate?: number
          updated_at?: string
          user_id?: string | null
          vendor_name: string
        }
        Update: {
          amount?: number
          applied_at?: string | null
          created_at?: string
          currency?: string
          discount_percent?: number
          entry_id?: string
          exchange_rate?: number
          factor?: number
          final_rate?: number
          id?: string
          is_selected?: boolean
          quoted_rate?: number
          updated_at?: string
          user_id?: string | null
          vendor_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "adjudication_quotes_entry_id_fkey"
            columns: ["entry_id"]
            isOneToOne: false
            referencedRelation: "adjudication_entries"
            referencedColumns: ["id"]
          },
        ]
      }
      boq_items: {
        Row: {
          amount: number | null
          amount_consultant: number | null
          amount_equipment: number | null
          amount_labor: number | null
          amount_material: number | null
          amount_subcontractor: number | null
          created_at: string
          description: string
          id: string
          item_no: string
          job_id: string
          level_type: string | null
          net_rate: number | null
          page_number: number | null
          price_code: string | null
          quantity: number | null
          sort_order: number | null
          unit: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          amount?: number | null
          amount_consultant?: number | null
          amount_equipment?: number | null
          amount_labor?: number | null
          amount_material?: number | null
          amount_subcontractor?: number | null
          created_at?: string
          description: string
          id?: string
          item_no: string
          job_id: string
          level_type?: string | null
          net_rate?: number | null
          page_number?: number | null
          price_code?: string | null
          quantity?: number | null
          sort_order?: number | null
          unit: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          amount?: number | null
          amount_consultant?: number | null
          amount_equipment?: number | null
          amount_labor?: number | null
          amount_material?: number | null
          amount_subcontractor?: number | null
          created_at?: string
          description?: string
          id?: string
          item_no?: string
          job_id?: string
          level_type?: string | null
          net_rate?: number | null
          page_number?: number | null
          price_code?: string | null
          quantity?: number | null
          sort_order?: number | null
          unit?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "boq_items_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      companies: {
        Row: {
          base_currency: string
          code: string
          country: string
          created_at: string
          id: string
          logo_url: string | null
          name: string
          notes: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          base_currency: string
          code: string
          country: string
          created_at?: string
          id?: string
          logo_url?: string | null
          name: string
          notes?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          base_currency?: string
          code?: string
          country?: string
          created_at?: string
          id?: string
          logo_url?: string | null
          name?: string
          notes?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      estimation_attachments: {
        Row: {
          created_at: string
          estimation_resource_id: string | null
          estimation_sheet_id: string | null
          file_name: string
          file_size: number | null
          file_type: string | null
          id: string
          storage_path: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          estimation_resource_id?: string | null
          estimation_sheet_id?: string | null
          file_name: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          storage_path: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          estimation_resource_id?: string | null
          estimation_sheet_id?: string | null
          file_name?: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          storage_path?: string
          user_id?: string | null
        }
        Relationships: []
      }
      estimation_history: {
        Row: {
          boq_item_id: string
          change_summary: string | null
          created_at: string
          estimation_sheet_id: string
          id: string
          snapshot_data: Json | null
          total_amount: number
          total_rate: number
          user_id: string | null
          version_number: number
        }
        Insert: {
          boq_item_id: string
          change_summary?: string | null
          created_at?: string
          estimation_sheet_id: string
          id?: string
          snapshot_data?: Json | null
          total_amount: number
          total_rate: number
          user_id?: string | null
          version_number: number
        }
        Update: {
          boq_item_id?: string
          change_summary?: string | null
          created_at?: string
          estimation_sheet_id?: string
          id?: string
          snapshot_data?: Json | null
          total_amount?: number
          total_rate?: number
          user_id?: string | null
          version_number?: number
        }
        Relationships: []
      }
      estimation_resources: {
        Row: {
          boq_item_id: string
          coefficient: number
          comments: string | null
          created_at: string
          estimation_sheet_id: string
          id: string
          rate: number
          resource_name: string
          resource_type: string
          sort_order: number | null
          total: number
          unit: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          boq_item_id: string
          coefficient?: number
          comments?: string | null
          created_at?: string
          estimation_sheet_id: string
          id?: string
          rate?: number
          resource_name: string
          resource_type: string
          sort_order?: number | null
          total?: number
          unit: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          boq_item_id?: string
          coefficient?: number
          comments?: string | null
          created_at?: string
          estimation_sheet_id?: string
          id?: string
          rate?: number
          resource_name?: string
          resource_type?: string
          sort_order?: number | null
          total?: number
          unit?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      estimation_sheets: {
        Row: {
          boq_item_id: string
          created_at: string
          currency: string
          id: string
          notes: string | null
          total_amount: number
          total_rate: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          boq_item_id: string
          created_at?: string
          currency?: string
          id?: string
          notes?: string | null
          total_amount?: number
          total_rate?: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          boq_item_id?: string
          created_at?: string
          currency?: string
          id?: string
          notes?: string | null
          total_amount?: number
          total_rate?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      global_settings: {
        Row: {
          created_at: string
          id: string
          setting_key: string
          setting_value: Json
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          setting_key: string
          setting_value: Json
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          setting_key?: string
          setting_value?: Json
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      jobs: {
        Row: {
          client: string
          company_id: string
          created_at: string
          currency: string
          id: string
          logo_url: string | null
          name: string
          notes: string | null
          project_location: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          client: string
          company_id: string
          created_at?: string
          currency: string
          id?: string
          logo_url?: string | null
          name: string
          notes?: string | null
          project_location: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          client?: string
          company_id?: string
          created_at?: string
          currency?: string
          id?: string
          logo_url?: string | null
          name?: string
          notes?: string | null
          project_location?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "jobs_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      markup_items: {
        Row: {
          base_amount: number
          created_at: string
          id: string
          markup_percent: number
          markup_type: string
          markup_value: number
          project_id: string
          ref_description: string
          ref_id: string
          ref_type: string
          remarks: string | null
          total_with_markup: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          base_amount?: number
          created_at?: string
          id?: string
          markup_percent?: number
          markup_type: string
          markup_value?: number
          project_id: string
          ref_description: string
          ref_id: string
          ref_type: string
          remarks?: string | null
          total_with_markup?: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          base_amount?: number
          created_at?: string
          id?: string
          markup_percent?: number
          markup_type?: string
          markup_value?: number
          project_id?: string
          ref_description?: string
          ref_id?: string
          ref_type?: string
          remarks?: string | null
          total_with_markup?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      markup_lines: {
        Row: {
          base_rate: number
          contingencies_percent: number
          created_at: string
          escalation_percent: number
          final_total: number
          grand_total: number
          ho_ga_percent: number
          id: string
          profit_percent: number
          ref_description: string
          ref_id: string
          remarks: string | null
          site_overhead_percent: number
          tax_amount: number
          tax_percent: number
          total_markup_value: number
          updated_at: string
          user_id: string | null
          version_id: string
        }
        Insert: {
          base_rate?: number
          contingencies_percent?: number
          created_at?: string
          escalation_percent?: number
          final_total?: number
          grand_total?: number
          ho_ga_percent?: number
          id?: string
          profit_percent?: number
          ref_description: string
          ref_id: string
          remarks?: string | null
          site_overhead_percent?: number
          tax_amount?: number
          tax_percent?: number
          total_markup_value?: number
          updated_at?: string
          user_id?: string | null
          version_id: string
        }
        Update: {
          base_rate?: number
          contingencies_percent?: number
          created_at?: string
          escalation_percent?: number
          final_total?: number
          grand_total?: number
          ho_ga_percent?: number
          id?: string
          profit_percent?: number
          ref_description?: string
          ref_id?: string
          remarks?: string | null
          site_overhead_percent?: number
          tax_amount?: number
          tax_percent?: number
          total_markup_value?: number
          updated_at?: string
          user_id?: string | null
          version_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "markup_lines_version_id_fkey"
            columns: ["version_id"]
            isOneToOne: false
            referencedRelation: "markup_versions"
            referencedColumns: ["id"]
          },
        ]
      }
      markup_versions: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          created_at: string
          created_by: string
          id: string
          mode: Database["public"]["Enums"]["markup_mode"]
          project_id: string
          remarks: string | null
          status: Database["public"]["Enums"]["markup_status"]
          updated_at: string
          user_id: string | null
          version_number: number
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by?: string
          id?: string
          mode: Database["public"]["Enums"]["markup_mode"]
          project_id: string
          remarks?: string | null
          status?: Database["public"]["Enums"]["markup_status"]
          updated_at?: string
          user_id?: string | null
          version_number: number
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          created_by?: string
          id?: string
          mode?: Database["public"]["Enums"]["markup_mode"]
          project_id?: string
          remarks?: string | null
          status?: Database["public"]["Enums"]["markup_status"]
          updated_at?: string
          user_id?: string | null
          version_number?: number
        }
        Relationships: []
      }
      price_code_analysis: {
        Row: {
          category: string
          created_at: string
          id: string
          price_code: string
          project_id: string
          quantity: number
          resource_code: string
          resource_name: string
          sort_order: number | null
          total_amount: number
          unit: string
          unit_rate: number
          updated_at: string
          user_id: string | null
          version_id: string | null
          wastage_percent: number
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          price_code: string
          project_id: string
          quantity?: number
          resource_code: string
          resource_name: string
          sort_order?: number | null
          total_amount?: number
          unit: string
          unit_rate?: number
          updated_at?: string
          user_id?: string | null
          version_id?: string | null
          wastage_percent?: number
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          price_code?: string
          project_id?: string
          quantity?: number
          resource_code?: string
          resource_name?: string
          sort_order?: number | null
          total_amount?: number
          unit?: string
          unit_rate?: number
          updated_at?: string
          user_id?: string | null
          version_id?: string | null
          wastage_percent?: number
        }
        Relationships: [
          {
            foreignKeyName: "price_code_analysis_version_id_fkey"
            columns: ["version_id"]
            isOneToOne: false
            referencedRelation: "price_code_versions"
            referencedColumns: ["id"]
          },
        ]
      }
      price_code_versions: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          change_summary: string | null
          created_at: string
          created_by: string
          id: string
          price_code: string
          project_id: string
          status: string
          version_number: number
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          change_summary?: string | null
          created_at?: string
          created_by: string
          id?: string
          price_code: string
          project_id: string
          status?: string
          version_number?: number
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          change_summary?: string | null
          created_at?: string
          created_by?: string
          id?: string
          price_code?: string
          project_id?: string
          status?: string
          version_number?: number
        }
        Relationships: []
      }
      price_list: {
        Row: {
          boq_reference: Json | null
          created_at: string
          description: string
          division: string
          id: string
          price_code: string
          project_id: string
          sort_order: number | null
          split_consultant: number | null
          split_equipment: number | null
          split_labor: number | null
          split_material: number | null
          split_subcontractor: number | null
          trade_code: string | null
          unit: string
          unit_rate: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          boq_reference?: Json | null
          created_at?: string
          description: string
          division: string
          id?: string
          price_code: string
          project_id: string
          sort_order?: number | null
          split_consultant?: number | null
          split_equipment?: number | null
          split_labor?: number | null
          split_material?: number | null
          split_subcontractor?: number | null
          trade_code?: string | null
          unit?: string
          unit_rate?: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          boq_reference?: Json | null
          created_at?: string
          description?: string
          division?: string
          id?: string
          price_code?: string
          project_id?: string
          sort_order?: number | null
          split_consultant?: number | null
          split_equipment?: number | null
          split_labor?: number | null
          split_material?: number | null
          split_subcontractor?: number | null
          trade_code?: string | null
          unit?: string
          unit_rate?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      resource_library: {
        Row: {
          created_at: string
          default_productivity: number
          default_rate: number
          dod_reference: string | null
          id: string
          notes: string | null
          resource_code: string
          resource_name: string
          resource_type: string
          unit: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          default_productivity?: number
          default_rate?: number
          dod_reference?: string | null
          id?: string
          notes?: string | null
          resource_code: string
          resource_name: string
          resource_type: string
          unit: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          default_productivity?: number
          default_rate?: number
          dod_reference?: string | null
          id?: string
          notes?: string | null
          resource_code?: string
          resource_name?: string
          resource_type?: string
          unit?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      resources: {
        Row: {
          bid_rate: number | null
          category: string
          created_at: string
          division: string
          id: string
          offer_currency: string | null
          offer_rate: number | null
          project_id: string
          rate: number
          resource_code: string
          resource_name: string
          sort_order: number
          total_amount: number | null
          unit: string
          updated_at: string
          usage_amount: number | null
          usage_quantity: number | null
          used_amount: number | null
          used_quantity: number
          user_id: string | null
          wastage_amount: number | null
          wastage_percent: number
          wastage_quantity: number | null
        }
        Insert: {
          bid_rate?: number | null
          category: string
          created_at?: string
          division: string
          id?: string
          offer_currency?: string | null
          offer_rate?: number | null
          project_id: string
          rate?: number
          resource_code: string
          resource_name: string
          sort_order?: number
          total_amount?: number | null
          unit?: string
          updated_at?: string
          usage_amount?: number | null
          usage_quantity?: number | null
          used_amount?: number | null
          used_quantity?: number
          user_id?: string | null
          wastage_amount?: number | null
          wastage_percent?: number
          wastage_quantity?: number | null
        }
        Update: {
          bid_rate?: number | null
          category?: string
          created_at?: string
          division?: string
          id?: string
          offer_currency?: string | null
          offer_rate?: number | null
          project_id?: string
          rate?: number
          resource_code?: string
          resource_name?: string
          sort_order?: number
          total_amount?: number | null
          unit?: string
          updated_at?: string
          usage_amount?: number | null
          usage_quantity?: number | null
          used_amount?: number | null
          used_quantity?: number
          user_id?: string | null
          wastage_amount?: number | null
          wastage_percent?: number
          wastage_quantity?: number | null
        }
        Relationships: []
      }
      subcontractor_quotes: {
        Row: {
          base_rate: number
          boq_item_id: string
          created_at: string
          created_by: string
          description: string
          discount_percent: number
          factor: number
          final_rate: number
          id: string
          inserted_to_boq: boolean
          price_code: string | null
          project_id: string
          quantity: number
          quote_value: number
          quote_vendor: string
          selected: boolean
          trade_code: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          base_rate?: number
          boq_item_id: string
          created_at?: string
          created_by?: string
          description: string
          discount_percent?: number
          factor?: number
          final_rate?: number
          id?: string
          inserted_to_boq?: boolean
          price_code?: string | null
          project_id: string
          quantity?: number
          quote_value?: number
          quote_vendor: string
          selected?: boolean
          trade_code: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          base_rate?: number
          boq_item_id?: string
          created_at?: string
          created_by?: string
          description?: string
          discount_percent?: number
          factor?: number
          final_rate?: number
          id?: string
          inserted_to_boq?: boolean
          price_code?: string | null
          project_id?: string
          quantity?: number
          quote_value?: number
          quote_vendor?: string
          selected?: boolean
          trade_code?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      supplier_quotes: {
        Row: {
          created_at: string
          created_by: string
          discount_percent: number
          factor: number
          final_rate: number
          id: string
          inserted_to_resources: boolean
          project_id: string
          quote_value: number
          resource_id: string
          selected: boolean
          updated_at: string
          user_id: string | null
          vendor_name: string
        }
        Insert: {
          created_at?: string
          created_by?: string
          discount_percent?: number
          factor?: number
          final_rate?: number
          id?: string
          inserted_to_resources?: boolean
          project_id: string
          quote_value?: number
          resource_id: string
          selected?: boolean
          updated_at?: string
          user_id?: string | null
          vendor_name: string
        }
        Update: {
          created_at?: string
          created_by?: string
          discount_percent?: number
          factor?: number
          final_rate?: number
          id?: string
          inserted_to_resources?: boolean
          project_id?: string
          quote_value?: number
          resource_id?: string
          selected?: boolean
          updated_at?: string
          user_id?: string | null
          vendor_name?: string
        }
        Relationships: []
      }
      trades: {
        Row: {
          color_code: string | null
          created_at: string
          description: string
          division: string
          id: string
          project_id: string
          sort_order: number
          subtrade_letter: string
          trade_code: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          color_code?: string | null
          created_at?: string
          description: string
          division: string
          id?: string
          project_id: string
          sort_order?: number
          subtrade_letter: string
          trade_code: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          color_code?: string | null
          created_at?: string
          description?: string
          division?: string
          id?: string
          project_id?: string
          sort_order?: number
          subtrade_letter?: string
          trade_code?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_active_rate_analysis: {
        Args: { p_project_id: string; p_price_code: string }
        Returns: {
          id: string
          project_id: string
          price_code: string
          resource_code: string
          resource_name: string
          category: string
          unit: string
          quantity: number
          unit_rate: number
          wastage_percent: number
          total_amount: number
          sort_order: number
          version_id: string
          version_number: number
          status: string
          user_id: string
          created_at: string
          updated_at: string
        }[]
      }
      get_draft_rate_analysis: {
        Args: { p_project_id: string; p_price_code: string }
        Returns: {
          id: string
          project_id: string
          price_code: string
          resource_code: string
          resource_name: string
          category: string
          unit: string
          quantity: number
          unit_rate: number
          wastage_percent: number
          total_amount: number
          sort_order: number
          version_id: string
          version_number: number
          status: string
          user_id: string
          created_at: string
          updated_at: string
        }[]
      }
      get_price_code_analysis: {
        Args: { p_project_id: string; p_price_code: string }
        Returns: {
          id: string
          project_id: string
          price_code: string
          resource_code: string
          resource_name: string
          category: string
          unit: string
          quantity: number
          unit_rate: number
          wastage_percent: number
          total_amount: number
          sort_order: number
          user_id: string
          created_at: string
          updated_at: string
        }[]
      }
    }
    Enums: {
      markup_mode: "trade" | "item"
      markup_status: "draft" | "submitted" | "approved" | "archived"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      markup_mode: ["trade", "item"],
      markup_status: ["draft", "submitted", "approved", "archived"],
    },
  },
} as const
