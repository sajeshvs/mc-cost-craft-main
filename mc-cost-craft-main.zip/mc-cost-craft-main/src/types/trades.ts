
export interface Trade {
  id: string;
  project_id: string;
  division: string;
  subtrade_letter: string;
  trade_code: string;
  description: string;
  color_code?: string;
  sort_order: number;
  created_at: string;
  updated_at: string;
  user_id?: string;
}

export interface Division {
  code: string;
  name: string;
}

export const UFGS_DIVISIONS: Division[] = [
  { code: '01', name: 'General Requirements' },
  { code: '02', name: 'Existing Conditions' },
  { code: '03', name: 'Concrete' },
  { code: '04', name: 'Masonry' },
  { code: '05', name: 'Metals' },
  { code: '06', name: 'Wood, Plastics, and Composites' },
  { code: '07', name: 'Thermal and Moisture Protection' },
  { code: '08', name: 'Openings' },
  { code: '09', name: 'Finishes' },
  { code: '10', name: 'Specialties' },
  { code: '11', name: 'Equipment' },
  { code: '12', name: 'Furnishings' },
  { code: '13', name: 'Special Construction' },
  { code: '14', name: 'Conveying Equipment' },
  { code: '21', name: 'Fire Suppression' },
  { code: '22', name: 'Plumbing' },
  { code: '23', name: 'Heating, Ventilating, and Air Conditioning' },
  { code: '25', name: 'Integrated Automation' },
  { code: '26', name: 'Electrical' },
  { code: '27', name: 'Communications' },
  { code: '28', name: 'Electronic Safety and Security' },
  { code: '31', name: 'Earthwork' },
  { code: '32', name: 'Exterior Improvements' },
  { code: '33', name: 'Utilities' },
  { code: '34', name: 'Transportation' },
  { code: '35', name: 'Waterway and Marine Construction' },
  { code: '40', name: 'Process Integration' },
  { code: '41', name: 'Material Processing and Handling Equipment' },
  { code: '42', name: 'Process Heating, Cooling, and Drying Equipment' },
  { code: '43', name: 'Process Gas and Liquid Handling, Purification' },
  { code: '44', name: 'Pollution Control Equipment' },
  { code: '45', name: 'Industry-Specific Manufacturing Equipment' },
  { code: '46', name: 'Water and Wastewater Equipment' },
  { code: '47', name: 'Mass Transit' },
  { code: '48', name: 'Electrical Power Generation' }
];

// Default UFGS subtrades for each division
export const DEFAULT_UFGS_SUBTRADES: Record<string, { letter: string; description: string; color: string }[]> = {
  '01': [
    { letter: 'A', description: 'Project Management', color: '#FF6B6B' },
    { letter: 'B', description: 'Quality Control', color: '#4ECDC4' },
    { letter: 'C', description: 'Temporary Facilities', color: '#45B7D1' },
    { letter: 'D', description: 'Construction Aids', color: '#96CEB4' },
    { letter: 'E', description: 'Project Closeout', color: '#FFEAA7' }
  ],
  '02': [
    { letter: 'A', description: 'Site Assessment', color: '#DDA0DD' },
    { letter: 'B', description: 'Selective Demolition', color: '#F0E68C' },
    { letter: 'C', description: 'Site Preparation', color: '#FFB347' },
    { letter: 'D', description: 'Hazardous Material Abatement', color: '#FF69B4' }
  ],
  '03': [
    { letter: 'A', description: 'Cast-in-Place Concrete', color: '#708090' },
    { letter: 'B', description: 'Precast Concrete', color: '#87CEEB' },
    { letter: 'C', description: 'Concrete Reinforcement', color: '#B0C4DE' },
    { letter: 'D', description: 'Concrete Restoration', color: '#D3D3D3' },
    { letter: 'E', description: 'Concrete Finishing', color: '#A9A9A9' }
  ],
  '04': [
    { letter: 'A', description: 'Brick Masonry', color: '#CD853F' },
    { letter: 'B', description: 'Concrete Masonry', color: '#D2B48C' },
    { letter: 'C', description: 'Stone Masonry', color: '#F4A460' },
    { letter: 'D', description: 'Masonry Restoration', color: '#DEB887' }
  ],
  '05': [
    { letter: 'A', description: 'Structural Steel', color: '#2F4F4F' },
    { letter: 'B', description: 'Steel Joists', color: '#696969' },
    { letter: 'C', description: 'Metal Decking', color: '#778899' },
    { letter: 'D', description: 'Cold-Formed Metal Framing', color: '#708090' },
    { letter: 'E', description: 'Metal Fabrications', color: '#B0C4DE' }
  ],
  '06': [
    { letter: 'A', description: 'Rough Carpentry', color: '#8B4513' },
    { letter: 'B', description: 'Finish Carpentry', color: '#A0522D' },
    { letter: 'C', description: 'Architectural Woodwork', color: '#D2691E' },
    { letter: 'D', description: 'Plastic Fabrications', color: '#F4A460' }
  ],
  '07': [
    { letter: 'A', description: 'Waterproofing', color: '#4169E1' },
    { letter: 'B', description: 'Roofing', color: '#8B0000' },
    { letter: 'C', description: 'Insulation', color: '#FFB6C1' },
    { letter: 'D', description: 'Siding', color: '#90EE90' },
    { letter: 'E', description: 'Joint Sealers', color: '#87CEFA' }
  ],
  '08': [
    { letter: 'A', description: 'Doors and Frames', color: '#8B4513' },
    { letter: 'B', description: 'Windows', color: '#4682B4' },
    { letter: 'C', description: 'Skylights', color: '#87CEEB' },
    { letter: 'D', description: 'Hardware', color: '#C0C0C0' }
  ],
  '09': [
    { letter: 'A', description: 'Gypsum Board', color: '#F5F5DC' },
    { letter: 'B', description: 'Tile', color: '#DDA0DD' },
    { letter: 'C', description: 'Flooring', color: '#D2B48C' },
    { letter: 'D', description: 'Painting', color: '#FF6347' },
    { letter: 'E', description: 'Wall Coverings', color: '#F0E68C' }
  ],
  '10': [
    { letter: 'A', description: 'Visual Display Units', color: '#FF1493' },
    { letter: 'B', description: 'Compartments and Cubicles', color: '#00CED1' },
    { letter: 'C', description: 'Louvers and Vents', color: '#9370DB' },
    { letter: 'D', description: 'Service Wall Systems', color: '#3CB371' }
  ],
  '11': [
    { letter: 'A', description: 'Vehicle Service Equipment', color: '#FF4500' },
    { letter: 'B', description: 'Mercantile Equipment', color: '#32CD32' },
    { letter: 'C', description: 'Residential Equipment', color: '#FF69B4' },
    { letter: 'D', description: 'Laboratory Equipment', color: '#00BFFF' }
  ],
  '12': [
    { letter: 'A', description: 'Artwork', color: '#FF6347' },
    { letter: 'B', description: 'Furnishings', color: '#40E0D0' },
    { letter: 'C', description: 'Multiple Seating', color: '#EE82EE' },
    { letter: 'D', description: 'Interior Plants', color: '#90EE90' }
  ],
  '13': [
    { letter: 'A', description: 'Special Purpose Rooms', color: '#FF1493' },
    { letter: 'B', description: 'Integrated Construction', color: '#00CED1' },
    { letter: 'C', description: 'Special Structures', color: '#9370DB' },
    { letter: 'D', description: 'Measurement and Control', color: '#3CB371' }
  ],
  '14': [
    { letter: 'A', description: 'Dumbwaiters', color: '#B22222' },
    { letter: 'B', description: 'Elevators', color: '#4169E1' },
    { letter: 'C', description: 'Escalators', color: '#32CD32' },
    { letter: 'D', description: 'Moving Walkways', color: '#FFD700' }
  ],
  '21': [
    { letter: 'A', description: 'Fire Suppression Piping', color: '#DC143C' },
    { letter: 'B', description: 'Fire Pumps', color: '#B22222' },
    { letter: 'C', description: 'Sprinkler Systems', color: '#FF0000' },
    { letter: 'D', description: 'Standpipe Systems', color: '#8B0000' }
  ],
  '22': [
    { letter: 'A', description: 'Plumbing Piping', color: '#4682B4' },
    { letter: 'B', description: 'Plumbing Equipment', color: '#5F9EA0' },
    { letter: 'C', description: 'Plumbing Fixtures', color: '#B0E0E6' },
    { letter: 'D', description: 'Fuel Gas Piping', color: '#FFD700' }
  ],
  '23': [
    { letter: 'A', description: 'HVAC Piping', color: '#00CED1' },
    { letter: 'B', description: 'HVAC Equipment', color: '#20B2AA' },
    { letter: 'C', description: 'HVAC Air Distribution', color: '#48D1CC' },
    { letter: 'D', description: 'HVAC Controls', color: '#40E0D0' }
  ],
  '25': [
    { letter: 'A', description: 'Integrated Automation', color: '#FF6347' },
    { letter: 'B', description: 'Control Systems', color: '#32CD32' },
    { letter: 'C', description: 'Monitoring Systems', color: '#1E90FF' },
    { letter: 'D', description: 'Detection Systems', color: '#FF1493' }
  ],
  '26': [
    { letter: 'A', description: 'Electrical Service', color: '#FFD700' },
    { letter: 'B', description: 'Electrical Distribution', color: '#FFA500' },
    { letter: 'C', description: 'Electrical Systems', color: '#FF8C00' },
    { letter: 'D', description: 'Lighting', color: '#FFFF00' }
  ],
  '27': [
    { letter: 'A', description: 'Communications Systems', color: '#9370DB' },
    { letter: 'B', description: 'Electronic Safety', color: '#8A2BE2' },
    { letter: 'C', description: 'Electronic Security', color: '#9400D3' },
    { letter: 'D', description: 'Audio Video Systems', color: '#4B0082' }
  ],
  '28': [
    { letter: 'A', description: 'Electronic Access Control', color: '#FF6347' },
    { letter: 'B', description: 'Electronic Detection', color: '#32CD32' },
    { letter: 'C', description: 'Electronic Monitoring', color: '#1E90FF' },
    { letter: 'D', description: 'Electronic Identification', color: '#FF1493' }
  ],
  '31': [
    { letter: 'A', description: 'Site Clearing', color: '#8B4513' },
    { letter: 'B', description: 'Earth Moving', color: '#A0522D' },
    { letter: 'C', description: 'Earthwork Support', color: '#D2691E' },
    { letter: 'D', description: 'Site Improvements', color: '#F4A460' }
  ],
  '32': [
    { letter: 'A', description: 'Paving', color: '#2F4F4F' },
    { letter: 'B', description: 'Planting', color: '#228B22' },
    { letter: 'C', description: 'Irrigation', color: '#00CED1' },
    { letter: 'D', description: 'Fences and Gates', color: '#8B4513' }
  ],
  '33': [
    { letter: 'A', description: 'Water Utilities', color: '#4169E1' },
    { letter: 'B', description: 'Sanitary Sewer', color: '#8B4513' },
    { letter: 'C', description: 'Storm Drainage', color: '#708090' },
    { letter: 'D', description: 'Electrical Utilities', color: '#FFD700' }
  ],
  '34': [
    { letter: 'A', description: 'Rail Transportation', color: '#2F4F4F' },
    { letter: 'B', description: 'Guideways', color: '#696969' },
    { letter: 'C', description: 'Transportation Facilities', color: '#778899' },
    { letter: 'D', description: 'Toll Collection Systems', color: '#4682B4' }
  ],
  '35': [
    { letter: 'A', description: 'Waterway Construction', color: '#4682B4' },
    { letter: 'B', description: 'Marine Construction', color: '#5F9EA0' },
    { letter: 'C', description: 'Coastal Construction', color: '#B0E0E6' },
    { letter: 'D', description: 'Underwater Construction', color: '#87CEEB' }
  ],
  '40': [
    { letter: 'A', description: 'Process Integration', color: '#FF6347' },
    { letter: 'B', description: 'Process Control', color: '#32CD32' },
    { letter: 'C', description: 'Process Monitoring', color: '#1E90FF' },
    { letter: 'D', description: 'Process Safety', color: '#FF1493' }
  ],
  '41': [
    { letter: 'A', description: 'Material Processing', color: '#8B4513' },
    { letter: 'B', description: 'Material Handling', color: '#A0522D' },
    { letter: 'C', description: 'Bulk Material Equipment', color: '#D2691E' },
    { letter: 'D', description: 'Package Conveyors', color: '#F4A460' }
  ],
  '42': [
    { letter: 'A', description: 'Process Heating', color: '#FF4500' },
    { letter: 'B', description: 'Process Cooling', color: '#00CED1' },
    { letter: 'C', description: 'Process Drying', color: '#FFD700' },
    { letter: 'D', description: 'Process Gas Handling', color: '#9370DB' }
  ],
  '43': [
    { letter: 'A', description: 'Gas Handling', color: '#9370DB' },
    { letter: 'B', description: 'Liquid Handling', color: '#4169E1' },
    { letter: 'C', description: 'Gas Purification', color: '#32CD32' },
    { letter: 'D', description: 'Liquid Purification', color: '#00CED1' }
  ],
  '44': [
    { letter: 'A', description: 'Air Pollution Control', color: '#90EE90' },
    { letter: 'B', description: 'Water Pollution Control', color: '#87CEEB' },
    { letter: 'C', description: 'Solid Waste Control', color: '#D2B48C' },
    { letter: 'D', description: 'Noise Control', color: '#DDA0DD' }
  ],
  '45': [
    { letter: 'A', description: 'Manufacturing Equipment', color: '#FF6347' },
    { letter: 'B', description: 'Food Service Equipment', color: '#32CD32' },
    { letter: 'C', description: 'Textile Equipment', color: '#1E90FF' },
    { letter: 'D', description: 'Printing Equipment', color: '#FF1493' }
  ],
  '46': [
    { letter: 'A', description: 'Water Treatment', color: '#4169E1' },
    { letter: 'B', description: 'Wastewater Treatment', color: '#8B4513' },
    { letter: 'C', description: 'Water Distribution', color: '#87CEEB' },
    { letter: 'D', description: 'Wastewater Collection', color: '#708090' }
  ],
  '47': [
    { letter: 'A', description: 'Mass Transit', color: '#2F4F4F' },
    { letter: 'B', description: 'Transit Vehicles', color: '#696969' },
    { letter: 'C', description: 'Transit Facilities', color: '#778899' },
    { letter: 'D', description: 'Transit Control Systems', color: '#4682B4' }
  ],
  '48': [
    { letter: 'A', description: 'Electrical Power Generation', color: '#FFD700' },
    { letter: 'B', description: 'Solar Power Generation', color: '#FFA500' },
    { letter: 'C', description: 'Wind Power Generation', color: '#87CEEB' },
    { letter: 'D', description: 'Hydroelectric Generation', color: '#4169E1' }
  ]
};

export const SUBTRADE_LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

export interface TradeFormData {
  division: string;
  subtrade_letter: string;
  description: string;
  color_code?: string;
}
