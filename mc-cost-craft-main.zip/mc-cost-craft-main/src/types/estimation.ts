
export interface EstimationSheet {
  id: string;
  boq_item_id: string;
  total_rate: number;
  total_amount: number;
  currency: string;
  notes?: string;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export interface EstimationResource {
  id: string;
  estimation_sheet_id: string;
  boq_item_id: string;
  resource_type: 'Labor' | 'Material' | 'Equipment' | 'Subcontract' | 'Others';
  resource_name: string;
  unit: string;
  rate: number;
  coefficient: number;
  total: number;
  comments?: string | null;
  sort_order: number;
  user_id?: string | null;
  created_at: string;
  updated_at: string;
}

export interface ResourceLibrary {
  id: string;
  resource_code: string;
  resource_name: string;
  resource_type: 'Labor' | 'Material' | 'Equipment' | 'Subcontract' | 'Others';
  unit: string;
  default_rate: number;
  default_productivity: number;
  notes?: string;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export interface EstimationHistory {
  id: string;
  estimation_sheet_id: string;
  boq_item_id: string;
  version_number: number;
  total_rate: number;
  total_amount: number;
  change_summary?: string;
  snapshot_data?: any;
  user_id?: string;
  created_at: string;
}

export interface EstimationAttachment {
  id: string;
  estimation_sheet_id?: string;
  estimation_resource_id?: string;
  file_name: string;
  file_size?: number;
  file_type?: string;
  storage_path: string;
  user_id?: string;
  created_at: string;
}

export interface GlobalSettings {
  id: string;
  setting_key: string;
  setting_value: any;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export const RESOURCE_TYPES = [
  { value: 'Labor', label: 'Labor', color: 'bg-blue-50 text-blue-700' },
  { value: 'Material', label: 'Material', color: 'bg-green-50 text-green-700' },
  { value: 'Equipment', label: 'Equipment', color: 'bg-orange-50 text-orange-700' },
  { value: 'Subcontract', label: 'Subcontract', color: 'bg-purple-50 text-purple-700' },
  { value: 'Others', label: 'Others', color: 'bg-gray-50 text-gray-700' }
] as const;

export const CURRENCIES = [
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
  { code: 'CHF', symbol: 'CHF', name: 'Swiss Franc' },
  { code: 'CNY', symbol: '¥', name: 'Chinese Yuan' },
  { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
  { code: 'AED', symbol: 'د.إ', name: 'UAE Dirham' },
  { code: 'SAR', symbol: 'ر.س', name: 'Saudi Riyal' }
] as const;
