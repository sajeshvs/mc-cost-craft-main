
export interface TradeSummaryItem {
  code: string;
  description: string;
  totalQuantity: number;
  laborManhours: number;
  laborAmount: number;
  materialAmount: number;
  equipmentAmount: number;
  subcontractorAmount: number;
  consultantAmount: number;
  totalDirectCost: number;
  indirectCost: number;
  profit: number;
  totalFinalValue: number;
  percentOfProject: number;
  type: 'trade' | 'level';
  boqItems: string[]; // Array of BOQ item IDs
}

export interface LevelSummaryItem extends TradeSummaryItem {
  level: number;
  hasAdminRow: boolean;
  adminDescription?: string;
}

export interface TradeSummaryFilters {
  selectedTrades: string[];
  selectedLevels: number[];
  includeAdminRows: boolean;
  boqRefRange: { start?: string; end?: string };
  descriptionFilter: string;
  sortBy: 'code' | 'description' | 'totalCost' | 'boqRef';
  sortOrder: 'asc' | 'desc';
}

export interface TradeSummaryTotals {
  totalQuantity: number;
  totalLaborManhours: number;
  totalLaborAmount: number;
  totalMaterialAmount: number;
  totalEquipmentAmount: number;
  totalSubcontractorAmount: number;
  totalConsultantAmount: number;
  totalDirectCost: number;
  totalIndirectCost: number;
  totalProfit: number;
  grandTotal: number;
}

export type SummaryMode = 'trade' | 'level';
