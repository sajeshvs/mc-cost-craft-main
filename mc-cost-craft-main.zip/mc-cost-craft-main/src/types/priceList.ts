
export interface PriceListItem {
  id: string;
  project_id: string;
  division: string;
  trade_code?: string;
  price_code: string;
  description: string;
  unit: string;
  unit_rate: number;
  split_labor: number;
  split_material: number;
  split_equipment: number;
  split_subcontractor: number;
  split_consultant: number;
  boq_reference: string[];
  sort_order: number;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export interface PriceCodeAnalysisResource {
  id: string;
  project_id: string;
  price_code: string;
  resource_code: string;
  resource_name: string;
  category: 'P' | 'M' | 'E' | 'S' | 'C';
  unit: string;
  quantity: number;
  unit_rate: number;
  wastage_percent: number;
  total_amount: number;
  sort_order: number;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export const UFGS_DIVISIONS = {
  '01': 'General Requirements',
  '02': 'Existing Conditions',
  '03': 'Concrete',
  '04': 'Masonry',
  '05': 'Metals',
  '06': 'Wood, Plastics, and Composites',
  '07': 'Thermal and Moisture Protection',
  '08': 'Openings',
  '09': 'Finishes',
  '10': 'Specialties',
  '11': 'Equipment',
  '12': 'Furnishings',
  '13': 'Special Construction',
  '14': 'Conveying Equipment',
  '21': 'Fire Suppression',
  '22': 'Plumbing',
  '23': 'Heating Ventilating and Air Conditioning',
  '25': 'Integrated Automation',
  '26': 'Electrical',
  '27': 'Communications',
  '28': 'Electronic Safety and Security',
  '31': 'Earthwork',
  '32': 'Exterior Improvements',
  '33': 'Utilities',
  '34': 'Transportation',
  '35': 'Waterway and Marine Construction',
  '40': 'Process Integration',
  '41': 'Material Processing and Handling Equipment',
  '42': 'Process Heating, Cooling, and Drying Equipment',
  '43': 'Process Gas and Liquid Handling, Purification, and Storage Equipment',
  '44': 'Pollution Control Equipment',
  '45': 'Industry-Specific Manufacturing Equipment',
  '46': 'Water and Wastewater Equipment',
  '47': 'Electrical Power Generation',
  '48': 'Electrical Power Transmission'
} as const;

export type UFGSDivision = keyof typeof UFGS_DIVISIONS;
