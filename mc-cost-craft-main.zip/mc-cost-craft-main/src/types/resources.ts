
export interface Resource {
  id: string;
  project_id: string;
  resource_code: string;
  category: 'P' | 'M' | 'E' | 'S' | 'C';
  division: string;
  resource_name: string;
  unit: string;
  offer_rate: number;
  offer_currency: string;
  bid_rate: number;
  discount_percent: number;
  final_rate: number;
  usage_quantity: number;
  used_quantity: number;
  used_amount: number;
  wastage_percent: number;
  wastage_quantity?: number;
  wastage_amount: number;
  total_quantity?: number;
  total_amount: number;
  linked_price_codes: string[];
  sort_order: number;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export interface ResourceInsert {
  project_id: string;
  resource_code: string;
  category: 'P' | 'M' | 'E' | 'S' | 'C';
  division: string;
  resource_name: string;
  unit: string;
  offer_rate: number;
  offer_currency: string;
  bid_rate: number;
  discount_percent: number;
  usage_quantity: number;
  wastage_percent: number;
  linked_price_codes: string[];
  sort_order: number;
  user_id?: string;
}

export const RESOURCE_CATEGORIES = {
  P: 'People (Labor & Staff)',
  M: 'Materials',
  E: 'Equipment (Temporary Construction)',
  S: 'Subcontractors',
  C: 'Consultants (3rd Party)'
} as const;

export const UFGS_DIVISIONS = [
  { code: '01', name: 'General Requirements' },
  { code: '02', name: 'Existing Conditions' },
  { code: '03', name: 'Concrete' },
  { code: '04', name: 'Masonry' },
  { code: '05', name: 'Metals' },
  { code: '06', name: 'Wood, Plastics, and Composites' },
  { code: '07', name: 'Thermal and Moisture Protection' },
  { code: '08', name: 'Openings' },
  { code: '09', name: 'Finishes' },
  { code: '10', name: 'Specialties' },
  { code: '11', name: 'Equipment' },
  { code: '12', name: 'Furnishings' },
  { code: '13', name: 'Special Construction' },
  { code: '14', name: 'Conveying Equipment' },
  { code: '21', name: 'Fire Suppression' },
  { code: '22', name: 'Plumbing' },
  { code: '23', name: 'Heating, Ventilating, and Air Conditioning' },
  { code: '25', name: 'Integrated Automation' },
  { code: '26', name: 'Electrical' },
  { code: '27', name: 'Communications' },
  { code: '28', name: 'Electronic Safety and Security' },
  { code: '31', name: 'Earthwork' },
  { code: '32', name: 'Exterior Improvements' },
  { code: '33', name: 'Utilities' },
  { code: '34', name: 'Transportation' },
  { code: '35', name: 'Waterway and Marine Construction' },
  { code: '40', name: 'Process Integration' },
  { code: '41', name: 'Material Processing and Handling Equipment' },
  { code: '42', name: 'Process Heating, Cooling, and Drying Equipment' },
  { code: '43', name: 'Process Gas and Liquid Handling, Purification, and Storage Equipment' },
  { code: '44', name: 'Pollution Control Equipment' },
  { code: '45', name: 'Industry-Specific Manufacturing Equipment' },
  { code: '46', name: 'Water and Wastewater Equipment' },
  { code: '47', name: 'Operation and Maintenance of Process Equipment' },
  { code: '48', name: 'Electrical Power Generation' }
];

// Complete UFGS-compliant default resources by category and division
export const DEFAULT_RESOURCES = {
  P: {
    '01': [
      'Project Manager', 'Assistant Project Manager', 'Site Superintendent', 'Assistant Superintendent',
      'Safety Officer', 'Quality Control Inspector', 'Survey Crew Chief', 'Survey Rodman',
      'Administrative Assistant', 'Timekeeper', 'Security Guard', 'First Aid Attendant',
      'Environmental Compliance Officer', 'Materials Testing Technician', 'Construction Manager'
    ],
    '02': [
      'Demolition Supervisor', 'Demolition Worker', 'Hazmat Specialist', 'Asbestos Abatement Worker',
      'Lead Paint Abatement Worker', 'Site Assessment Technician', 'Environmental Monitor'
    ],
    '03': [
      'Concrete Superintendent', 'Concrete Finisher', 'Concrete Laborer', 'Rebar Worker',
      'Rebar Tier', 'Formwork Carpenter', 'Concrete Pump Operator', 'Concrete Mixer Operator',
      'Vibrator Operator', 'Concrete Tester', 'Precast Erector', 'Post-Tension Technician'
    ],
    '04': [
      'Masonry Superintendent', 'Mason', 'Bricklayer', 'Block Mason', 'Stone Mason',
      'Tile Setter', 'Terrazzo Worker', 'Mason Tender', 'Mortar Mixer'
    ],
    '05': [
      'Structural Steel Superintendent', 'Structural Welder', 'Certified Welder', 'Ironworker',
      'Steel Erector', 'Rigger', 'Crane Operator', 'Bolter-Up', 'Steel Detailer'
    ],
    '06': [
      'Carpentry Superintendent', 'Carpenter', 'Rough Carpenter', 'Finish Carpenter',
      'Cabinet Maker', 'Millwright', 'Trim Carpenter', 'Framing Carpenter'
    ],
    '07': [
      'Roofing Superintendent', 'Roofer', 'Sheet Metal Worker', 'Waterproofing Specialist',
      'Insulation Installer', 'Caulking Specialist', 'Membrane Installer'
    ],
    '08': [
      'Glazing Superintendent', 'Glazier', 'Window Installer', 'Door Installer',
      'Curtain Wall Installer', 'Storefront Installer', 'Hardware Installer'
    ],
    '09': [
      'Finishes Superintendent', 'Painter', 'Drywall Installer', 'Taper', 'Sander',
      'Flooring Installer', 'Carpet Installer', 'Tile Installer', 'Ceiling Installer'
    ],
    '22': [
      'Plumbing Superintendent', 'Master Plumber', 'Journeyman Plumber', 'Plumber',
      'Pipe Fitter', 'Plumbing Helper', 'Plumbing Apprentice'
    ],
    '23': [
      'HVAC Superintendent', 'HVAC Technician', 'Sheet Metal Worker', 'Duct Installer',
      'Equipment Installer', 'Controls Technician', 'HVAC Helper'
    ],
    '26': [
      'Electrical Superintendent', 'Master Electrician', 'Journeyman Electrician', 'Electrician',
      'Electrical Helper', 'Electrical Apprentice', 'Low Voltage Technician'
    ],
    '31': [
      'Earthwork Superintendent', 'Heavy Equipment Operator', 'Excavator Operator',
      'Bulldozer Operator', 'Grader Operator', 'Compactor Operator', 'Laborer'
    ]
  },
  M: {
    '01': [
      'Temporary Fencing', 'Construction Signs', 'Temporary Facilities', 'Construction Trailer',
      'Temporary Utilities', 'Site Security System', 'Construction Equipment',
      'Safety Equipment', 'Personal Protective Equipment', 'First Aid Supplies'
    ],
    '02': [
      'Demolition Materials', 'Hazardous Material Containers', 'Disposal Containers',
      'Protective Sheeting', 'Temporary Barriers'
    ],
    '03': [
      'Ready Mix Concrete 3000 PSI', 'Ready Mix Concrete 4000 PSI', 'Ready Mix Concrete 5000 PSI',
      'Reinforcing Steel #3', 'Reinforcing Steel #4', 'Reinforcing Steel #5', 'Reinforcing Steel #6',
      'Welded Wire Mesh', 'Concrete Admixtures', 'Concrete Curing Compound', 'Form Oil',
      'Expansion Joint Material', 'Concrete Anchor Bolts', 'Concrete Inserts',
      'Precast Concrete Panels', 'Prestressed Concrete', 'Post-Tension Cable'
    ],
    '04': [
      'Common Brick', 'Face Brick', 'Fire Brick', 'Concrete Masonry Units 8"',
      'Concrete Masonry Units 12"', 'Mortar Type N', 'Mortar Type S', 'Grout',
      'Masonry Reinforcement', 'Wall Ties', 'Flashing', 'Weep Holes',
      'Natural Stone', 'Manufactured Stone', 'Tile Units'
    ],
    '05': [
      'Structural Steel W-Shapes', 'Structural Steel Channels', 'Structural Steel Angles',
      'Steel Plates', 'Steel Decking', 'Steel Joists', 'Steel Purlins',
      'High Strength Bolts', 'Welding Electrodes', 'Steel Primer Paint',
      'Galvanizing', 'Fireproofing Material'
    ],
    '06': [
      'Dimensional Lumber 2x4', 'Dimensional Lumber 2x6', 'Dimensional Lumber 2x8',
      'Dimensional Lumber 2x10', 'Dimensional Lumber 2x12', 'Plywood Sheathing',
      'OSB Sheathing', 'Engineered Lumber', 'Laminated Veneer Lumber',
      'Wood Preservative', 'Wood Stain', 'Construction Adhesive', 'Nails', 'Screws'
    ],
    '07': [
      'Built-Up Roofing', 'Modified Bitumen', 'Single Ply Membrane', 'Metal Roofing',
      'Shingles', 'Roof Insulation', 'Vapor Barrier', 'Flashing', 'Gutters',
      'Downspouts', 'Sealants', 'Caulking', 'Waterproofing Membrane'
    ],
    '08': [
      'Aluminum Windows', 'Vinyl Windows', 'Steel Doors', 'Wood Doors',
      'Hollow Metal Doors', 'Glass', 'Glazing Compound', 'Window Hardware',
      'Door Hardware', 'Weatherstripping', 'Thresholds'
    ],
    '09': [
      'Drywall 1/2"', 'Drywall 5/8"', 'Metal Studs', 'Joint Compound',
      'Drywall Tape', 'Primer', 'Paint', 'Carpet', 'Vinyl Flooring',
      'Ceramic Tile', 'Hardwood Flooring', 'Ceiling Tile', 'Insulation'
    ],
    '22': [
      'Copper Pipe Type L', 'PVC Pipe', 'Cast Iron Pipe', 'Pipe Fittings',
      'Pipe Insulation', 'Water Heater', 'Fixtures', 'Valves', 'Pumps'
    ],
    '23': [
      'Ductwork', 'Duct Insulation', 'HVAC Equipment', 'Air Handling Units',
      'Fans', 'Dampers', 'Diffusers', 'Grilles', 'Refrigerant', 'Controls'
    ],
    '26': [
      'Electrical Wire THHN', 'Electrical Cable', 'Conduit EMT', 'Conduit PVC',
      'Electrical Panels', 'Circuit Breakers', 'Outlets', 'Switches',
      'Light Fixtures', 'Conduit Fittings'
    ],
    '31': [
      'Aggregate Base', 'Sand', 'Gravel', 'Topsoil', 'Seed', 'Fertilizer',
      'Geotextile Fabric', 'Drainage Pipe', 'Catch Basins', 'Manholes'
    ]
  },
  E: {
    '01': [
      'Tower Crane', 'Mobile Crane', 'Site Office Trailer', 'Storage Trailer',
      'Temporary Fencing', 'Generator', 'Compressor', 'Temporary Power Distribution',
      'Temporary Lighting', 'Construction Elevator'
    ],
    '02': [
      'Excavator', 'Bulldozer', 'Skid Steer', 'Dump Truck', 'Dumpster',
      'Demolition Equipment', 'Concrete Breaker'
    ],
    '03': [
      'Concrete Mixer', 'Concrete Pump', 'Concrete Vibrator', 'Power Trowel',
      'Concrete Saw', 'Rebar Cutter', 'Rebar Bender', 'Form Vibrator'
    ],
    '05': [
      'Welding Machine', 'Cutting Torch', 'Plasma Cutter', 'Grinder',
      'Hoist', 'Come-Along', 'Rigging Equipment'
    ],
    '06': [
      'Table Saw', 'Circular Saw', 'Nail Gun', 'Compressor', 'Router',
      'Planer', 'Jointer', 'Band Saw'
    ],
    '31': [
      'Excavator', 'Bulldozer', 'Motor Grader', 'Compactor', 'Roller',
      'Scraper', 'Loader', 'Backhoe'
    ]
  },
  S: {
    '02': [
      'Demolition Contractor', 'Hazmat Removal Contractor', 'Asbestos Abatement Contractor',
      'Lead Paint Removal Contractor', 'Site Survey Contractor'
    ],
    '03': [
      'Ready Mix Concrete Supplier', 'Precast Concrete Contractor', 'Post-Tension Contractor',
      'Concrete Testing Laboratory'
    ],
    '04': [
      'Masonry Contractor', 'Stone Work Contractor', 'Tile Contractor',
      'Terrazzo Contractor'
    ],
    '05': [
      'Structural Steel Contractor', 'Steel Erection Contractor', 'Welding Contractor',
      'Steel Fabricator'
    ],
    '07': [
      'Roofing Contractor', 'Waterproofing Contractor', 'Insulation Contractor',
      'Siding Contractor'
    ],
    '08': [
      'Window Contractor', 'Glazing Contractor', 'Curtain Wall Contractor',
      'Door Contractor'
    ],
    '09': [
      'Painting Contractor', 'Drywall Contractor', 'Flooring Contractor',
      'Ceiling Contractor'
    ],
    '22': [
      'Plumbing Contractor', 'Fire Protection Contractor', 'Medical Gas Contractor'
    ],
    '23': [
      'HVAC Contractor', 'Sheet Metal Contractor', 'Controls Contractor',
      'Energy Management Contractor'
    ],
    '26': [
      'Electrical Contractor', 'Low Voltage Contractor', 'Fire Alarm Contractor',
      'Security System Contractor'
    ],
    '31': [
      'Earthwork Contractor', 'Utilities Contractor', 'Landscaping Contractor',
      'Paving Contractor'
    ]
  },
  C: {
    '01': [
      'Construction Manager', 'Project Consultant', 'Scheduling Consultant',
      'Cost Consultant', 'Value Engineering Consultant'
    ],
    '02': [
      'Structural Engineer', 'Geotechnical Engineer', 'Environmental Consultant',
      'Survey Consultant'
    ],
    '03': [
      'Concrete Testing Laboratory', 'Materials Testing Laboratory', 'Structural Engineer'
    ],
    '05': [
      'Structural Engineer', 'Steel Detailer', 'Connection Designer'
    ],
    '07': [
      'Building Envelope Consultant', 'Energy Consultant', 'Roofing Consultant'
    ],
    '22': [
      'Plumbing Engineer', 'Fire Protection Engineer'
    ],
    '23': [
      'MEP Engineer', 'HVAC Engineer', 'Commissioning Agent', 'Energy Auditor'
    ],
    '26': [
      'Electrical Engineer', 'Lighting Designer', 'Power Systems Engineer'
    ]
  }
};
