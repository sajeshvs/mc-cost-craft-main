
export interface MarkupItem {
  id: string;
  project_id: string;
  ref_type: 'trade' | 'item';
  ref_id: string; // Trade code or BOQ item ID
  ref_description: string;
  base_amount: number;
  markup_type: 'Site Overhead' | 'H.O G&A' | 'Profit' | 'Contingencies' | 'Escalation' | 'Tax' | 'Other';
  markup_percent: number;
  markup_value: number;
  total_with_markup: number;
  remarks?: string;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export interface MarkupEntry {
  id: string;
  project_id: string;
  ref_type: 'trade' | 'item';
  ref_id: string;
  ref_description: string;
  base_amount: number;
  site_overhead_percent: number;
  ho_ga_percent: number;
  profit_percent: number;
  contingencies_percent: number;
  escalation_percent: number;
  tax_percent: number;
  custom_markups: { [key: string]: number };
  total_markup_value: number;
  grand_total: number;
  tax_amount: number;
  final_total: number;
  remarks?: string;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export interface MarkupConfig {
  id: string;
  project_id: string;
  label: string;
  type: 'default' | 'custom';
  order: number;
  default_percent: number;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export interface MarkupVersion {
  id: string;
  project_id: string;
  mode: 'trade' | 'item';
  status: 'draft' | 'submitted' | 'approved' | 'archived';
  created_by: string;
  created_at: string;
  approved_by?: string;
  approved_at?: string;
  remarks?: string;
  version_number: number;
  user_id?: string;
  updated_at: string;
}

export interface MarkupLine {
  id: string;
  version_id: string;
  ref_id: string;
  ref_description: string;
  base_rate: number;
  base_amount: number; // Add this field that was missing
  site_overhead_percent: number;
  ho_ga_percent: number;
  profit_percent: number;
  contingencies_percent: number;
  escalation_percent: number;
  tax_percent: number;
  total_markup_value: number;
  grand_total: number;
  tax_amount: number;
  final_total: number;
  remarks?: string;
  user_id?: string;
  created_at: string;
  updated_at: string;
}

export interface MarkupSummary {
  base_total: number;
  markup_total: number;
  grand_total: number;
  tax_total: number;
  final_total: number;
}

export interface TradeMarkupData {
  trade_code: string;
  division: string;
  description: string;
  base_amount: number;
  item_count: number;
}

export interface ItemMarkupData {
  item_id: string;
  item_no: string;
  description: string;
  base_amount: number;
  trade_code?: string;
  division?: string;
}

export const DEFAULT_MARKUP_TYPES = [
  { key: 'site_overhead', label: 'Site Overhead', type: 'default' as const, order: 1 },
  { key: 'ho_ga', label: 'H.O G&A', type: 'default' as const, order: 2 },
  { key: 'profit', label: 'Profit', type: 'default' as const, order: 3 },
  { key: 'contingencies', label: 'Contingencies', type: 'default' as const, order: 4 },
  { key: 'escalation', label: 'Escalation', type: 'default' as const, order: 5 },
  { key: 'tax', label: 'Tax', type: 'default' as const, order: 6 }
];

export const MARKUP_TYPES = [
  { value: 'Site Overhead', label: 'Site Overhead', color: 'bg-blue-50 text-blue-700' },
  { value: 'H.O G&A', label: 'H.O G&A', color: 'bg-cyan-50 text-cyan-700' },
  { value: 'Profit', label: 'Profit', color: 'bg-green-50 text-green-700' },
  { value: 'Contingencies', label: 'Contingencies', color: 'bg-red-50 text-red-700' },
  { value: 'Escalation', label: 'Escalation', color: 'bg-orange-50 text-orange-700' },
  { value: 'Tax', label: 'Tax', color: 'bg-yellow-50 text-yellow-700' },
  { value: 'Other', label: 'Other', color: 'bg-gray-50 text-gray-700' }
] as const;

export const WORKFLOW_STATUS_COLORS = {
  draft: 'bg-gray-100 text-gray-700',
  submitted: 'bg-blue-100 text-blue-700',
  approved: 'bg-green-100 text-green-700',
  archived: 'bg-orange-100 text-orange-700'
} as const;

export const WORKFLOW_STATUS_LABELS = {
  draft: 'Draft',
  submitted: 'Submitted',
  approved: 'Approved',
  archived: 'Archived'
} as const;

export type MarkupType = typeof MARKUP_TYPES[number]['value'];
export type MarkupMode = 'trade' | 'item';
export type MarkupStatus = 'draft' | 'submitted' | 'approved' | 'archived';
