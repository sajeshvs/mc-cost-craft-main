
import { useSupabaseMutation } from '@/hooks/useSupabaseQuery';
import { BOQItem } from '@/types/mccost';
import { boqItemsService } from '@/services/boqItems';
import { useToast } from '@/hooks/use-toast';

export function useBOQMutations(jobId: string | undefined, cancelEditing: () => void, clearSelection: () => void) {
  const { toast } = useToast();

  const updateMutation = useSupabaseMutation(
    ({ id, ...data }: { id: string } & Partial<BOQItem>) => boqItemsService.update(id, data),
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Item updated successfully' });
        cancelEditing();
      },
      invalidateKeys: [['boq_items', jobId]]
    }
  );

  const createMutation = useSupabaseMutation(
    (data: Omit<BOQItem, 'id' | 'created_at' | 'updated_at' | 'user_id'>) => boqItemsService.create(data),
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Row inserted successfully' });
      },
      invalidateKeys: [['boq_items', jobId]]
    }
  );

  const deleteMutation = useSupabaseMutation(
    boqItemsService.delete,
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Row(s) deleted successfully' });
        clearSelection();
      },
      invalidateKeys: [['boq_items', jobId]]
    }
  );

  const reorderMutation = useSupabaseMutation(
    boqItemsService.updateSortOrder,
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Items reordered successfully' });
      },
      invalidateKeys: [['boq_items', jobId]]
    }
  );

  return {
    updateMutation,
    createMutation,
    deleteMutation,
    reorderMutation
  };
}
