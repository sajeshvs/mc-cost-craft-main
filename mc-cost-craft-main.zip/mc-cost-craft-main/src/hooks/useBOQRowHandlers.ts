
import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { BOQItem } from '@/types/mccost';
import { useToast } from '@/hooks/use-toast';

interface UseBOQRowHandlersProps {
  jobId: string;
  filteredItems: BOQItem[];
  selectedRows: Set<string>;
  getSelectedItems: () => BOQItem[];
  createMutation: any;
  deleteMutation: any;
  reorderMutation: any;
}

export function useBOQRowHandlers({
  jobId,
  filteredItems,
  selectedRows,
  getSelectedItems,
  createMutation,
  deleteMutation,
  reorderMutation
}: UseBOQRowHandlersProps) {
  const navigate = useNavigate();
  const { toast } = useToast();

  const getNextSortOrder = useCallback((position: 'above' | 'below' | 'beginning' | 'end' | 'after'): number => {
    if (position === 'beginning') return 0;
    if (position === 'end') return filteredItems.length;
    
    if (selectedRows.size === 0) return filteredItems.length;
    
    const selectedIndices = Array.from(selectedRows)
      .map(id => filteredItems.findIndex(item => item.id === id))
      .filter(index => index !== -1)
      .sort((a, b) => a - b);
    
    if (position === 'above') {
      return selectedIndices[0];
    } else if (position === 'below' || position === 'after') {
      return selectedIndices[selectedIndices.length - 1] + 1;
    }
    
    return filteredItems.length;
  }, [filteredItems, selectedRows]);

  const handleInsertRow = useCallback((position: 'above' | 'below' | 'beginning' | 'end') => {
    const insertIndex = getNextSortOrder(position);
    const referenceItem = insertIndex > 0 && insertIndex <= filteredItems.length 
      ? filteredItems[insertIndex - 1] 
      : filteredItems[0];

    const newItem = {
      job_id: jobId,
      item_no: '',
      description: 'New Item',
      unit: 'No',
      quantity: 0,
      level_type: referenceItem?.level_type || 'item' as BOQItem['level_type'],
      page_number: referenceItem?.page_number || null,
      sort_order: insertIndex
    };
    
    // Reorder existing items to make space
    const itemsToReorder = filteredItems
      .filter((_, index) => index >= insertIndex)
      .map((item, index) => ({
        id: item.id,
        sort_order: insertIndex + index + 1
      }));

    if (itemsToReorder.length > 0) {
      reorderMutation.mutate(itemsToReorder);
    }
    
    createMutation.mutate(newItem);
  }, [jobId, filteredItems, createMutation, reorderMutation, getNextSortOrder]);

  const handleImportMore = useCallback((position: 'after' | 'before' | 'beginning' | 'end') => {
    // Convert position for import
    let insertPosition: 'above' | 'below' | 'beginning' | 'end';
    switch (position) {
      case 'before':
        insertPosition = 'above';
        break;
      case 'after':
        insertPosition = 'below';
        break;
      default:
        insertPosition = position;
    }
    
    // Store position in sessionStorage for the import page
    sessionStorage.setItem('boq-import-position', insertPosition);
    sessionStorage.setItem('boq-import-sort-order', getNextSortOrder(insertPosition).toString());
    navigate(`/mccost/jobs/${jobId}/import-boq`);
  }, [jobId, navigate, getNextSortOrder]);

  const handleDeleteSelected = useCallback(() => {
    if (selectedRows.size === 0) return;
    
    if (confirm(`Are you sure you want to delete ${selectedRows.size} row(s)?`)) {
      Array.from(selectedRows).forEach(id => {
        deleteMutation.mutate(id);
      });
    }
  }, [selectedRows, deleteMutation]);

  const handleDuplicateSelected = useCallback(() => {
    if (selectedRows.size === 0) return;

    const selectedItems = filteredItems.filter(item => selectedRows.has(item.id));
    const lastSelectedIndex = Math.max(...selectedItems.map(item => filteredItems.indexOf(item)));
    
    // Create duplicates for all selected items
    selectedItems.forEach((item, index) => {
      const duplicateItem = {
        job_id: jobId,
        item_no: `${item.item_no} (Copy)`,
        description: item.description,
        unit: item.unit,
        quantity: item.quantity,
        level_type: item.level_type,
        page_number: item.page_number,
        sort_order: lastSelectedIndex + index + 1
      };

      createMutation.mutate(duplicateItem);
    });

    // Reorder existing items after the last selected item
    const itemsToReorder = filteredItems
      .filter((_, i) => i > lastSelectedIndex)
      .map((item, i) => ({
        id: item.id,
        sort_order: lastSelectedIndex + selectedItems.length + i + 1
      }));

    if (itemsToReorder.length > 0) {
      reorderMutation.mutate(itemsToReorder);
    }

    toast({
      title: 'Success',
      description: `${selectedItems.length} row(s) duplicated successfully`
    });
  }, [jobId, filteredItems, selectedRows, createMutation, reorderMutation, toast]);

  const handleDuplicateItem = useCallback((item: BOQItem, index: number) => {
    const duplicateItem = {
      job_id: jobId,
      item_no: `${item.item_no} (Copy)`,
      description: item.description,
      unit: item.unit,
      quantity: item.quantity,
      level_type: item.level_type,
      page_number: item.page_number,
      sort_order: index + 1
    };

    // Reorder existing items to make space
    const itemsToReorder = filteredItems
      .filter((_, i) => i > index)
      .map((item, i) => ({
        id: item.id,
        sort_order: index + i + 2
      }));

    if (itemsToReorder.length > 0) {
      reorderMutation.mutate(itemsToReorder);
    }

    createMutation.mutate(duplicateItem);
  }, [jobId, filteredItems, createMutation, reorderMutation]);

  return {
    handleInsertRow,
    handleImportMore,
    handleDeleteSelected,
    handleDuplicateSelected,
    handleDuplicateItem
  };
}
