
import { useState, useCallback } from 'react';

export interface ColumnWidths {
  [key: string]: number;
}

const defaultColumnWidths: ColumnWidths = {
  select: 50,
  price_code: 120,
  description: 200,
  trade_code: 80,
  resource_code: 120,
  color_code: 80,
  unit: 80,
  quantity: 100,
  unit_rate: 100,
  wastage: 100,
  rate: 100,
  total: 100
};

export function useColumnResize() {
  const [columnWidths, setColumnWidths] = useState<ColumnWidths>(defaultColumnWidths);
  const [isResizing, setIsResizing] = useState(false);

  const handleMouseDown = useCallback((columnKey: string, e: React.MouseEvent) => {
    e.preventDefault();
    setIsResizing(true);
    
    const startX = e.clientX;
    const startWidth = columnWidths[columnKey] || defaultColumnWidths[columnKey] || 100;

    const handleMouseMove = (e: MouseEvent) => {
      const diff = e.clientX - startX;
      const newWidth = Math.max(50, startWidth + diff);
      setColumnWidths(prev => ({
        ...prev,
        [columnKey]: newWidth
      }));
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  }, [columnWidths]);

  const handleDoubleClick = useCallback((columnKey: string) => {
    setColumnWidths(prev => ({
      ...prev,
      [columnKey]: defaultColumnWidths[columnKey] || 100
    }));
  }, []);

  return {
    columnWidths,
    isResizing,
    handleMouseDown,
    handleDoubleClick
  };
}
