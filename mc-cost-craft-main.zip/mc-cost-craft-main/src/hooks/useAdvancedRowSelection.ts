
import { useState, useCallback } from 'react';
import { BOQItem } from '@/types/mccost';

export function useAdvancedRowSelection(items: BOQItem[]) {
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [lastSelectedIndex, setLastSelectedIndex] = useState<number | null>(null);

  const toggleRowSelection = useCallback((rowId: string, isShiftClick = false, isCtrlClick = false) => {
    const currentIndex = items.findIndex(item => item.id === rowId);
    
    setSelectedRows(prev => {
      const newSet = new Set(prev);
      
      if (isShiftClick && lastSelectedIndex !== null) {
        // Shift+Click: Select range
        const startIndex = Math.min(currentIndex, lastSelectedIndex);
        const endIndex = Math.max(currentIndex, lastSelectedIndex);
        
        // Add range to selection (don't clear existing)
        for (let i = startIndex; i <= endIndex; i++) {
          if (items[i]) {
            newSet.add(items[i].id);
          }
        }
      } else if (isCtrlClick) {
        // Ctrl+Click: Toggle individual item
        if (newSet.has(rowId)) {
          newSet.delete(rowId);
        } else {
          newSet.add(rowId);
        }
      } else {
        // Normal click: Replace selection
        newSet.clear();
        newSet.add(rowId);
      }
      
      return newSet;
    });

    setLastSelectedIndex(currentIndex);
  }, [items, lastSelectedIndex]);

  const selectAllRows = useCallback(() => {
    setSelectedRows(new Set(items.map(item => item.id)));
    setLastSelectedIndex(null);
  }, [items]);

  const clearSelection = useCallback(() => {
    setSelectedRows(new Set());
    setLastSelectedIndex(null);
  }, []);

  const selectRange = useCallback((startIndex: number, endIndex: number) => {
    const start = Math.min(startIndex, endIndex);
    const end = Math.max(startIndex, endIndex);
    
    const rangeIds = new Set<string>();
    for (let i = start; i <= end && i < items.length; i++) {
      rangeIds.add(items[i].id);
    }
    
    setSelectedRows(rangeIds);
  }, [items]);

  const getSelectedItems = useCallback(() => {
    return items.filter(item => selectedRows.has(item.id));
  }, [items, selectedRows]);

  return {
    selectedRows,
    toggleRowSelection,
    selectAllRows,
    clearSelection,
    selectRange,
    lastSelectedIndex,
    getSelectedItems
  };
}
