import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { markupService } from '@/services/markup';
import { useToast } from '@/hooks/use-toast';
import { MarkupItem, MarkupEntry, MarkupConfig, MarkupSummary, TradeMarkupData, ItemMarkupData } from '@/types/markup';

export function useMarkupItems(projectId: string) {
  return useQuery({
    queryKey: ['markup-items', projectId],
    queryFn: () => markupService.getMarkupItems(projectId),
    enabled: !!projectId
  });
}

export function useMarkupEntries(projectId: string) {
  return useQuery({
    queryKey: ['markup-entries', projectId],
    queryFn: () => markupService.getMarkupEntries(projectId),
    enabled: !!projectId
  });
}

export function useMarkupConfigs(projectId: string) {
  return useQuery({
    queryKey: ['markup-configs', projectId],
    queryFn: () => markupService.getMarkupConfigs(projectId),
    enabled: !!projectId
  });
}

export function useTradeMarkupData(projectId: string) {
  return useQuery({
    queryKey: ['trade-markup-data', projectId],
    queryFn: () => markupService.getTradeMarkupData(projectId),
    enabled: !!projectId
  });
}

export function useItemMarkupData(projectId: string) {
  return useQuery({
    queryKey: ['item-markup-data', projectId],
    queryFn: () => markupService.getItemMarkupData(projectId),
    enabled: !!projectId
  });
}

export function useCreateMarkupEntry(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (entryData: Omit<MarkupEntry, 'id' | 'created_at' | 'updated_at'>) =>
      markupService.createMarkupEntry(entryData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['markup-entries', projectId] });
      toast({
        title: 'Success',
        description: 'Markup entry created successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create markup entry',
        variant: 'destructive'
      });
    }
  });
}

export function useUpdateMarkupEntry(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<MarkupEntry> }) =>
      markupService.updateMarkupEntry(id, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['markup-entries', projectId] });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update markup entry',
        variant: 'destructive'
      });
    }
  });
}

export function useCreateMarkupConfig(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (configData: Omit<MarkupConfig, 'id' | 'created_at' | 'updated_at'>) =>
      markupService.createMarkupConfig(configData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['markup-configs', projectId] });
      toast({
        title: 'Success',
        description: 'Custom markup column created successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create custom markup column',
        variant: 'destructive'
      });
    }
  });
}

export function useCreateMarkupItem(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (markupData: Omit<MarkupItem, 'id' | 'created_at' | 'updated_at'>) =>
      markupService.createMarkupItem(markupData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['markup-items', projectId] });
      toast({
        title: 'Success',
        description: 'Markup item created successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create markup item',
        variant: 'destructive'
      });
    }
  });
}

export function useUpdateMarkupItem(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<MarkupItem> }) =>
      markupService.updateMarkupItem(id, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['markup-items', projectId] });
      toast({
        title: 'Success',
        description: 'Markup item updated successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update markup item',
        variant: 'destructive'
      });
    }
  });
}

export function useDeleteMarkupItem(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (id: string) => markupService.deleteMarkupItem(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['markup-items', projectId] });
      toast({
        title: 'Success',
        description: 'Markup item deleted successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete markup item',
        variant: 'destructive'
      });
    }
  });
}

export function useMarkupSummary(markupItems: MarkupItem[]): MarkupSummary {
  const summary = markupItems.reduce((acc, item) => {
    acc.base_total += item.base_amount;
    acc.markup_total += item.markup_value;
    acc.grand_total += item.total_with_markup;

    return acc;
  }, {
    base_total: 0,
    markup_total: 0,
    grand_total: 0,
    tax_total: 0,
    final_total: 0
  });

  return summary;
}

export function useExportMarkupToExcel(projectId: string) {
  const { toast } = useToast();

  return useMutation({
    mutationFn: (mode: 'trade' | 'item') => markupService.exportMarkupToExcel(projectId, mode),
    onSuccess: () => {
      toast({
        title: 'Export Complete',
        description: 'Markup data exported to Excel successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Export Failed',
        description: error.message || 'Failed to export markup data',
        variant: 'destructive'
      });
    }
  });
}
