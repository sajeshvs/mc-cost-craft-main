
import { useState, useMemo } from 'react';
import { BOQItem } from '@/types/mccost';

export function useBOQVisibility() {
  const [hiddenLevels, setHiddenLevels] = useState<Set<string>>(new Set());

  const onToggleVisibility = (level: string) => {
    const newHiddenLevels = new Set(hiddenLevels);
    if (newHiddenLevels.has(level)) {
      newHiddenLevels.delete(level);
    } else {
      newHiddenLevels.add(level);
    }
    setHiddenLevels(newHiddenLevels);
  };

  const getVisibleItems = (items: BOQItem[]) => {
    return items.filter(item => {
      if (item.level_type && hiddenLevels.has(item.level_type)) {
        return false;
      }
      return true;
    });
  };

  return {
    hiddenLevels,
    onToggleVisibility,
    getVisibleItems
  };
}
