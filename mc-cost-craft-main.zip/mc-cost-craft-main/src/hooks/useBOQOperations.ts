
import { useCallback } from 'react';
import { BOQItem } from '@/types/mccost';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export function useBOQOperations(jobId: string) {
  const { toast } = useToast();

  const onAddRow = useCallback(() => {
    console.log('Add row clicked');
  }, []);

  const onDeleteSelected = useCallback(() => {
    console.log('Delete selected clicked');
  }, []);

  const onCopySelected = useCallback(() => {
    console.log('Copy selected clicked');
  }, []);

  const onUpdateItem = useCallback(async (id: string, updates: Partial<BOQItem>) => {
    try {
      const { error } = await supabase
        .from('boq_items')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Item updated successfully'
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to update item: ' + error.message,
        variant: 'destructive'
      });
    }
  }, [toast]);

  const onInsertRows = useCallback((afterId: string | null, count: number, type?: string) => {
    console.log('Insert rows:', { afterId, count, type });
  }, []);

  const onMoveRows = useCallback((rowIds: string[], targetId: string | null, position: 'before' | 'after') => {
    console.log('Move rows:', { rowIds, targetId, position });
  }, []);

  const onImportExcel = useCallback(() => {
    console.log('Import Excel clicked');
  }, []);

  const onExportExcel = useCallback(() => {
    console.log('Export Excel clicked');
  }, []);

  return {
    onAddRow,
    onDeleteSelected,
    onCopySelected,
    onUpdateItem,
    onInsertRows,
    onMoveRows,
    onImportExcel,
    onExportExcel
  };
}
