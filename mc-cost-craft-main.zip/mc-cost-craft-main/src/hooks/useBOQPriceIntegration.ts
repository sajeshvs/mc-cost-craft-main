
import { useState, useCallback } from 'react';
import { BOQItem } from '@/types/mccost';
import { useToast } from '@/hooks/use-toast';

export function useBOQPriceIntegration() {
  const [calculatingTotals, setCalculatingTotals] = useState(false);
  const { toast } = useToast();

  const calculateItemAmount = useCallback((item: BOQItem): number => {
    const quantity = item.quantity || 0;
    const netRate = item.net_rate || 0;
    return quantity * netRate;
  }, []);

  const calculateSplitAmounts = useCallback((item: BOQItem) => {
    const quantity = item.quantity || 0;
    
    return {
      amount_labor: quantity * (item.amount_labor || 0),
      amount_material: quantity * (item.amount_material || 0),
      amount_equipment: quantity * (item.amount_equipment || 0),
      amount_subcontractor: quantity * (item.amount_subcontractor || 0),
      amount_consultant: quantity * (item.amount_consultant || 0)
    };
  }, []);

  const recalculateItemTotals = useCallback((items: BOQItem[]): BOQItem[] => {
    return items.map(item => {
      const amount = calculateItemAmount(item);
      const splitAmounts = calculateSplitAmounts(item);
      
      return {
        ...item,
        amount,
        ...splitAmounts
      };
    });
  }, [calculateItemAmount, calculateSplitAmounts]);

  const calculateProjectTotals = useCallback((items: BOQItem[]) => {
    const totals = {
      totalAmount: 0,
      totalLabor: 0,
      totalMaterial: 0,
      totalEquipment: 0,
      totalSubcontractor: 0,
      totalConsultant: 0,
      itemCount: items.length
    };

    items.forEach(item => {
      if (item.level_type === 'item') {
        totals.totalAmount += item.amount || 0;
        totals.totalLabor += item.amount_labor || 0;
        totals.totalMaterial += item.amount_material || 0;
        totals.totalEquipment += item.amount_equipment || 0;
        totals.totalSubcontractor += item.amount_subcontractor || 0;
        totals.totalConsultant += item.amount_consultant || 0;
      }
    });

    return totals;
  }, []);

  const handlePriceCodeUpdate = useCallback(async (
    itemId: string,
    updates: {
      price_code?: string;
      net_rate?: number;
      amount_labor?: number;
      amount_material?: number;
      amount_equipment?: number;
      amount_subcontractor?: number;
      amount_consultant?: number;
    },
    onUpdate: (id: string, data: Partial<BOQItem>) => void
  ) => {
    try {
      onUpdate(itemId, updates);
      
      toast({
        title: 'Price Code Updated',
        description: 'BOQ item pricing has been updated successfully'
      });
    } catch (error) {
      console.error('Error updating price code:', error);
      toast({
        title: 'Error',
        description: 'Failed to update price code',
        variant: 'destructive'
      });
    }
  }, [toast]);

  const bulkCalculateTotals = useCallback(async (
    items: BOQItem[],
    onBulkUpdate: (updates: Array<{ id: string; data: Partial<BOQItem> }>) => void
  ) => {
    try {
      setCalculatingTotals(true);
      
      const updates = items.map(item => ({
        id: item.id,
        data: {
          amount: calculateItemAmount(item),
          ...calculateSplitAmounts(item)
        }
      }));

      onBulkUpdate(updates);
      
      toast({
        title: 'Totals Calculated',
        description: `Updated ${updates.length} BOQ items`
      });
    } catch (error) {
      console.error('Error calculating totals:', error);
      toast({
        title: 'Error',
        description: 'Failed to calculate totals',
        variant: 'destructive'
      });
    } finally {
      setCalculatingTotals(false);
    }
  }, [calculateItemAmount, calculateSplitAmounts, toast]);

  return {
    calculatingTotals,
    calculateItemAmount,
    calculateSplitAmounts,
    recalculateItemTotals,
    calculateProjectTotals,
    handlePriceCodeUpdate,
    bulkCalculateTotals
  };
}
