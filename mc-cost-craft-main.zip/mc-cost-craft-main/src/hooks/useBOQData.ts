
import { useState, useEffect } from 'react';
import { BOQItem } from '@/types/mccost';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export function useBOQData(jobId: string | undefined) {
  const { toast } = useToast();
  const [boqItems, setBOQItems] = useState<BOQItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Helper function to validate and cast level_type
  const castBOQItem = (item: any): BOQItem => {
    const validLevelTypes = ['item', 'level_1', 'level_2', 'level_3', 'level_4', 'level_5', 'level_6', 'level_7', 'level_8', 'level_9', 'comment'];
    const levelType = validLevelTypes.includes(item.level_type) ? item.level_type : 'item';
    
    return {
      ...item,
      level_type: levelType as BOQItem['level_type']
    };
  };

  // Load BOQ items
  useEffect(() => {
    if (!jobId) return;

    const loadBOQItems = async () => {
      try {
        setIsLoading(true);
        console.log('Loading BOQ items for job:', jobId);
        
        const { data, error } = await supabase
          .from('boq_items')
          .select('*')
          .eq('job_id', jobId)
          .order('sort_order');

        if (error) throw error;
        
        console.log('Loaded BOQ items:', data?.length || 0);
        
        // Cast the data to proper BOQItem type
        const typedItems = (data || []).map(castBOQItem);
        setBOQItems(typedItems);
        
      } catch (error: any) {
        console.error('Error loading BOQ items:', error);
        toast({
          title: 'Error',
          description: 'Failed to load BOQ items: ' + error.message,
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadBOQItems();
  }, [jobId, toast]);

  return {
    boqItems,
    setBOQItems,
    isLoading,
    castBOQItem
  };
}
