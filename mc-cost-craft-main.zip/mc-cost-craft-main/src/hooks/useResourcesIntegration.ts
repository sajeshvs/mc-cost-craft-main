
import { useCallback } from 'react';
import { resourcesService } from '@/services/resources';
import { useToast } from '@/hooks/use-toast';

export function useResourcesIntegration(projectId: string) {
  const { toast } = useToast();

  const updateResourcesFromPriceAnalysis = useCallback(async (
    priceCode: string,
    analysisResources: Array<{
      resourceCode: string;
      quantity: number;
      category: string;
    }>
  ) => {
    try {
      await resourcesService.updateResourceUsage(projectId, priceCode, analysisResources);
      
      toast({
        title: 'Resources Updated',
        description: `Updated ${analysisResources.length} resources from price code ${priceCode}`
      });
    } catch (error: any) {
      console.error('Error updating resources from price analysis:', error);
      toast({
        title: 'Error',
        description: 'Failed to update resources: ' + error.message,
        variant: 'destructive'
      });
    }
  }, [projectId, toast]);

  const updateResourcesFromBOQ = useCallback(async (
    boqQuantityChanges: Array<{
      priceCode: string;
      quantityMultiplier: number;
    }>
  ) => {
    try {
      // This would update all resources linked to the changed BOQ items
      // Implementation would depend on the specific BOQ-Resource linking logic
      console.log('Updating resources from BOQ changes:', boqQuantityChanges);
      
      toast({
        title: 'Resources Updated',
        description: 'Resource quantities updated based on BOQ changes'
      });
    } catch (error: any) {
      console.error('Error updating resources from BOQ:', error);
      toast({
        title: 'Error',
        description: 'Failed to update resources from BOQ: ' + error.message,
        variant: 'destructive'
      });
    }
  }, [toast]);

  return {
    updateResourcesFromPriceAnalysis,
    updateResourcesFromBOQ
  };
}
