
import { useCallback } from 'react';
import { BOQItem } from '@/types/mccost';
import { DropResult } from '@hello-pangea/dnd';

interface UseBOQDragHandlersProps {
  filteredItems: BOQItem[];
  reorderMutation: any;
}

export function useBOQDragHandlers({
  filteredItems,
  reorderMutation
}: UseBOQDragHandlersProps) {
  const handleDragEnd = useCallback((result: DropResult) => {
    if (!result.destination) return;

    const items = Array.from(filteredItems);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    const updateData = items.map((item, index) => ({
      id: item.id,
      sort_order: index
    }));

    reorderMutation.mutate(updateData);
  }, [filteredItems, reorderMutation]);

  return {
    handleDragEnd
  };
}
