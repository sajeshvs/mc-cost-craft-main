
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { markupService } from '@/services/markup';
import { useToast } from '@/hooks/use-toast';
import { MarkupVersion, MarkupLine, MarkupMode, MarkupStatus } from '@/types/markup';

export function useMarkupVersions(projectId: string, mode: MarkupMode) {
  return useQuery({
    queryKey: ['markup-versions', projectId, mode],
    queryFn: () => markupService.getMarkupVersions(projectId, mode),
    enabled: !!projectId
  });
}

export function useCurrentMarkupVersion(projectId: string, mode: MarkupMode) {
  return useQuery({
    queryKey: ['markup-current-version', projectId, mode],
    queryFn: () => markupService.getCurrentVersion(projectId, mode),
    enabled: !!projectId
  });
}

export function useApprovedMarkupVersion(projectId: string, mode: MarkupMode) {
  return useQuery({
    queryKey: ['markup-approved-version', projectId, mode],
    queryFn: () => markupService.getApprovedVersion(projectId, mode),
    enabled: !!projectId
  });
}

export function useMarkupLines(versionId: string) {
  return useQuery({
    queryKey: ['markup-lines', versionId],
    queryFn: () => markupService.getMarkupLines(versionId),
    enabled: !!versionId
  });
}

export function useCreateMarkupVersion(projectId: string, mode: MarkupMode) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (remarks?: string) => markupService.createVersion(projectId, mode, remarks),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['markup-versions', projectId, mode] });
      queryClient.invalidateQueries({ queryKey: ['markup-current-version', projectId, mode] });
      toast({
        title: 'Version Created',
        description: 'New markup version created successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create version',
        variant: 'destructive'
      });
    }
  });
}

export function useUpdateVersionStatus(projectId: string, mode: MarkupMode) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: ({ versionId, status, remarks }: { 
      versionId: string; 
      status: MarkupStatus; 
      remarks?: string; 
    }) => markupService.updateVersionStatus(versionId, status as 'submitted' | 'approved' | 'archived', remarks),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['markup-versions', projectId, mode] });
      queryClient.invalidateQueries({ queryKey: ['markup-current-version', projectId, mode] });
      queryClient.invalidateQueries({ queryKey: ['markup-approved-version', projectId, mode] });
      
      const statusMap = {
        submitted: 'submitted for review',
        approved: 'approved',
        archived: 'archived'
      };
      
      toast({
        title: 'Status Updated',
        description: `Version ${data.version_number} has been ${statusMap[data.status as keyof typeof statusMap]}`
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update version status',
        variant: 'destructive'
      });
    }
  });
}

export function useSaveMarkupLines(versionId: string, projectId: string, mode: MarkupMode) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (lines: Omit<MarkupLine, 'id' | 'version_id' | 'created_at' | 'updated_at'>[]) =>
      markupService.saveMarkupLines(versionId, lines),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['markup-lines', versionId] });
      toast({
        title: 'Saved',
        description: 'Markup data saved successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to save markup data',
        variant: 'destructive'
      });
    }
  });
}

export function useUpdateMarkupLine(versionId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ lineId, updates }: { lineId: string; updates: Partial<MarkupLine> }) =>
      markupService.updateMarkupLine(lineId, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['markup-lines', versionId] });
    }
  });
}
