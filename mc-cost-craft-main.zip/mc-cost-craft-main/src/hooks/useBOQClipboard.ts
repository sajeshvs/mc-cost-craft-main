
import { useState, useCallback } from 'react';
import { BOQItem, ClipboardData } from '@/types/mccost';
import { useToast } from '@/hooks/use-toast';

export function useBOQClipboard() {
  const [clipboardData, setClipboardData] = useState<ClipboardData | null>(null);
  const { toast } = useToast();

  const copyItems = useCallback((items: BOQItem[]) => {
    const data: ClipboardData = {
      items: items.map(item => ({ ...item })), // Deep copy
      timestamp: Date.now()
    };
    setClipboardData(data);
    toast({
      title: 'Copied',
      description: `${items.length} row(s) copied to clipboard`
    });
  }, [toast]);

  const canPaste = useCallback(() => {
    return clipboardData !== null && clipboardData.items.length > 0;
  }, [clipboardData]);

  const getPasteData = useCallback(() => {
    return clipboardData?.items || [];
  }, [clipboardData]);

  return {
    copyItems,
    canPaste,
    getPasteData
  };
}
