
import { useSupabaseMutation } from '@/hooks/useSupabaseQuery';
import { EstimationSheet, EstimationResource } from '@/types/estimation';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { estimationHistoryService } from '@/services/estimationHistory';

export function useEstimationMutations(boqItemId: string) {
  const { toast } = useToast();

  const createSheetMutation = useSupabaseMutation(
    async (data: Omit<EstimationSheet, 'id' | 'created_at' | 'updated_at'>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data: result, error } = await supabase
        .from('estimation_sheets')
        .insert({ ...data, user_id: user.id })
        .select()
        .single();
      
      if (error) throw error;
      if (!result || typeof result !== 'object') throw new Error('Invalid response data');
      
      return result as EstimationSheet;
    },
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Estimation sheet created successfully' });
      },
      invalidateKeys: [['estimation_sheets', boqItemId]]
    }
  );

  const createResourceMutation = useSupabaseMutation(
    async (data: Omit<EstimationResource, 'id' | 'created_at' | 'updated_at'>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // First, ensure estimation sheet exists
      const { data: sheet, error: sheetQueryError } = await supabase
        .from('estimation_sheets')
        .select('id')
        .eq('boq_item_id', data.boq_item_id)
        .single();

      let sheetId: string | undefined;

      if (!sheetQueryError && sheet && typeof sheet === 'object' && 'id' in sheet) {
        sheetId = sheet.id as string;
      } else {
        const { data: newSheet, error: sheetError } = await supabase
          .from('estimation_sheets')
          .insert({
            boq_item_id: data.boq_item_id,
            total_rate: 0,
            total_amount: 0,
            currency: 'USD',
            user_id: user.id
          })
          .select()
          .single();
        
        if (sheetError) throw sheetError;
        if (newSheet && typeof newSheet === 'object' && 'id' in newSheet) {
          sheetId = newSheet.id as string;
        }
      }

      const { data: result, error } = await supabase
        .from('estimation_resources')
        .insert({ 
          ...data, 
          estimation_sheet_id: sheetId,
          user_id: user.id 
        })
        .select()
        .single();
      
      if (error) throw error;
      if (!result || typeof result !== 'object') throw new Error('Invalid response data');

      // Update sheet totals and create history
      if (sheetId) {
        const newTotals = await updateSheetTotals(sheetId);
        await createHistoryEntry(sheetId, data.boq_item_id, newTotals, 'Added new resource');
      }
      
      return result as EstimationResource;
    },
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Resource added successfully' });
      },
      invalidateKeys: [['estimation_sheets', boqItemId], ['estimation_resources', boqItemId], ['estimation_history', boqItemId]]
    }
  );

  const updateResourceMutation = useSupabaseMutation(
    async ({ id, ...data }: { id: string } & Partial<EstimationResource>) => {
      const { data: result, error } = await supabase
        .from('estimation_resources')
        .update({ ...data, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      if (!result || typeof result !== 'object') throw new Error('Invalid response data');

      // Update sheet totals and create history
      const estimationSheetId = (result as any)?.estimation_sheet_id;
      if (estimationSheetId) {
        const newTotals = await updateSheetTotals(estimationSheetId);
        await createHistoryEntry(estimationSheetId, boqItemId, newTotals, 'Updated resource');
      }
      
      return result as EstimationResource;
    },
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Resource updated successfully' });
      },
      invalidateKeys: [['estimation_sheets', boqItemId], ['estimation_resources', boqItemId], ['estimation_history', boqItemId]]
    }
  );

  const deleteResourceMutation = useSupabaseMutation(
    async (id: string) => {
      // Get the sheet ID before deleting
      const { data: resource, error: resourceError } = await supabase
        .from('estimation_resources')
        .select('estimation_sheet_id')
        .eq('id', id)
        .single();

      const { error } = await supabase
        .from('estimation_resources')
        .delete()
        .eq('id', id);
      
      if (error) throw error;

      // Update sheet totals and create history if resource was found
      const estimationSheetId = !resourceError && resource && typeof resource === 'object' && 'estimation_sheet_id' in resource
        ? resource.estimation_sheet_id as string
        : null;
        
      if (estimationSheetId) {
        const newTotals = await updateSheetTotals(estimationSheetId);
        await createHistoryEntry(estimationSheetId, boqItemId, newTotals, 'Deleted resource');
      }
    },
    {
      onSuccess: () => {
        toast({ title: 'Success', description: 'Resource deleted successfully' });
      },
      invalidateKeys: [['estimation_sheets', boqItemId], ['estimation_resources', boqItemId], ['estimation_history', boqItemId]]
    }
  );

  return {
    createSheetMutation,
    createResourceMutation,
    updateResourceMutation,
    deleteResourceMutation
  };
}

async function updateSheetTotals(sheetId: string): Promise<{ totalRate: number; totalAmount: number }> {
  // Calculate total from all resources
  const { data: resources } = await supabase
    .from('estimation_resources')
    .select('total')
    .eq('estimation_sheet_id', sheetId);

  const totalRate = Array.isArray(resources) 
    ? resources.reduce((sum: number, r: any) => sum + (r.total || 0), 0) 
    : 0;

  // Get BOQ item quantity for total amount calculation
  const { data: sheet, error: sheetError } = await supabase
    .from('estimation_sheets')
    .select('boq_item_id')
    .eq('id', sheetId)
    .single();

  const boqItemId = !sheetError && sheet && typeof sheet === 'object' && 'boq_item_id' in sheet 
    ? sheet.boq_item_id as string 
    : null;
  let totalAmount = 0;

  if (boqItemId) {
    const { data: boqItem } = await supabase
      .from('boq_items')
      .select('quantity')
      .eq('id', boqItemId)
      .single();

    const quantity = boqItem && typeof boqItem === 'object' && 'quantity' in boqItem 
      ? (boqItem.quantity as number) || 0 
      : 0;
    totalAmount = totalRate * quantity;

    await supabase
      .from('estimation_sheets')
      .update({ 
        total_rate: totalRate,
        total_amount: totalAmount,
        updated_at: new Date().toISOString()
      })
      .eq('id', sheetId);
  }

  return { totalRate, totalAmount };
}

async function createHistoryEntry(
  sheetId: string, 
  boqItemId: string, 
  totals: { totalRate: number; totalAmount: number },
  changeSummary: string
) {
  try {
    // Get current resources for snapshot
    const { data: resources } = await supabase
      .from('estimation_resources')
      .select('*')
      .eq('estimation_sheet_id', sheetId);

    await estimationHistoryService.createVersion(
      sheetId,
      boqItemId,
      totals.totalRate,
      totals.totalAmount,
      changeSummary,
      { resources: Array.isArray(resources) ? resources : [] }
    );
  } catch (error) {
    console.error('Failed to create history entry:', error);
  }
}
