
import { useBOQCellHandlers } from './useBOQCellHandlers';
import { useBOQRowHandlers } from './useBOQRowHandlers';
import { useBOQDragHandlers } from './useBOQDragHandlers';
import { useBOQClipboardHandlers } from './useBOQClipboardHandlers';
import { useBOQCalculationHandlers } from './useBOQCalculationHandlers';
import { BOQItem } from '@/types/mccost';

interface UseBOQHandlersProps {
  jobId: string;
  filteredItems: BOQItem[];
  selectedRows: Set<string>;
  getSelectedItems: () => BOQItem[];
  updateMutation: any;
  createMutation: any;
  deleteMutation: any;
  reorderMutation: any;
}

export function useBOQHandlers({
  jobId,
  filteredItems,
  selectedRows,
  getSelectedItems,
  updateMutation,
  createMutation,
  deleteMutation,
  reorderMutation
}: UseBOQHandlersProps) {
  const cellHandlers = useBOQCellHandlers({
    filteredItems,
    updateMutation
  });

  const rowHandlers = useBOQRowHandlers({
    jobId,
    filteredItems,
    selectedRows,
    getSelectedItems,
    createMutation,
    deleteMutation,
    reorderMutation
  });

  const dragHandlers = useBOQDragHandlers({
    filteredItems,
    reorderMutation
  });

  const clipboardHandlers = useBOQClipboardHandlers({
    jobId,
    filteredItems,
    getSelectedItems,
    createMutation,
    reorderMutation
  });

  const calculationHandlers = useBOQCalculationHandlers({
    filteredItems,
    getSelectedItems,
    updateMutation
  });

  return {
    // Cell handlers
    handleCellSave: cellHandlers.handleCellSave,
    
    // Row handlers
    handleInsertRow: rowHandlers.handleInsertRow,
    handleImportMore: rowHandlers.handleImportMore,
    handleDeleteSelected: rowHandlers.handleDeleteSelected,
    handleDuplicateSelected: rowHandlers.handleDuplicateSelected,
    handleDuplicateItem: rowHandlers.handleDuplicateItem,
    
    // Drag handlers
    handleDragEnd: dragHandlers.handleDragEnd,
    
    // Clipboard handlers
    handleCopy: clipboardHandlers.handleCopy,
    handlePaste: clipboardHandlers.handlePaste,
    canPaste: clipboardHandlers.canPaste,
    
    // Calculation handlers
    handleCalculateTotals: calculationHandlers.handleCalculateTotals,
    handleClear: calculationHandlers.handleClear,
    handleSetQuantity: calculationHandlers.handleSetQuantity,
    handleMultiplyQuantity: calculationHandlers.handleMultiplyQuantity,
    handleShowSum: calculationHandlers.handleShowSum,
    handleEnterText: calculationHandlers.handleEnterText
  };
}
