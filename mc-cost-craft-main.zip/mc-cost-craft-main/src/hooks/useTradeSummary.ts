
import { useState, useEffect, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { TradeSummaryService } from '@/services/tradeSummary';
import { TradeSummaryItem, LevelSummaryItem, TradeSummaryFilters, TradeSummaryTotals, SummaryMode } from '@/types/tradeSummary';
import { useBOQData } from '@/hooks/useBOQData';
import { useTrades } from '@/hooks/useTrades';
import { priceListService } from '@/services/priceList';
import { priceCodeAnalysisService } from '@/services/priceCodeAnalysis';
import { markupService } from '@/services/markup';
import { useToast } from '@/hooks/use-toast';

export function useTradeSummary(projectId: string, jobId: string) {
  const { toast } = useToast();
  const [mode, setMode] = useState<SummaryMode>('trade');
  const [filters, setFilters] = useState<TradeSummaryFilters>({
    selectedTrades: [],
    selectedLevels: [1, 2, 3],
    includeAdminRows: false,
    boqRefRange: {},
    descriptionFilter: '',
    sortBy: 'code',
    sortOrder: 'asc'
  });

  // Load required data
  const { boqItems, isLoading: boqLoading } = useBOQData(jobId);
  const { data: trades = [], isLoading: tradesLoading } = useTrades(projectId);
  
  const { data: priceList = [], isLoading: priceListLoading } = useQuery({
    queryKey: ['price-list', projectId],
    queryFn: () => priceListService.getByProject(projectId),
    enabled: !!projectId
  });

  const { data: analysisResources = [], isLoading: analysisLoading } = useQuery({
    queryKey: ['all-price-analysis', projectId],
    queryFn: async () => {
      if (!priceList.length) return [];
      
      const priceCodes = [...new Set(priceList.map(p => p.price_code))];
      const allResources = [];
      
      for (const priceCode of priceCodes) {
        try {
          const resources = await priceCodeAnalysisService.getByPriceCode(projectId, priceCode);
          allResources.push(...resources);
        } catch (error) {
          console.warn(`Failed to load analysis for price code ${priceCode}:`, error);
        }
      }
      
      return allResources;
    },
    enabled: !!projectId && priceList.length > 0
  });

  const { data: markupLines = [], isLoading: markupLoading } = useQuery({
    queryKey: ['markup-lines', projectId, mode],
    queryFn: async () => {
      try {
        const markupMode = mode === 'level' ? 'trade' : mode;
        const versions = await markupService.getMarkupVersions(projectId, markupMode);
        if (versions.length === 0) return [];
        
        const latestVersion = versions[versions.length - 1];
        return await markupService.getMarkupLines(latestVersion.id);
      } catch (error) {
        console.warn('Failed to load markup data:', error);
        return [];
      }
    },
    enabled: !!projectId
  });

  const isLoading = boqLoading || tradesLoading || priceListLoading || analysisLoading || markupLoading;

  // Calculate summaries
  const summaries = useMemo(() => {
    if (isLoading || boqItems.length === 0) return [];

    try {
      if (mode === 'trade') {
        return TradeSummaryService.calculateTradeSummary(
          boqItems,
          trades,
          priceList,
          analysisResources,
          markupLines,
          filters.selectedTrades
        );
      } else {
        return TradeSummaryService.calculateLevelSummary(
          boqItems,
          priceList,
          analysisResources,
          markupLines,
          filters.selectedLevels,
          filters.includeAdminRows
        );
      }
    } catch (error) {
      console.error('Error calculating summaries:', error);
      toast({
        title: 'Calculation Error',
        description: 'Failed to calculate trade summaries',
        variant: 'destructive'
      });
      return [];
    }
  }, [boqItems, trades, priceList, analysisResources, markupLines, mode, filters, isLoading, toast]);

  // Calculate totals and update percentages
  const { summariesWithPercentages, totals } = useMemo(() => {
    const calculatedTotals = TradeSummaryService.calculateTotals(summaries);
    const updatedSummaries = TradeSummaryService.updatePercentages(summaries, calculatedTotals);
    
    return {
      summariesWithPercentages: updatedSummaries,
      totals: calculatedTotals
    };
  }, [summaries]);

  // Filter and sort summaries
  const filteredSummaries = useMemo(() => {
    let filtered = [...summariesWithPercentages];

    // Apply description filter
    if (filters.descriptionFilter) {
      const searchTerm = filters.descriptionFilter.toLowerCase();
      filtered = filtered.filter(item => 
        item.description.toLowerCase().includes(searchTerm) ||
        item.code.toLowerCase().includes(searchTerm)
      );
    }

    // Apply BOQ reference range filter
    if (filters.boqRefRange.start || filters.boqRefRange.end) {
      filtered = filtered.filter(item => {
        const itemCode = item.code.toLowerCase();
        const start = filters.boqRefRange.start?.toLowerCase() || '';
        const end = filters.boqRefRange.end?.toLowerCase() || '';
        
        if (start && end) {
          return itemCode >= start && itemCode <= end;
        } else if (start) {
          return itemCode >= start;
        } else if (end) {
          return itemCode <= end;
        }
        return true;
      });
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let aValue: any, bValue: any;
      
      switch (filters.sortBy) {
        case 'description':
          aValue = a.description;
          bValue = b.description;
          break;
        case 'totalCost':
          aValue = a.totalFinalValue;
          bValue = b.totalFinalValue;
          break;
        case 'boqRef':
          aValue = a.code;
          bValue = b.code;
          break;
        default:
          aValue = a.code;
          bValue = b.code;
      }
      
      const comparison = typeof aValue === 'string' ? aValue.localeCompare(bValue) : aValue - bValue;
      return filters.sortOrder === 'asc' ? comparison : -comparison;
    });

    return filtered;
  }, [summariesWithPercentages, filters]);

  // Initialize selected trades with all available trades
  useEffect(() => {
    if (mode === 'trade' && trades.length > 0 && filters.selectedTrades.length === 0) {
      setFilters(prev => ({
        ...prev,
        selectedTrades: trades.slice(0, 5).map(trade => trade.trade_code)
      }));
    }
  }, [mode, trades, filters.selectedTrades.length]);

  const updateFilters = (updates: Partial<TradeSummaryFilters>) => {
    setFilters(prev => ({ ...prev, ...updates }));
  };

  const exportToExcel = async () => {
    try {
      toast({
        title: 'Export Started',
        description: 'Trade summary export is being prepared...'
      });
      // TODO: Implement Excel export functionality
    } catch (error) {
      toast({
        title: 'Export Failed',
        description: 'Failed to export trade summary',
        variant: 'destructive'
      });
    }
  };

  return {
    mode,
    setMode,
    filters,
    updateFilters,
    summaries: filteredSummaries,
    totals,
    trades,
    isLoading,
    exportToExcel
  };
}
