import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export function useSupabaseQuery<T = any>(
  key: string[],
  queryFn: () => Promise<T>,
  options?: { enabled?: boolean }
) {
  return useQuery({
    queryKey: key,
    queryFn,
    enabled: options?.enabled
  });
}

export function useSupabaseMutation<T>(
  mutationFn: (data: any) => Promise<T>,
  options?: {
    onSuccess?: (data: T) => void;
    invalidateKeys?: string[][];
  }
) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn,
    onSuccess: (data) => {
      if (options?.onSuccess) {
        options.onSuccess(data);
      }
      if (options?.invalidateKeys) {
        options.invalidateKeys.forEach(key => {
          queryClient.invalidateQueries({ queryKey: key });
        });
      }
    },
    onError: (error: any) => {
      console.error('Mutation error:', error);
      toast({
        title: 'Error',
        description: error.message || 'An error occurred',
        variant: 'destructive'
      });
    }
  });
}