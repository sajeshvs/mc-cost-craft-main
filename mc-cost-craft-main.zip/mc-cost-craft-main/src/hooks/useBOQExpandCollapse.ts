
import { useState, useCallback } from 'react';
import { BOQItem } from '@/types/mccost';

export function useBOQExpandCollapse(items: BOQItem[]) {
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set());

  const expandAll = useCallback(() => {
    const allSectionIds = items
      .filter(item => item.level_type && item.level_type.startsWith('level_'))
      .map(item => item.id);
    setExpandedSections(new Set(allSectionIds));
  }, [items]);

  const collapseAll = useCallback(() => {
    setExpandedSections(new Set());
  }, []);

  const toggleSection = useCallback((sectionId: string) => {
    setExpandedSections(prev => {
      const newSet = new Set(prev);
      if (newSet.has(sectionId)) {
        newSet.delete(sectionId);
      } else {
        newSet.add(sectionId);
      }
      return newSet;
    });
  }, []);

  const getVisibleItems = useCallback(() => {
    const visibleItems: BOQItem[] = [];
    const levelStack: { level: number; expanded: boolean }[] = [];

    for (const item of items) {
      const levelType = item.level_type || 'item';
      
      // Handle level items (level_1, level_2, etc.)
      if (levelType.startsWith('level_')) {
        const currentLevel = parseInt(levelType.replace('level_', '')) || 1;
        
        // Remove levels that are at or below the current level
        while (levelStack.length > 0 && levelStack[levelStack.length - 1].level >= currentLevel) {
          levelStack.pop();
        }
        
        // Check if we should show this item (all parent levels must be expanded)
        const shouldShow = levelStack.length === 0 || levelStack.every(level => level.expanded);
        
        if (shouldShow) {
          visibleItems.push(item);
        }
        
        // Add this level to the stack
        const isExpanded = expandedSections.has(item.id);
        levelStack.push({ level: currentLevel, expanded: isExpanded });
        
      } else {
        // Regular items - show if all parent levels are expanded
        const shouldShow = levelStack.length === 0 || levelStack.every(level => level.expanded);
        
        if (shouldShow) {
          visibleItems.push(item);
        }
      }
    }

    return visibleItems;
  }, [items, expandedSections]);

  return {
    expandedSections,
    expandAll,
    collapseAll,
    toggleSection,
    getVisibleItems
  };
}
