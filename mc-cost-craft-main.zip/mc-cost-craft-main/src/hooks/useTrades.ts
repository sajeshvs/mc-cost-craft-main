
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { tradesService } from '@/services/trades';
import { useToast } from '@/hooks/use-toast';
import { TradeFormData } from '@/types/trades';

export function useTrades(projectId: string) {
  return useQuery({
    queryKey: ['trades', projectId],
    queryFn: async () => {
      console.log('Fetching trades for project:', projectId);
      const result = await tradesService.getByProject(projectId);
      console.log('Trades fetched:', result.length, 'trades');
      
      // Filter out any trades with empty or invalid trade codes
      const validTrades = result.filter(trade => 
        trade && 
        trade.trade_code && 
        typeof trade.trade_code === 'string' &&
        trade.trade_code.trim() !== '' &&
        trade.description &&
        typeof trade.description === 'string' &&
        trade.description.trim() !== ''
      );
      
      console.log('Valid trades after filtering:', validTrades.length, 'trades');
      return validTrades;
    },
    enabled: !!projectId,
    staleTime: 0, // Always refetch to ensure fresh data
    gcTime: 0 // Don't cache to avoid stale data issues (replaces cacheTime)
  });
}

export function useCreateTrade(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (tradeData: TradeFormData) => {
      const tradeWithDefaults = {
        ...tradeData,
        project_id: projectId,
        sort_order: 0,
      };
      return tradesService.create(projectId, tradeWithDefaults);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trades', projectId] });
      toast({
        title: 'Success',
        description: 'Trade created successfully'
      });
    },
    onError: (error: any) => {
      console.error('Create trade error:', error);
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  });
}

export function useUpdateTrade(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<TradeFormData> }) => 
      tradesService.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trades', projectId] });
      toast({
        title: 'Success',
        description: 'Trade updated successfully'
      });
    },
    onError: (error: any) => {
      console.error('Update trade error:', error);
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  });
}

export function useDeleteTrade(projectId: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: (id: string) => tradesService.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trades', projectId] });
      toast({
        title: 'Success',
        description: 'Trade deleted successfully'
      });
    },
    onError: (error: any) => {
      console.error('Delete trade error:', error);
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  });
}
