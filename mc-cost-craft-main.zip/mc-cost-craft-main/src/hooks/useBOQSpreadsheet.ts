
import { useState, useCallback } from 'react';
import { BOQItem } from '@/types/mccost';

export interface SpreadsheetState {
  selectedRows: Set<string>;
  editingCell: { rowId: string; field: keyof BOQItem } | null;
  editValue: string;
}

export function useBOQSpreadsheet(items: BOQItem[]) {
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [editingCell, setEditingCell] = useState<{ rowId: string; field: keyof BOQItem } | null>(null);
  const [editValue, setEditValue] = useState('');

  const toggleRowSelection = useCallback((rowId: string, isShiftClick = false) => {
    setSelectedRows(prev => {
      const newSet = new Set(prev);
      
      if (isShiftClick && prev.size > 0) {
        // Handle shift+click for range selection
        const lastSelected = Array.from(prev)[prev.size - 1];
        const currentIndex = items.findIndex(item => item.id === rowId);
        const lastIndex = items.findIndex(item => item.id === lastSelected);
        
        const startIndex = Math.min(currentIndex, lastIndex);
        const endIndex = Math.max(currentIndex, lastIndex);
        
        for (let i = startIndex; i <= endIndex; i++) {
          newSet.add(items[i].id);
        }
      } else {
        if (newSet.has(rowId)) {
          newSet.delete(rowId);
        } else {
          newSet.add(rowId);
        }
      }
      
      return newSet;
    });
  }, [items]);

  const selectAllRows = useCallback(() => {
    setSelectedRows(new Set(items.map(item => item.id)));
  }, [items]);

  const clearSelection = useCallback(() => {
    setSelectedRows(new Set());
  }, []);

  const startEditing = useCallback((rowId: string, field: keyof BOQItem, currentValue: any) => {
    setEditingCell({ rowId, field });
    setEditValue(String(currentValue || ''));
  }, []);

  const cancelEditing = useCallback(() => {
    setEditingCell(null);
    setEditValue('');
  }, []);

  return {
    selectedRows,
    editingCell,
    editValue,
    setEditValue,
    toggleRowSelection,
    selectAllRows,
    clearSelection,
    startEditing,
    cancelEditing
  };
}
