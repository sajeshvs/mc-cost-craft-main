import { useState, useCallback } from 'react';

const DEFAULT_COLUMN_ORDER = [
  'select',
  'expand', 
  'estimate',
  'page_number',
  'item_no',
  'description',
  'unit',
  'quantity',
  'level_type'
];

export function useColumnReorder() {
  const [columnOrder, setColumnOrder] = useState<string[]>(DEFAULT_COLUMN_ORDER);
  const [draggedColumn, setDraggedColumn] = useState<string | null>(null);

  const handleDragStart = useCallback((columnKey: string) => {
    setDraggedColumn(columnKey);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  const handleDrop = useCallback((targetColumnKey: string) => {
    if (!draggedColumn || draggedColumn === targetColumnKey) {
      setDraggedColumn(null);
      return;
    }

    setColumnOrder(prevOrder => {
      const newOrder = [...prevOrder];
      const draggedIndex = newOrder.indexOf(draggedColumn);
      const targetIndex = newOrder.indexOf(targetColumnKey);
      
      if (draggedIndex !== -1 && targetIndex !== -1) {
        // Remove dragged column and insert at target position
        newOrder.splice(draggedIndex, 1);
        const adjustedTargetIndex = draggedIndex < targetIndex ? targetIndex - 1 : targetIndex;
        newOrder.splice(adjustedTargetIndex, 0, draggedColumn);
      }
      
      return newOrder;
    });

    setDraggedColumn(null);
  }, [draggedColumn]);

  const handleDragEnd = useCallback(() => {
    setDraggedColumn(null);
  }, []);

  const getColumnOrder = useCallback(() => columnOrder, [columnOrder]);

  return {
    columnOrder,
    draggedColumn,
    handleDragStart,
    handleDragOver,
    handleDrop,
    handleDragEnd,
    getColumnOrder
  };
}
