
import { useCallback } from 'react';
import { BOQItem } from '@/types/mccost';

interface UseBOQCellHandlersProps {
  filteredItems: BOQItem[];
  updateMutation: any;
}

export function useBOQCellHandlers({
  filteredItems,
  updateMutation
}: UseBOQCellHandlersProps) {
  const handleCellSave = useCallback((itemId: string, field: keyof BOQItem, value: any) => {
    // Handle special page break logic
    if (field === 'page_number' && value === '+') {
      const currentItem = filteredItems.find(item => item.id === itemId);
      if (currentItem) {
        const maxPage = Math.max(...filteredItems.map(item => item.page_number || 0));
        updateMutation.mutate({ id: itemId, page_number: maxPage + 1 });
        return;
      }
    }
    
    updateMutation.mutate({ id: itemId, [field]: value });
  }, [updateMutation, filteredItems]);

  return {
    handleCellSave
  };
}
