
import { useCallback } from 'react';
import { BOQItem } from '@/types/mccost';
import { useToast } from '@/hooks/use-toast';
import { useBOQClipboard } from './useBOQClipboard';

interface UseBOQClipboardHandlersProps {
  jobId: string;
  filteredItems: BOQItem[];
  getSelectedItems: () => BOQItem[];
  createMutation: any;
  reorderMutation: any;
}

export function useBOQClipboardHandlers({
  jobId,
  filteredItems,
  getSelectedItems,
  createMutation,
  reorderMutation
}: UseBOQClipboardHandlersProps) {
  const { toast } = useToast();
  const { copyItems, canPaste, getPasteData } = useBOQClipboard();

  const handleCopy = useCallback(() => {
    const selectedItems = getSelectedItems();
    if (selectedItems.length > 0) {
      copyItems(selectedItems);
    }
  }, [getSelectedItems, copyItems]);

  const handlePaste = useCallback((afterIndex?: number) => {
    const pasteData = getPasteData();
    if (pasteData.length === 0) return;

    const insertIndex = afterIndex !== undefined ? afterIndex + 1 : filteredItems.length;
    
    // Create new items from clipboard data
    pasteData.forEach((item, index) => {
      const newItem = {
        job_id: jobId,
        item_no: `${item.item_no} (Copy)`,
        description: item.description,
        unit: item.unit,
        quantity: item.quantity,
        level_type: item.level_type,
        page_number: item.page_number,
        sort_order: insertIndex + index
      };
      createMutation.mutate(newItem);
    });

    // Reorder existing items to make space
    const itemsToReorder = filteredItems
      .filter((_, i) => i >= insertIndex)
      .map((item, i) => ({
        id: item.id,
        sort_order: insertIndex + pasteData.length + i
      }));

    if (itemsToReorder.length > 0) {
      reorderMutation.mutate(itemsToReorder);
    }

    toast({
      title: 'Success',
      description: `${pasteData.length} row(s) pasted successfully`
    });
  }, [getPasteData, filteredItems, jobId, createMutation, reorderMutation, toast]);

  return {
    handleCopy,
    handlePaste,
    canPaste: canPaste()
  };
}
