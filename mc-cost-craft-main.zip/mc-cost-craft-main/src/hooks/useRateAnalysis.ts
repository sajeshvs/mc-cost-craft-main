
import { useState, useEffect, useCallback, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { priceCodeAnalysisService, PriceCodeAnalysisResource, PriceCodeAnalysisWithVersion } from '@/services/priceCodeAnalysis';
import { priceCodeVersionsService, PriceCodeVersion } from '@/services/priceCodeVersions';
import { resourceLibraryService } from '@/services/resourceLibrary';
import { useToast } from '@/hooks/use-toast';

export interface RateAnalysisState {
  resources: PriceCodeAnalysisResource[];
  currentVersion: PriceCodeVersion | null;
  versions: PriceCodeVersion[];
  availableResources: any[];
  isLoading: boolean;
  isSaving: boolean;
  isDraft: boolean;
  totals: {
    labor: number;
    material: number;
    equipment: number;
    subcontractor: number;
    consultant: number;
    netRate: number;
  };
}

export function useRateAnalysis(projectId: string, priceCode: string) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const [resources, setResources] = useState<PriceCodeAnalysisResource[]>([]);
  const [currentVersion, setCurrentVersion] = useState<PriceCodeVersion | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Load versions
  const { data: versions = [] } = useQuery({
    queryKey: ['price-code-versions', projectId, priceCode],
    queryFn: () => priceCodeVersionsService.getByPriceCode(projectId, priceCode),
    enabled: !!projectId && !!priceCode
  });

  // Load available resources
  const { data: availableResources = [] } = useQuery({
    queryKey: ['resource-library'],
    queryFn: () => resourceLibraryService.getAll()
  });

  // Load current version and resources
  const { data: currentVersionData, isLoading } = useQuery({
    queryKey: ['current-version', projectId, priceCode],
    queryFn: () => priceCodeVersionsService.getCurrentVersion(projectId, priceCode),
    enabled: !!projectId && !!priceCode
  });

  // Load resources for current version
  const { data: resourcesData } = useQuery({
    queryKey: ['rate-analysis-resources', currentVersion?.id],
    queryFn: () => currentVersion ? priceCodeAnalysisService.getByVersion(currentVersion.id) : [],
    enabled: !!currentVersion
  });

  useEffect(() => {
    if (currentVersionData) {
      setCurrentVersion(currentVersionData);
    }
  }, [currentVersionData]);

  useEffect(() => {
    if (resourcesData) {
      setResources(resourcesData);
    }
  }, [resourcesData]);

  // Calculate totals
  const totals = useMemo(() => {
    const calculatedTotals = {
      labor: 0,
      material: 0,
      equipment: 0,
      subcontractor: 0,
      consultant: 0,
      netRate: 0
    };

    resources.forEach(resource => {
      let total = resource.quantity * resource.unit_rate;
      
      // Apply wastage for materials only
      if (resource.category === 'M' && resource.wastage_percent > 0) {
        total *= (1 + resource.wastage_percent / 100);
      }
      
      switch (resource.category) {
        case 'P':
          calculatedTotals.labor += total;
          break;
        case 'M':
          calculatedTotals.material += total;
          break;
        case 'E':
          calculatedTotals.equipment += total;
          break;
        case 'S':
          calculatedTotals.subcontractor += total;
          break;
        case 'C':
          calculatedTotals.consultant += total;
          break;
      }
    });

    calculatedTotals.netRate = Object.values(calculatedTotals).reduce((sum, val) => sum + val, 0) - calculatedTotals.netRate;

    return calculatedTotals;
  }, [resources]);

  // Create new version
  const createVersionMutation = useMutation({
    mutationFn: (data: { change_summary?: string }) => 
      priceCodeVersionsService.createVersion({
        price_code: priceCode,
        project_id: projectId,
        status: 'draft',
        change_summary: data.change_summary,
        created_by: '', // Will be set by the service
      }),
    onSuccess: (newVersion) => {
      setCurrentVersion(newVersion);
      queryClient.invalidateQueries({ queryKey: ['price-code-versions', projectId, priceCode] });
      toast({
        title: 'Success',
        description: 'New version created successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create version',
        variant: 'destructive'
      });
    }
  });

  // Update resource
  const updateResourceMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<PriceCodeAnalysisResource> }) =>
      priceCodeAnalysisService.update(id, updates),
    onSuccess: (updatedResource) => {
      setResources(prev => prev.map(r => r.id === updatedResource.id ? updatedResource : r));
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update resource',
        variant: 'destructive'
      });
    }
  });

  // Add resource
  const addResourceMutation = useMutation({
    mutationFn: (resourceData: Omit<PriceCodeAnalysisResource, 'id' | 'created_at' | 'updated_at'>) =>
      priceCodeAnalysisService.create(resourceData),
    onSuccess: (newResource) => {
      setResources(prev => [...prev, newResource]);
      toast({
        title: 'Success',
        description: 'Resource added successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to add resource',
        variant: 'destructive'
      });
    }
  });

  // Delete resource
  const deleteResourceMutation = useMutation({
    mutationFn: (id: string) => priceCodeAnalysisService.delete(id),
    onSuccess: (_, deletedId) => {
      setResources(prev => prev.filter(r => r.id !== deletedId));
      toast({
        title: 'Success',
        description: 'Resource deleted successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete resource',
        variant: 'destructive'
      });
    }
  });

  // Submit for approval
  const submitMutation = useMutation({
    mutationFn: (changeSummary?: string) => 
      priceCodeVersionsService.submitForApproval(currentVersion!.id, changeSummary),
    onSuccess: (updatedVersion) => {
      setCurrentVersion(updatedVersion);
      queryClient.invalidateQueries({ queryKey: ['price-code-versions', projectId, priceCode] });
      toast({
        title: 'Success',
        description: 'Rate analysis submitted for approval'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to submit for approval',
        variant: 'destructive'
      });
    }
  });

  // Approve version
  const approveMutation = useMutation({
    mutationFn: () => priceCodeVersionsService.approve(currentVersion!.id, ''), // User ID will be set by service
    onSuccess: (updatedVersion) => {
      setCurrentVersion(updatedVersion);
      queryClient.invalidateQueries({ queryKey: ['price-code-versions', projectId, priceCode] });
      toast({
        title: 'Success',
        description: 'Rate analysis approved successfully'
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to approve version',
        variant: 'destructive'
      });
    }
  });

  const addResource = useCallback(async (resourceData: Omit<PriceCodeAnalysisResource, 'id' | 'created_at' | 'updated_at'>) => {
    if (!currentVersion) {
      // Create new version first
      createVersionMutation.mutate({});
      return;
    }
    
    addResourceMutation.mutate({
      ...resourceData,
      version_id: currentVersion.id,
      sort_order: resources.length
    });
  }, [currentVersion, resources.length, addResourceMutation, createVersionMutation]);

  const updateResource = useCallback(async (id: string, updates: Partial<PriceCodeAnalysisResource>) => {
    updateResourceMutation.mutate({ id, updates });
  }, [updateResourceMutation]);

  const deleteResource = useCallback(async (id: string) => {
    deleteResourceMutation.mutate(id);
  }, [deleteResourceMutation]);

  const submitForApproval = useCallback(async (changeSummary?: string) => {
    if (!currentVersion) return;
    submitMutation.mutate(changeSummary);
  }, [currentVersion, submitMutation]);

  const approve = useCallback(async () => {
    if (!currentVersion) return;
    approveMutation.mutate();
  }, [currentVersion, approveMutation]);

  const createNewVersion = useCallback(async (changeSummary?: string) => {
    createVersionMutation.mutate({ change_summary: changeSummary });
  }, [createVersionMutation]);

  return {
    resources,
    currentVersion,
    versions,
    availableResources,
    isLoading,
    isSaving,
    isDraft: currentVersion?.status === 'draft',
    totals,
    addResource,
    updateResource,
    deleteResource,
    submitForApproval,
    approve,
    createNewVersion
  };
}
