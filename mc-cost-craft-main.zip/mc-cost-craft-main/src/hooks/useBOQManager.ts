
import { useState, useCallback, useMemo } from 'react';
import { BOQItem } from '@/types/mccost';
import { useSupabaseQuery } from '@/hooks/useSupabaseQuery';
import { boqItemsService } from '@/services/boqItems';
import { useBOQSpreadsheet } from '@/hooks/useBOQSpreadsheet';

export function useBOQManager(jobId: string) {
  // Data fetching
  const { data: boqItems = [], isLoading, error } = useSupabaseQuery(
    ['boq_items', jobId],
    () => boqItemsService.getByJob(jobId),
    { enabled: !!jobId }
  );

  // Spreadsheet functionality
  const spreadsheet = useBOQSpreadsheet(boqItems);

  // Additional state for BOQ management
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());
  const [selectedCells, setSelectedCells] = useState<Set<string>>(new Set());
  const [clipboard, setClipboard] = useState<{ items: BOQItem[] }>({ items: [] });
  const [editingCell, setEditingCell] = useState<{ rowId: string; field: keyof BOQItem } | null>(null);
  
  // Dialog states
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showInsertDialog, setShowInsertDialog] = useState(false);
  const [showMultiplyDialog, setShowMultiplyDialog] = useState(false);
  const [showQuantityDialog, setShowQuantityDialog] = useState(false);
  const [showTextDialog, setShowTextDialog] = useState(false);
  const [insertPosition, setInsertPosition] = useState<'above' | 'below' | 'beginning' | 'end'>('end');

  // Clear editing cell
  const clearEditingCell = useCallback(() => {
    setEditingCell(null);
  }, []);

  // Clear selection
  const clearSelection = useCallback(() => {
    spreadsheet.clearSelection();
  }, [spreadsheet]);

  // Handlers - placeholder implementations
  const handleInsertRow = useCallback(() => {
    console.log('Insert row');
  }, []);

  const handleDeleteSelected = useCallback(() => {
    console.log('Delete selected rows');
  }, []);

  const handleCopy = useCallback(() => {
    const selectedItems = boqItems.filter(item => spreadsheet.selectedRows.has(item.id));
    setClipboard({ items: selectedItems });
  }, [boqItems, spreadsheet.selectedRows]);

  const handlePaste = useCallback(() => {
    console.log('Paste items');
  }, []);

  const handleImport = useCallback(() => {
    setShowImportDialog(true);
  }, []);

  const handleExport = useCallback(() => {
    console.log('Export BOQ');
  }, []);

  const handleMultiply = useCallback(() => {
    setShowMultiplyDialog(true);
  }, []);

  const handleQuantityDialog = useCallback(() => {
    setShowQuantityDialog(true);
  }, []);

  const handleTextDialog = useCallback(() => {
    setShowTextDialog(true);
  }, []);

  const handleRefresh = useCallback(() => {
    console.log('Refresh BOQ');
  }, []);

  const handleRowSelect = useCallback((rowId: string, isShiftClick?: boolean, isCtrlClick?: boolean) => {
    spreadsheet.toggleRowSelection(rowId, isShiftClick);
  }, [spreadsheet]);

  const handleCellSelect = useCallback((cellId: string) => {
    setSelectedCells(prev => {
      const newSet = new Set(prev);
      if (newSet.has(cellId)) {
        newSet.delete(cellId);
      } else {
        newSet.add(cellId);
      }
      return newSet;
    });
  }, []);

  const handleCellEdit = useCallback((rowId: string, field: keyof BOQItem, value: any) => {
    console.log('Cell edit:', rowId, field, value);
  }, []);

  const handleItemUpdate = useCallback((itemId: string, field: keyof BOQItem, value: any) => {
    console.log('Item update:', itemId, field, value);
  }, []);

  const handleExpandToggle = useCallback((itemId: string) => {
    setExpandedItems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(itemId)) {
        newSet.delete(itemId);
      } else {
        newSet.add(itemId);
      }
      return newSet;
    });
  }, []);

  return {
    // Data
    boqItems,
    isLoading,
    error,
    
    // Spreadsheet state
    ...spreadsheet,
    selectedCells,
    expandedItems,
    setExpandedItems,
    clipboard,
    editingCell,
    setEditingCell,
    clearEditingCell,
    clearSelection,
    
    // Dialog states
    showImportDialog,
    setShowImportDialog,
    showInsertDialog,
    setShowInsertDialog,
    showMultiplyDialog,
    setShowMultiplyDialog,
    showQuantityDialog,
    setShowQuantityDialog,
    showTextDialog,
    setShowTextDialog,
    insertPosition,
    setInsertPosition,
    
    // Handlers
    handleInsertRow,
    handleDeleteSelected,
    handleCopy,
    handlePaste,
    handleImport,
    handleExport,
    handleMultiply,
    handleQuantityDialog,
    handleTextDialog,
    handleRefresh,
    handleRowSelect,
    handleCellSelect,
    handleCellEdit,
    handleItemUpdate,
    handleExpandToggle
  };
}
