
import { useCallback } from 'react';
import { BOQItem } from '@/types/mccost';

export function useKeyboardNavigation(
  items: BOQItem[],
  editingCell: { rowId: string; field: keyof BOQItem } | null,
  onStartEditing: (rowId: string, field: keyof BOQItem, currentValue: any) => void,
  onCancelEditing: () => void
) {
  const handleKeyDown = useCallback((e: React.KeyboardEvent, rowIndex: number, field: keyof BOQItem) => {
    const currentItem = items[rowIndex];
    const fields: (keyof BOQItem)[] = ['level_type', 'page_number', 'item_no', 'description', 'unit', 'quantity'];
    const currentFieldIndex = fields.indexOf(field);

    // If editing, handle editing-specific keys
    if (editingCell?.rowId === currentItem.id && editingCell?.field === field) {
      switch (e.key) {
        case 'Escape':
          e.preventDefault();
          onCancelEditing();
          break;
        case 'Enter':
          e.preventDefault();
          if (rowIndex < items.length - 1) {
            const nextItem = items[rowIndex + 1];
            onStartEditing(nextItem.id, field, nextItem[field]);
          } else {
            onCancelEditing();
          }
          break;
        case 'Tab':
          e.preventDefault();
          const nextFieldIndex = e.shiftKey 
            ? (currentFieldIndex - 1 + fields.length) % fields.length
            : (currentFieldIndex + 1) % fields.length;
          const nextField = fields[nextFieldIndex];
          
          if ((nextFieldIndex === 0 && !e.shiftKey) || (nextFieldIndex === fields.length - 1 && e.shiftKey)) {
            const nextRowIndex = e.shiftKey ? rowIndex - 1 : rowIndex + 1;
            if (nextRowIndex >= 0 && nextRowIndex < items.length) {
              const nextItem = items[nextRowIndex];
              onStartEditing(nextItem.id, nextField, nextItem[nextField]);
            } else {
              onCancelEditing();
            }
          } else {
            onStartEditing(currentItem.id, nextField, currentItem[nextField]);
          }
          break;
        case 'ArrowUp':
          e.preventDefault();
          if (rowIndex > 0) {
            const prevItem = items[rowIndex - 1];
            onStartEditing(prevItem.id, field, prevItem[field]);
          }
          break;
        case 'ArrowDown':
          e.preventDefault();
          if (rowIndex < items.length - 1) {
            const nextItem = items[rowIndex + 1];
            onStartEditing(nextItem.id, field, nextItem[field]);
          }
          break;
        case 'ArrowLeft':
          e.preventDefault();
          if (currentFieldIndex > 0) {
            const leftField = fields[currentFieldIndex - 1];
            onStartEditing(currentItem.id, leftField, currentItem[leftField]);
          }
          break;
        case 'ArrowRight':
          e.preventDefault();
          if (currentFieldIndex < fields.length - 1) {
            const rightField = fields[currentFieldIndex + 1];
            onStartEditing(currentItem.id, rightField, currentItem[rightField]);
          }
          break;
      }
      return;
    }

    // Navigation when not editing
    switch (e.key) {
      case 'Enter':
      case 'F2':
      case ' ':
        e.preventDefault();
        // Don't allow editing disabled fields
        const isComment = currentItem.level_type === 'comment';
        const isPricingField = field === 'unit' || field === 'quantity';
        if (!(isComment && isPricingField)) {
          onStartEditing(currentItem.id, field, currentItem[field]);
        }
        break;
      case 'Escape':
        e.preventDefault();
        (e.target as HTMLElement).blur();
        break;
      case 'Tab':
        e.preventDefault();
        const nextFieldIdx = e.shiftKey 
          ? (currentFieldIndex - 1 + fields.length) % fields.length
          : (currentFieldIndex + 1) % fields.length;
        const nextFld = fields[nextFieldIdx];
        
        if ((nextFieldIdx === 0 && !e.shiftKey) || (nextFieldIdx === fields.length - 1 && e.shiftKey)) {
          const nextRowIdx = e.shiftKey ? rowIndex - 1 : rowIndex + 1;
          if (nextRowIdx >= 0 && nextRowIdx < items.length) {
            const nextItm = items[nextRowIdx];
            const nextIsComment = nextItm.level_type === 'comment';
            const nextIsPricing = nextFld === 'unit' || nextFld === 'quantity';
            if (!(nextIsComment && nextIsPricing)) {
              onStartEditing(nextItm.id, nextFld, nextItm[nextFld]);
            }
          }
        } else {
          const currIsComment = currentItem.level_type === 'comment';
          const currIsPricing = nextFld === 'unit' || nextFld === 'quantity';
          if (!(currIsComment && currIsPricing)) {
            onStartEditing(currentItem.id, nextFld, currentItem[nextFld]);
          }
        }
        break;
      case 'ArrowUp':
        e.preventDefault();
        if (rowIndex > 0) {
          const prevItem = items[rowIndex - 1];
          const prevIsComment = prevItem.level_type === 'comment';
          const prevIsPricing = field === 'unit' || field === 'quantity';
          if (!(prevIsComment && prevIsPricing)) {
            onStartEditing(prevItem.id, field, prevItem[field]);
          }
        }
        break;
      case 'ArrowDown':
        e.preventDefault();
        if (rowIndex < items.length - 1) {
          const nextItem = items[rowIndex + 1];
          const nextIsComment = nextItem.level_type === 'comment';
          const nextIsPricing = field === 'unit' || field === 'quantity';
          if (!(nextIsComment && nextIsPricing)) {
            onStartEditing(nextItem.id, field, nextItem[field]);
          }
        }
        break;
      case 'ArrowLeft':
        e.preventDefault();
        if (currentFieldIndex > 0) {
          const leftField = fields[currentFieldIndex - 1];
          const currIsComment = currentItem.level_type === 'comment';
          const currIsPricing = leftField === 'unit' || leftField === 'quantity';
          if (!(currIsComment && currIsPricing)) {
            onStartEditing(currentItem.id, leftField, currentItem[leftField]);
          }
        }
        break;
      case 'ArrowRight':
        e.preventDefault();
        if (currentFieldIndex < fields.length - 1) {
          const rightField = fields[currentFieldIndex + 1];
          const currIsComment = currentItem.level_type === 'comment';
          const currIsPricing = rightField === 'unit' || rightField === 'quantity';
          if (!(currIsComment && currIsPricing)) {
            onStartEditing(currentItem.id, rightField, currentItem[rightField]);
          }
        }
        break;
    }
  }, [editingCell, items, onStartEditing, onCancelEditing]);

  return { handleKeyDown };
}
