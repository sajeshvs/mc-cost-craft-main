
import { useState, useRef } from 'react';
import { useTrades } from '@/hooks/useTrades';
import { Trade } from '@/types/trades';

interface CellPosition {
  tradeId: string;
  field: string;
}

export function useTradesSpreadsheetState(projectId: string) {
  const [isMinimized, setIsMinimized] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [selectedCells, setSelectedCells] = useState<Set<string>>(new Set());
  const [editingCell, setEditingCell] = useState<{ id: string; field: string } | null>(null);
  const [expandedDivisions, setExpandedDivisions] = useState<Set<string>>(new Set(['01', '02', '03']));
  const [position, setPosition] = useState({ x: 100, y: 100 });
  const [isDragging, setIsDragging] = useState(false);
  const [focusedCell, setFocusedCell] = useState<CellPosition | null>(null);
  const [isRangeSelecting, setIsRangeSelecting] = useState(false);
  const [rangeStart, setRangeStart] = useState<CellPosition | null>(null);
  const [columnWidths, setColumnWidths] = useState<Record<string, number>>({});
  const [isColumnResizing, setIsColumnResizing] = useState(false);
  const dragRef = useRef<HTMLDivElement>(null);
  const tableRef = useRef<HTMLTableElement>(null);

  // Use the trades hook to get actual data
  const { data: trades = [], isLoading } = useTrades(projectId);

  const getCellKey = (tradeId: string, field: string) => `${tradeId}-${field}`;

  const handleToggleDivision = (division: string) => {
    setExpandedDivisions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(division)) {
        newSet.delete(division);
      } else {
        newSet.add(division);
      }
      return newSet;
    });
  };

  const handleRowSelection = (tradeId: string, isCtrl: boolean, isShift: boolean) => {
    if (isCtrl) {
      setSelectedRows(prev => {
        const newSet = new Set(prev);
        if (newSet.has(tradeId)) {
          newSet.delete(tradeId);
        } else {
          newSet.add(tradeId);
        }
        return newSet;
      });
    } else if (isShift) {
      setSelectedRows(prev => new Set([...prev, tradeId]));
    } else {
      setSelectedRows(new Set([tradeId]));
    }
  };

  const handleAddTrade = (division: string) => {
    // TODO: Implement add trade functionality
    console.log('Add trade for division:', division);
  };

  const handleDeleteTrades = (tradeIds: string[]) => {
    // TODO: Implement delete trades functionality
    console.log('Delete trades:', tradeIds);
  };

  const handleUpdateTrade = (tradeId: string, updates: Partial<Trade>) => {
    // TODO: Implement update trade functionality
    console.log('Update trade:', tradeId, updates);
  };

  const handleRowSelect = (tradeId: string) => {
    setSelectedRows(new Set([tradeId]));
  };

  const handleCellMouseDown = (tradeId: string, field: string) => {
    setFocusedCell({ tradeId, field });
  };

  const handleCellDoubleClick = (tradeId: string, field: string) => {
    setEditingCell({ id: tradeId, field });
  };

  const handleCellEditComplete = (tradeId: string, field: string, value: string) => {
    setEditingCell(null);
    handleUpdateTrade(tradeId, { [field]: value });
  };

  const handleCellEditCancel = () => {
    setEditingCell(null);
  };

  const handleColumnMouseDown = (field: string) => {
    setIsColumnResizing(true);
  };

  const handleColumnDoubleClick = (field: string) => {
    // Auto-size column
    setColumnWidths(prev => ({ ...prev, [field]: 100 }));
  };

  const handleExpandAll = () => {
    const allDivisions = new Set(['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20']);
    setExpandedDivisions(allDivisions);
  };

  const handleCollapseAll = () => {
    setExpandedDivisions(new Set());
  };

  const handleImportCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
    // TODO: Implement CSV import
    console.log('Import CSV');
  };

  const handleExportCSV = () => {
    // TODO: Implement CSV export
    console.log('Export CSV');
  };

  return {
    // Basic state
    isMinimized,
    setIsMinimized,
    isMaximized,
    setIsMaximized,
    selectedRows,
    setSelectedRows,
    selectedCells,
    setSelectedCells,
    editingCell,
    setEditingCell,
    expandedDivisions,
    setExpandedDivisions,
    position,
    setPosition,
    isDragging,
    setIsDragging,
    focusedCell,
    setFocusedCell,
    isRangeSelecting,
    setIsRangeSelecting,
    rangeStart,
    setRangeStart,
    columnWidths,
    setColumnWidths,
    isColumnResizing,
    setIsColumnResizing,
    dragRef,
    tableRef,
    
    // Data
    trades,
    isLoading,
    
    // Handlers
    getCellKey,
    handleToggleDivision,
    handleRowSelection,
    handleAddTrade,
    handleDeleteTrades,
    handleUpdateTrade,
    handleRowSelect,
    handleCellMouseDown,
    handleCellDoubleClick,
    handleCellEditComplete,
    handleCellEditCancel,
    handleColumnMouseDown,
    handleColumnDoubleClick,
    handleExpandAll,
    handleCollapseAll,
    handleImportCSV,
    handleExportCSV,
    
    // Legacy compatibility
    toggleDivision: handleToggleDivision
  };
}
