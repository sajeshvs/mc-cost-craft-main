
import { useCallback } from 'react';
import { BOQItem } from '@/types/mccost';
import { useToast } from '@/hooks/use-toast';

interface UseBOQCalculationHandlersProps {
  filteredItems: BOQItem[];
  getSelectedItems: () => BOQItem[];
  updateMutation: any;
}

export function useBOQCalculationHandlers({
  filteredItems,
  getSelectedItems,
  updateMutation
}: UseBOQCalculationHandlersProps) {
  const { toast } = useToast();

  const handleCalculateTotals = useCallback(() => {
    const total = filteredItems.reduce((sum, item) => {
      if (item.level_type === 'item' && typeof item.quantity === 'number') {
        return sum + item.quantity;
      }
      return sum;
    }, 0);
    
    toast({
      title: 'Total Calculation',
      description: `Total quantity: ${total.toLocaleString()}`
    });
  }, [filteredItems, toast]);

  const handleClear = useCallback(() => {
    const selectedItems = getSelectedItems();
    selectedItems.forEach(item => {
      updateMutation.mutate({
        id: item.id,
        item_no: '',
        description: '',
        unit: 'No',
        quantity: 0
      });
    });

    toast({
      title: 'Success',
      description: `${selectedItems.length} row(s) cleared`
    });
  }, [getSelectedItems, updateMutation, toast]);

  const handleSetQuantity = useCallback((quantity: number) => {
    const selectedItems = getSelectedItems();
    selectedItems.forEach(item => {
      if (item.level_type !== 'comment') {
        updateMutation.mutate({
          id: item.id,
          quantity: quantity
        });
      }
    });
  }, [getSelectedItems, updateMutation]);

  const handleMultiplyQuantity = useCallback((factor: number) => {
    const selectedItems = getSelectedItems();
    selectedItems.forEach(item => {
      if (item.level_type !== 'comment' && typeof item.quantity === 'number') {
        updateMutation.mutate({
          id: item.id,
          quantity: item.quantity * factor
        });
      }
    });
  }, [getSelectedItems, updateMutation]);

  const handleShowSum = useCallback(() => {
    const selectedItems = getSelectedItems();
    const total = selectedItems
      .filter(item => item.level_type !== 'comment')
      .reduce((sum, item) => sum + (item.quantity || 0), 0);
    
    toast({
      title: 'Sum of Selected Rows',
      description: `Total quantity: ${total.toLocaleString()} (${selectedItems.length} rows)`
    });
  }, [getSelectedItems, toast]);

  const handleEnterText = useCallback((text: string) => {
    const selectedItems = getSelectedItems();
    selectedItems.forEach(item => {
      updateMutation.mutate({
        id: item.id,
        description: text
      });
    });
  }, [getSelectedItems, updateMutation]);

  return {
    handleCalculateTotals,
    handleClear,
    handleSetQuantity,
    handleMultiplyQuantity,
    handleShowSum,
    handleEnterText
  };
}
