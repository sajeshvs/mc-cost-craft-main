
import { useEffect } from 'react';
import { Trade } from '@/types/trades';

interface CellPosition {
  tradeId: string;
  field: string;
}

interface UseTradesSpreadsheetKeyboardProps {
  trades: Trade[];
  selectedRows: Set<string>;
  focusedCell: CellPosition | null;
  selectedCells: Set<string>;
  editingCell: { id: string; field: string } | null;
  onCellEditComplete: (tradeId: string, field: string, value: string) => void;
  onCellEditCancel: () => void;
  onDeleteSelected: () => void;
  onRowSelect: (tradeId: string) => void;
  onCellMouseDown: (tradeId: string, field: string) => void;
  getCellKey: (tradeId: string, field: string) => string;
}

export function useTradesSpreadsheetKeyboard({
  trades,
  selectedRows,
  focusedCell,
  selectedCells,
  editingCell,
  onCellEditComplete,
  onCellEditCancel,
  onDeleteSelected,
  onRowSelect,
  onCellMouseDown,
  getCellKey
}: UseTradesSpreadsheetKeyboardProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // If we're editing a cell, don't handle navigation keys
      if (editingCell) {
        if (e.key === 'Enter') {
          e.preventDefault();
          onCellEditComplete(editingCell.id, editingCell.field, '');
        } else if (e.key === 'Escape') {
          e.preventDefault();
          onCellEditCancel();
        }
        return;
      }

      const fields = ['trade_code', 'description', 'color_code'];

      switch (e.key) {
        case 'Escape':
          e.preventDefault();
          // Clear selections
          break;

        case 'Delete':
          e.preventDefault();
          if (selectedRows.size > 0) {
            onDeleteSelected();
          }
          break;

        case 'Enter':
          e.preventDefault();
          if (focusedCell) {
            // Start editing the focused cell
            onCellEditComplete(focusedCell.tradeId, focusedCell.field, '');
          }
          break;

        case 'ArrowUp':
        case 'ArrowDown':
        case 'ArrowLeft':
        case 'ArrowRight':
          e.preventDefault();
          if (!focusedCell) return;

          const currentTradeIndex = trades.findIndex(t => t.id === focusedCell.tradeId);
          const currentFieldIndex = fields.indexOf(focusedCell.field);

          let newTradeIndex = currentTradeIndex;
          let newFieldIndex = currentFieldIndex;

          switch (e.key) {
            case 'ArrowUp':
              newTradeIndex = Math.max(0, currentTradeIndex - 1);
              break;
            case 'ArrowDown':
              newTradeIndex = Math.min(trades.length - 1, currentTradeIndex + 1);
              break;
            case 'ArrowLeft':
              newFieldIndex = Math.max(0, currentFieldIndex - 1);
              break;
            case 'ArrowRight':
              newFieldIndex = Math.min(fields.length - 1, currentFieldIndex + 1);
              break;
          }

          const newTrade = trades[newTradeIndex];
          if (newTrade) {
            onCellMouseDown(newTrade.id, fields[newFieldIndex]);
          }
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [trades, selectedRows, focusedCell, selectedCells, editingCell, onCellEditComplete, onCellEditCancel, onDeleteSelected, onRowSelect, onCellMouseDown, getCellKey]);
}
