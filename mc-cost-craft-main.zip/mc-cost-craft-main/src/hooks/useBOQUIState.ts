
import { useState } from 'react';
import { BOQItem } from '@/types/mccost';

export function useBOQUIState() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [lastSelectedItem, setLastSelectedItem] = useState<string | null>(null);
  const [editingCell, setEditingCell] = useState<{ rowId: string; field: keyof BOQItem } | null>(null);
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; rowId: string } | null>(null);
  const [showInsertDialog, setShowInsertDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);

  return {
    searchTerm,
    setSearchTerm,
    selectedItems,
    lastSelectedItem,
    editingCell,
    contextMenu,
    showInsertDialog,
    showImportDialog,
    setSelectedItems,
    setLastSelectedItem,
    setEditingCell,
    setContextMenu,
    setShowInsertDialog,
    setShowImportDialog
  };
}
