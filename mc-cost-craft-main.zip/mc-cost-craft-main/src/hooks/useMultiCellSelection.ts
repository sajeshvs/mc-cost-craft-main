
import { useState, useCallback, useRef } from 'react';
import { BOQItem } from '@/types/mccost';

interface CellPosition {
  rowIndex: number;
  columnKey: string;
}

interface CellRange {
  start: CellPosition;
  end: CellPosition;
}

export function useMultiCellSelection(items: BOQItem[]) {
  const [selectedCells, setSelectedCells] = useState<Set<string>>(new Set());
  const [selectionRange, setSelectionRange] = useState<CellRange | null>(null);
  const [isSelecting, setIsSelecting] = useState(false);
  const selectionStartRef = useRef<CellPosition | null>(null);

  const getCellKey = (rowIndex: number, columnKey: string) => `${rowIndex}-${columnKey}`;

  const startSelection = useCallback((rowIndex: number, columnKey: string) => {
    const startPos = { rowIndex, columnKey };
    selectionStartRef.current = startPos;
    setIsSelecting(true);
    setSelectionRange({ start: startPos, end: startPos });
    setSelectedCells(new Set([getCellKey(rowIndex, columnKey)]));
  }, []);

  const updateSelection = useCallback((rowIndex: number, columnKey: string) => {
    if (!isSelecting || !selectionStartRef.current) return;

    const endPos = { rowIndex, columnKey };
    const startPos = selectionStartRef.current;
    
    const newRange = { start: startPos, end: endPos };
    setSelectionRange(newRange);

    // Calculate all cells in the range
    const minRow = Math.min(startPos.rowIndex, endPos.rowIndex);
    const maxRow = Math.max(startPos.rowIndex, endPos.rowIndex);
    
    // Get column order and find start/end column indices
    const columns = ['level_type', 'page_number', 'item_no', 'description', 'unit', 'quantity'];
    const startColIndex = columns.indexOf(startPos.columnKey);
    const endColIndex = columns.indexOf(endPos.columnKey);
    const minCol = Math.min(startColIndex, endColIndex);
    const maxCol = Math.max(startColIndex, endColIndex);

    const newSelectedCells = new Set<string>();
    for (let row = minRow; row <= maxRow; row++) {
      for (let col = minCol; col <= maxCol; col++) {
        if (col >= 0 && col < columns.length) {
          newSelectedCells.add(getCellKey(row, columns[col]));
        }
      }
    }
    
    setSelectedCells(newSelectedCells);
  }, [isSelecting]);

  const endSelection = useCallback(() => {
    setIsSelecting(false);
    selectionStartRef.current = null;
  }, []);

  const clearSelection = useCallback(() => {
    setSelectedCells(new Set());
    setSelectionRange(null);
    setIsSelecting(false);
    selectionStartRef.current = null;
  }, []);

  const isCellSelected = useCallback((rowIndex: number, columnKey: string) => {
    return selectedCells.has(getCellKey(rowIndex, columnKey));
  }, [selectedCells]);

  const getSelectedCellsData = useCallback(() => {
    const result: Array<{ item: BOQItem; field: keyof BOQItem; value: any }> = [];
    
    selectedCells.forEach(cellKey => {
      const [rowIndexStr, columnKey] = cellKey.split('-');
      const rowIndex = parseInt(rowIndexStr);
      const item = items[rowIndex];
      
      if (item && columnKey in item) {
        result.push({
          item,
          field: columnKey as keyof BOQItem,
          value: item[columnKey as keyof BOQItem]
        });
      }
    });
    
    return result;
  }, [selectedCells, items]);

  return {
    selectedCells,
    selectionRange,
    isSelecting,
    startSelection,
    updateSelection,
    endSelection,
    clearSelection,
    isCellSelected,
    getSelectedCellsData
  };
}
