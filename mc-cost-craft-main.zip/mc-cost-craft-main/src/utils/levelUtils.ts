
export const getLevelNumber = (levelType: string): number => {
  if (levelType.startsWith('level_')) {
    return parseInt(levelType.split('_')[1]) || 0;
  }
  return 0;
};

export const getLevelStyles = (levelType: string) => {
  const level = getLevelNumber(levelType);
  
  switch (level) {
    case 1:
      return 'bg-blue-100 font-bold text-blue-900 text-lg border-l-4 border-l-blue-500';
    case 2:
      return 'bg-blue-50 font-semibold text-blue-800 border-l-4 border-l-blue-300';
    case 3:
    case 4:
    case 5:
      return 'bg-gray-50 text-gray-700 border-l-2 border-l-gray-300';
    default:
      if (levelType === 'comment') {
        return 'bg-yellow-50 italic text-gray-600 border-l-2 border-l-yellow-400';
      }
      return 'bg-white hover:bg-gray-50';
  }
};

export const getRowHeight = (levelType: string) => {
  const level = getLevelNumber(levelType);
  return level === 1 ? 'h-12' : level === 2 ? 'h-10' : 'h-8';
};
